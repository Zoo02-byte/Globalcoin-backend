package org.intellij.lang.annotations;
/* loaded from: Coinglobal1.jar:org/intellij/lang/annotations/PrintFormat.class */
public @interface PrintFormat {
}
