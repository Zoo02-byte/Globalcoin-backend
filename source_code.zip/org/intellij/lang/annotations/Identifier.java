package org.intellij.lang.annotations;
/* loaded from: Coinglobal1.jar:org/intellij/lang/annotations/Identifier.class */
public @interface Identifier {
}
