package org.intellij.lang.annotations;
/* loaded from: Coinglobal1.jar:org/intellij/lang/annotations/Subst.class */
public @interface Subst {
    String value();
}
