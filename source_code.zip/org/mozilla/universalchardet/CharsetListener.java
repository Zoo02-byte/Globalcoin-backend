package org.mozilla.universalchardet;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/CharsetListener.class */
public interface CharsetListener {
    void report(String str);
}
