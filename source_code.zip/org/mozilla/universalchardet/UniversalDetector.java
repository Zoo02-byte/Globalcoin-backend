package org.mozilla.universalchardet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.EscCharsetProber;
import org.mozilla.universalchardet.prober.MBCSGroupProber;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/UniversalDetector.class */
public class UniversalDetector {
    public static final float MINIMUM_THRESHOLD = 0.2f;
    public static final float SHORTCUT_THRESHOLD = 0.95f;
    private String detectedCharset;
    private boolean done;
    private CharsetProber escCharsetProber;
    private boolean gotData;
    private InputState inputState;
    private byte lastChar;
    private CharsetListener listener;
    private CharsetProber[] probers;
    private boolean start;

    /* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/UniversalDetector$InputState.class */
    public enum InputState {
        PURE_ASCII,
        ESC_ASCII,
        HIGHBYTE
    }

    public UniversalDetector() {
        this(null);
    }

    public UniversalDetector(CharsetListener charsetListener) {
        this.listener = charsetListener;
        this.escCharsetProber = null;
        this.probers = new CharsetProber[1];
        reset();
    }

    public static String detectCharset(File file) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            byte[] bArr = new byte[4096];
            UniversalDetector universalDetector = new UniversalDetector(null);
            while (true) {
                int read = fileInputStream.read(bArr);
                if (read <= 0 || universalDetector.isDone()) {
                    break;
                }
                universalDetector.handleData(bArr, 0, read);
            }
            universalDetector.dataEnd();
            String detectedCharset = universalDetector.getDetectedCharset();
            universalDetector.reset();
            fileInputStream.close();
            return detectedCharset;
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public void dataEnd() {
        CharsetProber[] charsetProberArr;
        if (this.gotData) {
            String str = this.detectedCharset;
            if (str != null) {
                this.done = true;
                CharsetListener charsetListener = this.listener;
                if (charsetListener != null) {
                    charsetListener.report(str);
                }
            } else if (this.inputState == InputState.HIGHBYTE) {
                int i2 = 0;
                float f2 = 0.0f;
                int i3 = 0;
                while (true) {
                    charsetProberArr = this.probers;
                    if (i2 >= charsetProberArr.length) {
                        break;
                    }
                    float confidence = charsetProberArr[i2].getConfidence();
                    f2 = f2;
                    if (confidence > f2) {
                        i3 = i2;
                        f2 = confidence;
                    }
                    i2++;
                }
                if (f2 > 0.2f) {
                    String charSetName = charsetProberArr[i3].getCharSetName();
                    this.detectedCharset = charSetName;
                    CharsetListener charsetListener2 = this.listener;
                    if (charsetListener2 != null) {
                        charsetListener2.report(charSetName);
                    }
                }
            }
        }
    }

    public String getDetectedCharset() {
        return this.detectedCharset;
    }

    public CharsetListener getListener() {
        return this.listener;
    }

    public void handleData(byte[] bArr) {
        handleData(bArr, 0, bArr.length);
    }

    public void handleData(byte[] bArr, int i2, int i3) {
        if (!this.done) {
            if (i3 > 0) {
                this.gotData = true;
            }
            int i4 = 0;
            if (this.start) {
                this.start = false;
                if (i3 > 3) {
                    int i5 = bArr[i2] & 255;
                    int i6 = bArr[i2 + 1] & 255;
                    int i7 = bArr[i2 + 2] & 255;
                    int i8 = bArr[i2 + 3] & 255;
                    if (i5 != 0) {
                        if (i5 != 239) {
                            if (i5 != 254) {
                                if (i5 == 255) {
                                    if (i6 == 254 && i7 == 0 && i8 == 0) {
                                        this.detectedCharset = Constants.CHARSET_UTF_32LE;
                                    } else if (i6 == 254) {
                                        this.detectedCharset = Constants.CHARSET_UTF_16LE;
                                    }
                                }
                            } else if (i6 == 255 && i7 == 0 && i8 == 0) {
                                this.detectedCharset = Constants.CHARSET_X_ISO_10646_UCS_4_3412;
                            } else if (i6 == 255) {
                                this.detectedCharset = Constants.CHARSET_UTF_16BE;
                            }
                        } else if (i6 == 187 && i7 == 191) {
                            this.detectedCharset = Constants.CHARSET_UTF_8;
                        }
                    } else if (i6 == 0 && i7 == 254 && i8 == 255) {
                        this.detectedCharset = Constants.CHARSET_UTF_32BE;
                    } else if (i6 == 0 && i7 == 255 && i8 == 254) {
                        this.detectedCharset = Constants.CHARSET_X_ISO_10646_UCS_4_2143;
                    }
                    if (this.detectedCharset != null) {
                        this.done = true;
                        return;
                    }
                }
            }
            for (int i9 = i2; i9 < i2 + i3; i9++) {
                byte b2 = bArr[i9];
                int i10 = b2 & 255;
                if ((b2 & 128) == 0 || i10 == 160) {
                    if (this.inputState == InputState.PURE_ASCII && (i10 == 27 || (i10 == 123 && this.lastChar == 126))) {
                        this.inputState = InputState.ESC_ASCII;
                    }
                    this.lastChar = b2;
                } else {
                    InputState inputState = this.inputState;
                    InputState inputState2 = InputState.HIGHBYTE;
                    if (inputState != inputState2) {
                        this.inputState = inputState2;
                        if (this.escCharsetProber != null) {
                            this.escCharsetProber = null;
                        }
                        CharsetProber[] charsetProberArr = this.probers;
                        if (charsetProberArr[0] == null) {
                            charsetProberArr[0] = new MBCSGroupProber();
                        }
                    }
                }
            }
            InputState inputState3 = this.inputState;
            if (inputState3 == InputState.ESC_ASCII) {
                if (this.escCharsetProber == null) {
                    this.escCharsetProber = new EscCharsetProber();
                }
                if (this.escCharsetProber.handleData(bArr, i2, i3) == CharsetProber.ProbingState.FOUND_IT) {
                    this.done = true;
                    this.detectedCharset = this.escCharsetProber.getCharSetName();
                }
            } else if (inputState3 == InputState.HIGHBYTE) {
                while (true) {
                    CharsetProber[] charsetProberArr2 = this.probers;
                    if (i4 >= charsetProberArr2.length) {
                        return;
                    }
                    if (charsetProberArr2[i4].handleData(bArr, i2, i3) == CharsetProber.ProbingState.FOUND_IT) {
                        this.done = true;
                        this.detectedCharset = this.probers[i4].getCharSetName();
                        return;
                    }
                    i4++;
                }
            }
        }
    }

    public boolean isDone() {
        return this.done;
    }

    public void reset() {
        this.done = false;
        this.start = true;
        this.detectedCharset = null;
        this.gotData = false;
        this.inputState = InputState.PURE_ASCII;
        this.lastChar = 0;
        CharsetProber charsetProber = this.escCharsetProber;
        int i2 = 0;
        if (charsetProber != null) {
            charsetProber.reset();
            i2 = 0;
        }
        while (true) {
            CharsetProber[] charsetProberArr = this.probers;
            if (i2 < charsetProberArr.length) {
                CharsetProber charsetProber2 = charsetProberArr[i2];
                if (charsetProber2 != null) {
                    charsetProber2.reset();
                }
                i2++;
            } else {
                return;
            }
        }
    }

    public void setListener(CharsetListener charsetListener) {
        this.listener = charsetListener;
    }
}
