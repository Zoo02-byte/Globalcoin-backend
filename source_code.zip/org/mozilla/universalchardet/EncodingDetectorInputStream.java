package org.mozilla.universalchardet;

import java.io.IOException;
import java.io.InputStream;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/EncodingDetectorInputStream.class */
public class EncodingDetectorInputStream extends InputStream {
    private final UniversalDetector detector = new UniversalDetector(null);
    private InputStream in;

    public EncodingDetectorInputStream(InputStream inputStream) {
        this.in = inputStream;
    }

    @Override // java.io.InputStream
    public int available() throws IOException {
        return this.in.available();
    }

    @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.in.close();
    }

    public String getDetectedCharset() {
        return this.detector.getDetectedCharset();
    }

    @Override // java.io.InputStream
    public void mark(int i2) {
        this.in.mark(i2);
    }

    @Override // java.io.InputStream
    public boolean markSupported() {
        return this.in.markSupported();
    }

    @Override // java.io.InputStream
    public int read() throws IOException {
        byte[] bArr = new byte[1];
        if (read(bArr, 0, 1) >= 0) {
            return bArr[0];
        }
        return -1;
    }

    @Override // java.io.InputStream
    public int read(byte[] bArr) throws IOException {
        return read(bArr, 0, bArr.length);
    }

    @Override // java.io.InputStream
    public int read(byte[] bArr, int i2, int i3) throws IOException {
        int read = this.in.read(bArr, i2, i3);
        if (!this.detector.isDone() && read > 0) {
            this.detector.handleData(bArr, i2, read);
        }
        if (read == -1) {
            this.detector.dataEnd();
        }
        return read;
    }

    @Override // java.io.InputStream
    public void reset() throws IOException {
        this.in.reset();
    }

    @Override // java.io.InputStream
    public long skip(long j2) throws IOException {
        if (this.detector.isDone()) {
            return this.in.skip(j2);
        }
        int i2 = 0;
        long j3 = -1;
        for (long j4 = 0; j4 < j2 && i2 >= 0; j4++) {
            i2 = this.in.read();
            j3++;
        }
        return j3;
    }
}
