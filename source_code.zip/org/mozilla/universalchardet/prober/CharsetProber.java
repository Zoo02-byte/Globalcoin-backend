package org.mozilla.universalchardet.prober;

import java.nio.ByteBuffer;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/CharsetProber.class */
public abstract class CharsetProber {
    public static final int ASCII_A = 97;
    public static final int ASCII_A_CAPITAL = 65;
    public static final int ASCII_GT = 62;
    public static final int ASCII_LT = 60;
    public static final int ASCII_SP = 32;
    public static final int ASCII_Z = 122;
    public static final int ASCII_Z_CAPITAL = 90;
    public static final float SHORTCUT_THRESHOLD = 0.95f;
    private boolean active = true;

    /* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/CharsetProber$ProbingState.class */
    public enum ProbingState {
        DETECTING,
        FOUND_IT,
        NOT_ME
    }

    private boolean isAscii(byte b2) {
        return (b2 & 128) == 0;
    }

    private boolean isAsciiSymbol(byte b2) {
        int i2 = b2 & 255;
        return i2 < 65 || (i2 > 90 && i2 < 97) || i2 > 122;
    }

    public ByteBuffer filterWithEnglishLetters(byte[] bArr, int i2, int i3) {
        boolean z2;
        ByteBuffer allocate = ByteBuffer.allocate(i3);
        int i4 = i2;
        boolean z3 = false;
        int i5 = i2;
        while (i5 < i3 + i2) {
            byte b2 = bArr[i5];
            if (b2 == 62) {
                z2 = false;
            } else {
                z2 = z3;
                if (b2 == 60) {
                    z2 = true;
                }
            }
            i4 = i4;
            if (isAscii(b2)) {
                i4 = i4;
                if (isAsciiSymbol(b2)) {
                    if (i5 > i4 && !z2) {
                        allocate.put(bArr, i4, i5 - i4);
                        allocate.put((byte) 32);
                    }
                    i4 = i5 + 1;
                }
            }
            i5++;
            z3 = z2;
        }
        if (!z3 && i5 > i4) {
            allocate.put(bArr, i4, i5 - i4);
        }
        return allocate;
    }

    public ByteBuffer filterWithoutEnglishLetters(byte[] bArr, int i2, int i3) {
        ByteBuffer allocate = ByteBuffer.allocate(i3);
        int i4 = i2;
        boolean z2 = false;
        int i5 = i2;
        while (i5 < i3 + i2) {
            byte b2 = bArr[i5];
            if (!isAscii(b2)) {
                z2 = true;
                i4 = i4;
            } else {
                i4 = i4;
                z2 = z2;
                if (isAsciiSymbol(b2)) {
                    if (!z2 || i5 <= i4) {
                        i4 = i5 + 1;
                        z2 = z2;
                    } else {
                        allocate.put(bArr, i4, i5 - i4);
                        allocate.put((byte) 32);
                        i4 = i5 + 1;
                        z2 = false;
                    }
                }
            }
            i5++;
        }
        if (z2 && i5 > i4) {
            allocate.put(bArr, i4, i5 - i4);
        }
        return allocate;
    }

    public abstract String getCharSetName();

    public abstract float getConfidence();

    public abstract ProbingState getState();

    public abstract ProbingState handleData(byte[] bArr, int i2, int i3);

    public boolean isActive() {
        return this.active;
    }

    public abstract void reset();

    public void setActive(boolean z2) {
        this.active = z2;
    }

    public abstract void setOption();
}
