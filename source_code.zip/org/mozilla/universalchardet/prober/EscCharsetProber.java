package org.mozilla.universalchardet.prober;

import org.mozilla.universalchardet.prober.CharsetProber;
import org.mozilla.universalchardet.prober.statemachine.CodingStateMachine;
import org.mozilla.universalchardet.prober.statemachine.HZSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022CNSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022JPSMModel;
import org.mozilla.universalchardet.prober.statemachine.ISO2022KRSMModel;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/EscCharsetProber.class */
public class EscCharsetProber extends CharsetProber {
    private static final HZSMModel hzsModel = new HZSMModel();
    private static final ISO2022CNSMModel iso2022cnModel = new ISO2022CNSMModel();
    private static final ISO2022JPSMModel iso2022jpModel = new ISO2022JPSMModel();
    private static final ISO2022KRSMModel iso2022krModel = new ISO2022KRSMModel();
    private int activeSM;
    private CodingStateMachine[] codingSM;
    private String detectedCharset;
    private CharsetProber.ProbingState state;

    public EscCharsetProber() {
        CodingStateMachine[] codingStateMachineArr = new CodingStateMachine[4];
        this.codingSM = codingStateMachineArr;
        codingStateMachineArr[0] = new CodingStateMachine(hzsModel);
        this.codingSM[1] = new CodingStateMachine(iso2022cnModel);
        this.codingSM[2] = new CodingStateMachine(iso2022jpModel);
        this.codingSM[3] = new CodingStateMachine(iso2022krModel);
        reset();
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public String getCharSetName() {
        return this.detectedCharset;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public float getConfidence() {
        return 0.99f;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState getState() {
        return this.state;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public CharsetProber.ProbingState handleData(byte[] bArr, int i2, int i3) {
        for (int i4 = i2; i4 < i3 + i2 && this.state == CharsetProber.ProbingState.DETECTING; i4++) {
            for (int i5 = this.activeSM - 1; i5 >= 0; i5--) {
                int nextState = this.codingSM[i5].nextState(bArr[i4]);
                if (nextState == 1) {
                    int i6 = this.activeSM - 1;
                    this.activeSM = i6;
                    if (i6 <= 0) {
                        CharsetProber.ProbingState probingState = CharsetProber.ProbingState.NOT_ME;
                        this.state = probingState;
                        return probingState;
                    } else if (i5 != i6) {
                        CodingStateMachine[] codingStateMachineArr = this.codingSM;
                        CodingStateMachine codingStateMachine = codingStateMachineArr[i6];
                        codingStateMachineArr[i6] = codingStateMachineArr[i5];
                        codingStateMachineArr[i5] = codingStateMachine;
                    }
                } else if (nextState == 2) {
                    this.state = CharsetProber.ProbingState.FOUND_IT;
                    this.detectedCharset = this.codingSM[i5].getCodingStateMachine();
                    return this.state;
                }
            }
        }
        return this.state;
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void reset() {
        this.state = CharsetProber.ProbingState.DETECTING;
        int i2 = 0;
        while (true) {
            CodingStateMachine[] codingStateMachineArr = this.codingSM;
            if (i2 < codingStateMachineArr.length) {
                codingStateMachineArr[i2].reset();
                i2++;
            } else {
                this.activeSM = codingStateMachineArr.length;
                this.detectedCharset = null;
                return;
            }
        }
    }

    @Override // org.mozilla.universalchardet.prober.CharsetProber
    public void setOption() {
    }
}
