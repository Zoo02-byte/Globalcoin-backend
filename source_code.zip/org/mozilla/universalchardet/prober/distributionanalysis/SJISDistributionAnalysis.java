package org.mozilla.universalchardet.prober.distributionanalysis;

import com.alibaba.fastjson.asm.Opcodes;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/distributionanalysis/SJISDistributionAnalysis.class */
public class SJISDistributionAnalysis extends JISDistributionAnalysis {
    public static final int HIGHBYTE_BEGIN_1 = 129;
    public static final int HIGHBYTE_BEGIN_2 = 224;
    public static final int HIGHBYTE_END_1 = 159;
    public static final int HIGHBYTE_END_2 = 239;
    public static final int LOWBYTE_BEGIN_1 = 64;
    public static final int LOWBYTE_BEGIN_2 = 128;

    @Override // org.mozilla.universalchardet.prober.distributionanalysis.CharDistributionAnalysis
    protected int getOrder(byte[] bArr, int i2) {
        int i3;
        int i4 = bArr[i2] & 255;
        if (i4 >= 129 && i4 <= 159) {
            i3 = i4 - 129;
        } else if (i4 < 224 || i4 > 239) {
            return -1;
        } else {
            i3 = i4 - 193;
        }
        int i5 = bArr[i2 + 1] & 255;
        int i6 = (i3 * Opcodes.NEWARRAY) + (i5 - 64);
        int i7 = i6;
        if (i5 >= 128) {
            i7 = i6 - 1;
        }
        return i7;
    }
}
