package org.mozilla.universalchardet.prober.sequence;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/SequenceModel.class */
public abstract class SequenceModel {
    protected short[] charToOrderMap;
    protected String charsetName;
    protected boolean keepEnglishLetter;
    protected byte[] precedenceMatrix;
    protected float typicalPositiveRatio;

    public SequenceModel(short[] sArr, byte[] bArr, float f2, boolean z2, String str) {
        this.charToOrderMap = (short[]) sArr.clone();
        this.precedenceMatrix = (byte[]) bArr.clone();
        this.typicalPositiveRatio = f2;
        this.keepEnglishLetter = z2;
        this.charsetName = str;
    }

    public String getCharsetName() {
        return this.charsetName;
    }

    public boolean getKeepEnglishLetter() {
        return this.keepEnglishLetter;
    }

    public short getOrder(byte b2) {
        return this.charToOrderMap[b2 & 255];
    }

    public byte getPrecedence(int i2) {
        return this.precedenceMatrix[i2];
    }

    public float getTypicalPositiveRatio() {
        return this.typicalPositiveRatio;
    }
}
