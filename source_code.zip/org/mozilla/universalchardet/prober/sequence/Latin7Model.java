package org.mozilla.universalchardet.prober.sequence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.mozilla.universalchardet.Constants;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/Latin7Model.class */
public class Latin7Model extends GreekModel {
    private static final short[] latin7CharToOrderMap = $d2j$hex$6fa8837d$decode_S("ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fe00ff00ff00fe00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fc00fc00fc00fc00fc00fc00fc00fc00fc00fc00fd00fd00fd00fd00fd00fd00fd005200640068005e0062006500740066006f00bb0075005c005800710055004f007600690053004300720077005f0063006d00bc00fd00fd00fd00fd00fd00fd0048004600500051003c0060005d0059004400780061004d005600450037004e007300410042003a004c006a00670057006b007000fd00fd00fd00fd00fd00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00e9005a00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd004a00fd00fd00fd00fd00fd00fd00f700f8003d0024002e0047004900fd003600fd006c007b006e001f0033002b00290022005b00280034002f002c003500260031003b00270023003000fa00250021002d003800320054003900780079001100120016000f007c0001001d0014001500030020000d00190005000b0010000a0006001e000400090008000e00070002000c001c0017002a00180040004b0013001a001b00fd00");

    public Latin7Model() {
        super(latin7CharToOrderMap, Constants.CHARSET_ISO_8859_7);
    }

    private static long[] $d2j$hex$6fa8837d$decode_J(String src) {
        byte[] d2 = $d2j$hex$6fa8837d$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        LongBuffer s2 = b2.asLongBuffer();
        long[] data = new long[d2.length / 8];
        s2.get(data);
        return data;
    }

    private static int[] $d2j$hex$6fa8837d$decode_I(String src) {
        byte[] d2 = $d2j$hex$6fa8837d$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        IntBuffer s2 = b2.asIntBuffer();
        int[] data = new int[d2.length / 4];
        s2.get(data);
        return data;
    }

    private static short[] $d2j$hex$6fa8837d$decode_S(String src) {
        byte[] d2 = $d2j$hex$6fa8837d$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer s2 = b2.asShortBuffer();
        short[] data = new short[d2.length / 2];
        s2.get(data);
        return data;
    }

    private static byte[] $d2j$hex$6fa8837d$decode_B(String src) {
        int hh;
        int ll;
        char[] d2 = src.toCharArray();
        byte[] ret = new byte[src.length() / 2];
        for (int i2 = 0; i2 < ret.length; i2++) {
            char h2 = d2[2 * i2];
            char l2 = d2[(2 * i2) + 1];
            if (h2 >= '0' && h2 <= '9') {
                hh = h2 - '0';
            } else if (h2 >= 'a' && h2 <= 'f') {
                hh = (h2 - 'a') + 10;
            } else if (h2 < 'A' || h2 > 'F') {
                throw new RuntimeException();
            } else {
                hh = (h2 - 'A') + 10;
            }
            if (l2 >= '0' && l2 <= '9') {
                ll = l2 - '0';
            } else if (l2 >= 'a' && l2 <= 'f') {
                ll = (l2 - 'a') + 10;
            } else if (l2 < 'A' || l2 > 'F') {
                throw new RuntimeException();
            } else {
                ll = (l2 - 'A') + 10;
            }
            ret[i2] = (byte) ((hh << 4) | ll);
        }
        return ret;
    }
}
