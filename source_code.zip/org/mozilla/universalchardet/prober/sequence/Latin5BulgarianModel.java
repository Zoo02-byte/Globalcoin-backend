package org.mozilla.universalchardet.prober.sequence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.mozilla.universalchardet.Constants;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/Latin5BulgarianModel.class */
public class Latin5BulgarianModel extends BulgarianModel {
    private static final short[] latin5BulgarianCharToOrderMap = $d2j$hex$b01b056c$decode_S("ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fe00ff00ff00fe00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fc00fc00fc00fc00fc00fc00fc00fc00fc00fc00fd00fd00fd00fd00fd00fd00fd004d005a006300640048006d006b0065004f00b900510066004c005e0052006e00ba006c005b004a007700540060006f00bb007300fd00fd00fd00fd00fd00fd0041004500460042003f004400700067005c00c20068005f005600570047007400c30055005d0061007100c400c500c600c700c800fd00fd00fd00fd00fd00c200c300c400c500c600c700c800c900ca00cb00cc00cd00ce00cf00d000d100d200d300d400d500d600d700d800d900da00db00dc00dd00de00df00e000e1005100e200e300e400e500e6006900e700e800e900ea00eb00ec002d00ed00ee001f00200023002b0025002c0037002f0028003b0021002e002600240029001e0027001c00220033003000310035003200360039003d00ef004300f0003c00380001001200090014000b00030017000f0002001a000c000a000e00060004000d0007000800050013001d001900160015001b00180011004b003400f1002a0010003e00f200f300f4003a00f5006200f600f700f800f900fa00fb005b00fc00fd00");

    public Latin5BulgarianModel() {
        super(latin5BulgarianCharToOrderMap, Constants.CHARSET_ISO_8859_5);
    }

    private static long[] $d2j$hex$b01b056c$decode_J(String src) {
        byte[] d2 = $d2j$hex$b01b056c$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        LongBuffer s2 = b2.asLongBuffer();
        long[] data = new long[d2.length / 8];
        s2.get(data);
        return data;
    }

    private static int[] $d2j$hex$b01b056c$decode_I(String src) {
        byte[] d2 = $d2j$hex$b01b056c$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        IntBuffer s2 = b2.asIntBuffer();
        int[] data = new int[d2.length / 4];
        s2.get(data);
        return data;
    }

    private static short[] $d2j$hex$b01b056c$decode_S(String src) {
        byte[] d2 = $d2j$hex$b01b056c$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer s2 = b2.asShortBuffer();
        short[] data = new short[d2.length / 2];
        s2.get(data);
        return data;
    }

    private static byte[] $d2j$hex$b01b056c$decode_B(String src) {
        int hh;
        int ll;
        char[] d2 = src.toCharArray();
        byte[] ret = new byte[src.length() / 2];
        for (int i2 = 0; i2 < ret.length; i2++) {
            char h2 = d2[2 * i2];
            char l2 = d2[(2 * i2) + 1];
            if (h2 >= '0' && h2 <= '9') {
                hh = h2 - '0';
            } else if (h2 >= 'a' && h2 <= 'f') {
                hh = (h2 - 'a') + 10;
            } else if (h2 < 'A' || h2 > 'F') {
                throw new RuntimeException();
            } else {
                hh = (h2 - 'A') + 10;
            }
            if (l2 >= '0' && l2 <= '9') {
                ll = l2 - '0';
            } else if (l2 >= 'a' && l2 <= 'f') {
                ll = (l2 - 'a') + 10;
            } else if (l2 < 'A' || l2 > 'F') {
                throw new RuntimeException();
            } else {
                ll = (l2 - 'A') + 10;
            }
            ret[i2] = (byte) ((hh << 4) | ll);
        }
        return ret;
    }
}
