package org.mozilla.universalchardet.prober.sequence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.mozilla.universalchardet.Constants;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/Win1251BulgarianModel.class */
public class Win1251BulgarianModel extends BulgarianModel {
    private static final short[] win1251BulgarianCharToOrderMap = $d2j$hex$67daf2ac$decode_S("ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fe00ff00ff00fe00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fc00fc00fc00fc00fc00fc00fc00fc00fc00fc00fd00fd00fd00fd00fd00fd00fd004d005a006300640048006d006b0065004f00b900510066004c005e0052006e00ba006c005b004a007700540060006f00bb007300fd00fd00fd00fd00fd00fd0041004500460042003f004400700067005c00c20068005f005600570047007400c30055005d0061007100c400c500c600c700c800fd00fd00fd00fd00fd00ce00cf00d000d100d200d300d400d5007800d600d700d800d900da00db00dc00dd004e00400053007900620075006900de00df00e000e100e200e300e400e5005800e600e700e800e9007a0059006a00ea00eb00ec00ed00ee002d00ef00f0004900500076007200f100f200f300f400f5003e003a00f600f700f800f900fa001f00200023002b0025002c0037002f0028003b0021002e002600240029001e0027001c00220033003000310035003200360039003d00fb004300fc003c00380001001200090014000b00030017000f0002001a000c000a000e00060004000d0007000800050013001d001900160015001b00180011004b003400fd002a001000");

    public Win1251BulgarianModel() {
        super(win1251BulgarianCharToOrderMap, Constants.CHARSET_WINDOWS_1251);
    }

    private static long[] $d2j$hex$67daf2ac$decode_J(String src) {
        byte[] d2 = $d2j$hex$67daf2ac$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        LongBuffer s2 = b2.asLongBuffer();
        long[] data = new long[d2.length / 8];
        s2.get(data);
        return data;
    }

    private static int[] $d2j$hex$67daf2ac$decode_I(String src) {
        byte[] d2 = $d2j$hex$67daf2ac$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        IntBuffer s2 = b2.asIntBuffer();
        int[] data = new int[d2.length / 4];
        s2.get(data);
        return data;
    }

    private static short[] $d2j$hex$67daf2ac$decode_S(String src) {
        byte[] d2 = $d2j$hex$67daf2ac$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer s2 = b2.asShortBuffer();
        short[] data = new short[d2.length / 2];
        s2.get(data);
        return data;
    }

    private static byte[] $d2j$hex$67daf2ac$decode_B(String src) {
        int hh;
        int ll;
        char[] d2 = src.toCharArray();
        byte[] ret = new byte[src.length() / 2];
        for (int i2 = 0; i2 < ret.length; i2++) {
            char h2 = d2[2 * i2];
            char l2 = d2[(2 * i2) + 1];
            if (h2 >= '0' && h2 <= '9') {
                hh = h2 - '0';
            } else if (h2 >= 'a' && h2 <= 'f') {
                hh = (h2 - 'a') + 10;
            } else if (h2 < 'A' || h2 > 'F') {
                throw new RuntimeException();
            } else {
                hh = (h2 - 'A') + 10;
            }
            if (l2 >= '0' && l2 <= '9') {
                ll = l2 - '0';
            } else if (l2 >= 'a' && l2 <= 'f') {
                ll = (l2 - 'a') + 10;
            } else if (l2 < 'A' || l2 > 'F') {
                throw new RuntimeException();
            } else {
                ll = (l2 - 'A') + 10;
            }
            ret[i2] = (byte) ((hh << 4) | ll);
        }
        return ret;
    }
}
