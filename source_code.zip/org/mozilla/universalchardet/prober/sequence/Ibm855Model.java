package org.mozilla.universalchardet.prober.sequence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.mozilla.universalchardet.Constants;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/Ibm855Model.class */
public class Ibm855Model extends CyrillicModel {
    private static final short[] ibm855CharToOrderMap = $d2j$hex$7a93f721$decode_S("ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fe00ff00ff00fe00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fc00fc00fc00fc00fc00fc00fc00fc00fc00fc00fd00fd00fd00fd00fd00fd00fd008e008f009000910092009300940095009600970098004a0099004b009a009b009c009d009e009f00a000a100a200a300a400a500fd00fd00fd00fd00fd00fd004700ac004200ad004100ae004c00af004000b000b1004d004800b20045004300b3004e004900b400b5004f00b600b700b800b900fd00fd00fd00fd00fd00bf00c000c100c2004400c300c400c500c600c700c800c900ca00cb00cc00cd00ce00cf00d000d100d200d300d400d500d600d700d800d9001b003b00360046000300250015002c001c003a000d002900020030002700350013002e00da00db00dc00dd00de00df00e0001a00370004002a00e100e200e300e40017003c00e500e600e700e800e900ea00eb000b002400ec00ed00ee00ef00f000f100f200f300080031000c00260005001f00010022000f00f400f500f600f70023001000f8002b0009002d0007002000060028000e003400180038000a00210011003d00f900fa0012003e0014003300190039001e002f001d003f0016003200fb00fc00ff00");

    public Ibm855Model() {
        super(ibm855CharToOrderMap, Constants.CHARSET_IBM855);
    }

    private static long[] $d2j$hex$7a93f721$decode_J(String src) {
        byte[] d2 = $d2j$hex$7a93f721$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        LongBuffer s2 = b2.asLongBuffer();
        long[] data = new long[d2.length / 8];
        s2.get(data);
        return data;
    }

    private static int[] $d2j$hex$7a93f721$decode_I(String src) {
        byte[] d2 = $d2j$hex$7a93f721$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        IntBuffer s2 = b2.asIntBuffer();
        int[] data = new int[d2.length / 4];
        s2.get(data);
        return data;
    }

    private static short[] $d2j$hex$7a93f721$decode_S(String src) {
        byte[] d2 = $d2j$hex$7a93f721$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer s2 = b2.asShortBuffer();
        short[] data = new short[d2.length / 2];
        s2.get(data);
        return data;
    }

    private static byte[] $d2j$hex$7a93f721$decode_B(String src) {
        int hh;
        int ll;
        char[] d2 = src.toCharArray();
        byte[] ret = new byte[src.length() / 2];
        for (int i2 = 0; i2 < ret.length; i2++) {
            char h2 = d2[2 * i2];
            char l2 = d2[(2 * i2) + 1];
            if (h2 >= '0' && h2 <= '9') {
                hh = h2 - '0';
            } else if (h2 >= 'a' && h2 <= 'f') {
                hh = (h2 - 'a') + 10;
            } else if (h2 < 'A' || h2 > 'F') {
                throw new RuntimeException();
            } else {
                hh = (h2 - 'A') + 10;
            }
            if (l2 >= '0' && l2 <= '9') {
                ll = l2 - '0';
            } else if (l2 >= 'a' && l2 <= 'f') {
                ll = (l2 - 'a') + 10;
            } else if (l2 < 'A' || l2 > 'F') {
                throw new RuntimeException();
            } else {
                ll = (l2 - 'A') + 10;
            }
            ret[i2] = (byte) ((hh << 4) | ll);
        }
        return ret;
    }
}
