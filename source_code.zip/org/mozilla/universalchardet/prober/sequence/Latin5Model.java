package org.mozilla.universalchardet.prober.sequence;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.mozilla.universalchardet.Constants;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/sequence/Latin5Model.class */
public class Latin5Model extends CyrillicModel {
    private static final short[] latin5CharToOrderMap = $d2j$hex$37a35137$decode_S("ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fe00ff00ff00fe00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fd00fc00fc00fc00fc00fc00fc00fc00fc00fc00fc00fd00fd00fd00fd00fd00fd00fd008e008f009000910092009300940095009600970098004a0099004b009a009b009c009d009e009f00a000a100a200a300a400a500fd00fd00fd00fd00fd00fd004700ac004200ad004100ae004c00af004000b000b1004d004800b20045004300b3004e004900b400b5004f00b600b700b800b900fd00fd00fd00fd00fd00bf00c000c100c200c300c400c500c600c700c800c900ca00cb00cc00cd00ce00cf00d000d100d200d300d400d500d600d700d800d900da00db00dc00dd00de00df00e000e100e200e300e400e500e600e700e800e900ea00eb00ec00ed00ee0025002c0021002e0029003000380033002a003c002400310026001f00220023002d00200028003400350037003a00320039003f0046003e003d002f003b002b00030015000a0013000d00020018001400040017000b0008000c00050001000f000900070006000e0027001a001c00160019001d003600120011001e001b001000ef004400f000f100f200f300f400f500f600f700f800f900fa00fb00fc00ff00");

    public Latin5Model() {
        super(latin5CharToOrderMap, Constants.CHARSET_ISO_8859_5);
    }

    private static long[] $d2j$hex$37a35137$decode_J(String src) {
        byte[] d2 = $d2j$hex$37a35137$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        LongBuffer s2 = b2.asLongBuffer();
        long[] data = new long[d2.length / 8];
        s2.get(data);
        return data;
    }

    private static int[] $d2j$hex$37a35137$decode_I(String src) {
        byte[] d2 = $d2j$hex$37a35137$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        IntBuffer s2 = b2.asIntBuffer();
        int[] data = new int[d2.length / 4];
        s2.get(data);
        return data;
    }

    private static short[] $d2j$hex$37a35137$decode_S(String src) {
        byte[] d2 = $d2j$hex$37a35137$decode_B(src);
        ByteBuffer b2 = ByteBuffer.wrap(d2);
        b2.order(ByteOrder.LITTLE_ENDIAN);
        ShortBuffer s2 = b2.asShortBuffer();
        short[] data = new short[d2.length / 2];
        s2.get(data);
        return data;
    }

    private static byte[] $d2j$hex$37a35137$decode_B(String src) {
        int hh;
        int ll;
        char[] d2 = src.toCharArray();
        byte[] ret = new byte[src.length() / 2];
        for (int i2 = 0; i2 < ret.length; i2++) {
            char h2 = d2[2 * i2];
            char l2 = d2[(2 * i2) + 1];
            if (h2 >= '0' && h2 <= '9') {
                hh = h2 - '0';
            } else if (h2 >= 'a' && h2 <= 'f') {
                hh = (h2 - 'a') + 10;
            } else if (h2 < 'A' || h2 > 'F') {
                throw new RuntimeException();
            } else {
                hh = (h2 - 'A') + 10;
            }
            if (l2 >= '0' && l2 <= '9') {
                ll = l2 - '0';
            } else if (l2 >= 'a' && l2 <= 'f') {
                ll = (l2 - 'a') + 10;
            } else if (l2 < 'A' || l2 > 'F') {
                throw new RuntimeException();
            } else {
                ll = (l2 - 'A') + 10;
            }
            ret[i2] = (byte) ((hh << 4) | ll);
        }
        return ret;
    }
}
