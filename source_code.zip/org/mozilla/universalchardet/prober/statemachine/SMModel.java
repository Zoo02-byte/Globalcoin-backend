package org.mozilla.universalchardet.prober.statemachine;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/statemachine/SMModel.class */
public abstract class SMModel {
    public static final int ERROR = 1;
    public static final int ITSME = 2;
    public static final int START = 0;
    protected int[] charLenTable;
    protected int classFactor;
    protected PkgInt classTable;
    protected String name;
    protected PkgInt stateTable;

    public SMModel(PkgInt pkgInt, int i2, PkgInt pkgInt2, int[] iArr, String str) {
        this.classTable = pkgInt;
        this.classFactor = i2;
        this.stateTable = pkgInt2;
        this.charLenTable = (int[]) iArr.clone();
        this.name = str;
    }

    public int getCharLen(int i2) {
        return this.charLenTable[i2];
    }

    public int getClass(byte b2) {
        return this.classTable.unpack(b2 & 255);
    }

    public String getName() {
        return this.name;
    }

    public int getNextState(int i2, int i3) {
        return this.stateTable.unpack((i3 * this.classFactor) + i2);
    }
}
