package org.mozilla.universalchardet.prober.statemachine;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/statemachine/PkgInt.class */
public class PkgInt {
    public static final int BIT_SHIFT_16BITS = 4;
    public static final int BIT_SHIFT_4BITS = 2;
    public static final int BIT_SHIFT_8BITS = 3;
    public static final int INDEX_SHIFT_16BITS = 1;
    public static final int INDEX_SHIFT_4BITS = 3;
    public static final int INDEX_SHIFT_8BITS = 2;
    public static final int SHIFT_MASK_16BITS = 1;
    public static final int SHIFT_MASK_4BITS = 7;
    public static final int SHIFT_MASK_8BITS = 3;
    public static final int UNIT_MASK_16BITS = 65535;
    public static final int UNIT_MASK_4BITS = 15;
    public static final int UNIT_MASK_8BITS = 255;
    private int bitShift;
    private int[] data;
    private int indexShift;
    private int shiftMask;
    private int unitMask;

    public PkgInt(int i2, int i3, int i4, int i5, int[] iArr) {
        this.indexShift = i2;
        this.shiftMask = i3;
        this.bitShift = i4;
        this.unitMask = i5;
        this.data = (int[]) iArr.clone();
    }

    public static int pack16bits(int i2, int i3) {
        return i2 | (i3 << 16);
    }

    public static int pack4bits(int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        return pack8bits(i2 | (i3 << 4), (i5 << 4) | i4, (i7 << 4) | i6, (i9 << 4) | i8);
    }

    public static int pack8bits(int i2, int i3, int i4, int i5) {
        return pack16bits(i2 | (i3 << 8), (i5 << 8) | i4);
    }

    public int unpack(int i2) {
        return (this.data[i2 >> this.indexShift] >> ((i2 & this.shiftMask) << this.bitShift)) & this.unitMask;
    }
}
