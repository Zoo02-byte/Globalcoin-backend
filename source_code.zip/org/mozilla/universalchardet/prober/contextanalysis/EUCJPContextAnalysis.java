package org.mozilla.universalchardet.prober.contextanalysis;

import org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/contextanalysis/EUCJPContextAnalysis.class */
public class EUCJPContextAnalysis extends JapaneseContextAnalysis {
    public static final int FIRSTPLANE_HIGHBYTE_BEGIN = 161;
    public static final int FIRSTPLANE_HIGHBYTE_END = 254;
    public static final int HIRAGANA_HIGHBYTE = 164;
    public static final int HIRAGANA_LOWBYTE_BEGIN = 161;
    public static final int HIRAGANA_LOWBYTE_END = 243;
    public static final int SINGLE_SHIFT_2 = 142;
    public static final int SINGLE_SHIFT_3 = 143;

    @Override // org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis
    protected int getOrder(byte[] bArr, int i2) {
        int i3;
        if ((bArr[i2] & 255) != 164 || (i3 = bArr[i2 + 1] & 255) < 161 || i3 > 243) {
            return -1;
        }
        return i3 - 161;
    }

    @Override // org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis
    protected void getOrder(JapaneseContextAnalysis.Order order, byte[] bArr, int i2) {
        int i3;
        order.order = -1;
        order.charLength = 1;
        int i4 = bArr[i2] & 255;
        if (i4 == 142 || (i4 >= 161 && i4 <= 254)) {
            order.charLength = 2;
        } else if (i4 == 143) {
            order.charLength = 3;
        }
        if (i4 == 164 && (i3 = bArr[i2 + 1] & 255) >= 161 && i3 <= 243) {
            order.order = i3 - 161;
        }
    }
}
