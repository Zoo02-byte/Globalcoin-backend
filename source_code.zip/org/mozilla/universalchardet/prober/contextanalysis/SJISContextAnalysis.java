package org.mozilla.universalchardet.prober.contextanalysis;

import org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis;
/* loaded from: Coinglobal1.jar:org/mozilla/universalchardet/prober/contextanalysis/SJISContextAnalysis.class */
public class SJISContextAnalysis extends JapaneseContextAnalysis {
    public static final int HIGHBYTE_BEGIN_1 = 129;
    public static final int HIGHBYTE_BEGIN_2 = 224;
    public static final int HIGHBYTE_END_1 = 159;
    public static final int HIGHBYTE_END_2 = 239;
    public static final int HIRAGANA_HIGHBYTE = 130;
    public static final int HIRAGANA_LOWBYTE_BEGIN = 159;
    public static final int HIRAGANA_LOWBYTE_END = 241;

    @Override // org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis
    protected int getOrder(byte[] bArr, int i2) {
        int i3;
        if ((bArr[i2] & 255) != 130 || (i3 = bArr[i2 + 1] & 255) < 159 || i3 > 241) {
            return -1;
        }
        return i3 - 159;
    }

    @Override // org.mozilla.universalchardet.prober.contextanalysis.JapaneseContextAnalysis
    protected void getOrder(JapaneseContextAnalysis.Order order, byte[] bArr, int i2) {
        int i3;
        order.order = -1;
        order.charLength = 1;
        int i4 = bArr[i2] & 255;
        if ((i4 >= 129 && i4 <= 159) || (i4 >= 224 && i4 <= 239)) {
            order.charLength = 2;
        }
        if (i4 == 130 && (i3 = bArr[i2 + 1] & 255) >= 159 && i3 <= 241) {
            order.order = i3 - 159;
        }
    }
}
