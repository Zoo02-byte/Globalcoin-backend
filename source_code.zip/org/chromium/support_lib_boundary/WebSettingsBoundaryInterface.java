package org.chromium.support_lib_boundary;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebSettingsBoundaryInterface.class */
public interface WebSettingsBoundaryInterface {

    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebSettingsBoundaryInterface$ForceDarkBehavior.class */
    public @interface ForceDarkBehavior {
        public static final int FORCE_DARK_ONLY = 0;
        public static final int MEDIA_QUERY_ONLY = 1;
        public static final int PREFER_MEDIA_QUERY_OVER_FORCE_DARK = 2;
    }

    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebSettingsBoundaryInterface$RequestedWithHeaderMode.class */
    public @interface RequestedWithHeaderMode {
        public static final int APP_PACKAGE_NAME = 1;
        public static final int NO_HEADER = 0;
    }

    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebSettingsBoundaryInterface$WebAuthnSupport.class */
    public @interface WebAuthnSupport {
        public static final int APP = 1;
        public static final int BROWSER = 2;
        public static final int NONE = 0;
    }

    int getDisabledActionModeMenuItems();

    boolean getEnterpriseAuthenticationAppLinkPolicyEnabled();

    int getForceDark();

    int getForceDarkBehavior();

    boolean getOffscreenPreRaster();

    int getRequestedWithHeaderMode();

    boolean getSafeBrowsingEnabled();

    int getWebAuthnSupport();

    boolean getWillSuppressErrorPage();

    boolean isAlgorithmicDarkeningAllowed();

    void setAlgorithmicDarkeningAllowed(boolean z2);

    void setDisabledActionModeMenuItems(int i2);

    void setEnterpriseAuthenticationAppLinkPolicyEnabled(boolean z2);

    void setForceDark(int i2);

    void setForceDarkBehavior(int i2);

    void setOffscreenPreRaster(boolean z2);

    void setRequestedWithHeaderMode(int i2);

    void setSafeBrowsingEnabled(boolean z2);

    void setWebAuthnSupport(int i2);

    void setWillSuppressErrorPage(boolean z2);
}
