package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/SafeBrowsingResponseBoundaryInterface.class */
public interface SafeBrowsingResponseBoundaryInterface {
    void backToSafety(boolean z2);

    void proceed(boolean z2);

    void showInterstitial(boolean z2);
}
