package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/ScriptHandlerBoundaryInterface.class */
public interface ScriptHandlerBoundaryInterface {
    void remove();
}
