package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebResourceErrorBoundaryInterface.class */
public interface WebResourceErrorBoundaryInterface {
    CharSequence getDescription();

    int getErrorCode();
}
