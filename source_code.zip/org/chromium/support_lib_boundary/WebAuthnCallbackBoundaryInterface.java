package org.chromium.support_lib_boundary;

import android.content.Intent;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebAuthnCallbackBoundaryInterface.class */
public interface WebAuthnCallbackBoundaryInterface {
    void onResult(int i2, Intent intent);
}
