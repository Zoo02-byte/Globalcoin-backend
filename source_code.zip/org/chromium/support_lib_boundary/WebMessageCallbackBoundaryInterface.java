package org.chromium.support_lib_boundary;

import java.lang.reflect.InvocationHandler;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebMessageCallbackBoundaryInterface.class */
public interface WebMessageCallbackBoundaryInterface extends FeatureFlagHolderBoundaryInterface {
    void onMessage(InvocationHandler invocationHandler, InvocationHandler invocationHandler2);
}
