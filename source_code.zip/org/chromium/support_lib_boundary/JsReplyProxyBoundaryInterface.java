package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/JsReplyProxyBoundaryInterface.class */
public interface JsReplyProxyBoundaryInterface extends IsomorphicObjectBoundaryInterface {
    void postMessage(String str);
}
