package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/ServiceWorkerWebSettingsBoundaryInterface.class */
public interface ServiceWorkerWebSettingsBoundaryInterface {
    boolean getAllowContentAccess();

    boolean getAllowFileAccess();

    boolean getBlockNetworkLoads();

    int getCacheMode();

    int getRequestedWithHeaderMode();

    void setAllowContentAccess(boolean z2);

    void setAllowFileAccess(boolean z2);

    void setBlockNetworkLoads(boolean z2);

    void setCacheMode(int i2);

    void setRequestedWithHeaderMode(int i2);
}
