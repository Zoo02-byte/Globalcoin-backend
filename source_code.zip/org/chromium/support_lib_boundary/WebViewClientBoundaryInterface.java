package org.chromium.support_lib_boundary;

import android.app.PendingIntent;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import java.lang.reflect.InvocationHandler;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebViewClientBoundaryInterface.class */
public interface WebViewClientBoundaryInterface extends FeatureFlagHolderBoundaryInterface {
    @Override // org.chromium.support_lib_boundary.WebViewClientBoundaryInterface
    void onPageCommitVisible(WebView webView, String str);

    void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, InvocationHandler invocationHandler);

    @Override // org.chromium.support_lib_boundary.WebViewClientBoundaryInterface
    void onReceivedHttpError(WebView webView, WebResourceRequest webResourceRequest, WebResourceResponse webResourceResponse);

    void onSafeBrowsingHit(WebView webView, WebResourceRequest webResourceRequest, int i2, InvocationHandler invocationHandler);

    boolean onWebAuthnIntent(WebView webView, PendingIntent pendingIntent, InvocationHandler invocationHandler);

    @Override // org.chromium.support_lib_boundary.WebViewClientBoundaryInterface
    boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest);
}
