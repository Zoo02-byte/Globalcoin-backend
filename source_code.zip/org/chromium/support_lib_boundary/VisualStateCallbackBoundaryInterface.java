package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/VisualStateCallbackBoundaryInterface.class */
public interface VisualStateCallbackBoundaryInterface {
    void onComplete(long j2);
}
