package org.chromium.support_lib_boundary;
/* loaded from: Coinglobal1.jar:org/chromium/support_lib_boundary/WebResourceRequestBoundaryInterface.class */
public interface WebResourceRequestBoundaryInterface {
    boolean isRedirect();
}
