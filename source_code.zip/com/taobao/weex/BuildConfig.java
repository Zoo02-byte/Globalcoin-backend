package com.taobao.weex;
/* loaded from: Coinglobal1.jar:com/taobao/weex/BuildConfig.class */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.taobao.weex";
    public static final String buildJavascriptFrameworkVersion = "0.29.6";
    public static final String buildVersion = "0.28.0";
    public static final boolean isV8 = true;
}
