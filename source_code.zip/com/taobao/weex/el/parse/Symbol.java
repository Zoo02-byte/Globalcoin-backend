package com.taobao.weex.el.parse;
/* loaded from: Coinglobal1.jar:com/taobao/weex/el/parse/Symbol.class */
public class Symbol {
    public final String op;
    public final int pos;

    public Symbol(String str, int i2) {
        this.op = str;
        this.pos = i2;
    }
}
