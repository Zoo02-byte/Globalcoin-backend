package com.taobao.weex.el.parse;

import java.util.ArrayList;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/el/parse/ArrayStack.class */
public class ArrayStack<T> {
    private ArrayList<T> stack = new ArrayList<>(4);

    public void add(int i2, T t2) {
        this.stack.add(i2, t2);
    }

    public T get(int i2) {
        return this.stack.get(i2);
    }

    public List<T> getList() {
        return this.stack;
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public T peek() {
        ArrayList<T> arrayList = this.stack;
        return arrayList.get(arrayList.size() - 1);
    }

    public T pop() {
        ArrayList<T> arrayList = this.stack;
        return arrayList.remove(arrayList.size() - 1);
    }

    public void push(T t2) {
        this.stack.add(t2);
    }

    public T remove(int i2) {
        return this.stack.remove(i2);
    }

    public int size() {
        return this.stack.size();
    }
}
