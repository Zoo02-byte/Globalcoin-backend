package com.taobao.weex.common;

import android.widget.ImageView;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXImageStrategy.class */
public class WXImageStrategy {
    public int blurRadius;
    ImageListener imageListener;
    public String instanceId;
    boolean isAutoCompression = true;
    @Deprecated
    public boolean isClipping;
    public boolean isSharpen;
    public String placeHolder;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXImageStrategy$ImageListener.class */
    public interface ImageListener {
        void onImageFinish(String str, ImageView imageView, boolean z2, Map map);
    }

    public WXImageStrategy() {
    }

    public WXImageStrategy(String str) {
        this.instanceId = str;
    }

    public ImageListener getImageListener() {
        return this.imageListener;
    }

    public boolean isAutoCompression() {
        return this.isAutoCompression;
    }

    public void setAutoCompression(boolean z2) {
        this.isAutoCompression = z2;
    }

    public void setImageListener(ImageListener imageListener) {
        this.imageListener = imageListener;
    }
}
