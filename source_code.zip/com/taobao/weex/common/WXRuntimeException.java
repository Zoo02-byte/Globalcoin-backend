package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXRuntimeException.class */
public class WXRuntimeException extends RuntimeException {
    private static final long serialVersionUID = 5732315311747521491L;

    public WXRuntimeException(String str) {
        super(str);
    }
}
