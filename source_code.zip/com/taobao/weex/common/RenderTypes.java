package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/RenderTypes.class */
public class RenderTypes {
    public static final String RENDER_TYPE_HERON = "heron";
    public static final String RENDER_TYPE_HERON_URL_PARAM = "wx_heron=true";
    public static final String RENDER_TYPE_NATIVE = "platform";
}
