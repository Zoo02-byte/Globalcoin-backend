package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXRequestListener.class */
public interface WXRequestListener {
    void onError(int i2, Object obj, WXResponse wXResponse);

    void onSuccess(int i2, Object obj, WXResponse wXResponse);
}
