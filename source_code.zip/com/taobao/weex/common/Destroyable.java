package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/Destroyable.class */
public interface Destroyable {
    void destroy();
}
