package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXRefreshData.class */
public class WXRefreshData {
    public String data;
    public boolean isDirty;

    public WXRefreshData(String str, boolean z2) {
        this.data = str;
        this.isDirty = z2;
    }
}
