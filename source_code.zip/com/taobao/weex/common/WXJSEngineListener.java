package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXJSEngineListener.class */
public interface WXJSEngineListener {
    void callback(boolean z2, String str, String str2, String str3);

    void createInstanceFailed(String str);

    void createInstanceSuccess(String str);

    void destroyInstanceFailed(String str);

    void destroyInstanceSuccess(String str);

    void fireEvent(boolean z2, String str, String str2, String str3);

    void initFramework(boolean z2, String str, double d2);
}
