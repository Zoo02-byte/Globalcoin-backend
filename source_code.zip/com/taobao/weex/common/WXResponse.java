package com.taobao.weex.common;

import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXResponse.class */
public class WXResponse {
    public String data;
    public String errorCode;
    public String errorMsg;
    public Map<String, Object> extendParams;
    public byte[] originalData;
    public String statusCode;
    public String toastMsg;
}
