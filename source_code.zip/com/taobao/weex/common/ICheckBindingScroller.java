package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/ICheckBindingScroller.class */
public interface ICheckBindingScroller {
    boolean isNeedScroller(String str, Object obj);
}
