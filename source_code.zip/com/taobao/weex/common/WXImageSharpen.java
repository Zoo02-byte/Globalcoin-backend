package com.taobao.weex.common;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/WXImageSharpen.class */
public enum WXImageSharpen {
    UNSHARPEN,
    SHARPEN
}
