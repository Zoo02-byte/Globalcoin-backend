package com.taobao.weex.common;

import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.bridge.WXDebugJsBridge;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/IWXDebugConfig.class */
public interface IWXDebugConfig {
    WXDebugJsBridge getWXDebugJsBridge();

    WXBridgeManager getWXJSManager();
}
