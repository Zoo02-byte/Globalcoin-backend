package com.taobao.weex.common;

import android.view.View;
/* loaded from: Coinglobal1.jar:com/taobao/weex/common/OnWXScrollListener.class */
public interface OnWXScrollListener {
    public static final int DRAGGING = 1;
    public static final int IDLE = 0;
    public static final int SETTLING = 2;

    void onScrollStateChanged(View view, int i2, int i3, int i4);

    void onScrolled(View view, int i2, int i3);
}
