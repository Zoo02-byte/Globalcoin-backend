package com.taobao.weex.base;
/* loaded from: Coinglobal1.jar:com/taobao/weex/base/FloatUtil.class */
public class FloatUtil {
    private static final float EPSILON = 1.0E-5f;

    public static boolean floatsEqual(float f2, float f3) {
        boolean z2 = true;
        boolean z3 = true;
        if (Float.isNaN(f2) || Float.isNaN(f3)) {
            if (!Float.isNaN(f2) || !Float.isNaN(f3)) {
                z2 = false;
            }
            return z2;
        }
        if (Math.abs(f3 - f2) >= EPSILON) {
            z3 = false;
        }
        return z3;
    }
}
