package com.taobao.weex.base;
/* loaded from: Coinglobal1.jar:com/taobao/weex/base/CalledByNative.class */
public @interface CalledByNative {
}
