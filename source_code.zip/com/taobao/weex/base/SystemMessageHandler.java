package com.taobao.weex.base;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.io.Serializable;
import java.lang.reflect.Method;
/* loaded from: Coinglobal1.jar:com/taobao/weex/base/SystemMessageHandler.class */
public class SystemMessageHandler extends Handler implements Serializable {
    private static final int SCHEDULED_WORK = 1;
    private static final String TAG = "SystemMessageHandler";
    private Method mMessageMethodSetAsynchronous;
    private long mMessagePumpDelegateNative;

    private SystemMessageHandler(long j2, boolean z2) {
        super(z2 ? Looper.getMainLooper() : Looper.myLooper());
        this.mMessagePumpDelegateNative = j2;
        try {
            this.mMessageMethodSetAsynchronous = Class.forName("android.os.Message").getMethod("setAsynchronous", Boolean.TYPE);
        } catch (ClassNotFoundException e2) {
            Log.e(TAG, "Failed to find android.os.Message class:" + e2);
        } catch (NoSuchMethodException e3) {
            Log.e(TAG, "Failed to load Message.setAsynchronous method:" + e3);
        } catch (RuntimeException e4) {
            Log.e(TAG, "Exception while loading Message.setAsynchronous method: " + e4);
        }
    }

    public static SystemMessageHandler create(long j2, boolean z2) {
        return new SystemMessageHandler(j2, z2);
    }

    private native void nativeRunWork(long j2);

    private Message obtainAsyncMessage(int i2) {
        Message obtain = Message.obtain();
        obtain.what = i2;
        return obtain;
    }

    private void scheduleDelayedWork(long j2) {
        sendMessageDelayed(obtainAsyncMessage(1), j2);
    }

    private void scheduleWork() {
        sendMessage(obtainAsyncMessage(1));
    }

    private void stop() {
        removeMessages(1);
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        nativeRunWork(this.mMessagePumpDelegateNative);
    }
}
