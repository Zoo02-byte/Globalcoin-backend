package com.taobao.weex.ui.flat.widget;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import com.taobao.weex.ui.view.border.BorderDrawable;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/flat/widget/Widget.class */
public interface Widget {
    public static final String TAG;

    void draw(Canvas canvas);

    BorderDrawable getBackgroundAndBorder();

    Rect getBorderBox();

    Point getLocInFlatContainer();

    void onDraw(Canvas canvas);

    void setBackgroundAndBorder(BorderDrawable borderDrawable);

    void setContentBox(int i2, int i3, int i4, int i5);

    void setLayout(int i2, int i3, int i4, int i5, int i6, int i7, Point point);
}
