package com.taobao.weex.ui.flat.widget;

import android.graphics.Canvas;
import android.graphics.Point;
import com.taobao.weex.ui.flat.FlatGUIContext;
import com.taobao.weex.ui.view.border.BorderDrawable;
import java.util.LinkedList;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/flat/widget/WidgetGroup.class */
public class WidgetGroup extends BaseWidget {
    private List<Widget> mChildren = new LinkedList();

    public WidgetGroup(FlatGUIContext flatGUIContext) {
        super(flatGUIContext);
    }

    public List<Widget> getChildren() {
        return this.mChildren;
    }

    @Override // com.taobao.weex.ui.flat.widget.Widget
    public void onDraw(Canvas canvas) {
        for (Widget widget : this.mChildren) {
            widget.draw(canvas);
        }
    }

    public void replaceAll(List<Widget> list) {
        this.mChildren = list;
        invalidate();
    }

    @Override // com.taobao.weex.ui.flat.widget.BaseWidget, com.taobao.weex.ui.flat.widget.Widget
    public /* bridge */ /* synthetic */ void setBackgroundAndBorder(BorderDrawable borderDrawable) {
        setBackgroundAndBorder(borderDrawable);
    }

    @Override // com.taobao.weex.ui.flat.widget.BaseWidget, com.taobao.weex.ui.flat.widget.Widget
    public /* bridge */ /* synthetic */ void setContentBox(int i2, int i3, int i4, int i5) {
        setContentBox(i2, i3, i4, i5);
    }

    @Override // com.taobao.weex.ui.flat.widget.BaseWidget, com.taobao.weex.ui.flat.widget.Widget
    public /* bridge */ /* synthetic */ void setLayout(int i2, int i3, int i4, int i5, int i6, int i7, Point point) {
        setLayout(i2, i3, i4, i5, i6, i7, point);
    }
}
