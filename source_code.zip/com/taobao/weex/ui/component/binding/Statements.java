package com.taobao.weex.ui.component.binding;

import android.os.Looper;
import android.text.TextUtils;
import androidx.collection.ArrayMap;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.bridge.EventResult;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.dom.WXAttr;
import com.taobao.weex.dom.WXEvent;
import com.taobao.weex.dom.WXStyle;
import com.taobao.weex.dom.binding.ELUtils;
import com.taobao.weex.dom.binding.JSONUtils;
import com.taobao.weex.dom.binding.WXStatement;
import com.taobao.weex.el.parse.ArrayStack;
import com.taobao.weex.el.parse.Token;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.action.GraphicPosition;
import com.taobao.weex.ui.action.GraphicSize;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXComponentFactory;
import com.taobao.weex.ui.component.WXImage;
import com.taobao.weex.ui.component.WXVContainer;
import com.taobao.weex.ui.component.list.WXCell;
import com.taobao.weex.ui.component.list.template.CellDataManager;
import com.taobao.weex.ui.component.list.template.CellRenderContext;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.component.list.template.VirtualComponentLifecycle;
import com.taobao.weex.ui.component.list.template.WXRecyclerTemplateList;
import com.taobao.weex.ui.component.list.template.jni.NativeRenderObjectUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/binding/Statements.class */
public class Statements {
    private static final ThreadLocal<Map<String, Object>> dynamicLocal = new ThreadLocal<>();

    public static WXComponent copyComponentTree(WXComponent wXComponent) {
        return copyComponentTree(wXComponent, wXComponent.getParent());
    }

    private static final WXComponent copyComponentTree(WXComponent wXComponent, WXVContainer wXVContainer) {
        BasicComponentData basicComponentData;
        try {
            basicComponentData = wXComponent.getBasicComponentData().clone();
        } catch (CloneNotSupportedException e2) {
            e2.printStackTrace();
            basicComponentData = null;
        }
        WXComponent newInstance = WXComponentFactory.newInstance(wXComponent.getInstance(), wXVContainer, basicComponentData);
        GraphicPosition layoutPosition = wXComponent.getLayoutPosition();
        GraphicSize layoutSize = wXComponent.getLayoutSize();
        newInstance.updateDemission(layoutPosition.getTop(), layoutPosition.getBottom(), layoutPosition.getLeft(), layoutPosition.getRight(), layoutSize.getHeight(), layoutSize.getWidth());
        newInstance.updateExtra(wXComponent.getExtra());
        if (wXComponent instanceof WXVContainer) {
            WXVContainer wXVContainer2 = (WXVContainer) wXComponent;
            WXVContainer wXVContainer3 = (WXVContainer) newInstance;
            int childCount = wXVContainer2.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                WXComponent child = wXVContainer2.getChild(i2);
                if (child != null) {
                    WXComponent copyComponentTree = copyComponentTree(child, wXVContainer3);
                    wXVContainer3.addChild(copyComponentTree);
                    NativeRenderObjectUtils.nativeAddChildRenderObject(wXVContainer3.getRenderObjectPtr(), copyComponentTree.getRenderObjectPtr());
                }
            }
        }
        if (wXComponent.isWaste()) {
            newInstance.setWaste(true);
        }
        return newInstance;
    }

    private static void doBindingAttrsEventAndRenderChildNode(WXComponent wXComponent, CellRenderContext cellRenderContext, List<WXComponent> list) {
        String str;
        boolean z2;
        Map<String, Object> map;
        String str2;
        boolean z3;
        Map<String, Object> map2;
        WXAttr attrs = wXComponent.getAttrs();
        ArrayStack arrayStack = cellRenderContext.stack;
        Object obj = attrs.get(ELUtils.IS_COMPONENT_ROOT);
        int i2 = 0;
        if (obj == null || !WXUtils.getBoolean(attrs.get(ELUtils.IS_COMPONENT_ROOT), false).booleanValue() || attrs.get(ELUtils.COMPONENT_PROPS) == null || !JSONUtils.isJSON(attrs.get(ELUtils.COMPONENT_PROPS))) {
            str = null;
            z2 = false;
        } else {
            String str3 = (String) attrs.get(CellDataManager.SUB_COMPONENT_TEMPLATE_ID);
            if (!TextUtils.isEmpty(str3)) {
                str2 = cellRenderContext.getRenderState().getVirtualComponentIds().get(wXComponent.getViewTreeKey());
                if (str2 == null) {
                    str2 = CellDataManager.createVirtualComponentId(cellRenderContext.templateList.getRef(), wXComponent.getViewTreeKey(), cellRenderContext.templateList.getItemId(cellRenderContext.position));
                    Map<String, Object> renderProps = renderProps(JSONUtils.toJSON(attrs.get(ELUtils.COMPONENT_PROPS)), cellRenderContext.stack);
                    EventResult syncCallJSEventWithResult = WXBridgeManager.getInstance().syncCallJSEventWithResult(WXBridgeManager.METHD_COMPONENT_HOOK_SYNC, wXComponent.getInstanceId(), null, str3, VirtualComponentLifecycle.LIFECYCLE, "create", new Object[]{str2, renderProps}, null);
                    if (!(syncCallJSEventWithResult == null || syncCallJSEventWithResult.getResult() == null || !(syncCallJSEventWithResult.getResult() instanceof Map))) {
                        renderProps.putAll((Map) syncCallJSEventWithResult.getResult());
                    }
                    cellRenderContext.getRenderState().getVirtualComponentIds().put(wXComponent.getViewTreeKey(), str2);
                    cellRenderContext.templateList.getCellDataManager().createVirtualComponentData(cellRenderContext.position, str2, renderProps);
                    z3 = true;
                    map2 = renderProps;
                } else {
                    Object obj2 = cellRenderContext.getRenderState().getVirtualComponentDatas().get(str2);
                    Map<String, Object> map3 = obj2;
                    if (cellRenderContext.getRenderState().isHasDataUpdate()) {
                        Map<String, Object> renderProps2 = renderProps((JSONObject) attrs.get(ELUtils.COMPONENT_PROPS), cellRenderContext.stack);
                        EventResult syncCallJSEventWithResult2 = WXBridgeManager.getInstance().syncCallJSEventWithResult(WXBridgeManager.METHD_COMPONENT_HOOK_SYNC, wXComponent.getInstanceId(), null, str2, VirtualComponentLifecycle.LIFECYCLE, VirtualComponentLifecycle.SYNSTATE, new Object[]{str2, renderProps2}, null);
                        map3 = obj2;
                        if (syncCallJSEventWithResult2 != null) {
                            map3 = obj2;
                            if (syncCallJSEventWithResult2.getResult() != null) {
                                map3 = obj2;
                                if (syncCallJSEventWithResult2.getResult() instanceof Map) {
                                    renderProps2.putAll((Map) syncCallJSEventWithResult2.getResult());
                                    cellRenderContext.templateList.getCellDataManager().updateVirtualComponentData(str2, renderProps2);
                                    map3 = renderProps2;
                                }
                            }
                        }
                    }
                    z3 = false;
                    map2 = map3;
                }
                wXComponent.getAttrs().put(CellDataManager.VIRTUAL_COMPONENT_ID, (Object) str2);
                map = map2;
            } else {
                str2 = null;
                z3 = false;
                map = renderProps((JSONObject) attrs.get(ELUtils.COMPONENT_PROPS), cellRenderContext.stack);
            }
            cellRenderContext.stack = new ArrayStack();
            z2 = z3;
            str = str2;
            if (map != null) {
                cellRenderContext.stack.push(map == 1 ? 1 : 0);
                z2 = z3;
                str = str2;
            }
        }
        if ((attrs.getStatement() != null ? attrs.getStatement().get(WXStatement.WX_ONCE) : null) != null) {
            ArrayStack arrayStack2 = cellRenderContext.getRenderState().getOnceComponentStates().get(wXComponent.getViewTreeKey());
            ArrayStack arrayStack3 = arrayStack2;
            if (arrayStack2 == null) {
                arrayStack3 = cellRenderContext.templateList.copyStack(cellRenderContext, arrayStack);
                cellRenderContext.getRenderState().getOnceComponentStates().put(wXComponent.getViewTreeKey(), arrayStack3);
            }
            cellRenderContext.stack = arrayStack3;
        }
        doRenderBindingAttrsAndEvent(wXComponent, cellRenderContext);
        if (wXComponent instanceof WXVContainer) {
            if (!wXComponent.isWaste() || (wXComponent instanceof WXCell)) {
                WXVContainer wXVContainer = (WXVContainer) wXComponent;
                while (i2 < wXVContainer.getChildCount()) {
                    i2 += doRenderComponent(wXVContainer.getChild(i2), cellRenderContext, list);
                }
            } else {
                return;
            }
        }
        if (arrayStack != cellRenderContext.stack) {
            cellRenderContext.stack = arrayStack;
        }
        if (z2 && str != null) {
            WXBridgeManager.getInstance().asyncCallJSEventVoidResult(WXBridgeManager.METHD_COMPONENT_HOOK_SYNC, wXComponent.getInstanceId(), null, str, VirtualComponentLifecycle.LIFECYCLE, "attach", new Object[]{TemplateDom.findAllComponentRefs(cellRenderContext.templateList.getRef(), cellRenderContext.position, wXComponent)});
        }
    }

    public static final void doInitCompontent(List<WXComponent> list) {
        if (!(list == null || list.size() == 0)) {
            for (WXComponent wXComponent : list) {
                if (wXComponent.getParent() != null) {
                    WXVContainer parent = wXComponent.getParent();
                    int indexOf = parent.indexOf(wXComponent);
                    if (indexOf >= 0) {
                        parent.createChildViewAt(indexOf);
                        wXComponent.applyLayoutAndEvent(wXComponent);
                        wXComponent.bindData(wXComponent);
                    } else {
                        throw new IllegalArgumentException("render node cann't find");
                    }
                } else {
                    throw new IllegalArgumentException("render node parent cann't find");
                }
            }
        }
    }

    public static final List<WXComponent> doRender(WXComponent wXComponent, CellRenderContext cellRenderContext) {
        ArrayList arrayList = new ArrayList(4);
        try {
            doRenderComponent(wXComponent, cellRenderContext, arrayList);
        } catch (Exception e2) {
            WXLogUtils.e("WeexStatementRender", e2);
        }
        return arrayList;
    }

    private static void doRenderBindingAttrsAndEvent(WXComponent wXComponent, CellRenderContext cellRenderContext) {
        ArrayStack arrayStack = cellRenderContext.stack;
        wXComponent.setWaste(false);
        WXAttr attrs = wXComponent.getAttrs();
        if (!(attrs == null || attrs.getBindingAttrs() == null || attrs.getBindingAttrs().size() <= 0)) {
            Map<String, Object> renderBindingAttrs = renderBindingAttrs(wXComponent.getAttrs().getBindingAttrs(), arrayStack);
            Iterator<Map.Entry<String, Object>> it = renderBindingAttrs.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Object> next = it.next();
                String key = next.getKey();
                Object value = next.getValue();
                Object obj = attrs.get(key);
                if (value == null) {
                    if (obj == null) {
                        it.remove();
                    }
                } else if (value.equals(obj)) {
                    it.remove();
                }
            }
            if (renderBindingAttrs.size() > 0) {
                if (renderBindingAttrs.size() != 1 || renderBindingAttrs.get("src") == null || !(wXComponent instanceof WXImage)) {
                    wXComponent.nativeUpdateAttrs(renderBindingAttrs);
                } else {
                    wXComponent.getAttrs().put("src", renderBindingAttrs.get("src"));
                }
                if (isMainThread()) {
                    wXComponent.updateProperties(renderBindingAttrs);
                }
                renderBindingAttrs.clear();
            }
        }
        WXStyle styles = wXComponent.getStyles();
        if (!(styles == null || styles.getBindingStyle() == null)) {
            Map<String, Object> renderBindingAttrs2 = renderBindingAttrs(styles.getBindingStyle(), arrayStack);
            Iterator<Map.Entry<String, Object>> it2 = renderBindingAttrs2.entrySet().iterator();
            while (it2.hasNext()) {
                Map.Entry<String, Object> next2 = it2.next();
                String key2 = next2.getKey();
                Object value2 = next2.getValue();
                Object obj2 = styles.get(key2);
                if (value2 == null) {
                    if (obj2 == null) {
                        it2.remove();
                    }
                } else if (value2.equals(obj2)) {
                    it2.remove();
                }
            }
            if (renderBindingAttrs2.size() > 0) {
                wXComponent.updateNativeStyles(renderBindingAttrs2);
                if (isMainThread()) {
                    wXComponent.updateProperties(renderBindingAttrs2);
                }
            }
        }
        WXEvent events = wXComponent.getEvents();
        if (!(events == null || events.getEventBindingArgs() == null)) {
            for (Map.Entry entry : events.getEventBindingArgs().entrySet()) {
                List<Object> bindingEventArgs = getBindingEventArgs(arrayStack, entry.getValue());
                if (bindingEventArgs != null) {
                    events.putEventBindingArgsValue((String) entry.getKey(), bindingEventArgs);
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x00c2, code lost:
        if ((r16 instanceof java.util.Map) != false) goto L_0x00c5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private static final int doRenderComponent(com.taobao.weex.ui.component.WXComponent r7, com.taobao.weex.ui.component.list.template.CellRenderContext r8, java.util.List<com.taobao.weex.ui.component.WXComponent> r9) {
        /*
        // Method dump skipped, instructions count: 814
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.binding.Statements.doRenderComponent(com.taobao.weex.ui.component.WXComponent, com.taobao.weex.ui.component.list.template.CellRenderContext, java.util.List):int");
    }

    public static List<Object> getBindingEventArgs(ArrayStack arrayStack, Object obj) {
        ArrayList arrayList = new ArrayList(4);
        if (obj instanceof JSONArray) {
            JSONArray jSONArray = (JSONArray) obj;
            for (int i2 = 0; i2 < jSONArray.size(); i2++) {
                Object obj2 = jSONArray.get(i2);
                if (obj2 instanceof JSONObject) {
                    JSONObject jSONObject = (JSONObject) obj2;
                    if (jSONObject.get(ELUtils.BINDING) instanceof Token) {
                        arrayList.add(((Token) jSONObject.get(ELUtils.BINDING)).execute(arrayStack));
                    }
                }
                arrayList.add(obj2);
            }
        } else if (obj instanceof JSONObject) {
            JSONObject jSONObject2 = (JSONObject) obj;
            if (jSONObject2.get(ELUtils.BINDING) instanceof Token) {
                arrayList.add(((Token) jSONObject2.get(ELUtils.BINDING)).execute(arrayStack));
            } else {
                arrayList.add(obj.toString());
            }
        } else {
            arrayList.add(obj.toString());
        }
        return arrayList;
    }

    public static String getComponentId(WXComponent wXComponent) {
        if ((wXComponent instanceof WXCell) || wXComponent == null) {
            return null;
        }
        WXAttr attrs = wXComponent.getAttrs();
        if (attrs.get(ELUtils.IS_COMPONENT_ROOT) == null || !WXUtils.getBoolean(attrs.get(ELUtils.IS_COMPONENT_ROOT), false).booleanValue() || attrs.get(ELUtils.COMPONENT_PROPS) == null || !(attrs.get(ELUtils.COMPONENT_PROPS) instanceof JSONObject)) {
            return getComponentId(wXComponent.getParent());
        }
        Object obj = attrs.get(CellDataManager.VIRTUAL_COMPONENT_ID);
        if (obj == null) {
            return null;
        }
        return obj.toString();
    }

    public static void initLazyComponent(WXComponent wXComponent, WXVContainer wXVContainer) {
        if (wXComponent.isLazy() || wXComponent.getHostView() == null) {
            wXComponent.lazy(false);
            if (wXVContainer != null) {
                wXVContainer.createChildViewAt(wXVContainer.indexOf(wXComponent));
            } else {
                wXComponent.createView();
            }
            wXComponent.applyLayoutAndEvent(wXComponent);
            wXComponent.bindData(wXComponent);
        }
    }

    private static boolean isCreateFromNodeStatement(WXComponent wXComponent, WXComponent wXComponent2) {
        return wXComponent.getRef() != null && wXComponent.getRef().equals(wXComponent2.getRef());
    }

    private static boolean isMainThread() {
        return Thread.currentThread() == Looper.getMainLooper().getThread();
    }

    public static void parseStatementsToken(WXComponent wXComponent) {
        if (wXComponent.getBasicComponentData().isRenderPtrEmpty()) {
            wXComponent.getBasicComponentData().setRenderObjectPr(wXComponent.getRenderObjectPtr());
        }
        if (wXComponent.getBasicComponentData() != null) {
            BasicComponentData basicComponentData = wXComponent.getBasicComponentData();
            basicComponentData.getAttrs().parseStatements();
            basicComponentData.getStyles().parseStatements();
            basicComponentData.getEvents().parseStatements();
        }
        if (wXComponent instanceof WXVContainer) {
            WXVContainer wXVContainer = (WXVContainer) wXComponent;
            int childCount = wXVContainer.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                parseStatementsToken(wXVContainer.getChild(i2));
            }
        }
    }

    public static Map<String, Object> renderBindingAttrs(ArrayMap arrayMap, ArrayStack arrayStack) {
        Set<Map.Entry> entrySet = arrayMap.entrySet();
        ThreadLocal<Map<String, Object>> threadLocal = dynamicLocal;
        Map<String, Object> map = threadLocal.get();
        Map<String, Object> map2 = map;
        if (map == null) {
            map2 = new HashMap<>();
            threadLocal.set(map2);
        }
        if (map2.size() > 0) {
            map2.clear();
        }
        for (Map.Entry entry : entrySet) {
            Object value = entry.getValue();
            String str = (String) entry.getKey();
            if (value instanceof JSONObject) {
                JSONObject jSONObject = (JSONObject) value;
                if (jSONObject.get(ELUtils.BINDING) instanceof Token) {
                    map2.put(str, ((Token) jSONObject.get(ELUtils.BINDING)).execute(arrayStack));
                }
            }
            if (value instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray) value;
                StringBuilder sb = new StringBuilder();
                for (int i2 = 0; i2 < jSONArray.size(); i2++) {
                    Object obj = jSONArray.get(i2);
                    if (obj instanceof CharSequence) {
                        sb.append(obj);
                    } else if (obj instanceof JSONObject) {
                        JSONObject jSONObject2 = (JSONObject) obj;
                        if (jSONObject2.get(ELUtils.BINDING) instanceof Token) {
                            Object execute = ((Token) jSONObject2.get(ELUtils.BINDING)).execute(arrayStack);
                            Object obj2 = execute;
                            if (execute == null) {
                                obj2 = "";
                            }
                            sb.append(obj2);
                        }
                    }
                }
                String sb2 = sb.toString();
                if (sb2.length() > 256 && WXEnvironment.isApkDebugable()) {
                    WXLogUtils.w(WXRecyclerTemplateList.TAG, " warn too big string " + sb2);
                }
                map2.put(str, sb2);
            }
        }
        return map2;
    }

    public static Map<String, Object> renderProps(JSONObject jSONObject, ArrayStack arrayStack) {
        Set<Map.Entry<String, Object>> entrySet = jSONObject.entrySet();
        ArrayMap arrayMap = new ArrayMap(4);
        for (Map.Entry<String, Object> entry : entrySet) {
            Object value = entry.getValue();
            String key = entry.getKey();
            if (value instanceof JSONObject) {
                JSONObject jSONObject2 = (JSONObject) value;
                if (jSONObject2.get(ELUtils.BINDING) instanceof Token) {
                    arrayMap.put(key, ((Token) jSONObject2.get(ELUtils.BINDING)).execute(arrayStack));
                }
            }
            arrayMap.put(key, value);
        }
        return arrayMap;
    }
}
