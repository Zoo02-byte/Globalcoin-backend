package com.taobao.weex.ui.component.binding;

import android.os.AsyncTask;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXVContainer;
import com.taobao.weex.ui.component.list.WXCell;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.component.list.template.TemplateViewHolder;
import com.taobao.weex.ui.component.list.template.WXRecyclerTemplateList;
import com.taobao.weex.ui.component.list.template.jni.NativeRenderObjectUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/binding/Layouts.class */
public class Layouts {
    public static void doLayoutAsync(TemplateViewHolder templateViewHolder, boolean z2) {
        WXComponent component = templateViewHolder.getComponent();
        int holderPosition = templateViewHolder.getHolderPosition();
        if (templateViewHolder.asyncTask != null) {
            templateViewHolder.asyncTask.cancel(false);
            templateViewHolder.asyncTask = null;
        }
        if (z2) {
            AsynLayoutTask asynLayoutTask = new AsynLayoutTask(templateViewHolder, holderPosition, component);
            templateViewHolder.asyncTask = asynLayoutTask;
            asynLayoutTask.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, new Void[0]);
            return;
        }
        doLayoutOnly(component, templateViewHolder);
        setLayout(component, false);
        if (templateViewHolder.getHolderPosition() >= 0) {
            templateViewHolder.getTemplateList().fireEvent(TemplateDom.ATTACH_CELL_SLOT, TemplateDom.findAllComponentRefs(templateViewHolder.getTemplateList().getRef(), holderPosition, component));
        }
    }

    public static void doLayoutOnly(WXComponent wXComponent, TemplateViewHolder templateViewHolder) {
        doSafeLayout(wXComponent, templateViewHolder.getTemplateList().getLayoutWidth(), templateViewHolder.getTemplateList().getLayoutHeight());
    }

    public static void doLayoutSync(WXCell wXCell, float f2, float f3) {
        doSafeLayout(wXCell, f2, f3);
        setLayout(wXCell, false);
    }

    private static void doSafeLayout(WXComponent wXComponent, float f2, float f3) {
        try {
            System.currentTimeMillis();
            int nativeLayoutRenderObject = NativeRenderObjectUtils.nativeLayoutRenderObject(wXComponent.getRenderObjectPtr(), f2, f3);
            WXEnvironment.isOpenDebugLog();
            if (nativeLayoutRenderObject <= 0) {
                WXLogUtils.e(WXRecyclerTemplateList.TAG, " WXTemplateList doSafeLayout wrong template " + wXComponent.getAttrs().get(Constants.Name.Recycler.SLOT_TEMPLATE_CASE) + " cell height " + nativeLayoutRenderObject);
            }
        } catch (Exception e2) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.e(WXRecyclerTemplateList.TAG, e2);
            }
        }
    }

    public static final void setLayout(WXComponent wXComponent, boolean z2) {
        if (!wXComponent.isWaste()) {
            if (wXComponent.getAttrs().containsKey(TemplateDom.KEY_RESET_ANIMATION) && WXUtils.getBoolean(wXComponent.getAttrs().get(TemplateDom.KEY_RESET_ANIMATION), true).booleanValue()) {
                TemplateDom.resetAnimaiton(wXComponent.getHostView());
            }
            long renderObjectPtr = wXComponent.getRenderObjectPtr();
            if (NativeRenderObjectUtils.nativeRenderObjectHasNewLayout(renderObjectPtr)) {
                NativeRenderObjectUtils.nativeRenderObjectUpdateComponent(renderObjectPtr, wXComponent);
            }
            if (wXComponent instanceof WXVContainer) {
                WXVContainer wXVContainer = (WXVContainer) wXComponent;
                int childCount = wXVContainer.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    WXComponent child = wXVContainer.getChild(i2);
                    if (child != null) {
                        setLayout(child, z2);
                    }
                }
            }
        }
    }
}
