package com.taobao.weex.ui.component;

import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.list.WXCell;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXHeader.class */
public class WXHeader extends WXCell {
    @Deprecated
    public WXHeader(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXHeader(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        String componentType = wXVContainer.getComponentType();
        if (WXBasicComponentType.LIST.equals(componentType) || WXBasicComponentType.RECYCLE_LIST.equals(componentType)) {
            getStyles().put("position", "sticky");
            setSticky("sticky");
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean canRecycled() {
        return !isSticky();
    }

    @Override // com.taobao.weex.ui.component.list.WXCell, com.taobao.weex.ui.component.WXComponent
    public boolean isLazy() {
        return false;
    }
}
