package com.taobao.weex.ui.component;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.Pair;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.interpolator.view.animation.FastOutLinearInInterpolator;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.asm.Opcodes;
import com.taobao.weex.ComponentObserver;
import com.taobao.weex.IWXActivityStateListener;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXAccessibilityRoleAdapter;
import com.taobao.weex.adapter.IWXConfigAdapter;
import com.taobao.weex.bridge.EventResult;
import com.taobao.weex.bridge.Invoker;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.IWXObject;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.common.WXPerformance;
import com.taobao.weex.common.WXRuntimeException;
import com.taobao.weex.dom.CSSShorthand;
import com.taobao.weex.dom.WXEvent;
import com.taobao.weex.dom.WXStyle;
import com.taobao.weex.dom.transition.WXTransition;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.tracing.Stopwatch;
import com.taobao.weex.tracing.WXTracing;
import com.taobao.weex.ui.IFComponentHolder;
import com.taobao.weex.ui.WXRenderManager;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.action.GraphicActionAnimation;
import com.taobao.weex.ui.action.GraphicActionUpdateStyle;
import com.taobao.weex.ui.action.GraphicPosition;
import com.taobao.weex.ui.action.GraphicSize;
import com.taobao.weex.ui.animation.WXAnimationBean;
import com.taobao.weex.ui.component.basic.WXBasicComponent;
import com.taobao.weex.ui.component.binding.Statements;
import com.taobao.weex.ui.component.list.WXCell;
import com.taobao.weex.ui.component.list.template.jni.NativeRenderObjectUtils;
import com.taobao.weex.ui.component.pesudo.OnActivePseudoListner;
import com.taobao.weex.ui.component.pesudo.PesudoStatus;
import com.taobao.weex.ui.component.pesudo.TouchActivePseudoListener;
import com.taobao.weex.ui.flat.FlatComponent;
import com.taobao.weex.ui.flat.FlatGUIContext;
import com.taobao.weex.ui.flat.widget.AndroidViewWidget;
import com.taobao.weex.ui.flat.widget.Widget;
import com.taobao.weex.ui.view.BaseFrameLayout;
import com.taobao.weex.ui.view.border.BorderDrawable;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import com.taobao.weex.ui.view.gesture.WXGestureType;
import com.taobao.weex.utils.WXDataStructureUtil;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXReflectionUtils;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.feature.uniapp.dom.AbsCSSShorthand;
import io.dcloud.feature.uniapp.ui.AbsAnimationHolder;
import io.dcloud.feature.uniapp.ui.action.UniMethodData;
import io.dcloud.feature.uniapp.ui.component.AbsBasicComponent;
import io.dcloud.feature.uniapp.ui.shadow.UniBoxShadowData;
import io.dcloud.feature.uniapp.ui.shadow.UniInsetBoxShadowLayer;
import io.dcloud.feature.uniapp.ui.shadow.UniNormalBoxShadowDrawable;
import io.dcloud.feature.uniapp.utils.UniBoxShadowUtil;
import io.dcloud.weex.ViewHover;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent.class */
public abstract class WXComponent<T extends View> extends WXBasicComponent<T> implements IWXObject, IWXActivityStateListener, OnActivePseudoListner {
    public static final String PROP_FIXED_SIZE;
    public static final String PROP_FS_MATCH_PARENT;
    public static final String PROP_FS_WRAP_CONTENT;
    public static final String ROOT;
    public static final int STATE_ALL_FINISH;
    public static final int STATE_DOM_FINISH;
    public static final int STATE_UI_FINISH;
    public static final String TYPE;
    public static final int TYPE_COMMON;
    public static final int TYPE_VIRTUAL;
    private int[] EMPTY_STATE_SET;
    private int[] ENABLED_STATE_SET;
    private int[] FOCUSED_ENABLED_STATE_SET;
    private long PRESSED_ANIM_DELAY;
    private long PRESSED_ANIM_DURATION;
    private int[] PRESSED_ENABLED_STATE_SET;
    private ConcurrentLinkedQueue<Pair<String, Map<String, Object>>> animations;
    protected ContentBoxMeasurement contentBoxMeasurement;
    public int interactionAbsoluteX;
    public int interactionAbsoluteY;
    public boolean isIgnoreInteraction;
    private boolean isLastLayoutDirectionRTL;
    private boolean isPreventGesture;
    private boolean isUsing;
    private int mAbsoluteX;
    private int mAbsoluteY;
    private AbsAnimationHolder mAnimationHolder;
    private Set<String> mAppendEvents;
    private BorderDrawable mBackgroundDrawable;
    private UniBoxShadowData mBoxShadowData;
    private UniNormalBoxShadowDrawable mBoxShadowDrawable;
    private WXComponent<T>.OnClickListenerImp mClickEventListener;
    private Context mContext;
    public int mDeepInComponentTree;
    private float mElevation;
    private int mFixedProp;
    private List<OnFocusChangeListener> mFocusChangeListeners;
    protected WXGesture mGesture;
    private Set<String> mGestureType;
    private boolean mHasAddFocusListener;
    private IFComponentHolder mHolder;
    T mHost;
    private List<OnClickListener> mHostClickListeners;
    private ViewHover mHover;
    private UniInsetBoxShadowLayer mInsetBoxShadowDrawable;
    private WXSDKInstance mInstance;
    public boolean mIsAddElementToTree;
    private boolean mIsDestroyed;
    private boolean mIsDisabled;
    private String mLastBoxShadowId;
    private boolean mLazy;
    private boolean mNeedLayoutOnAnimation;
    private volatile WXVContainer mParent;
    private ConcurrentLinkedQueue<UniMethodData> mPendingComponetMethodQueue;
    private PesudoStatus mPesudoStatus;
    private int mPreRealHeight;
    private int mPreRealLeft;
    private int mPreRealRight;
    private int mPreRealTop;
    private int mPreRealWidth;
    private GraphicSize mPseudoResetGraphicSize;
    private Drawable mRippleBackground;
    private int mStickyOffset;
    public WXTracing.TraceInfo mTraceInfo;
    private WXTransition mTransition;
    private int mType;
    private String mViewTreeKey;
    private boolean waste;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent$MeasureOutput.class */
    public static class MeasureOutput {
        public int height;
        public int width;
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent$OnClickListener.class */
    public interface OnClickListener {
        void onHostViewClick();
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent$OnClickListenerImp.class */
    public class OnClickListenerImp implements OnClickListener {
        final WXComponent this$0;

        private OnClickListenerImp(WXComponent wXComponent) {
            this.this$0 = wXComponent;
        }

        @Override // com.taobao.weex.ui.component.WXComponent.OnClickListener
        public void onHostViewClick() {
            HashMap newHashMapWithExpectedSize = WXDataStructureUtil.newHashMapWithExpectedSize(1);
            HashMap newHashMapWithExpectedSize2 = WXDataStructureUtil.newHashMapWithExpectedSize(4);
            int[] iArr = new int[2];
            this.this$0.mHost.getLocationOnScreen(iArr);
            newHashMapWithExpectedSize2.put(Constants.Name.X, Float.valueOf(WXViewUtils.getWebPxByWidth((float) iArr[0], this.this$0.mInstance.getInstanceViewPortWidthWithFloat())));
            newHashMapWithExpectedSize2.put(Constants.Name.Y, Float.valueOf(WXViewUtils.getWebPxByWidth((float) iArr[1], this.this$0.mInstance.getInstanceViewPortWidthWithFloat())));
            newHashMapWithExpectedSize2.put("width", Float.valueOf(WXViewUtils.getWebPxByWidth(this.this$0.getLayoutWidth(), this.this$0.mInstance.getInstanceViewPortWidthWithFloat())));
            newHashMapWithExpectedSize2.put("height", Float.valueOf(WXViewUtils.getWebPxByWidth(this.this$0.getLayoutHeight(), this.this$0.mInstance.getInstanceViewPortWidthWithFloat())));
            newHashMapWithExpectedSize.put("position", newHashMapWithExpectedSize2);
            this.this$0.fireEvent(Constants.Event.CLICK, newHashMapWithExpectedSize);
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent$OnFocusChangeListener.class */
    public interface OnFocusChangeListener {
        void onFocusChange(boolean z2);
    }

    @Target({ElementType.PARAMETER})
    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponent$RenderState.class */
    public @interface RenderState {
    }

    public WXComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, int i2, BasicComponentData basicComponentData) {
        super(basicComponentData);
        this.mFixedProp = 0;
        this.mAbsoluteY = 0;
        this.mAbsoluteX = 0;
        this.isLastLayoutDirectionRTL = false;
        this.mPreRealWidth = 0;
        this.mPreRealHeight = 0;
        this.mPreRealLeft = 0;
        this.mPreRealRight = 0;
        this.mPreRealTop = 0;
        this.mStickyOffset = 0;
        this.isUsing = false;
        this.mIsDestroyed = false;
        this.mIsDisabled = false;
        this.mType = 0;
        this.mNeedLayoutOnAnimation = false;
        this.mDeepInComponentTree = 0;
        this.mIsAddElementToTree = false;
        this.interactionAbsoluteX = 0;
        this.interactionAbsoluteY = 0;
        this.mHasAddFocusListener = false;
        this.mTraceInfo = new WXTracing.TraceInfo();
        this.waste = false;
        this.isIgnoreInteraction = false;
        this.mPendingComponetMethodQueue = new ConcurrentLinkedQueue<>();
        this.PRESSED_ANIM_DURATION = 100;
        this.PRESSED_ANIM_DELAY = 100;
        this.ENABLED_STATE_SET = new int[]{16842910};
        this.EMPTY_STATE_SET = new int[0];
        this.PRESSED_ENABLED_STATE_SET = new int[]{16842919, 16842910};
        this.FOCUSED_ENABLED_STATE_SET = new int[]{16842908, 16842910};
        this.mElevation = 0.0f;
        this.mLazy = false;
        this.isPreventGesture = false;
        this.mInstance = wXSDKInstance;
        this.mContext = wXSDKInstance.getContext();
        this.mParent = wXVContainer;
        this.mType = i2;
        if (wXSDKInstance != null) {
            setViewPortWidth(wXSDKInstance.getInstanceViewPortWidthWithFloat());
        }
        onCreate();
        ComponentObserver componentObserver = getInstance().getComponentObserver();
        if (componentObserver != null) {
            componentObserver.onCreate(this);
        }
    }

    public WXComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, 0, basicComponentData);
    }

    @Deprecated
    public WXComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    @Deprecated
    public WXComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, basicComponentData);
    }

    private void applyBorder(AbsBasicComponent absBasicComponent) {
        AbsCSSShorthand border = absBasicComponent.getBorder();
        float f2 = border.get(CSSShorthand.EDGE.LEFT);
        float f3 = border.get(CSSShorthand.EDGE.TOP);
        float f4 = border.get(CSSShorthand.EDGE.RIGHT);
        float f5 = border.get(CSSShorthand.EDGE.BOTTOM);
        if (this.mHost != null) {
            setBorderWidth(Constants.Name.BORDER_LEFT_WIDTH, f2);
            setBorderWidth(Constants.Name.BORDER_TOP_WIDTH, f3);
            setBorderWidth(Constants.Name.BORDER_RIGHT_WIDTH, f4);
            setBorderWidth(Constants.Name.BORDER_BOTTOM_WIDTH, f5);
        }
    }

    private void applyEvents() {
        if (getEvents() != null && !getEvents().isEmpty()) {
            WXEvent events = getEvents();
            int size = events.size();
            int i2 = 0;
            while (i2 < size && i2 < events.size()) {
                addEvent((String) events.get(i2));
                i2++;
            }
            setActiveTouchListener();
        }
    }

    private WXAnimationBean createAnimationBean(String str, Map<String, Object> map) {
        if (map == null) {
            return null;
        }
        try {
            Object obj = map.get("transform");
            if (!(obj instanceof String) || TextUtils.isEmpty((String) obj)) {
                return null;
            }
            String str2 = (String) map.get(Constants.Name.TRANSFORM_ORIGIN);
            WXAnimationBean wXAnimationBean = new WXAnimationBean();
            int layoutWidth = (int) getLayoutWidth();
            int layoutHeight = (int) getLayoutHeight();
            wXAnimationBean.styles = new WXAnimationBean.Style();
            wXAnimationBean.styles.init(str2, (String) obj, layoutWidth, layoutHeight, WXSDKManager.getInstanceViewPortWidth(getInstanceId()), getInstance());
            return wXAnimationBean;
        } catch (RuntimeException e2) {
            WXLogUtils.e("", e2);
            return null;
        }
    }

    private final void fireEvent(String str, Map<String, Object> map, Map<String, Object> map2, EventResult eventResult) {
        String componentId;
        if (this.mInstance != null) {
            List<Object> list = (getEvents() == null || getEvents().getEventBindingArgsValues() == null) ? null : getEvents().getEventBindingArgsValues().get(str);
            if (!(map == null || (componentId = Statements.getComponentId(this)) == null)) {
                map.put("componentId", componentId);
            }
            this.mInstance.fireEvent(getRef(), str, map, map2, list, eventResult);
        }
    }

    private void initOutlineProvider(float f2) {
        if (useFeature() && (getHostView() instanceof BaseFrameLayout)) {
            getHostView().setOutlineProvider(new ViewOutlineProvider(this, f2) { // from class: com.taobao.weex.ui.component.WXComponent.8
                final WXComponent this$0;
                final float val$radius;

                {
                    this.this$0 = r4;
                    this.val$radius = r5;
                }

                @Override // android.view.ViewOutlineProvider
                public void getOutline(View view, Outline outline) {
                    if (!this.this$0.getInstance().isDestroy()) {
                        int width = view.getWidth();
                        int height = view.getHeight();
                        if (width != 0 && height != 0 && this.this$0.getOrCreateBorder().isRounded()) {
                            Rect rect = new Rect(0, 0, width, height);
                            float f3 = ((float) width) / (this.val$radius * 2.0f);
                            if (Float.isNaN(f3) || f3 >= 1.0f) {
                                outline.setRoundRect(rect, this.val$radius);
                            } else {
                                outline.setRoundRect(rect, f3 * this.val$radius);
                            }
                        }
                    }
                }
            });
            getHostView().setClipToOutline(true);
        }
    }

    private final void invokePendingComponetMethod() {
        if (this.mPendingComponetMethodQueue.size() > 0) {
            WXBridgeManager.getInstance().post(new Runnable(this) { // from class: com.taobao.weex.ui.component.WXComponent.6
                final WXComponent this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    while (!this.this$0.mPendingComponetMethodQueue.isEmpty()) {
                        UniMethodData uniMethodData = (UniMethodData) this.this$0.mPendingComponetMethodQueue.poll();
                        if (uniMethodData != null) {
                            this.this$0.invoke(uniMethodData.getMethod(), uniMethodData.getArgs());
                        }
                    }
                }
            });
        }
    }

    private boolean needGestureDetector(String str) {
        if (this.mHost != null) {
            for (WXGestureType.LowLevelGesture lowLevelGesture : WXGestureType.LowLevelGesture.values()) {
                if (str.equals(lowLevelGesture.toString())) {
                    return true;
                }
            }
            for (WXGestureType.HighLevelGesture highLevelGesture : WXGestureType.HighLevelGesture.values()) {
                if (str.equals(highLevelGesture.toString())) {
                    return true;
                }
            }
        }
        return WXGesture.isStopPropagation(str) || str.equals(ViewHover.VIEW_HOVER_EVENT) || isPreventGesture();
    }

    private void parseAnimation() {
        WXAnimationBean createAnimationBean;
        ConcurrentLinkedQueue<Pair<String, Map<String, Object>>> concurrentLinkedQueue = this.animations;
        if (concurrentLinkedQueue != null) {
            Iterator<Pair<String, Map<String, Object>>> it = concurrentLinkedQueue.iterator();
            while (it.hasNext()) {
                Pair<String, Map<String, Object>> next = it.next();
                if (!TextUtils.isEmpty((CharSequence) next.first) && (createAnimationBean = createAnimationBean((String) next.first, (Map) next.second)) != null) {
                    new GraphicActionAnimation(getInstance(), getRef(), createAnimationBean).executeAction();
                }
            }
            this.animations.clear();
        }
    }

    private Drawable prepareBackgroundRipple() {
        int i2;
        try {
            if (getStyles() == null || getStyles().getPesudoResetStyles() == null) {
                return null;
            }
            Map<String, Object> pesudoResetStyles = getStyles().getPesudoResetStyles();
            Object obj = pesudoResetStyles.get("backgroundColor");
            if (obj != null) {
                int color = WXResourceUtils.getColor(obj.toString(), 0);
                i2 = color;
                if (color == 0) {
                    return null;
                }
            } else {
                i2 = 0;
            }
            Object obj2 = pesudoResetStyles.get("backgroundColor:active");
            if (obj2 == null) {
                return null;
            }
            return new RippleDrawable(this, new ColorStateList(new int[][]{new int[0]}, new int[]{WXResourceUtils.getColor(obj2.toString(), i2)}), new ColorDrawable(i2), null) { // from class: com.taobao.weex.ui.component.WXComponent.7
                final WXComponent this$0;

                {
                    this.this$0 = r6;
                }

                @Override // android.graphics.drawable.RippleDrawable, android.graphics.drawable.LayerDrawable, android.graphics.drawable.Drawable
                public void draw(Canvas canvas) {
                    if (this.this$0.mBackgroundDrawable != null) {
                        canvas.clipPath(this.this$0.mBackgroundDrawable.getContentPath(new RectF(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight())));
                    }
                    draw(canvas);
                }
            };
        } catch (Throwable th) {
            WXLogUtils.w("Exception on create ripple: ", th);
            return null;
        }
    }

    private void recordInteraction(int i2, int i3) {
        if (this.mIsAddElementToTree) {
            boolean z2 = false;
            this.mIsAddElementToTree = false;
            if (this.mParent == null) {
                this.interactionAbsoluteX = 0;
                this.interactionAbsoluteY = 0;
            } else {
                float cSSLayoutTop = getCSSLayoutTop();
                float cSSLayoutLeft = getCSSLayoutLeft();
                if (!isFixed()) {
                    cSSLayoutLeft += (float) this.mParent.interactionAbsoluteX;
                }
                this.interactionAbsoluteX = (int) cSSLayoutLeft;
                this.interactionAbsoluteY = (int) (isFixed() ? cSSLayoutTop : cSSLayoutTop + ((float) this.mParent.interactionAbsoluteY));
            }
            if (getInstance().getApmForInstance().instanceRect == null) {
                getInstance().getApmForInstance().instanceRect = new Rect();
            }
            Rect rect = getInstance().getApmForInstance().instanceRect;
            rect.set(0, 0, this.mInstance.getWeexWidth(), this.mInstance.getWeexHeight());
            if (rect.contains(this.interactionAbsoluteX, this.interactionAbsoluteY) || rect.contains(this.interactionAbsoluteX + i2, this.interactionAbsoluteY) || rect.contains(this.interactionAbsoluteX, this.interactionAbsoluteY + i3) || rect.contains(this.interactionAbsoluteX + i2, this.interactionAbsoluteY + i3)) {
                z2 = true;
            }
            this.mInstance.onChangeElement(this, !z2);
        }
    }

    private void setActiveTouchListener() {
        View realView;
        if (getStyles().getPesudoStyles().containsKey(Constants.PSEUDO.ACTIVE) && (realView = getRealView()) != null) {
            realView.setOnTouchListener(new TouchActivePseudoListener(this, !isConsumeTouch()));
        }
    }

    private void setComponentLayoutParams(int i2, int i3, int i4, int i5, int i6, int i7, Point point) {
        int i8;
        int i9;
        int i10;
        int i11;
        Widget widget;
        if (getInstance() != null && !getInstance().isDestroy()) {
            updateBoxShadow(i2, i3, false);
            UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
            if (uniBoxShadowData == null || uniBoxShadowData.getNormalShadows().size() <= 0) {
                i9 = i2;
                i10 = i3;
                i11 = i4;
                i8 = i5;
            } else {
                i9 = this.mBoxShadowData.getNormalMaxWidth();
                i10 = this.mBoxShadowData.getNormalMaxHeight();
                i11 = i4 - (this.mBoxShadowData.getNormalLeft() / 2);
                i8 = i5 - (this.mBoxShadowData.getNormalTop() / 2);
            }
            FlatGUIContext flatUIContext = getInstance().getFlatUIContext();
            if (flatUIContext != null && flatUIContext.getFlatComponentAncestor(this) != null) {
                if (this instanceof FlatComponent) {
                    FlatComponent flatComponent = (FlatComponent) this;
                    if (!flatComponent.promoteToView(true)) {
                        widget = flatComponent.getOrCreateFlatWidget();
                        setWidgetParams(widget, flatUIContext, point, i9, i10, i11, i6, i8, i7);
                    }
                }
                widget = flatUIContext.getAndroidViewWidget(this);
                setWidgetParams(widget, flatUIContext, point, i9, i10, i11, i6, i8, i7);
            } else if (this.mHost != null) {
                if (isFixed()) {
                    setFixedHostLayoutParams(this.mHost, i9, i10, i11, i6, i8, i7);
                } else {
                    setHostLayoutParams(this.mHost, i9, i10, i11, i6, i8, i7);
                }
                recordInteraction(i2, i3);
                this.mPreRealWidth = i2;
                this.mPreRealHeight = i3;
                this.mPreRealLeft = i4;
                this.mPreRealRight = i6;
                this.mPreRealTop = i5;
                onFinishLayout();
            }
        }
    }

    private void setFixedHostLayoutParams(T t2, int i2, int i3, int i4, int i5, int i6, int i7) {
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        layoutParams.width = i2;
        layoutParams.height = i3;
        setMarginsSupportRTL(layoutParams, i4, i6, i5, i7);
        t2.setLayoutParams(layoutParams);
        this.mInstance.moveFixedView(t2);
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("Weex_Fixed_Style", "WXComponent:setLayout :" + i4 + Operators.SPACE_STR + i6 + Operators.SPACE_STR + i2 + Operators.SPACE_STR + i3);
            WXLogUtils.d("Weex_Fixed_Style", "WXComponent:setLayout Left:" + getStyles().getLeft() + Operators.SPACE_STR + ((int) getStyles().getTop()));
        }
    }

    private void setFixedSize(String str) {
        ViewGroup.LayoutParams layoutParams;
        if (PROP_FS_MATCH_PARENT.equals(str)) {
            this.mFixedProp = -1;
        } else if (PROP_FS_WRAP_CONTENT.equals(str)) {
            this.mFixedProp = -2;
        } else {
            this.mFixedProp = 0;
            return;
        }
        T t2 = this.mHost;
        if (t2 != null && (layoutParams = t2.getLayoutParams()) != null) {
            layoutParams.height = this.mFixedProp;
            layoutParams.width = this.mFixedProp;
            this.mHost.setLayoutParams(layoutParams);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0103  */
    /* JADX WARN: Removed duplicated region for block: B:29:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private void setWidgetParams(com.taobao.weex.ui.flat.widget.Widget r11, com.taobao.weex.ui.flat.FlatGUIContext r12, android.graphics.Point r13, int r14, int r15, int r16, int r17, int r18, int r19) {
        /*
        // Method dump skipped, instructions count: 298
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXComponent.setWidgetParams(com.taobao.weex.ui.flat.widget.Widget, com.taobao.weex.ui.flat.FlatGUIContext, android.graphics.Point, int, int, int, int, int, int):void");
    }

    private boolean shouldCancelHardwareAccelerate() {
        IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
        boolean z2 = true;
        z2 = true;
        if (wxConfigAdapter != null) {
            try {
                z2 = Boolean.parseBoolean(wxConfigAdapter.getConfig("android_weex_test_gpu", "cancel_hardware_accelerate", AbsoluteConst.TRUE));
            } catch (Exception e2) {
                WXLogUtils.e(WXLogUtils.getStackTrace(e2));
            }
            WXLogUtils.i("cancel_hardware_accelerate : " + z2);
        }
        return z2;
    }

    private void updateElevation() {
        float elevation = getAttrs().getElevation(getInstance().getInstanceViewPortWidthWithFloat());
        if (!Float.isNaN(elevation)) {
            ViewCompat.setElevation(getHostView(), elevation);
        }
    }

    private void updateStyleByPesudo(Map<String, Object> map) {
        if (getInstance() != null) {
            new GraphicActionUpdateStyle(getInstance(), getRef(), map, getPadding(), getMargin(), getBorder(), true).executeActionOnRender();
            if (getLayoutWidth() != 0.0f || getLayoutHeight() != 0.0f) {
                if (map.containsKey("width")) {
                    WXBridgeManager.getInstance().setStyleWidth(getInstanceId(), getRef(), getLayoutWidth());
                } else if (map.containsKey("height")) {
                    WXBridgeManager.getInstance().setStyleHeight(getInstanceId(), getRef(), getLayoutHeight());
                }
            }
        }
    }

    public void addAnimationForElement(Map<String, Object> map) {
        if (map != null && !map.isEmpty()) {
            if (this.animations == null) {
                this.animations = new ConcurrentLinkedQueue<>();
            }
            this.animations.add(new Pair<>(getRef(), map));
        }
    }

    public final void addClickListener(OnClickListener onClickListener) {
        View realView;
        if (onClickListener != null && (realView = getRealView()) != null) {
            if (this.mHostClickListeners == null) {
                this.mHostClickListeners = new ArrayList();
            }
            if (!realView.hasOnClickListeners()) {
                realView.setClickable(true);
                realView.setOnClickListener(new View.OnClickListener(this) { // from class: com.taobao.weex.ui.component.WXComponent.4
                    final WXComponent this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        if (this.this$0.mGesture == null || !this.this$0.mGesture.isTouchEventConsumedByAdvancedGesture()) {
                            for (OnClickListener onClickListener2 : this.this$0.mHostClickListeners) {
                                if (onClickListener2 != null) {
                                    onClickListener2.onHostViewClick();
                                }
                            }
                        }
                    }
                });
            }
            this.mHostClickListeners.add(onClickListener);
        }
    }

    public void addEvent(String str) {
        if (this.mAppendEvents == null) {
            this.mAppendEvents = new HashSet();
        }
        if (!TextUtils.isEmpty(str) && !this.mAppendEvents.contains(str)) {
            View realView = getRealView();
            if (str.equals(Constants.Event.LAYEROVERFLOW)) {
                addLayerOverFlowListener(getRef());
            }
            if (str.equals(Constants.Event.CLICK)) {
                if (realView != null) {
                    if (this.mClickEventListener == null) {
                        this.mClickEventListener = new OnClickListenerImp();
                    }
                    addClickListener(this.mClickEventListener);
                } else {
                    return;
                }
            } else if (str.equals(Constants.Event.FOCUS) || str.equals(Constants.Event.BLUR)) {
                if (!this.mHasAddFocusListener) {
                    this.mHasAddFocusListener = true;
                    addFocusChangeListener(new OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.WXComponent.1
                        final WXComponent this$0;

                        {
                            this.this$0 = r4;
                        }

                        @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
                        public void onFocusChange(boolean z2) {
                            HashMap hashMap = new HashMap();
                            hashMap.put("timeStamp", Long.valueOf(System.currentTimeMillis()));
                            this.this$0.fireEvent(z2 ? Constants.Event.FOCUS : Constants.Event.BLUR, hashMap);
                        }
                    });
                }
            } else if (!needGestureDetector(str)) {
                Scrollable parentScroller = getParentScroller();
                if (parentScroller != null) {
                    if (str.equals(Constants.Event.APPEAR)) {
                        parentScroller.bindAppearEvent(this);
                    } else if (str.equals(Constants.Event.DISAPPEAR)) {
                        parentScroller.bindDisappearEvent(this);
                    }
                } else {
                    return;
                }
            } else if (realView != null) {
                if (realView instanceof WXGestureObservable) {
                    if (this.mGesture == null) {
                        this.mGesture = new WXGesture(this, this.mContext);
                        this.mGesture.setPreventMoveEvent(WXUtils.getBoolean(getAttrs().get(Constants.Name.PREVENT_MOVE_EVENT), false).booleanValue());
                    }
                    if (this.mGestureType == null) {
                        this.mGestureType = new HashSet();
                    }
                    if (!ViewHover.VIEW_HOVER_EVENT.equals(str)) {
                        this.mGestureType.add(str);
                    }
                    ((WXGestureObservable) realView).registerGestureListener(this.mGesture);
                } else {
                    WXLogUtils.e(realView.getClass().getSimpleName() + " don't implement WXGestureObservable, so no gesture is supported.");
                }
            } else {
                return;
            }
            this.mAppendEvents.add(str);
        }
    }

    public final void addFocusChangeListener(OnFocusChangeListener onFocusChangeListener) {
        View realView;
        if (onFocusChangeListener != null && (realView = getRealView()) != null) {
            if (this.mFocusChangeListeners == null) {
                this.mFocusChangeListeners = new ArrayList();
                realView.setFocusable(true);
                realView.setOnFocusChangeListener(new View.OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.WXComponent.3
                    final WXComponent this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.view.View.OnFocusChangeListener
                    public void onFocusChange(View view, boolean z2) {
                        for (OnFocusChangeListener onFocusChangeListener2 : this.this$0.mFocusChangeListeners) {
                            if (onFocusChangeListener2 != null) {
                                onFocusChangeListener2.onFocusChange(z2);
                            }
                        }
                    }
                });
            }
            this.mFocusChangeListeners.add(onFocusChangeListener);
        }
    }

    public void addLayerOverFlowListener(String str) {
        if (getInstance() != null) {
            getInstance().addLayerOverFlowListener(str);
        }
    }

    protected void appendEventToDOM(String str) {
    }

    public void applyComponentEvents() {
        applyEvents();
    }

    public void applyLayoutAndEvent(AbsBasicComponent absBasicComponent) {
        if (!isLazy()) {
            AbsBasicComponent absBasicComponent2 = absBasicComponent;
            if (absBasicComponent == null) {
                absBasicComponent2 = this;
            }
            WXComponent<T> wXComponent = (WXComponent) absBasicComponent2;
            bindComponent(wXComponent);
            setSafeLayout(wXComponent);
            setPadding(absBasicComponent2.getPadding(), absBasicComponent2.getBorder());
            applyEvents();
        }
    }

    public void applyLayoutOnly() {
        if (!isLazy()) {
            setSafeLayout(this);
            setPadding(getPadding(), getBorder());
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsBasicComponent
    protected final void bindComponent(AbsBasicComponent absBasicComponent) {
        bindComponent(absBasicComponent);
        if (getInstance() != null) {
            setViewPortWidth(getInstance().getInstanceViewPortWidthWithFloat());
        }
        WXComponent wXComponent = (WXComponent) absBasicComponent;
        this.mParent = wXComponent.getParent();
        this.mType = wXComponent.getType();
    }

    public void bindComponentData(AbsBasicComponent absBasicComponent) {
        if (!isLazy()) {
            AbsBasicComponent absBasicComponent2 = absBasicComponent;
            if (absBasicComponent == null) {
                absBasicComponent2 = this;
            }
            WXComponent<T> wXComponent = (WXComponent) absBasicComponent2;
            bindComponent(wXComponent);
            updateStyles(wXComponent);
            updateAttrs(absBasicComponent2);
            updateExtra(absBasicComponent2.getExtra());
        }
    }

    public void bindData(WXComponent wXComponent) {
        bindComponentData(wXComponent);
    }

    public void bindHolder(IFComponentHolder iFComponentHolder) {
        this.mHolder = iFComponentHolder;
    }

    public boolean canRecycled() {
        return (!isFixed() || !isSticky()) && getAttrs().canRecycled();
    }

    protected void clearBoxShadow() {
        if (!UniBoxShadowUtil.isBoxShadowEnabled()) {
            WXLogUtils.w("BoxShadow", "box-shadow disabled");
            return;
        }
        BorderDrawable borderDrawable = this.mBackgroundDrawable;
        if (borderDrawable != null) {
            borderDrawable.updateBoxShadowData(null);
        }
        if (!(getHostView() == null || this.mBackgroundDrawable == null || !(getHostView().getBackground() instanceof LayerDrawable))) {
            if (this.mRippleBackground == null) {
                WXViewUtils.setBackGround(getHostView(), new LayerDrawable(new Drawable[]{this.mBackgroundDrawable}), this);
            } else {
                WXViewUtils.setBackGround(getHostView(), new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable}), this);
            }
        }
        if (this.mBoxShadowData != null) {
            this.mBoxShadowData = null;
        }
        UniNormalBoxShadowDrawable uniNormalBoxShadowDrawable = this.mBoxShadowDrawable;
        if (uniNormalBoxShadowDrawable != null) {
            if (uniNormalBoxShadowDrawable.getBitmap() != null) {
                this.mBoxShadowDrawable.getBitmap().recycle();
            }
            this.mBoxShadowDrawable = null;
        }
        if (this.mInsetBoxShadowDrawable != null) {
            this.mInsetBoxShadowDrawable = null;
        }
    }

    public void clearPreLayout() {
        this.mPreRealLeft = 0;
        this.mPreRealRight = 0;
        this.mPreRealWidth = 0;
        this.mPreRealHeight = 0;
        this.mPreRealTop = 0;
    }

    public void computeVisiblePointInViewCoordinate(PointF pointF) {
        View realView = getRealView();
        pointF.set((float) realView.getScrollX(), (float) realView.getScrollY());
    }

    public boolean containsEvent(String str) {
        Set<String> set;
        return getEvents().contains(str) || ((set = this.mAppendEvents) != null && set.contains(str));
    }

    public boolean containsGesture(WXGestureType wXGestureType) {
        Set<String> set = this.mGestureType;
        return set != null && set.contains(wXGestureType.toString());
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x01bc, code lost:
        if (r4.equals(com.taobao.weex.common.Constants.Name.BORDER_RIGHT_COLOR) == false) goto L_0x0098;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public java.lang.Object convertEmptyProperty(java.lang.String r4, java.lang.Object r5) {
        /*
        // Method dump skipped, instructions count: 543
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXComponent.convertEmptyProperty(java.lang.String, java.lang.Object):java.lang.Object");
    }

    public final void createView() {
        if (!isLazy()) {
            createViewImpl();
        }
    }

    public void createViewImpl() {
        Context context = this.mContext;
        if (context != null) {
            T initComponentHostView = initComponentHostView(context);
            this.mHost = initComponentHostView;
            if (initComponentHostView == null && !isVirtualComponent()) {
                initView();
            }
            T t2 = this.mHost;
            if (t2 != null) {
                if (t2.getId() == -1) {
                    this.mHost.setId(WXViewUtils.generateViewId());
                }
                ComponentObserver componentObserver = getInstance().getComponentObserver();
                if (componentObserver != null) {
                    componentObserver.onViewCreated(this, this.mHost);
                }
                invokePendingComponetMethod();
            }
            onHostViewInitialized(this.mHost);
            return;
        }
        WXLogUtils.e("createViewImpl", "Context is null");
    }

    public void destroy() {
        T hostView;
        if (getInstance() != null) {
            clearBoxShadow();
            ComponentObserver componentObserver = getInstance().getComponentObserver();
            if (componentObserver != null) {
                componentObserver.onPreDestory(this);
            }
            if (!WXEnvironment.isApkDebugable() || WXUtils.isUiThread()) {
                T t2 = this.mHost;
                if (t2 != null && t2.getLayerType() == 2 && isLayerTypeEnabled()) {
                    this.mHost.setLayerType(0, null);
                }
                removeAllEvent();
                removeStickyStyle();
                if (isFixed() && (hostView = getHostView()) != null) {
                    getInstance().removeFixedView(hostView);
                }
                ContentBoxMeasurement contentBoxMeasurement = this.contentBoxMeasurement;
                if (contentBoxMeasurement != null) {
                    contentBoxMeasurement.destroy();
                    this.contentBoxMeasurement = null;
                }
                this.mIsDestroyed = true;
                ConcurrentLinkedQueue<Pair<String, Map<String, Object>>> concurrentLinkedQueue = this.animations;
                if (concurrentLinkedQueue != null) {
                    concurrentLinkedQueue.clear();
                }
                ViewHover viewHover = this.mHover;
                if (viewHover != null) {
                    viewHover.destroy();
                    this.mHover = null;
                }
                this.mInstance = null;
                List<OnFocusChangeListener> list = this.mFocusChangeListeners;
                if (list != null) {
                    list.clear();
                }
                List<OnClickListener> list2 = this.mHostClickListeners;
                if (list2 != null) {
                    list2.clear();
                    return;
                }
                return;
            }
            throw new WXRuntimeException("[WXComponent] destroy can only be called in main thread");
        }
    }

    public View detachViewAndClearPreInfo() {
        T t2 = this.mHost;
        this.mPreRealLeft = 0;
        this.mPreRealRight = 0;
        this.mPreRealWidth = 0;
        this.mPreRealHeight = 0;
        this.mPreRealTop = 0;
        return t2;
    }

    protected final WXComponent findComponent(String str) {
        if (this.mInstance == null || str == null) {
            return null;
        }
        return WXSDKManager.getInstance().getWXRenderManager().getWXComponent(this.mInstance.getInstanceId(), str);
    }

    public Object findTypeParent(AbsBasicComponent absBasicComponent, Class cls) {
        if (absBasicComponent.getClass() == cls) {
            return absBasicComponent;
        }
        WXComponent wXComponent = (WXComponent) absBasicComponent;
        if (wXComponent.getParent() == null) {
            return null;
        }
        findTypeParent(wXComponent.getParent(), cls);
        return null;
    }

    public final void fireEvent(String str) {
        fireEvent(str, null);
    }

    public final void fireEvent(String str, Map<String, Object> map) {
        if (WXUtils.getBoolean(getAttrs().get("fireEventSyn"), false).booleanValue()) {
            fireEventWait(str, map);
        } else {
            fireEvent(str, map, null, null);
        }
    }

    protected final void fireEvent(String str, Map<String, Object> map, Map<String, Object> map2) {
        fireEvent(str, map, map2, null);
    }

    public final EventResult fireEventWait(String str, Map<String, Object> map) {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        AnonymousClass2 r02 = new EventResult(this, countDownLatch) { // from class: com.taobao.weex.ui.component.WXComponent.2
            final WXComponent this$0;
            final CountDownLatch val$waitLatch;

            {
                this.this$0 = r4;
                this.val$waitLatch = r5;
            }

            @Override // com.taobao.weex.bridge.EventResult
            public void onCallback(Object obj) {
                onCallback(obj);
                this.val$waitLatch.countDown();
            }
        };
        try {
            fireEvent(str, map, null, r02);
            countDownLatch.await(50, TimeUnit.MILLISECONDS);
            return r02;
        } catch (Exception e2) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.e("fireEventWait", e2);
            }
            return r02;
        }
    }

    public int getAbsoluteX() {
        return this.mAbsoluteX;
    }

    public int getAbsoluteY() {
        return this.mAbsoluteY;
    }

    public String getAttrByKey(String str) {
        return "default";
    }

    public Rect getComponentSize() {
        Rect rect = new Rect();
        if (!(this.mHost == null || this.mInstance.getContainerView() == null)) {
            int[] iArr = new int[2];
            int[] iArr2 = new int[2];
            this.mHost.getLocationOnScreen(iArr);
            this.mInstance.getContainerView().getLocationOnScreen(iArr2);
            int i2 = iArr[0] - iArr2[0];
            int i3 = (iArr[1] - this.mStickyOffset) - iArr2[1];
            rect.set(i2, i3, ((int) getLayoutWidth()) + i2, ((int) getLayoutHeight()) + i3);
        }
        return rect;
    }

    public Context getContext() {
        return this.mContext;
    }

    public Scrollable getFirstScroller() {
        if (this instanceof Scrollable) {
            return (Scrollable) this;
        }
        return null;
    }

    public T getHostView() {
        return this.mHost;
    }

    public ViewHover getHover() {
        return this.mHover;
    }

    public WXSDKInstance getInstance() {
        return this.mInstance;
    }

    public String getInstanceId() {
        return this.mInstance.getInstanceId();
    }

    public int getLayoutTopOffsetForSibling() {
        return 0;
    }

    protected BorderDrawable getOrCreateBorder() {
        if (this.mBackgroundDrawable == null) {
            this.mBackgroundDrawable = new BorderDrawable();
            T t2 = this.mHost;
            if (t2 != null) {
                WXViewUtils.setBackGround(t2, null, this);
                if (this.mRippleBackground == null) {
                    if (this.mBoxShadowDrawable != null) {
                        WXViewUtils.setBackGround(this.mHost, new LayerDrawable(new Drawable[]{this.mBoxShadowDrawable, this.mBackgroundDrawable}), this);
                    } else if (this.mInsetBoxShadowDrawable != null) {
                        WXViewUtils.setBackGround(this.mHost, new LayerDrawable(new Drawable[]{this.mBackgroundDrawable, this.mInsetBoxShadowDrawable}), this);
                    } else {
                        WXViewUtils.setBackGround(this.mHost, this.mBackgroundDrawable, this);
                    }
                } else if (this.mBoxShadowDrawable != null) {
                    WXViewUtils.setBackGround(this.mHost, new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBoxShadowDrawable, this.mBackgroundDrawable}), this);
                } else if (this.mInsetBoxShadowDrawable != null) {
                    WXViewUtils.setBackGround(this.mHost, new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable, this.mInsetBoxShadowDrawable}), this);
                } else {
                    WXViewUtils.setBackGround(this.mHost, new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable}), this);
                }
            }
        }
        return this.mBackgroundDrawable;
    }

    public WXVContainer getParent() {
        return this.mParent;
    }

    public Scrollable getParentScroller() {
        WXVContainer parent;
        WXVContainer wXVContainer = this;
        do {
            parent = wXVContainer.getParent();
            if (parent == null) {
                return null;
            }
            if (parent instanceof Scrollable) {
                return (Scrollable) parent;
            }
            wXVContainer = parent;
        } while (!parent.getRef().equals(ROOT));
        return null;
    }

    public View getRealView() {
        return this.mHost;
    }

    public long getRenderObjectPtr() {
        if (getBasicComponentData().isRenderPtrEmpty()) {
            getBasicComponentData().setRenderObjectPr(NativeRenderObjectUtils.nativeGetRenderObject(getInstanceId(), getRef()));
        }
        return getBasicComponentData().getRenderObjectPr();
    }

    public int getStickyOffset() {
        return this.mStickyOffset;
    }

    public WXTransition getTransition() {
        return this.mTransition;
    }

    public int getType() {
        return this.mType;
    }

    @Deprecated
    public View getView() {
        return this.mHost;
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsBasicComponent
    public float getViewPortWidthForFloat() {
        if (getInstance() != null) {
            return getInstance().getInstanceViewPortWidthWithFloat();
        }
        return 720.0f;
    }

    public String getViewTreeKey() {
        if (this.mViewTreeKey == null) {
            if (getParent() == null) {
                this.mViewTreeKey = hashCode() + "_" + getRef();
            } else {
                this.mViewTreeKey = hashCode() + "_" + getRef() + "_" + getParent().indexOf(this);
            }
        }
        return this.mViewTreeKey;
    }

    public String getVisibility() {
        try {
            return (String) getStyles().get(Constants.Name.VISIBILITY);
        } catch (Exception e2) {
            return "visible";
        }
    }

    public boolean hasScrollParent(WXComponent wXComponent) {
        if (wXComponent.getParent() == null) {
            return true;
        }
        if (wXComponent.getParent() instanceof WXBaseScroller) {
            return false;
        }
        return hasScrollParent(wXComponent.getParent());
    }

    @WXComponentProp(name = "hoverClass")
    public void hoverClass(String str) {
        JSONObject parseObject = JSON.parseObject(str);
        if (parseObject != null) {
            ViewHover viewHover = this.mHover;
            if (viewHover == null) {
                this.mHover = new ViewHover(this, parseObject);
            } else {
                viewHover.update(parseObject);
            }
            if (!getEvents().contains(ViewHover.VIEW_HOVER_EVENT)) {
                addEvent(ViewHover.VIEW_HOVER_EVENT);
            }
        }
    }

    @WXComponentProp(name = "hoverStartTime")
    public void hoverStartTime(int i2) {
        if (this.mHover == null) {
            this.mHover = new ViewHover(this);
        }
        this.mHover.setHoverStartTime(i2);
    }

    @WXComponentProp(name = "hoverStayTime")
    public void hoverStayTime(int i2) {
        if (this.mHover == null) {
            this.mHover = new ViewHover(this);
        }
        this.mHover.setHoverStayTime(i2);
    }

    @WXComponentProp(name = "hoverStopPropagation")
    public void hoverStopPropagation(boolean z2) {
        if (this.mHover == null) {
            this.mHover = new ViewHover(this);
        }
        this.mHover.setHoverStopPropagation(z2);
        if (!getEvents().contains(ViewHover.VIEW_HOVER_EVENT)) {
            addEvent(ViewHover.VIEW_HOVER_EVENT);
        }
        if (this.mParent != null && z2) {
            this.mParent.setHoverReceiveTouch(false);
        }
    }

    protected T initComponentHostView(Context context) {
        return null;
    }

    protected void initElevation(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.mElevation = WXViewUtils.getRealSubPxByWidth(WXUtils.getFloat(str, Float.valueOf(0.0f)).floatValue(), this.mInstance.getInstanceViewPortWidthWithFloat());
            if (this.mBoxShadowData != null) {
                clearBoxShadow();
            }
            StateListAnimator stateListAnimator = new StateListAnimator();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.play(ObjectAnimator.ofFloat(getHostView(), Constants.Name.ELEVATION, this.mElevation).setDuration(0L)).with(ObjectAnimator.ofFloat(getHostView(), View.TRANSLATION_Z, 0.0f).setDuration(this.PRESSED_ANIM_DURATION));
            animatorSet.setInterpolator(new FastOutLinearInInterpolator());
            stateListAnimator.addState(this.PRESSED_ENABLED_STATE_SET, animatorSet);
            AnimatorSet animatorSet2 = new AnimatorSet();
            animatorSet2.play(ObjectAnimator.ofFloat(getHostView(), Constants.Name.ELEVATION, this.mElevation).setDuration(0L)).with(ObjectAnimator.ofFloat(getHostView(), View.TRANSLATION_Z, 0.0f).setDuration(this.PRESSED_ANIM_DURATION));
            animatorSet2.setInterpolator(new FastOutLinearInInterpolator());
            stateListAnimator.addState(this.FOCUSED_ENABLED_STATE_SET, animatorSet2);
            AnimatorSet animatorSet3 = new AnimatorSet();
            ArrayList arrayList = new ArrayList();
            arrayList.add(ObjectAnimator.ofFloat(getHostView(), Constants.Name.ELEVATION, this.mElevation).setDuration(0L));
            if (Build.VERSION.SDK_INT <= 24) {
                arrayList.add(ObjectAnimator.ofFloat(getHostView(), View.TRANSLATION_Z, getHostView().getTranslationZ()).setDuration(this.PRESSED_ANIM_DELAY));
            }
            arrayList.add(ObjectAnimator.ofFloat(getHostView(), View.TRANSLATION_Z, 0.0f).setDuration(this.PRESSED_ANIM_DURATION));
            animatorSet3.playSequentially((Animator[]) arrayList.toArray(new ObjectAnimator[0]));
            animatorSet3.setInterpolator(new FastOutLinearInInterpolator());
            stateListAnimator.addState(this.ENABLED_STATE_SET, animatorSet3);
            AnimatorSet animatorSet4 = new AnimatorSet();
            animatorSet4.play(ObjectAnimator.ofFloat(getHostView(), Constants.Name.ELEVATION, 0.0f).setDuration(0L)).with(ObjectAnimator.ofFloat(getHostView(), View.TRANSLATION_Z, 0.0f).setDuration(0L));
            animatorSet4.setInterpolator(new FastOutLinearInInterpolator());
            stateListAnimator.addState(this.EMPTY_STATE_SET, animatorSet4);
            getHostView().setStateListAnimator(stateListAnimator);
        }
    }

    @Deprecated
    protected void initView() {
        Context context = this.mContext;
        if (context != null) {
            T initComponentHostView = initComponentHostView(context);
            this.mHost = initComponentHostView;
            if (initComponentHostView != null) {
                invokePendingComponetMethod();
            }
        }
    }

    public void interceptFocusAndBlurEvent() {
        this.mHasAddFocusListener = true;
    }

    public final void invoke(String str, JSONArray jSONArray) {
        if (getHostView() == null || getRealView() == null) {
            this.mPendingComponetMethodQueue.offer(new UniMethodData(str, jSONArray));
            return;
        }
        Invoker methodInvoker = this.mHolder.getMethodInvoker(str);
        if (methodInvoker != null) {
            try {
                getInstance().getNativeInvokeHelper().invoke(this, methodInvoker, jSONArray);
            } catch (Exception e2) {
                WXLogUtils.e("[WXComponent] updateProperties :class:" + getClass() + "method:" + methodInvoker.toString() + " function " + WXLogUtils.getStackTrace(e2));
            }
        } else {
            onInvokeUnknownMethod(str, jSONArray);
        }
    }

    protected boolean isConsumeTouch() {
        List<OnClickListener> list = this.mHostClickListeners;
        return (list != null && list.size() > 0) || this.mGesture != null;
    }

    public boolean isDestoryed() {
        return this.mIsDestroyed;
    }

    public boolean isDisabled() {
        return this.mIsDisabled;
    }

    public boolean isFixed() {
        return getStyles().isFixed();
    }

    public boolean isFlatUIEnabled() {
        return this.mParent != null && this.mParent.isFlatUIEnabled();
    }

    public boolean isLayerTypeEnabled() {
        return getInstance().isLayerTypeEnabled();
    }

    public boolean isLazy() {
        boolean z2 = true;
        if (this.mLazy) {
            return true;
        }
        if (this.mParent == null || !this.mParent.isLazy()) {
            z2 = false;
        }
        return z2;
    }

    public boolean isPreventGesture() {
        return this.isPreventGesture;
    }

    protected boolean isRippleEnabled() {
        boolean z2 = false;
        try {
            z2 = WXUtils.getBoolean(getAttrs().get(Constants.Name.RIPPLE_ENABLED), false).booleanValue();
        } catch (Throwable th) {
        }
        return z2;
    }

    public boolean isSticky() {
        return getStyles().isSticky();
    }

    public boolean isUsing() {
        return this.isUsing;
    }

    public boolean isVirtualComponent() {
        boolean z2 = true;
        if (this.mType != 1) {
            z2 = false;
        }
        return z2;
    }

    public boolean isWaste() {
        return this.waste;
    }

    protected boolean ismHasFocusChangeListener(OnFocusChangeListener onFocusChangeListener) {
        List<OnFocusChangeListener> list = this.mFocusChangeListeners;
        if (list != null) {
            return list.contains(onFocusChangeListener);
        }
        return false;
    }

    protected void layoutDirectionDidChanged(boolean z2) {
    }

    public void lazy(boolean z2) {
        this.mLazy = z2;
    }

    protected MeasureOutput measure(int i2, int i3) {
        MeasureOutput measureOutput = new MeasureOutput();
        int i4 = this.mFixedProp;
        if (i4 != 0) {
            measureOutput.width = i4;
            measureOutput.height = this.mFixedProp;
        } else {
            measureOutput.width = i2;
            measureOutput.height = i3;
        }
        return measureOutput;
    }

    public void nativeUpdateAttrs(Map<String, Object> map) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getKey() != null) {
                updateNativeAttr(entry.getKey(), entry.getValue());
            }
        }
    }

    public void notifyAppearStateChange(String str, String str2) {
        if (containsEvent(Constants.Event.APPEAR) || containsEvent(Constants.Event.DISAPPEAR)) {
            HashMap hashMap = new HashMap();
            hashMap.put("direction", str2);
            fireEvent(str, hashMap);
        }
    }

    public void notifyNativeSizeChanged(int i2, int i3) {
        if (this.mNeedLayoutOnAnimation) {
            UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
            int i4 = i2;
            int i5 = i3;
            if (uniBoxShadowData != null) {
                i4 = i2;
                i5 = i3;
                if (uniBoxShadowData.getNormalShadows().size() > 0) {
                    i4 = i2 - this.mBoxShadowData.getNormalLeft();
                    i5 = i3 - this.mBoxShadowData.getNormalTop();
                }
            }
            WXBridgeManager instance = WXBridgeManager.getInstance();
            instance.setStyleWidth(getInstanceId(), getRef(), (float) i4);
            instance.setStyleHeight(getInstanceId(), getRef(), (float) i5);
        }
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public boolean onActivityBack() {
        return false;
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityCreate() {
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityDestroy() {
        ConcurrentLinkedQueue<UniMethodData> concurrentLinkedQueue = this.mPendingComponetMethodQueue;
        if (concurrentLinkedQueue != null) {
            concurrentLinkedQueue.clear();
        }
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityPause() {
    }

    public void onActivityResult(int i2, int i3, Intent intent) {
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityResume() {
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityStart() {
    }

    @Override // com.taobao.weex.IWXActivityStateListener
    public void onActivityStop() {
    }

    protected void onCreate() {
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    public void onFinishLayout() {
        Object obj = getStyles() != null ? getStyles().get(Constants.Name.BACKGROUND_IMAGE) : null;
        if (obj != null) {
            setBackgroundImage(obj.toString());
        }
    }

    public void onHostViewInitialized(T t2) {
        AbsAnimationHolder absAnimationHolder = this.mAnimationHolder;
        if (absAnimationHolder != null) {
            absAnimationHolder.execute(this.mInstance, this);
        }
        setActiveTouchListener();
    }

    protected void onInvokeUnknownMethod(String str, JSONArray jSONArray) {
    }

    public void onRenderFinish(int i2) {
        if (WXTracing.isAvailable()) {
            double nanosToMillis = Stopwatch.nanosToMillis(this.mTraceInfo.uiThreadNanos);
            if (i2 == 2 || i2 == 0) {
                WXTracing.TraceEvent newEvent = WXTracing.newEvent("DomExecute", getInstanceId(), this.mTraceInfo.rootEventId);
                newEvent.ph = "X";
                newEvent.ts = this.mTraceInfo.domThreadStart;
                newEvent.tname = "DOMThread";
                newEvent.name = getComponentType();
                newEvent.classname = getClass().getSimpleName();
                if (getParent() != null) {
                    newEvent.parentRef = getParent().getRef();
                }
                newEvent.submit();
            }
            if (i2 != 2 && i2 != 1) {
                return;
            }
            if (this.mTraceInfo.uiThreadStart != -1) {
                WXTracing.TraceEvent newEvent2 = WXTracing.newEvent("UIExecute", getInstanceId(), this.mTraceInfo.rootEventId);
                newEvent2.ph = "X";
                newEvent2.duration = nanosToMillis;
                newEvent2.ts = this.mTraceInfo.uiThreadStart;
                newEvent2.name = getComponentType();
                newEvent2.classname = getClass().getSimpleName();
                if (getParent() != null) {
                    newEvent2.parentRef = getParent().getRef();
                }
                newEvent2.submit();
            } else if (WXEnvironment.isApkDebugable()) {
                isLazy();
            }
        }
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
    }

    public void postAnimation(AbsAnimationHolder absAnimationHolder) {
        this.mAnimationHolder = absAnimationHolder;
    }

    public void readyToRender() {
        if (this.mParent != null && getInstance() != null && getInstance().isTrackComponent()) {
            this.mParent.readyToRender();
        }
    }

    public void recycled() {
        isFixed();
    }

    public void refreshData(WXComponent wXComponent) {
    }

    @Deprecated
    public void registerActivityStateListener() {
    }

    public void removeAllEvent() {
        if (getEvents().size() >= 1) {
            WXEvent events = getEvents();
            int size = events.size();
            int i2 = 0;
            while (i2 < size && i2 < events.size()) {
                String str = (String) events.get(i2);
                if (str != null) {
                    removeEventFromView(str);
                }
                i2++;
            }
            Set<String> set = this.mAppendEvents;
            if (set != null) {
                set.clear();
            }
            Set<String> set2 = this.mGestureType;
            if (set2 != null) {
                set2.clear();
            }
            this.mGesture = null;
            if (getRealView() != null && (getRealView() instanceof WXGestureObservable)) {
                ((WXGestureObservable) getRealView()).registerGestureListener(null);
            }
            T t2 = this.mHost;
            if (t2 != null) {
                t2.setOnFocusChangeListener(null);
                List<OnClickListener> list = this.mHostClickListeners;
                if (list != null && list.size() > 0) {
                    this.mHostClickListeners.clear();
                    this.mHost.setOnClickListener(null);
                }
            }
        }
    }

    protected final void removeClickListener(OnClickListener onClickListener) {
        this.mHostClickListeners.remove(onClickListener);
    }

    public void removeEvent(String str) {
        if (!TextUtils.isEmpty(str)) {
            if (str.equals(Constants.Event.LAYEROVERFLOW)) {
                removeLayerOverFlowListener(getRef());
            }
            if (getEvents() != null) {
                getEvents().remove(str);
            }
            Set<String> set = this.mAppendEvents;
            if (set != null) {
                set.remove(str);
            }
            Set<String> set2 = this.mGestureType;
            if (set2 != null) {
                set2.remove(str);
            }
            removeEventFromView(str);
        }
    }

    public void removeEventFromView(String str) {
        if (!(!str.equals(Constants.Event.CLICK) || getRealView() == null || this.mHostClickListeners == null)) {
            if (this.mClickEventListener == null) {
                this.mClickEventListener = new OnClickListenerImp();
            }
            this.mHostClickListeners.remove(this.mClickEventListener);
            if (this.mHostClickListeners.size() < 1) {
                getRealView().setOnClickListener(null);
                getRealView().setClickable(false);
            }
        }
        Scrollable parentScroller = getParentScroller();
        if (str.equals(Constants.Event.APPEAR) && parentScroller != null) {
            parentScroller.unbindAppearEvent(this);
        }
        if (str.equals(Constants.Event.DISAPPEAR) && parentScroller != null) {
            parentScroller.unbindDisappearEvent(this);
        }
    }

    public void removeLayerOverFlowListener(String str) {
        if (getInstance() != null) {
            getInstance().removeLayerOverFlowListener(str);
        }
    }

    public final void removeStickyStyle() {
        Scrollable parentScroller;
        if (isSticky() && (parentScroller = getParentScroller()) != null) {
            parentScroller.unbindStickStyle(this);
        }
    }

    public void removeVirtualComponent() {
    }

    protected void setAriaHidden(boolean z2) {
        T hostView = getHostView();
        if (hostView != null) {
            hostView.setImportantForAccessibility(z2 ? 2 : 1);
        }
    }

    protected void setAriaLabel(String str) {
        T hostView = getHostView();
        if (hostView != null) {
            hostView.setContentDescription(str);
        }
    }

    public void setBackgroundColor(String str) {
        if (!TextUtils.isEmpty(str)) {
            int color = WXResourceUtils.getColor(str);
            if (isRippleEnabled()) {
                Drawable prepareBackgroundRipple = prepareBackgroundRipple();
                this.mRippleBackground = prepareBackgroundRipple;
                if (prepareBackgroundRipple != null) {
                    if (this.mBackgroundDrawable == null) {
                        WXViewUtils.setBackGround(this.mHost, prepareBackgroundRipple, this);
                        return;
                    } else {
                        WXViewUtils.setBackGround(this.mHost, this.mBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBoxShadowDrawable, this.mBackgroundDrawable, this.mInsetBoxShadowDrawable}) : this.mInsetBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable, this.mInsetBoxShadowDrawable}) : new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable}), this);
                        return;
                    }
                }
            }
            if (color != 0 || this.mBackgroundDrawable != null) {
                getOrCreateBorder().setColor(color);
            }
        }
    }

    public void setBackgroundImage(String str) {
        if ("".equals(str.trim())) {
            getOrCreateBorder().setImage(null);
            return;
        }
        getOrCreateBorder().setImage(WXResourceUtils.getShader(str, getLayoutSize().getWidth(), getLayoutSize().getHeight()));
    }

    public void setBorderColor(String str, String str2) {
        int color;
        if (!TextUtils.isEmpty(str2) && (color = WXResourceUtils.getColor(str2)) != Integer.MIN_VALUE) {
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -1989576717:
                    if (str.equals(Constants.Name.BORDER_RIGHT_COLOR)) {
                        c2 = 0;
                        break;
                    }
                    break;
                case -1470826662:
                    if (str.equals(Constants.Name.BORDER_TOP_COLOR)) {
                        c2 = 1;
                        break;
                    }
                    break;
                case -1308858324:
                    if (str.equals(Constants.Name.BORDER_BOTTOM_COLOR)) {
                        c2 = 2;
                        break;
                    }
                    break;
                case -242276144:
                    if (str.equals(Constants.Name.BORDER_LEFT_COLOR)) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 722830999:
                    if (str.equals(Constants.Name.BORDER_COLOR)) {
                        c2 = 4;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    getOrCreateBorder().setBorderColor(CSSShorthand.EDGE.RIGHT, color);
                    return;
                case 1:
                    getOrCreateBorder().setBorderColor(CSSShorthand.EDGE.TOP, color);
                    return;
                case 2:
                    getOrCreateBorder().setBorderColor(CSSShorthand.EDGE.BOTTOM, color);
                    return;
                case 3:
                    getOrCreateBorder().setBorderColor(CSSShorthand.EDGE.LEFT, color);
                    return;
                case 4:
                    getOrCreateBorder().setBorderColor(CSSShorthand.EDGE.ALL, color);
                    return;
                default:
                    return;
            }
        }
    }

    public void setBorderRadius(String str, float f2) {
        if (f2 >= 0.0f) {
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -1228066334:
                    if (str.equals(Constants.Name.BORDER_TOP_LEFT_RADIUS)) {
                        c2 = 0;
                        break;
                    }
                    break;
                case 333432965:
                    if (str.equals(Constants.Name.BORDER_TOP_RIGHT_RADIUS)) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 581268560:
                    if (str.equals(Constants.Name.BORDER_BOTTOM_LEFT_RADIUS)) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 588239831:
                    if (str.equals(Constants.Name.BORDER_BOTTOM_RIGHT_RADIUS)) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 1349188574:
                    if (str.equals(Constants.Name.BORDER_RADIUS)) {
                        c2 = 4;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    getOrCreateBorder().setBorderRadius(CSSShorthand.CORNER.BORDER_TOP_LEFT, WXViewUtils.getRealSubPxByWidth(f2, this.mInstance.getInstanceViewPortWidthWithFloat()));
                    return;
                case 1:
                    getOrCreateBorder().setBorderRadius(CSSShorthand.CORNER.BORDER_TOP_RIGHT, WXViewUtils.getRealSubPxByWidth(f2, this.mInstance.getInstanceViewPortWidthWithFloat()));
                    return;
                case 2:
                    getOrCreateBorder().setBorderRadius(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT, WXViewUtils.getRealSubPxByWidth(f2, this.mInstance.getInstanceViewPortWidthWithFloat()));
                    return;
                case 3:
                    getOrCreateBorder().setBorderRadius(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT, WXViewUtils.getRealSubPxByWidth(f2, this.mInstance.getInstanceViewPortWidthWithFloat()));
                    return;
                case 4:
                    getOrCreateBorder().setBorderRadius(CSSShorthand.CORNER.ALL, WXViewUtils.getRealSubPxByWidth(f2, this.mInstance.getInstanceViewPortWidthWithFloat()));
                    return;
                default:
                    return;
            }
        }
    }

    public void setBorderStyle(String str, String str2) {
        if (!TextUtils.isEmpty(str2)) {
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -1974639039:
                    if (str.equals(Constants.Name.BORDER_RIGHT_STYLE)) {
                        c2 = 0;
                        break;
                    }
                    break;
                case -1455888984:
                    if (str.equals(Constants.Name.BORDER_TOP_STYLE)) {
                        c2 = 1;
                        break;
                    }
                    break;
                case -1293920646:
                    if (str.equals(Constants.Name.BORDER_BOTTOM_STYLE)) {
                        c2 = 2;
                        break;
                    }
                    break;
                case -227338466:
                    if (str.equals(Constants.Name.BORDER_LEFT_STYLE)) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 737768677:
                    if (str.equals(Constants.Name.BORDER_STYLE)) {
                        c2 = 4;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    getOrCreateBorder().setBorderStyle(CSSShorthand.EDGE.RIGHT, str2);
                    return;
                case 1:
                    getOrCreateBorder().setBorderStyle(CSSShorthand.EDGE.TOP, str2);
                    return;
                case 2:
                    getOrCreateBorder().setBorderStyle(CSSShorthand.EDGE.BOTTOM, str2);
                    return;
                case 3:
                    getOrCreateBorder().setBorderStyle(CSSShorthand.EDGE.LEFT, str2);
                    return;
                case 4:
                    getOrCreateBorder().setBorderStyle(CSSShorthand.EDGE.ALL, str2);
                    return;
                default:
                    return;
            }
        }
    }

    public void setBorderWidth(String str, float f2) {
        if (f2 >= 0.0f) {
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -1971292586:
                    if (str.equals(Constants.Name.BORDER_RIGHT_WIDTH)) {
                        c2 = 0;
                        break;
                    }
                    break;
                case -1452542531:
                    if (str.equals(Constants.Name.BORDER_TOP_WIDTH)) {
                        c2 = 1;
                        break;
                    }
                    break;
                case -1290574193:
                    if (str.equals(Constants.Name.BORDER_BOTTOM_WIDTH)) {
                        c2 = 2;
                        break;
                    }
                    break;
                case -223992013:
                    if (str.equals(Constants.Name.BORDER_LEFT_WIDTH)) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 741115130:
                    if (str.equals(Constants.Name.BORDER_WIDTH)) {
                        c2 = 4;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    getOrCreateBorder().setBorderWidth(CSSShorthand.EDGE.RIGHT, f2);
                    return;
                case 1:
                    getOrCreateBorder().setBorderWidth(CSSShorthand.EDGE.TOP, f2);
                    return;
                case 2:
                    getOrCreateBorder().setBorderWidth(CSSShorthand.EDGE.BOTTOM, f2);
                    return;
                case 3:
                    getOrCreateBorder().setBorderWidth(CSSShorthand.EDGE.LEFT, f2);
                    return;
                case 4:
                    getOrCreateBorder().setBorderWidth(CSSShorthand.EDGE.ALL, f2);
                    return;
                default:
                    return;
            }
        }
    }

    protected void setContentBoxMeasurement(ContentBoxMeasurement contentBoxMeasurement) {
        this.contentBoxMeasurement = contentBoxMeasurement;
        this.mInstance.addContentBoxMeasurement(getRenderObjectPtr(), contentBoxMeasurement);
        WXBridgeManager.getInstance().bindMeasurementToRenderObject(getRenderObjectPtr());
    }

    public void setDemission(GraphicSize graphicSize, GraphicPosition graphicPosition) {
        setLayoutPosition(graphicPosition);
        setLayoutSize(graphicSize);
    }

    public void setDisabled(boolean z2) {
        this.mIsDisabled = z2;
        T t2 = this.mHost;
        if (t2 != null) {
            t2.setEnabled(!z2);
        }
    }

    @WXComponentProp(name = Constants.Name.ELEVATION)
    public void setElevation(String str) {
        initElevation(str);
    }

    public void setHostLayoutParams(T t2, int i2, int i3, int i4, int i5, int i6, int i7) {
        FrameLayout.LayoutParams layoutParams;
        if (this.mParent == null) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(i2, i3);
            setMarginsSupportRTL(layoutParams2, i4, i6, i5, i7);
            layoutParams = layoutParams2;
        } else {
            layoutParams = this.mParent.getChildLayoutParams(this, t2, i2, i3, i4, i5, i6, i7);
        }
        if (layoutParams != null) {
            t2.setLayoutParams(layoutParams);
        }
    }

    public void setHoverClassStatus(boolean z2) {
        Map<String, Object> updateStatusAndGetUpdateStyles = this.mHover.updateStatusAndGetUpdateStyles(z2);
        if (updateStatusAndGetUpdateStyles != null) {
            if (z2) {
                boolean contains = updateStatusAndGetUpdateStyles.keySet().contains("width");
                boolean contains2 = updateStatusAndGetUpdateStyles.keySet().contains("height");
                if (contains || contains2) {
                    this.mPseudoResetGraphicSize = new GraphicSize(getLayoutSize().getWidth(), getLayoutSize().getHeight());
                }
                if (contains) {
                    getLayoutSize().setWidth(WXViewUtils.getRealPxByWidth(WXUtils.parseFloat(updateStatusAndGetUpdateStyles.get("width")), getViewPortWidthForFloat()));
                } else if (contains2) {
                    getLayoutSize().setHeight(WXViewUtils.getRealPxByWidth(WXUtils.parseFloat(updateStatusAndGetUpdateStyles.get("height")), getViewPortWidthForFloat()));
                }
            } else {
                GraphicSize graphicSize = this.mPseudoResetGraphicSize;
                if (graphicSize != null) {
                    setLayoutSize(graphicSize);
                }
            }
        }
        updateStyleByPesudo(updateStatusAndGetUpdateStyles);
    }

    public void setHoverReceiveTouch(boolean z2) {
        if (getHover() != null) {
            getHover().setReceiveTouch(z2);
        }
        if (this.mParent != null) {
            this.mParent.setHoverReceiveTouch(z2);
        }
    }

    public void setLayout(WXComponent wXComponent) {
        int i2;
        int i3;
        setLayoutSize(wXComponent.getLayoutSize());
        setLayoutPosition(wXComponent.getLayoutPosition());
        setPaddings(wXComponent.getPadding());
        setMargins(wXComponent.getMargin());
        setBorders(wXComponent.getBorder());
        boolean isLayoutRTL = wXComponent.isLayoutRTL();
        setIsLayoutRTL(isLayoutRTL);
        if (isLayoutRTL != wXComponent.isLastLayoutDirectionRTL) {
            wXComponent.isLastLayoutDirectionRTL = isLayoutRTL;
            layoutDirectionDidChanged(isLayoutRTL);
        }
        float f2 = 0.0f;
        try {
            if (!(getLayoutSize().getWidth() == 0.0f || getLayoutSize().getHeight() == 0.0f)) {
                parseAnimation();
            }
        } catch (Exception e2) {
        }
        int i4 = 0;
        boolean z2 = this.mParent == null;
        if (!z2) {
            i4 = this.mParent.getChildrenLayoutTopOffset();
        }
        CSSShorthand cSSShorthand = z2 ? new CSSShorthand() : this.mParent.getPadding();
        CSSShorthand cSSShorthand2 = z2 ? new CSSShorthand() : this.mParent.getBorder();
        int width = (int) getLayoutSize().getWidth();
        int height = (int) getLayoutSize().getHeight();
        if (isFixed()) {
            i2 = (int) (getLayoutPosition().getLeft() - ((float) getInstance().getRenderContainerPaddingLeft()));
            i3 = ((int) (getLayoutPosition().getTop() - ((float) getInstance().getRenderContainerPaddingTop()))) + i4;
        } else {
            i2 = (int) ((getLayoutPosition().getLeft() - cSSShorthand.get(CSSShorthand.EDGE.LEFT)) - cSSShorthand2.get(CSSShorthand.EDGE.LEFT));
            i3 = ((int) ((getLayoutPosition().getTop() - cSSShorthand.get(CSSShorthand.EDGE.TOP)) - cSSShorthand2.get(CSSShorthand.EDGE.TOP))) + i4;
        }
        int i5 = (int) getMargin().get(CSSShorthand.EDGE.RIGHT);
        int i6 = (int) getMargin().get(CSSShorthand.EDGE.BOTTOM);
        Point point = new Point((int) getLayoutPosition().getLeft(), (int) getLayoutPosition().getTop());
        if (this.mPreRealWidth != width || this.mPreRealHeight != height || this.mPreRealLeft != i2 || this.mPreRealRight != i5 || this.mPreRealTop != i3) {
            if ((this instanceof WXCell) && height >= WXPerformance.VIEW_LIMIT_HEIGHT && width >= WXPerformance.VIEW_LIMIT_WIDTH) {
                this.mInstance.getApmForInstance().updateDiffStats(WXInstanceApm.KEY_PAGE_STATS_CELL_EXCEED_NUM, 1.0d);
                this.mInstance.getWXPerformance().cellExceedNum++;
            }
            this.mAbsoluteY = (int) (z2 ? 0.0f : ((float) this.mParent.getAbsoluteY()) + getCSSLayoutTop());
            if (!z2) {
                f2 = ((float) this.mParent.getAbsoluteX()) + getCSSLayoutLeft();
            }
            this.mAbsoluteX = (int) f2;
            T t2 = this.mHost;
            if (t2 != null) {
                if (!(t2 instanceof ViewGroup) && this.mAbsoluteY + height > this.mInstance.getWeexHeight() + 1) {
                    if (!this.mInstance.mEnd) {
                        this.mInstance.onOldFsRenderTimeLogic();
                    }
                    if (!this.mInstance.isNewFsEnd) {
                        this.mInstance.isNewFsEnd = true;
                        this.mInstance.getApmForInstance().arriveNewFsRenderTime();
                    }
                }
                MeasureOutput measure = measure(width, height);
                setComponentLayoutParams(measure.width, measure.height, i2, i3, i5, i6, point);
            }
        }
    }

    public void setMarginsSupportRTL(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, int i3, int i4, int i5) {
        marginLayoutParams.setMargins(i2, i3, i4, i5);
        if (marginLayoutParams instanceof FrameLayout.LayoutParams) {
            ((FrameLayout.LayoutParams) marginLayoutParams).gravity = 51;
        }
    }

    public void setNeedLayoutOnAnimation(boolean z2) {
        this.mNeedLayoutOnAnimation = z2;
    }

    public void setOpacity(float f2) {
        if (f2 >= 0.0f && f2 <= 1.0f && this.mHost.getAlpha() != f2) {
            int openGLRenderLimitValue = WXRenderManager.getOpenGLRenderLimitValue();
            if (isLayerTypeEnabled()) {
                this.mHost.setLayerType(2, null);
            }
            if (isLayerTypeEnabled() && shouldCancelHardwareAccelerate() && openGLRenderLimitValue > 0) {
                float f3 = (float) openGLRenderLimitValue;
                if (getLayoutHeight() > f3 || getLayoutWidth() > f3) {
                    this.mHost.setLayerType(0, null);
                }
            }
            this.mHost.setAlpha(f2);
        }
    }

    public void setPadding(AbsCSSShorthand absCSSShorthand, AbsCSSShorthand absCSSShorthand2) {
        int i2 = (int) (absCSSShorthand.get(CSSShorthand.EDGE.LEFT) + absCSSShorthand2.get(CSSShorthand.EDGE.LEFT));
        int i3 = (int) (absCSSShorthand.get(CSSShorthand.EDGE.TOP) + absCSSShorthand2.get(CSSShorthand.EDGE.TOP));
        int i4 = (int) (absCSSShorthand.get(CSSShorthand.EDGE.RIGHT) + absCSSShorthand2.get(CSSShorthand.EDGE.RIGHT));
        int i5 = (int) (absCSSShorthand.get(CSSShorthand.EDGE.BOTTOM) + absCSSShorthand2.get(CSSShorthand.EDGE.BOTTOM));
        if (this instanceof FlatComponent) {
            FlatComponent flatComponent = (FlatComponent) this;
            if (!flatComponent.promoteToView(true)) {
                flatComponent.getOrCreateFlatWidget().setContentBox(i2, i3, i4, i5);
                return;
            }
        }
        if (this.mHost != null) {
            UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
            int i6 = i2;
            int i7 = i3;
            int i8 = i4;
            int i9 = i5;
            if (uniBoxShadowData != null) {
                int i10 = i2;
                int i11 = i4;
                if (uniBoxShadowData.getNormalLeft() > 0) {
                    int normalLeft = this.mBoxShadowData.getNormalLeft() / 2;
                    i10 = i2 + normalLeft;
                    i11 = i4 + normalLeft;
                }
                i6 = i10;
                i7 = i3;
                i8 = i11;
                i9 = i5;
                if (this.mBoxShadowData.getNormalTop() > 0) {
                    int normalTop = this.mBoxShadowData.getNormalTop() / 2;
                    i7 = i3 + normalTop;
                    i9 = i5 + normalTop;
                    i8 = i11;
                    i6 = i10;
                }
            }
            this.mHost.setPadding(i6, i7, i8, i9);
        }
    }

    @WXComponentProp(name = "preventGesture")
    public void setPreventGesture(boolean z2) {
        this.isPreventGesture = z2;
        addEvent("preventGesture");
    }

    public boolean setProperty(String str, Object obj) {
        if (str == null || getInstance() == null) {
            return true;
        }
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1989576717:
                if (str.equals(Constants.Name.BORDER_RIGHT_COLOR)) {
                    c2 = 0;
                    break;
                }
                break;
            case -1974639039:
                if (str.equals(Constants.Name.BORDER_RIGHT_STYLE)) {
                    c2 = 1;
                    break;
                }
                break;
            case -1971292586:
                if (str.equals(Constants.Name.BORDER_RIGHT_WIDTH)) {
                    c2 = 2;
                    break;
                }
                break;
            case -1501175880:
                if (str.equals(Constants.Name.PADDING_LEFT)) {
                    c2 = 3;
                    break;
                }
                break;
            case -1470826662:
                if (str.equals(Constants.Name.BORDER_TOP_COLOR)) {
                    c2 = 4;
                    break;
                }
                break;
            case -1455888984:
                if (str.equals(Constants.Name.BORDER_TOP_STYLE)) {
                    c2 = 5;
                    break;
                }
                break;
            case -1452542531:
                if (str.equals(Constants.Name.BORDER_TOP_WIDTH)) {
                    c2 = 6;
                    break;
                }
                break;
            case -1383228885:
                if (str.equals("bottom")) {
                    c2 = 7;
                    break;
                }
                break;
            case -1375815020:
                if (str.equals(Constants.Name.MIN_WIDTH)) {
                    c2 = '\b';
                    break;
                }
                break;
            case -1308858324:
                if (str.equals(Constants.Name.BORDER_BOTTOM_COLOR)) {
                    c2 = '\t';
                    break;
                }
                break;
            case -1293920646:
                if (str.equals(Constants.Name.BORDER_BOTTOM_STYLE)) {
                    c2 = '\n';
                    break;
                }
                break;
            case -1290574193:
                if (str.equals(Constants.Name.BORDER_BOTTOM_WIDTH)) {
                    c2 = 11;
                    break;
                }
                break;
            case -1267206133:
                if (str.equals("opacity")) {
                    c2 = '\f';
                    break;
                }
                break;
            case -1228066334:
                if (str.equals(Constants.Name.BORDER_TOP_LEFT_RADIUS)) {
                    c2 = '\r';
                    break;
                }
                break;
            case -1221029593:
                if (str.equals("height")) {
                    c2 = 14;
                    break;
                }
                break;
            case -1111969773:
                if (str.equals(Constants.Name.ARIA_HIDDEN)) {
                    c2 = 15;
                    break;
                }
                break;
            case -1081309778:
                if (str.equals("margin")) {
                    c2 = 16;
                    break;
                }
                break;
            case -1063257157:
                if (str.equals(Constants.Name.ALIGN_ITEMS)) {
                    c2 = 17;
                    break;
                }
                break;
            case -1044792121:
                if (str.equals(Constants.Name.MARGIN_TOP)) {
                    c2 = 18;
                    break;
                }
                break;
            case -975171706:
                if (str.equals(Constants.Name.FLEX_DIRECTION)) {
                    c2 = 19;
                    break;
                }
                break;
            case -906066005:
                if (str.equals(Constants.Name.MAX_HEIGHT)) {
                    c2 = 20;
                    break;
                }
                break;
            case -863700117:
                if (str.equals(Constants.Name.ARIA_LABEL)) {
                    c2 = 21;
                    break;
                }
                break;
            case -806339567:
                if (str.equals("padding")) {
                    c2 = 22;
                    break;
                }
                break;
            case -289173127:
                if (str.equals(Constants.Name.MARGIN_BOTTOM)) {
                    c2 = 23;
                    break;
                }
                break;
            case -242276144:
                if (str.equals(Constants.Name.BORDER_LEFT_COLOR)) {
                    c2 = 24;
                    break;
                }
                break;
            case -227338466:
                if (str.equals(Constants.Name.BORDER_LEFT_STYLE)) {
                    c2 = 25;
                    break;
                }
                break;
            case -223992013:
                if (str.equals(Constants.Name.BORDER_LEFT_WIDTH)) {
                    c2 = 26;
                    break;
                }
                break;
            case -133587431:
                if (str.equals(Constants.Name.MIN_HEIGHT)) {
                    c2 = 27;
                    break;
                }
                break;
            case 115029:
                if (str.equals("top")) {
                    c2 = 28;
                    break;
                }
                break;
            case 3145721:
                if (str.equals(Constants.Name.FLEX)) {
                    c2 = 29;
                    break;
                }
                break;
            case 3317767:
                if (str.equals("left")) {
                    c2 = 30;
                    break;
                }
                break;
            case 3506294:
                if (str.equals(Constants.Name.ROLE)) {
                    c2 = 31;
                    break;
                }
                break;
            case 90130308:
                if (str.equals(Constants.Name.PADDING_TOP)) {
                    c2 = ' ';
                    break;
                }
                break;
            case 108511772:
                if (str.equals("right")) {
                    c2 = '!';
                    break;
                }
                break;
            case 113126854:
                if (str.equals("width")) {
                    c2 = '\"';
                    break;
                }
                break;
            case 202355100:
                if (str.equals(Constants.Name.PADDING_BOTTOM)) {
                    c2 = '#';
                    break;
                }
                break;
            case 270940796:
                if (str.equals(Constants.Name.DISABLED)) {
                    c2 = '$';
                    break;
                }
                break;
            case 333432965:
                if (str.equals(Constants.Name.BORDER_TOP_RIGHT_RADIUS)) {
                    c2 = '%';
                    break;
                }
                break;
            case 400381634:
                if (str.equals(Constants.Name.MAX_WIDTH)) {
                    c2 = '&';
                    break;
                }
                break;
            case 581268560:
                if (str.equals(Constants.Name.BORDER_BOTTOM_LEFT_RADIUS)) {
                    c2 = '\'';
                    break;
                }
                break;
            case 588239831:
                if (str.equals(Constants.Name.BORDER_BOTTOM_RIGHT_RADIUS)) {
                    c2 = '(';
                    break;
                }
                break;
            case 713848971:
                if (str.equals(Constants.Name.PADDING_RIGHT)) {
                    c2 = ')';
                    break;
                }
                break;
            case 717381201:
                if (str.equals(Constants.Name.PREVENT_MOVE_EVENT)) {
                    c2 = '*';
                    break;
                }
                break;
            case 722830999:
                if (str.equals(Constants.Name.BORDER_COLOR)) {
                    c2 = '+';
                    break;
                }
                break;
            case 737768677:
                if (str.equals(Constants.Name.BORDER_STYLE)) {
                    c2 = ',';
                    break;
                }
                break;
            case 741115130:
                if (str.equals(Constants.Name.BORDER_WIDTH)) {
                    c2 = '-';
                    break;
                }
                break;
            case 743055051:
                if (str.equals(Constants.Name.BOX_SHADOW)) {
                    c2 = '.';
                    break;
                }
                break;
            case 747463061:
                if (str.equals(PROP_FIXED_SIZE)) {
                    c2 = '/';
                    break;
                }
                break;
            case 747804969:
                if (str.equals("position")) {
                    c2 = '0';
                    break;
                }
                break;
            case 975087886:
                if (str.equals(Constants.Name.MARGIN_RIGHT)) {
                    c2 = '1';
                    break;
                }
                break;
            case 1287124693:
                if (str.equals("backgroundColor")) {
                    c2 = '2';
                    break;
                }
                break;
            case 1292595405:
                if (str.equals(Constants.Name.BACKGROUND_IMAGE)) {
                    c2 = '3';
                    break;
                }
                break;
            case 1349188574:
                if (str.equals(Constants.Name.BORDER_RADIUS)) {
                    c2 = '4';
                    break;
                }
                break;
            case 1744216035:
                if (str.equals(Constants.Name.FLEX_WRAP)) {
                    c2 = '5';
                    break;
                }
                break;
            case 1767100401:
                if (str.equals(Constants.Name.ALIGN_SELF)) {
                    c2 = '6';
                    break;
                }
                break;
            case 1860657097:
                if (str.equals(Constants.Name.JUSTIFY_CONTENT)) {
                    c2 = '7';
                    break;
                }
                break;
            case 1941332754:
                if (str.equals(Constants.Name.VISIBILITY)) {
                    c2 = '8';
                    break;
                }
                break;
            case 1970934485:
                if (str.equals(Constants.Name.MARGIN_LEFT)) {
                    c2 = '9';
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
            case 4:
            case '\t':
            case 24:
            case '+':
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setBorderColor(str, string);
                return true;
            case 1:
            case 5:
            case '\n':
            case 25:
            case ',':
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setBorderStyle(str, string2);
                return true;
            case 2:
            case 3:
            case 6:
            case 7:
            case '\b':
            case 11:
            case 14:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 22:
            case 23:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case ' ':
            case '!':
            case '\"':
            case '#':
            case '&':
            case ')':
            case '-':
            case '1':
            case '5':
            case '6':
            case Opcodes.LSTORE:
            case Opcodes.DSTORE:
                return true;
            case '\f':
                Float f2 = WXUtils.getFloat(obj, Float.valueOf(1.0f));
                if (f2 == null) {
                    return true;
                }
                setOpacity(f2.floatValue());
                return true;
            case '\r':
            case '%':
            case '\'':
            case '(':
            case '4':
                Float f3 = WXUtils.getFloat(obj, null);
                if (f3 == null) {
                    return true;
                }
                setBorderRadius(str, f3.floatValue());
                return true;
            case 15:
                setAriaHidden(WXUtils.getBoolean(obj, false).booleanValue());
                return true;
            case 21:
                setAriaLabel(WXUtils.getString(obj, ""));
                return true;
            case 31:
                setRole(WXUtils.getString(obj, ""));
                return true;
            case '$':
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                setDisabled(bool.booleanValue());
                setPseudoClassStatus(Constants.PSEUDO.DISABLED, bool.booleanValue());
                return true;
            case '*':
                WXGesture wXGesture = this.mGesture;
                if (wXGesture == null) {
                    return true;
                }
                wXGesture.setPreventMoveEvent(WXUtils.getBoolean(obj, false).booleanValue());
                return true;
            case '.':
                try {
                    getHostView();
                    return true;
                } catch (Throwable th) {
                    th.printStackTrace();
                    return true;
                }
            case '/':
                setFixedSize(WXUtils.getString(obj, PROP_FS_MATCH_PARENT));
                return true;
            case '0':
                String string3 = WXUtils.getString(obj, null);
                if (string3 == null) {
                    return true;
                }
                setSticky(string3);
                return true;
            case '2':
                String string4 = WXUtils.getString(obj, null);
                if (string4 == null) {
                    return true;
                }
                setBackgroundColor(string4);
                return true;
            case '3':
                String string5 = WXUtils.getString(obj, null);
                if (string5 == null || this.mHost == null) {
                    return true;
                }
                setBackgroundImage(string5);
                return true;
            case '8':
                String string6 = WXUtils.getString(obj, null);
                if (string6 == null) {
                    return true;
                }
                setVisibility(string6);
                return true;
            default:
                return false;
        }
    }

    protected void setPseudoClassStatus(String str, boolean z2) {
        WXStyle styles = getStyles();
        Map<String, Map<String, Object>> pesudoStyles = styles.getPesudoStyles();
        if (pesudoStyles != null && pesudoStyles.size() != 0) {
            if (this.mPesudoStatus == null) {
                this.mPesudoStatus = new PesudoStatus();
            }
            Map<String, Object> updateStatusAndGetUpdateStyles = this.mPesudoStatus.updateStatusAndGetUpdateStyles(str, z2, pesudoStyles, styles.getPesudoResetStyles());
            if (updateStatusAndGetUpdateStyles != null) {
                if (z2) {
                    this.mPseudoResetGraphicSize = new GraphicSize(getLayoutSize().getWidth(), getLayoutSize().getHeight());
                    if (updateStatusAndGetUpdateStyles.keySet().contains("width")) {
                        getLayoutSize().setWidth(WXViewUtils.getRealPxByWidth(WXUtils.parseFloat(styles.getPesudoResetStyles().get("width:active")), getViewPortWidthForFloat()));
                    } else if (updateStatusAndGetUpdateStyles.keySet().contains("height")) {
                        getLayoutSize().setHeight(WXViewUtils.getRealPxByWidth(WXUtils.parseFloat(styles.getPesudoResetStyles().get("height:active")), getViewPortWidthForFloat()));
                    }
                } else {
                    GraphicSize graphicSize = this.mPseudoResetGraphicSize;
                    if (graphicSize != null) {
                        setLayoutSize(graphicSize);
                    }
                }
            }
            updateStyleByPesudo(updateStatusAndGetUpdateStyles);
        }
    }

    protected void setRole(String str) {
        T hostView = getHostView();
        if (hostView != null && !TextUtils.isEmpty(str)) {
            IWXAccessibilityRoleAdapter accessibilityRoleAdapter = WXSDKManager.getInstance().getAccessibilityRoleAdapter();
            String str2 = str;
            if (accessibilityRoleAdapter != null) {
                str2 = accessibilityRoleAdapter.getRole(str);
            }
            ViewCompat.setAccessibilityDelegate(hostView, new AccessibilityDelegateCompat(this, str2) { // from class: com.taobao.weex.ui.component.WXComponent.5
                final WXComponent this$0;
                final String val$finalRole;

                {
                    this.this$0 = r4;
                    this.val$finalRole = r5;
                }

                @Override // androidx.core.view.AccessibilityDelegateCompat
                public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
                    try {
                        onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
                        accessibilityNodeInfoCompat.setRoleDescription(this.val$finalRole);
                    } catch (Throwable th) {
                        WXLogUtils.e("SetRole failed!");
                    }
                }
            });
        }
    }

    public void setSafeLayout(WXComponent wXComponent) {
        if (!TextUtils.isEmpty(wXComponent.getComponentType()) && !TextUtils.isEmpty(wXComponent.getRef()) && wXComponent.getLayoutPosition() != null && wXComponent.getLayoutSize() != null) {
            setLayout(wXComponent);
        }
    }

    public void setSticky(String str) {
        Scrollable parentScroller;
        if (!TextUtils.isEmpty(str) && str.equals("sticky") && (parentScroller = getParentScroller()) != null) {
            parentScroller.bindStickStyle(this);
        }
    }

    public void setStickyOffset(int i2) {
        this.mStickyOffset = i2;
    }

    public void setTransition(WXTransition wXTransition) {
        this.mTransition = wXTransition;
    }

    public void setUsing(boolean z2) {
        this.isUsing = z2;
    }

    public void setVisibility(String str) {
        View realView = getRealView();
        if (realView == null) {
            return;
        }
        if (TextUtils.equals(str, "visible")) {
            realView.setVisibility(0);
        } else if (TextUtils.equals(str, "hidden")) {
            realView.setVisibility(8);
        }
    }

    public void setWaste(boolean z2) {
        if (this.waste != z2) {
            this.waste = z2;
            if (!WXBasicComponentType.RECYCLE_LIST.equals(getParent().getComponentType())) {
                NativeRenderObjectUtils.nativeRenderObjectChildWaste(getRenderObjectPtr(), z2);
            }
            if (z2) {
                getStyles().put(Constants.Name.VISIBILITY, (Object) "hidden");
                if (getHostView() != null) {
                    getHostView().setVisibility(8);
                } else if (!this.mLazy) {
                    lazy(true);
                }
            } else {
                getStyles().put(Constants.Name.VISIBILITY, (Object) "visible");
                if (getHostView() != null) {
                    getHostView().setVisibility(0);
                } else if (!this.mLazy) {
                } else {
                    if (this.mParent == null || !this.mParent.isLazy()) {
                        Statements.initLazyComponent(this, this.mParent);
                    } else {
                        lazy(false);
                    }
                }
            }
        }
    }

    @Override // com.taobao.weex.ui.component.pesudo.OnActivePseudoListner
    public void updateActivePseudo(boolean z2) {
        if (getInstance() != null) {
            setPseudoClassStatus(Constants.PSEUDO.ACTIVE, z2);
        }
    }

    public void updateAttrs(AbsBasicComponent absBasicComponent) {
        if (absBasicComponent != null) {
            updateProperties(absBasicComponent.getAttrs());
        }
    }

    public void updateAttrs(Map<String, Object> map) {
        if (map != null) {
            updateProperties(map);
        }
    }

    protected void updateBoxShadow(int i2, int i3, boolean z2) {
        UniBoxShadowData parseBoxShadow;
        int i4;
        int i5;
        if (!UniBoxShadowUtil.isBoxShadowEnabled() || this.mElevation > 0.0f || getStyles().get(Constants.Name.ELEVATION) != null || getAttrs().get(Constants.Name.ELEVATION) != null) {
            WXLogUtils.w("BoxShadow", "box-shadow disabled");
            if (this.mBoxShadowData != null) {
                clearBoxShadow();
            }
        } else if (getStyles() != null) {
            Object obj = getStyles().get(Constants.Name.BOX_SHADOW);
            Object obj2 = getAttrs().get(Constants.Name.SHADOW_QUALITY);
            if (obj != null && i2 > 0 && i3 > 0) {
                float floatValue = WXUtils.getFloat(obj2, Float.valueOf(0.5f)).floatValue();
                float instanceViewPortWidthWithFloat = getInstance().getInstanceViewPortWidthWithFloat();
                float[] fArr = new float[8];
                fArr[0] = 0.0f;
                fArr[1] = 0.0f;
                fArr[2] = 0.0f;
                fArr[3] = 0.0f;
                fArr[4] = 0.0f;
                fArr[5] = 0.0f;
                fArr[6] = 0.0f;
                fArr[7] = 0.0f;
                WXStyle styles = getStyles();
                if (styles != null) {
                    float floatValue2 = WXUtils.getFloat(styles.get(Constants.Name.BORDER_TOP_LEFT_RADIUS), Float.valueOf(0.0f)).floatValue();
                    fArr[0] = WXViewUtils.getRealSubPxByWidth(floatValue2, instanceViewPortWidthWithFloat);
                    fArr[1] = WXViewUtils.getRealSubPxByWidth(floatValue2, instanceViewPortWidthWithFloat);
                    float floatValue3 = WXUtils.getFloat(styles.get(Constants.Name.BORDER_TOP_RIGHT_RADIUS), Float.valueOf(0.0f)).floatValue();
                    fArr[2] = WXViewUtils.getRealSubPxByWidth(floatValue3, instanceViewPortWidthWithFloat);
                    fArr[3] = WXViewUtils.getRealSubPxByWidth(floatValue3, instanceViewPortWidthWithFloat);
                    float floatValue4 = WXUtils.getFloat(styles.get(Constants.Name.BORDER_BOTTOM_RIGHT_RADIUS), Float.valueOf(0.0f)).floatValue();
                    fArr[4] = WXViewUtils.getRealSubPxByWidth(floatValue4, instanceViewPortWidthWithFloat);
                    fArr[5] = WXViewUtils.getRealSubPxByWidth(floatValue4, instanceViewPortWidthWithFloat);
                    float floatValue5 = WXUtils.getFloat(styles.get(Constants.Name.BORDER_BOTTOM_LEFT_RADIUS), Float.valueOf(0.0f)).floatValue();
                    fArr[6] = WXViewUtils.getRealSubPxByWidth(floatValue5, instanceViewPortWidthWithFloat);
                    fArr[7] = WXViewUtils.getRealSubPxByWidth(floatValue5, instanceViewPortWidthWithFloat);
                    if (styles.containsKey(Constants.Name.BORDER_RADIUS)) {
                        float floatValue6 = WXUtils.getFloat(styles.get(Constants.Name.BORDER_RADIUS), Float.valueOf(0.0f)).floatValue();
                        for (int i6 = 0; i6 < 8; i6++) {
                            fArr[i6] = WXViewUtils.getRealSubPxByWidth(floatValue6, instanceViewPortWidthWithFloat);
                        }
                    }
                }
                UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
                if ((uniBoxShadowData == null || !uniBoxShadowData.equalsUniBoxShadowData(obj.toString(), i2, i3, fArr)) && (parseBoxShadow = UniBoxShadowUtil.parseBoxShadow(i2, i3, obj.toString(), fArr, instanceViewPortWidthWithFloat, floatValue)) != null) {
                    this.mBoxShadowData = parseBoxShadow;
                    UniNormalBoxShadowDrawable normalBoxShadowDrawable = UniBoxShadowUtil.getNormalBoxShadowDrawable(parseBoxShadow, getContext().getResources());
                    UniInsetBoxShadowLayer insetBoxShadowDrawable = UniBoxShadowUtil.getInsetBoxShadowDrawable(parseBoxShadow);
                    if (!(normalBoxShadowDrawable == null && insetBoxShadowDrawable == null)) {
                        if (!(normalBoxShadowDrawable == null || parseBoxShadow == null || !z2 || this.mHost == null)) {
                            int normalMaxWidth = parseBoxShadow.getNormalMaxWidth();
                            int normalMaxHeight = parseBoxShadow.getNormalMaxHeight();
                            boolean z3 = this.mParent == null;
                            CSSShorthand cSSShorthand = z3 ? new CSSShorthand() : this.mParent.getPadding();
                            CSSShorthand cSSShorthand2 = z3 ? new CSSShorthand() : this.mParent.getBorder();
                            int childrenLayoutTopOffset = z3 ? 0 : this.mParent.getChildrenLayoutTopOffset();
                            if (isFixed()) {
                                i4 = (int) (getLayoutPosition().getLeft() - ((float) getInstance().getRenderContainerPaddingLeft()));
                                i5 = ((int) (getLayoutPosition().getTop() - ((float) getInstance().getRenderContainerPaddingTop()))) + childrenLayoutTopOffset;
                            } else {
                                i4 = (int) ((getLayoutPosition().getLeft() - cSSShorthand.get(CSSShorthand.EDGE.LEFT)) - cSSShorthand2.get(CSSShorthand.EDGE.LEFT));
                                i5 = ((int) ((getLayoutPosition().getTop() - cSSShorthand.get(CSSShorthand.EDGE.TOP)) - cSSShorthand2.get(CSSShorthand.EDGE.TOP))) + childrenLayoutTopOffset;
                            }
                            int i7 = (int) getMargin().get(CSSShorthand.EDGE.RIGHT);
                            int i8 = (int) getMargin().get(CSSShorthand.EDGE.BOTTOM);
                            int normalLeft = i4 - (parseBoxShadow.getNormalLeft() / 2);
                            int normalTop = i5 - (parseBoxShadow.getNormalTop() / 2);
                            if (isFixed()) {
                                setFixedHostLayoutParams(this.mHost, normalMaxWidth, normalMaxHeight, normalLeft, i7, normalTop, i8);
                            } else {
                                setHostLayoutParams(this.mHost, normalMaxWidth, normalMaxHeight, normalLeft, i7, normalTop, i8);
                            }
                            setPadding(getPadding(), getBorder());
                        }
                        if (this.mBackgroundDrawable != null) {
                            clearBoxShadow();
                            WXViewUtils.setBackGround(getHostView(), this.mRippleBackground == null ? normalBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{normalBoxShadowDrawable, this.mBackgroundDrawable}) : insetBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{this.mBackgroundDrawable, insetBoxShadowDrawable}) : new LayerDrawable(new Drawable[]{this.mBackgroundDrawable}) : normalBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{this.mRippleBackground, normalBoxShadowDrawable, this.mBackgroundDrawable}) : insetBoxShadowDrawable != null ? new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable, insetBoxShadowDrawable}) : new LayerDrawable(new Drawable[]{this.mRippleBackground, this.mBackgroundDrawable}), this);
                            this.mBoxShadowData = parseBoxShadow;
                            this.mBoxShadowDrawable = normalBoxShadowDrawable;
                            this.mInsetBoxShadowDrawable = insetBoxShadowDrawable;
                            this.mBackgroundDrawable.updateBoxShadowData(parseBoxShadow);
                            return;
                        }
                        clearBoxShadow();
                        this.mBoxShadowData = parseBoxShadow;
                        this.mBoxShadowDrawable = normalBoxShadowDrawable;
                        this.mInsetBoxShadowDrawable = insetBoxShadowDrawable;
                        getOrCreateBorder().updateBoxShadowData(parseBoxShadow);
                    }
                }
            }
        } else {
            WXLogUtils.w("Can not resolve styles");
        }
    }

    public void updateDemission(float f2, float f3, float f4, float f5, float f6, float f7) {
        getLayoutPosition().update(f2, f3, f4, f5);
        getLayoutSize().update(f7, f6);
    }

    public void updateNativeAttr(String str, Object obj) {
        if (str != null) {
            Object obj2 = obj;
            if (obj == null) {
                obj2 = "";
            }
            getBasicComponentData().getAttrs().put(str, obj2);
            NativeRenderObjectUtils.nativeUpdateRenderObjectAttr(getRenderObjectPtr(), str, obj2.toString());
        }
    }

    public void updateNativeStyle(String str, Object obj) {
        if (str != null) {
            Object obj2 = obj;
            if (obj == null) {
                obj2 = "";
            }
            getBasicComponentData().getStyles().put(str, obj2);
            NativeRenderObjectUtils.nativeUpdateRenderObjectStyle(getRenderObjectPtr(), str, obj2.toString());
        }
    }

    public void updateNativeStyles(Map<String, Object> map) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getKey() != null) {
                updateNativeStyle(entry.getKey(), entry.getValue());
            }
        }
    }

    @Deprecated
    public void updateProperties(Map<String, Object> map) {
        if (map == null) {
            return;
        }
        if ((this.mHost != null || isVirtualComponent()) && getInstance() != null) {
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                String string = WXUtils.getString(value, null);
                if (key == null) {
                    WXExceptionUtils.commitCriticalExceptionRT(getInstanceId(), WXErrorCode.WX_RENDER_ERR_NULL_KEY, "updateProperties", WXErrorCode.WX_RENDER_ERR_NULL_KEY.getErrorMsg(), null);
                } else {
                    if (TextUtils.isEmpty(string)) {
                        value = convertEmptyProperty(key, string);
                    }
                    if (setProperty(key, value)) {
                        continue;
                    } else if (this.mHolder != null && getInstance() != null) {
                        Invoker propertyInvoker = this.mHolder.getPropertyInvoker(key);
                        if (propertyInvoker != null) {
                            try {
                                Type[] parameterTypes = propertyInvoker.getParameterTypes();
                                if (parameterTypes.length != 1) {
                                    WXLogUtils.e("[WXComponent] setX method only one parameter：" + propertyInvoker);
                                    return;
                                }
                                propertyInvoker.invoke(this, WXReflectionUtils.parseArgument(parameterTypes[0], value));
                            } catch (Exception e2) {
                                WXLogUtils.e("[WXComponent] updateProperties :class:" + getClass() + "method:" + propertyInvoker.toString() + " function " + WXLogUtils.getStackTrace(e2));
                            }
                        } else {
                            continue;
                        }
                    } else {
                        return;
                    }
                }
            }
            readyToRender();
            if ((this instanceof FlatComponent) && this.mBackgroundDrawable != null) {
                FlatComponent flatComponent = (FlatComponent) this;
                if (!(flatComponent.promoteToView(true) || (flatComponent.getOrCreateFlatWidget() instanceof AndroidViewWidget))) {
                    flatComponent.getOrCreateFlatWidget().setBackgroundAndBorder(this.mBackgroundDrawable);
                }
            }
        }
    }

    public void updateStyles(WXComponent wXComponent) {
        if (wXComponent != null) {
            updateProperties(wXComponent.getStyles());
            applyBorder(wXComponent);
        }
    }

    public void updateStyles(Map<String, Object> map) {
        if (map != null) {
            updateProperties(map);
            applyBorder(this);
        }
    }

    public boolean useFeature() {
        return true;
    }
}
