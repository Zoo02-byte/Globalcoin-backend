package com.taobao.weex.ui.component;

import android.content.Context;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.viewpager.widget.ViewPager;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.common.Constants;
import com.taobao.weex.dom.WXEvent;
import com.taobao.weex.ui.ComponentCreator;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.view.BaseFrameLayout;
import com.taobao.weex.ui.view.WXCircleIndicator;
import com.taobao.weex.ui.view.WXCirclePageAdapter;
import com.taobao.weex.ui.view.WXCircleViewPager;
import com.taobao.weex.ui.view.gesture.WXGestureType;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.constant.AbsoluteConst;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSlider.class */
public class WXSlider extends WXVContainer<FrameLayout> {
    public static final String INDEX;
    public static final String INFINITE;
    private int initIndex;
    private Runnable initRunnable;
    private boolean isInfinite;
    private boolean keepIndex;
    protected WXCirclePageAdapter mAdapter;
    protected WXIndicator mIndicator;
    protected ViewPager.OnPageChangeListener mPageChangeListener;
    protected boolean mShowIndicators;
    WXCircleViewPager mViewPager;
    private float offsetXAccuracy;
    Map<String, Object> params;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSlider$Creator.class */
    public static class Creator implements ComponentCreator {
        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            return new WXSlider(wXSDKInstance, wXVContainer, basicComponentData);
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSlider$FlingGestureListener.class */
    public static class FlingGestureListener extends GestureDetector.SimpleOnGestureListener {
        private WeakReference<WXCircleViewPager> pagerRef;
        private static final int SWIPE_MIN_DISTANCE = WXViewUtils.dip2px(50.0f);
        private static final int SWIPE_MAX_OFF_PATH = WXViewUtils.dip2px(250.0f);
        private static final int SWIPE_THRESHOLD_VELOCITY = WXViewUtils.dip2px(200.0f);

        FlingGestureListener(WXCircleViewPager wXCircleViewPager) {
            this.pagerRef = new WeakReference<>(wXCircleViewPager);
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
            WXCircleViewPager wXCircleViewPager = this.pagerRef.get();
            if (wXCircleViewPager == null) {
                return false;
            }
            try {
                if (Math.abs(motionEvent.getY() - motionEvent2.getY()) > ((float) SWIPE_MAX_OFF_PATH)) {
                    return false;
                }
                float x2 = motionEvent.getX();
                float x3 = motionEvent2.getX();
                int i2 = SWIPE_MIN_DISTANCE;
                if (x2 - x3 > ((float) i2) && Math.abs(f2) > ((float) SWIPE_THRESHOLD_VELOCITY) && wXCircleViewPager.superGetCurrentItem() == 1) {
                    wXCircleViewPager.setCurrentItem(0, false);
                    return true;
                } else if (motionEvent2.getX() - motionEvent.getX() <= ((float) i2) || Math.abs(f2) <= ((float) SWIPE_THRESHOLD_VELOCITY) || wXCircleViewPager.superGetCurrentItem() != 0) {
                    return false;
                } else {
                    wXCircleViewPager.setCurrentItem(1, false);
                    return true;
                }
            } catch (Exception e2) {
                return false;
            }
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSlider$SliderOnScrollListener.class */
    protected static class SliderOnScrollListener implements ViewPager.OnPageChangeListener {
        private float lastPositionOffset = 99.0f;
        private int selectedPosition;
        private WXSlider target;

        public SliderOnScrollListener(WXSlider wXSlider) {
            this.target = wXSlider;
            this.selectedPosition = wXSlider.mViewPager.superGetCurrentItem();
        }

        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageScrollStateChanged(int i2) {
            if (i2 == 0) {
                this.lastPositionOffset = 99.0f;
                this.target.fireEvent(Constants.Event.SCROLL_END);
            } else if (i2 == 1) {
                this.target.fireEvent(Constants.Event.SCROLL_START);
            }
        }

        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageScrolled(int i2, float f2, int i3) {
            float f3 = this.lastPositionOffset;
            if (f3 == 99.0f) {
                this.lastPositionOffset = f2;
            } else if (Math.abs(f2 - f3) >= this.target.offsetXAccuracy) {
                int i4 = this.selectedPosition;
                if (i2 == i4) {
                    HashMap hashMap = new HashMap(1);
                    hashMap.put(Constants.Name.OFFSET_X_RATIO, Float.valueOf(-f2));
                    this.target.fireEvent("scroll", hashMap);
                } else if (i2 < i4) {
                    HashMap hashMap2 = new HashMap(1);
                    hashMap2.put(Constants.Name.OFFSET_X_RATIO, Float.valueOf(1.0f - f2));
                    this.target.fireEvent("scroll", hashMap2);
                }
                this.lastPositionOffset = f2;
            }
        }

        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageSelected(int i2) {
            this.selectedPosition = i2;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSlider$SliderPageChangeListener.class */
    public class SliderPageChangeListener implements ViewPager.OnPageChangeListener {
        private int lastPos = -1;
        final WXSlider this$0;

        protected SliderPageChangeListener(WXSlider wXSlider) {
            this.this$0 = wXSlider;
        }

        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageScrollStateChanged(int i2) {
            FrameLayout frameLayout = (FrameLayout) this.this$0.getHostView();
            if (frameLayout != null) {
                frameLayout.invalidate();
            }
        }

        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageScrolled(int i2, float f2, int i3) {
        }

        /* JADX WARN: Type inference failed for: r0v42, types: [android.view.View] */
        @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
        public void onPageSelected(int i2) {
            if (this.this$0.mAdapter.getRealPosition(i2) != this.lastPos) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("onPageSelected >>>>" + this.this$0.mAdapter.getRealPosition(i2) + " lastPos: " + this.lastPos);
                }
                if (this.this$0.mAdapter != null && this.this$0.mAdapter.getRealCount() != 0) {
                    int realPosition = this.this$0.mAdapter.getRealPosition(i2);
                    if (this.this$0.mChildren != null && realPosition < this.this$0.mChildren.size() && this.this$0.getEvents().size() != 0) {
                        WXEvent events = this.this$0.getEvents();
                        String ref = this.this$0.getRef();
                        if (events.contains(Constants.Event.CHANGE) && WXViewUtils.onScreenArea(this.this$0.getHostView())) {
                            this.this$0.params.put("index", Integer.valueOf(realPosition));
                            HashMap hashMap = new HashMap();
                            HashMap hashMap2 = new HashMap();
                            hashMap2.put("index", Integer.valueOf(realPosition));
                            hashMap.put(TemplateDom.KEY_ATTRS, hashMap2);
                            WXSDKManager.getInstance().fireEvent(this.this$0.getInstanceId(), ref, Constants.Event.CHANGE, this.this$0.params, hashMap);
                        }
                        this.this$0.mViewPager.requestLayout();
                        ((FrameLayout) this.this$0.getHostView()).invalidate();
                        this.lastPos = this.this$0.mAdapter.getRealPosition(i2);
                    }
                }
            }
        }
    }

    public WXSlider(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
        this.isInfinite = true;
        this.params = new HashMap();
        this.offsetXAccuracy = 0.1f;
        this.initIndex = -1;
        this.keepIndex = false;
        this.mPageChangeListener = new SliderPageChangeListener(this);
    }

    @Deprecated
    public WXSlider(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, basicComponentData);
    }

    public int getInitIndex() {
        int intValue = WXUtils.getInteger(getAttrs().get("index"), Integer.valueOf(this.initIndex)).intValue();
        WXCirclePageAdapter wXCirclePageAdapter = this.mAdapter;
        if (wXCirclePageAdapter == null || wXCirclePageAdapter.getCount() == 0) {
            return 0;
        }
        int i2 = intValue;
        if (intValue >= this.mAdapter.getRealCount()) {
            i2 = intValue % this.mAdapter.getRealCount();
        }
        return i2;
    }

    public int getRealIndex(int i2) {
        int i3 = i2;
        if (this.mAdapter.getRealCount() > 0) {
            int i4 = i2;
            if (i2 >= this.mAdapter.getRealCount()) {
                i4 = this.mAdapter.getRealCount() - 1;
            }
            i3 = i4;
            if (isLayoutRTL()) {
                i3 = (this.mAdapter.getRealCount() - 1) - i4;
            }
        }
        return i3;
    }

    private void hackTwoItemsInfiniteScroll() {
        WXCirclePageAdapter wXCirclePageAdapter;
        if (this.mViewPager != null && (wXCirclePageAdapter = this.mAdapter) != null && this.isInfinite) {
            if (wXCirclePageAdapter.getRealCount() == 2) {
                this.mViewPager.setOnTouchListener(new View.OnTouchListener(this, new GestureDetector(getContext(), new FlingGestureListener(this.mViewPager))) { // from class: com.taobao.weex.ui.component.WXSlider.2
                    final WXSlider this$0;
                    final GestureDetector val$gestureDetector;

                    {
                        this.this$0 = r4;
                        this.val$gestureDetector = r5;
                    }

                    @Override // android.view.View.OnTouchListener
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return this.val$gestureDetector.onTouchEvent(motionEvent);
                    }
                });
            } else {
                this.mViewPager.setOnTouchListener(null);
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        WXCircleViewPager wXCircleViewPager;
        addEvent(str);
        if ("scroll".equals(str) && (wXCircleViewPager = this.mViewPager) != null) {
            wXCircleViewPager.addOnPageChangeListener(new SliderOnScrollListener(this));
        }
    }

    public void addIndicator(WXIndicator wXIndicator) {
        FrameLayout frameLayout = (FrameLayout) getHostView();
        if (frameLayout != null) {
            this.mIndicator = wXIndicator;
            WXCircleIndicator hostView = wXIndicator.getHostView();
            if (hostView != null) {
                hostView.setCircleViewPager(this.mViewPager);
                frameLayout.addView(hostView);
            }
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addSubView(View view, int i2) {
        WXCirclePageAdapter wXCirclePageAdapter;
        if (view != null && (wXCirclePageAdapter = this.mAdapter) != null && !(view instanceof WXCircleIndicator)) {
            wXCirclePageAdapter.addPageView(view);
            hackTwoItemsInfiniteScroll();
            if (this.initIndex != -1 && this.mAdapter.getRealCount() > this.initIndex) {
                if (this.initRunnable == null) {
                    this.initRunnable = new Runnable(this) { // from class: com.taobao.weex.ui.component.WXSlider.1
                        final WXSlider this$0;

                        {
                            this.this$0 = r4;
                        }

                        @Override // java.lang.Runnable
                        public void run() {
                            WXSlider wXSlider = this.this$0;
                            wXSlider.initIndex = wXSlider.getInitIndex();
                            WXCircleViewPager wXCircleViewPager = this.this$0.mViewPager;
                            WXSlider wXSlider2 = this.this$0;
                            wXCircleViewPager.setCurrentItem(wXSlider2.getRealIndex(wXSlider2.initIndex));
                            this.this$0.initIndex = -1;
                            this.this$0.initRunnable = null;
                        }
                    };
                }
                this.mViewPager.removeCallbacks(this.initRunnable);
                this.mViewPager.postDelayed(this.initRunnable, 50);
            } else if (!this.keepIndex) {
                this.mViewPager.setCurrentItem(getRealIndex(0));
            }
            WXIndicator wXIndicator = this.mIndicator;
            if (wXIndicator != null) {
                wXIndicator.getHostView().forceLayout();
                this.mIndicator.getHostView().requestLayout();
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean containsGesture(WXGestureType wXGestureType) {
        return containsGesture(wXGestureType);
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        WXCircleViewPager wXCircleViewPager = this.mViewPager;
        if (wXCircleViewPager != null) {
            wXCircleViewPager.stopAutoScroll();
            this.mViewPager.removeAllViews();
            this.mViewPager.destory();
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public ViewGroup.LayoutParams getChildLayoutParams(WXComponent wXComponent, View view, int i2, int i3, int i4, int i5, int i6, int i7) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = new FrameLayout.LayoutParams(i2, i3);
        } else {
            layoutParams.width = i2;
            layoutParams.height = i3;
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            if (wXComponent instanceof WXIndicator) {
                setMarginsSupportRTL((ViewGroup.MarginLayoutParams) layoutParams, i4, i6, i5, i7);
            } else {
                setMarginsSupportRTL((ViewGroup.MarginLayoutParams) layoutParams, 0, 0, 0, 0);
            }
        }
        return layoutParams;
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public ViewGroup getRealView() {
        return this.mViewPager;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public BaseFrameLayout initComponentHostView(Context context) {
        BaseFrameLayout baseFrameLayout = new BaseFrameLayout(context);
        if (getAttrs() != null) {
            this.isInfinite = WXUtils.getBoolean(getAttrs().get("infinite"), true).booleanValue();
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        WXCircleViewPager wXCircleViewPager = new WXCircleViewPager(context);
        this.mViewPager = wXCircleViewPager;
        wXCircleViewPager.setCircle(this.isInfinite);
        this.mViewPager.setLayoutParams(layoutParams);
        WXCirclePageAdapter wXCirclePageAdapter = new WXCirclePageAdapter(this.isInfinite);
        this.mAdapter = wXCirclePageAdapter;
        this.mViewPager.setAdapter(wXCirclePageAdapter);
        baseFrameLayout.addView(this.mViewPager);
        this.mViewPager.addOnPageChangeListener(this.mPageChangeListener);
        registerActivityStateListener();
        return baseFrameLayout;
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent, com.taobao.weex.IWXActivityStateListener
    public void onActivityResume() {
        onActivityResume();
        WXCircleViewPager wXCircleViewPager = this.mViewPager;
        if (wXCircleViewPager != null && wXCircleViewPager.isAutoScroll()) {
            this.mViewPager.startAutoScroll();
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent, com.taobao.weex.IWXActivityStateListener
    public void onActivityStop() {
        onActivityStop();
        WXCircleViewPager wXCircleViewPager = this.mViewPager;
        if (wXCircleViewPager != null) {
            wXCircleViewPager.pauseAutoScroll();
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void remove(WXComponent wXComponent, boolean z2) {
        WXCirclePageAdapter wXCirclePageAdapter;
        if (wXComponent != null && wXComponent.getHostView() != null && (wXCirclePageAdapter = this.mAdapter) != null) {
            wXCirclePageAdapter.removePageView(wXComponent.getHostView());
            hackTwoItemsInfiniteScroll();
            remove(wXComponent, z2);
        }
    }

    @WXComponentProp(name = Constants.Name.AUTO_PLAY)
    public void setAutoPlay(String str) {
        if (TextUtils.isEmpty(str) || str.equals(AbsoluteConst.FALSE)) {
            this.mViewPager.stopAutoScroll();
            return;
        }
        this.mViewPager.stopAutoScroll();
        this.mViewPager.startAutoScroll();
    }

    @WXComponentProp(name = "index")
    public void setIndex(int i2) {
        WXCirclePageAdapter wXCirclePageAdapter;
        WXCirclePageAdapter wXCirclePageAdapter2;
        if (this.mViewPager != null && (wXCirclePageAdapter = this.mAdapter) != null) {
            if (i2 >= wXCirclePageAdapter.getRealCount() || i2 < 0) {
                this.initIndex = i2;
                return;
            }
            int realIndex = getRealIndex(i2);
            this.mViewPager.setCurrentItem(realIndex);
            WXIndicator wXIndicator = this.mIndicator;
            if (wXIndicator != null && wXIndicator.getHostView() != null && this.mIndicator.getHostView().getRealCurrentItem() != realIndex) {
                WXLogUtils.d("setIndex >>>> correction indicator to " + realIndex);
                this.mIndicator.getHostView().setRealCurrentItem(realIndex);
                this.mIndicator.getHostView().invalidate();
                ViewPager.OnPageChangeListener onPageChangeListener = this.mPageChangeListener;
                if (onPageChangeListener != null && (wXCirclePageAdapter2 = this.mAdapter) != null) {
                    onPageChangeListener.onPageSelected(wXCirclePageAdapter2.getFirst() + realIndex);
                }
            }
        }
    }

    @WXComponentProp(name = "interval")
    public void setInterval(int i2) {
        WXCircleViewPager wXCircleViewPager = this.mViewPager;
        if (wXCircleViewPager != null && i2 > 0) {
            wXCircleViewPager.setIntervalTime((long) i2);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void setLayout(WXComponent wXComponent) {
        WXCirclePageAdapter wXCirclePageAdapter = this.mAdapter;
        if (wXCirclePageAdapter != null) {
            wXCirclePageAdapter.setLayoutDirectionRTL(isLayoutRTL());
        }
        setLayout(wXComponent);
    }

    @WXComponentProp(name = Constants.Name.OFFSET_X_ACCURACY)
    public void setOffsetXAccuracy(float f2) {
        this.offsetXAccuracy = f2;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1768064947:
                if (str.equals(Constants.Name.KEEP_INDEX)) {
                    c2 = 0;
                    break;
                }
                break;
            case 66669991:
                if (str.equals(Constants.Name.SCROLLABLE)) {
                    c2 = 1;
                    break;
                }
                break;
            case 100346066:
                if (str.equals("index")) {
                    c2 = 2;
                    break;
                }
                break;
            case 111972721:
                if (str.equals("value")) {
                    c2 = 3;
                    break;
                }
                break;
            case 570418373:
                if (str.equals("interval")) {
                    c2 = 4;
                    break;
                }
                break;
            case 996926241:
                if (str.equals(Constants.Name.SHOW_INDICATORS)) {
                    c2 = 5;
                    break;
                }
                break;
            case 1438608771:
                if (str.equals(Constants.Name.AUTO_PLAY)) {
                    c2 = 6;
                    break;
                }
                break;
            case 1565939262:
                if (str.equals(Constants.Name.OFFSET_X_ACCURACY)) {
                    c2 = 7;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                this.keepIndex = WXUtils.getBoolean(obj, false).booleanValue();
                return true;
            case 1:
                setScrollable(WXUtils.getBoolean(obj, true).booleanValue());
                return true;
            case 2:
                Integer integer = WXUtils.getInteger(obj, null);
                if (integer == null) {
                    return true;
                }
                setIndex(integer.intValue());
                return true;
            case 3:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setValue(string);
                return true;
            case 4:
                Integer integer2 = WXUtils.getInteger(obj, null);
                if (integer2 == null) {
                    return true;
                }
                setInterval(integer2.intValue());
                return true;
            case 5:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setShowIndicators(string2);
                return true;
            case 6:
                String string3 = WXUtils.getString(obj, null);
                if (string3 == null) {
                    return true;
                }
                setAutoPlay(string3);
                return true;
            case 7:
                Float f2 = WXUtils.getFloat(obj, Float.valueOf(0.1f));
                if (f2.floatValue() == 0.0f) {
                    return true;
                }
                setOffsetXAccuracy(f2.floatValue());
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLLABLE)
    public void setScrollable(boolean z2) {
        WXCircleViewPager wXCircleViewPager = this.mViewPager;
        if (wXCircleViewPager != null && this.mAdapter != null) {
            wXCircleViewPager.setScrollable(z2);
        }
    }

    @WXComponentProp(name = Constants.Name.SHOW_INDICATORS)
    public void setShowIndicators(String str) {
        if (TextUtils.isEmpty(str) || str.equals(AbsoluteConst.FALSE)) {
            this.mShowIndicators = false;
        } else {
            this.mShowIndicators = true;
        }
        WXIndicator wXIndicator = this.mIndicator;
        if (wXIndicator != null) {
            wXIndicator.setShowIndicators(this.mShowIndicators);
        }
    }

    @WXComponentProp(name = "value")
    @Deprecated
    public void setValue(String str) {
        if (str != null && getHostView() != 0) {
            try {
                setIndex(Integer.parseInt(str));
            } catch (NumberFormatException e2) {
                WXLogUtils.e("", e2);
            }
        }
    }
}
