package com.taobao.weex.ui.component;

import android.content.Context;
import android.text.TextUtils;
import android.widget.FrameLayout;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXRuntimeException;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.view.WXCircleIndicator;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.feature.weex.extend.DCWXSlider;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXIndicator.class */
public class WXIndicator extends WXComponent<WXCircleIndicator> {
    @Deprecated
    public WXIndicator(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXIndicator(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public WXCircleIndicator initComponentHostView(Context context) {
        WXCircleIndicator wXCircleIndicator = new WXCircleIndicator(context);
        if ((getParent() instanceof WXSlider) || (getParent() instanceof DCWXSlider)) {
            return wXCircleIndicator;
        }
        if (!WXEnvironment.isApkDebugable()) {
            return null;
        }
        throw new WXRuntimeException("WXIndicator initView error.");
    }

    public void onHostViewInitialized(WXCircleIndicator wXCircleIndicator) {
        onHostViewInitialized((WXIndicator) wXCircleIndicator);
        if (getParent() instanceof WXSlider) {
            ((WXSlider) getParent()).addIndicator(this);
        } else if (getParent() instanceof DCWXSlider) {
            ((DCWXSlider) getParent()).addIndicator(this);
        }
    }

    public void setHostLayoutParams(WXCircleIndicator wXCircleIndicator, int i2, int i3, int i4, int i5, int i6, int i7) {
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(i2, i3);
        setMarginsSupportRTL(layoutParams, i4, i6, i5, i7);
        wXCircleIndicator.setLayoutParams(layoutParams);
    }

    @WXComponentProp(name = Constants.Name.ITEM_COLOR)
    public void setItemColor(String str) {
        int color;
        if (!TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setPageColor(color);
            getHostView().forceLayout();
            getHostView().requestLayout();
        }
    }

    @WXComponentProp(name = Constants.Name.ITEM_SELECTED_COLOR)
    public void setItemSelectedColor(String str) {
        int color;
        if (!TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setFillColor(color);
            getHostView().forceLayout();
            getHostView().requestLayout();
        }
    }

    @WXComponentProp(name = Constants.Name.ITEM_SIZE)
    public void setItemSize(int i2) {
        if (i2 >= 0) {
            getHostView().setRadius(WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidthWithFloat()) / 2.0f);
            getHostView().forceLayout();
            getHostView().requestLayout();
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case 1177488820:
                if (str.equals(Constants.Name.ITEM_SIZE)) {
                    c2 = 0;
                    break;
                }
                break;
            case 1873297717:
                if (str.equals(Constants.Name.ITEM_SELECTED_COLOR)) {
                    c2 = 1;
                    break;
                }
                break;
            case 2127804432:
                if (str.equals(Constants.Name.ITEM_COLOR)) {
                    c2 = 2;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                Integer integer = WXUtils.getInteger(obj, null);
                if (integer == null) {
                    return true;
                }
                setItemSize(integer.intValue());
                return true;
            case 1:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setItemSelectedColor(string);
                return true;
            case 2:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setItemColor(string2);
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    public void setShowIndicators(boolean z2) {
        if (getHostView() != null) {
            if (z2) {
                getHostView().setVisibility(0);
            } else {
                getHostView().setVisibility(8);
            }
        }
    }
}
