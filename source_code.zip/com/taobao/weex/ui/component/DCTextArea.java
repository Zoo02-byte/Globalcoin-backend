package com.taobao.weex.ui.component;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.dom.CSSConstants;
import com.taobao.weex.dom.WXAttr;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.view.WXEditText;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.feature.weex.WeexInstanceMgr;
import java.util.HashMap;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCTextArea.class */
public class DCTextArea extends DCWXInput {
    private WXAttr attr;
    private boolean isAutoHeight = false;
    private boolean isLineChange = false;
    private WXComponent.OnFocusChangeListener mOnFocusChangeListener = new WXComponent.OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.DCTextArea.2
        int count = 0;
        final DCTextArea this$0;

        {
            this.this$0 = r4;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void fireEventForFocus(TextView textView) {
            this.this$0.getHostView().postDelayed(new Runnable(this, textView) { // from class: com.taobao.weex.ui.component.DCTextArea.2.1
                final AnonymousClass2 this$1;
                final TextView val$text;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$1 = r4;
                    this.val$text = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (this.this$1.this$0.keyboardHeight == 0.0f) {
                        this.this$1.count++;
                        if (this.this$1.count > 3) {
                            HashMap hashMap = new HashMap(1);
                            HashMap hashMap2 = new HashMap(1);
                            hashMap2.put("value", this.val$text.getText().toString());
                            hashMap2.put("height", Float.valueOf(this.this$1.this$0.keyboardHeight));
                            hashMap.put("detail", hashMap2);
                            this.this$1.this$0.fireEvent(Constants.Event.FOCUS, hashMap);
                            return;
                        }
                        this.this$1.fireEventForFocus(this.val$text);
                        return;
                    }
                    this.this$1.count = 0;
                    HashMap hashMap3 = new HashMap(1);
                    HashMap hashMap4 = new HashMap(1);
                    hashMap4.put("value", this.val$text.getText().toString());
                    hashMap4.put("height", Float.valueOf(this.this$1.this$0.keyboardHeight));
                    hashMap3.put("detail", hashMap4);
                    this.this$1.this$0.fireEvent(Constants.Event.FOCUS, hashMap3);
                }
            }, 200);
        }

        @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
        public void onFocusChange(boolean z2) {
            WXEditText hostView = this.this$0.getHostView();
            if (hostView != null) {
                HashMap hashMap = new HashMap(1);
                HashMap hashMap2 = new HashMap(1);
                hashMap2.put("value", hostView.getText().toString());
                if (!z2) {
                    hashMap2.put("cursor", Integer.valueOf(hostView.getSelectionStart()));
                    hashMap.put("detail", hashMap2);
                    this.this$0.fireEvent(Constants.Event.BLUR, hashMap);
                } else if (this.this$0.keyboardHeight == 0.0f) {
                    fireEventForFocus(hostView);
                } else {
                    hashMap2.put("height", Float.valueOf(this.this$0.keyboardHeight));
                    hashMap2.put("value", hostView.getText().toString());
                    hashMap.put("detail", hashMap2);
                    this.this$0.fireEvent(Constants.Event.FOCUS, hashMap);
                }
            }
        }
    };
    boolean isShowConfirm = true;

    public DCTextArea(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        this.attr = basicComponentData.getAttrs();
        setContentBoxMeasurement(new ContentBoxMeasurement(this) { // from class: com.taobao.weex.ui.component.DCTextArea.1
            final DCTextArea this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutAfter(float f2, float f3) {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutBefore() {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void measureInternal(float f2, float f3, int i2, int i3) {
                if (CSSConstants.isUndefined(f2)) {
                    this.mMeasureWidth = WXViewUtils.getRealPxByWidth(300.0f, this.this$0.getInstance().getInstanceViewPortWidthWithFloat());
                }
                if (!CSSConstants.isUndefined(f3)) {
                    return;
                }
                if (!this.this$0.attr.containsKey("autoHeight") || !WXUtils.getBoolean(this.this$0.attr.get("autoHeight"), false).booleanValue()) {
                    this.mMeasureHeight = WXViewUtils.getRealPxByWidth(150.0f, this.this$0.getInstance().getInstanceViewPortWidthWithFloat());
                } else {
                    this.mMeasureHeight = WXViewUtils.getRealPxByWidth(((float) this.this$0.getInstance().getDefaultFontSize()) * 1.4f, this.this$0.getInstance().getInstanceViewPortWidthWithFloat());
                }
            }
        });
    }

    private void watchLine() {
        addTextChangedListener(new TextWatcher(this) { // from class: com.taobao.weex.ui.component.DCTextArea.3
            int line = 0;
            final DCTextArea this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                if (this.this$0.getHostView().getLineCount() != this.line) {
                    this.line = this.this$0.getHostView().getLineCount();
                    int extendedPaddingTop = this.this$0.getHostView().getExtendedPaddingTop() + this.this$0.getHostView().getExtendedPaddingBottom();
                    float lineTop = (float) (this.this$0.getHostView().getLayout().getLineTop(this.this$0.getHostView().getLineCount()) + extendedPaddingTop);
                    float f2 = lineTop;
                    if (extendedPaddingTop == 0) {
                        f2 = lineTop;
                        if (this.this$0.isAutoHeight) {
                            f2 = WXViewUtils.getRealPxByWidth(((float) this.this$0.getInstance().getDefaultFontSize()) * 1.4f, this.this$0.getInstance().getInstanceViewPortWidthWithFloat()) + ((float) this.this$0.getHostView().getLayout().getLineTop(this.this$0.getHostView().getLineCount() - 1));
                        }
                    }
                    if (this.this$0.isAutoHeight && f2 > 0.0f) {
                        WXSDKManager.getInstance().getWXBridgeManager().post(new Runnable(this, f2) { // from class: com.taobao.weex.ui.component.DCTextArea.3.1
                            final AnonymousClass3 this$1;
                            final float val$finalHeight;

                            /* JADX WARN: Incorrect args count in method signature: ()V */
                            {
                                this.this$1 = r4;
                                this.val$finalHeight = r5;
                            }

                            @Override // java.lang.Runnable
                            public void run() {
                                WXBridgeManager.getInstance().setStyleHeight(this.this$1.this$0.getInstanceId(), this.this$1.this$0.getRef(), this.val$finalHeight);
                                WXBridgeManager.getInstance().notifyLayout(this.this$1.this$0.getInstanceId());
                                WXBridgeManager.getInstance().forceLayout(this.this$1.this$0.getInstanceId());
                            }
                        });
                    }
                    if (this.this$0.isLineChange) {
                        HashMap hashMap = new HashMap(3);
                        hashMap.put("lineCount", Integer.valueOf(this.line));
                        hashMap.put("height", Float.valueOf(WXViewUtils.getWebPxByWidth(f2, this.this$0.getInstance().getInstanceViewPortWidthWithFloat())));
                        hashMap.put("heightRpx", Float.valueOf(f2));
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("linechange", hashMap2);
                    }
                }
            }
        });
    }

    @Override // com.taobao.weex.ui.component.DCWXInput, com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        addEvent(str);
        if (str.equals("linechange")) {
            this.isLineChange = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.DCWXInput
    public void appleStyleAfterCreated(WXEditText wXEditText) {
        appleStyleAfterCreated(wXEditText);
        wXEditText.setSingleLine(false);
        wXEditText.setMinLines(1);
        wXEditText.setMaxLines(100);
        wXEditText.setInputType(IjkMediaPlayer.OnNativeInvokeListener.CTRL_WILL_TCP_OPEN);
    }

    @Override // com.taobao.weex.ui.component.DCWXInput, com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        ConfirmBar.getInstance().removeComponent(this);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.DCWXInput
    public float getMeasureHeight() {
        return this.isAutoHeight ? getMeasuredLineHeight() : getMeasureHeight();
    }

    @Override // com.taobao.weex.ui.component.DCWXInput
    protected int getVerticalGravity() {
        return 48;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.DCWXInput
    public void onHostViewInitialized(WXEditText wXEditText) {
        this.isNeedConfirm = false;
        wXEditText.setAllowDisableMovement(false);
        onHostViewInitialized(wXEditText);
        try {
            ConfirmBar.getInstance().createConfirmBar(getContext(), WeexInstanceMgr.self().findWebview(getInstance()).obtainApp());
            ConfirmBar.getInstance().addComponent(this);
        } catch (Exception e2) {
        }
        if (this.attr.containsKey("autoHeight") && WXUtils.getBoolean(this.attr.get("autoHeight"), false).booleanValue()) {
            WXBridgeManager.getInstance().setStyleHeight(getInstanceId(), getRef(), WXViewUtils.getRealPxByWidth(((float) getInstance().getDefaultFontSize()) * 1.4f, getInstance().getInstanceViewPortWidthWithFloat()));
        }
        watchLine();
    }

    @WXComponentProp(name = "autoHeight")
    public void setAutoHeight(boolean z2) {
        this.isAutoHeight = z2;
    }

    @Override // com.taobao.weex.ui.component.DCWXInput
    protected void setFocusAndBlur() {
        if (!ismHasFocusChangeListener(this.mOnFocusChangeListener)) {
            addFocusChangeListener(this.mOnFocusChangeListener);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.DCWXInput
    public void setHostLayoutParams(WXEditText wXEditText, int i2, int i3, int i4, int i5, int i6, int i7) {
        setHostLayoutParams(wXEditText, i2, i3, i4, i5, i6, i7);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.DCWXInput, com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        this.isConfirmHold = WXUtils.getBoolean(obj, true).booleanValue();
        return setProperty(str, obj);
    }

    @WXComponentProp(name = "showConfirmBar")
    public void setShowConfirmBar(boolean z2) {
        this.isShowConfirm = z2;
    }

    @Override // com.taobao.weex.ui.component.DCWXInput
    public void setSingleLine(boolean z2) {
        getHostView().setSingleLine(false);
    }

    @Override // com.taobao.weex.ui.component.DCWXInput
    public void setType(String str) {
        if (getHostView() != null && str != null && getHostView() != null && !this.mType.equals(str)) {
            getHostView().setInputType(IjkMediaPlayer.OnNativeInvokeListener.CTRL_WILL_TCP_OPEN);
        }
    }
}
