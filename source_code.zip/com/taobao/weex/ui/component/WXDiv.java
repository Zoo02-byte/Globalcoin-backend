package com.taobao.weex.ui.component;

import android.content.Context;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.ui.ComponentCreator;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.flat.FlatComponent;
import com.taobao.weex.ui.flat.WidgetContainer;
import com.taobao.weex.ui.flat.widget.WidgetGroup;
import com.taobao.weex.ui.view.WXFrameLayout;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXDiv.class */
public class WXDiv extends WidgetContainer<WXFrameLayout> implements FlatComponent<WidgetGroup> {
    private WidgetGroup mWidgetGroup;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXDiv$Ceator.class */
    public static class Ceator implements ComponentCreator {
        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            return new WXDiv(wXSDKInstance, wXVContainer, basicComponentData);
        }
    }

    public WXDiv(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
    }

    @Deprecated
    public WXDiv(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, basicComponentData);
    }

    @Override // com.taobao.weex.ui.flat.FlatComponent
    public WidgetGroup getOrCreateFlatWidget() {
        if (this.mWidgetGroup == null) {
            this.mWidgetGroup = new WidgetGroup(getInstance().getFlatUIContext());
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                createChildViewAt(i2);
            }
            mountFlatGUI();
        }
        return this.mWidgetGroup;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public WXFrameLayout initComponentHostView(Context context) {
        WXFrameLayout wXFrameLayout = new WXFrameLayout(context);
        wXFrameLayout.holdComponent(this);
        return wXFrameLayout;
    }

    @Override // com.taobao.weex.ui.flat.WidgetContainer
    public boolean intendToBeFlatContainer() {
        return getInstance().getFlatUIContext().isFlatUIEnabled(this) && WXDiv.class.equals(getClass());
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean isVirtualComponent() {
        return true ^ promoteToView(true);
    }

    @Override // com.taobao.weex.ui.flat.WidgetContainer
    protected void mountFlatGUI() {
        if (this.widgets == null) {
            this.widgets = new LinkedList();
        }
        if (!promoteToView(true)) {
            this.mWidgetGroup.replaceAll(this.widgets);
        } else if (getHostView() != 0) {
            ((WXFrameLayout) getHostView()).mountFlatGUI(this.widgets);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0029, code lost:
        if (getInstance().getFlatUIContext().promoteToView(r5, r6, com.taobao.weex.ui.component.WXDiv.class) != false) goto L_0x002c;
     */
    @Override // com.taobao.weex.ui.flat.FlatComponent
    /* Code decompiled incorrectly, please refer to instructions dump */
    public boolean promoteToView(boolean r6) {
        /*
            r5 = this;
            r0 = r5
            com.taobao.weex.WXSDKInstance r0 = r0.getInstance()
            com.taobao.weex.ui.flat.FlatGUIContext r0 = r0.getFlatUIContext()
            r9 = r0
            r0 = 0
            r8 = r0
            r0 = r8
            r7 = r0
            r0 = r9
            if (r0 == 0) goto L_0x002e
            r0 = r5
            boolean r0 = r0.intendToBeFlatContainer()
            if (r0 == 0) goto L_0x002c
            r0 = r8
            r7 = r0
            r0 = r5
            com.taobao.weex.WXSDKInstance r0 = r0.getInstance()
            com.taobao.weex.ui.flat.FlatGUIContext r0 = r0.getFlatUIContext()
            r1 = r5
            r2 = r6
            java.lang.Class<com.taobao.weex.ui.component.WXDiv> r3 = com.taobao.weex.ui.component.WXDiv.class
            boolean r0 = r0.promoteToView(r1, r2, r3)
            if (r0 == 0) goto L_0x002e
        L_0x002c:
            r0 = 1
            r7 = r0
        L_0x002e:
            r0 = r7
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXDiv.promoteToView(boolean):boolean");
    }

    @Override // com.taobao.weex.ui.flat.WidgetContainer
    public void unmountFlatGUI() {
        if (getHostView() != 0) {
            ((WXFrameLayout) getHostView()).unmountFlatGUI();
        }
    }
}
