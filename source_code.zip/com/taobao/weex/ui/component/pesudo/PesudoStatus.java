package com.taobao.weex.ui.component.pesudo;

import androidx.collection.ArrayMap;
import com.taobao.weex.common.Constants;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/pesudo/PesudoStatus.class */
public class PesudoStatus {
    static final int CLASS_ACTIVE = 0;
    static final int CLASS_DISABLED = 3;
    static final int CLASS_ENABLED = 2;
    static final int CLASS_FOCUS = 1;
    private static final int SET = 1;
    private static final int UNSET = 0;
    private int[] mStatuses = new int[4];

    public PesudoStatus() {
        int i2 = 0;
        while (true) {
            int[] iArr = this.mStatuses;
            if (i2 < iArr.length) {
                iArr[i2] = 0;
                i2++;
            } else {
                return;
            }
        }
    }

    public String getStatuses() {
        StringBuilder sb = new StringBuilder();
        if (isSet(0)) {
            sb.append(Constants.PSEUDO.ACTIVE);
        }
        if (isSet(3)) {
            sb.append(Constants.PSEUDO.DISABLED);
        }
        if (isSet(1) && !isSet(3)) {
            sb.append(Constants.PSEUDO.FOCUS);
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    public boolean isSet(int i2) {
        boolean z2 = true;
        if (this.mStatuses[i2] != 1) {
            z2 = false;
        }
        return z2;
    }

    void setStatus(int i2, boolean z2) {
        this.mStatuses[i2] = z2 ? 1 : 0;
    }

    public void setStatus(String str, boolean z2) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1487344704:
                if (str.equals(Constants.PSEUDO.ACTIVE)) {
                    c2 = 0;
                    break;
                }
                break;
            case -1482202954:
                if (str.equals(Constants.PSEUDO.DISABLED)) {
                    c2 = 1;
                    break;
                }
                break;
            case 689157575:
                if (str.equals(Constants.PSEUDO.ENABLED)) {
                    c2 = 2;
                    break;
                }
                break;
            case 1758095582:
                if (str.equals(Constants.PSEUDO.FOCUS)) {
                    c2 = 3;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                setStatus(0, z2);
                return;
            case 1:
                setStatus(3, z2);
                return;
            case 2:
                setStatus(2, z2);
                return;
            case 3:
                setStatus(1, z2);
                return;
            default:
                return;
        }
    }

    public Map<String, Object> updateStatusAndGetUpdateStyles(String str, boolean z2, Map<String, Map<String, Object>> map, Map<String, Object> map2) {
        String statuses = getStatuses();
        setStatus(str, z2);
        Map<String, Object> map3 = map.get(getStatuses());
        Map<String, Object> map4 = map.get(statuses);
        ArrayMap arrayMap = new ArrayMap();
        if (map4 != null) {
            arrayMap.putAll(map4);
        }
        for (K k2 : arrayMap.keySet()) {
            arrayMap.put(k2, map2.containsKey(k2) ? map2.get(k2) : "");
        }
        if (map3 != null) {
            for (Map.Entry<String, Object> entry : map3.entrySet()) {
                arrayMap.put(entry.getKey(), entry.getValue());
            }
        }
        return arrayMap;
    }
}
