package com.taobao.weex.ui.component.pesudo;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/pesudo/OnActivePseudoListner.class */
public interface OnActivePseudoListner {
    void updateActivePseudo(boolean z2);
}
