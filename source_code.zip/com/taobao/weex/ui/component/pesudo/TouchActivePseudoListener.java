package com.taobao.weex.ui.component.pesudo;

import android.view.MotionEvent;
import android.view.View;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/pesudo/TouchActivePseudoListener.class */
public class TouchActivePseudoListener implements View.OnTouchListener {
    private boolean mIsConsumeOnTouch;
    private OnActivePseudoListner mOnActivePseudoListner;

    public TouchActivePseudoListener(OnActivePseudoListner onActivePseudoListner, boolean z2) {
        this.mOnActivePseudoListner = onActivePseudoListner;
        this.mIsConsumeOnTouch = z2;
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        OnActivePseudoListner onActivePseudoListner = this.mOnActivePseudoListner;
        if (onActivePseudoListner != null) {
            if (action == 0 || action == 5) {
                onActivePseudoListner.updateActivePseudo(true);
            } else if (action == 3 || action == 1 || action == 6) {
                onActivePseudoListner.updateActivePseudo(false);
            }
        }
        return this.mIsConsumeOnTouch;
    }
}
