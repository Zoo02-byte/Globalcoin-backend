package com.taobao.weex.ui.component;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import androidx.core.view.ViewCompat;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.ICheckBindingScroller;
import com.taobao.weex.common.OnWXScrollListener;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.ui.ComponentCreator;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.helper.ScrollStartEndHelper;
import com.taobao.weex.ui.view.IWXScroller;
import com.taobao.weex.ui.view.WXBaseRefreshLayout;
import com.taobao.weex.ui.view.refresh.wrapper.BaseBounceView;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.common.util.DensityUtils;
import io.dcloud.common.util.StringUtil;
import io.dcloud.feature.weex_scroller.helper.DCScrollStartEndHelper;
import io.dcloud.feature.weex_scroller.view.DCBounceScrollerView;
import io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView;
import io.dcloud.feature.weex_scroller.view.DCWXScrollView;
import io.dcloud.feature.weex_scroller.view.WXStickyHelper;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXScroller.class */
public class DCWXScroller extends WXBaseScroller implements DCWXScrollView.WXScrollViewListener, Scrollable {
    public static final String DIRECTION;
    private static final int SWIPE_MIN_DISTANCE;
    private static final int SWIPE_THRESHOLD_VELOCITY;
    private boolean canScroll2Top;
    Map<String, WXComponent> childens;
    private Handler handler;
    private boolean isAnimation;
    private boolean isScrollable;
    private AtomicBoolean isViewLayoutFinished;
    private int mActiveFeature;
    private Map<String, AppearanceHelper> mAppearanceComponents;
    private int mChildrenLayoutOffset;
    private int mContentHeight;
    private int mContentWidth;
    private boolean mForceLoadmoreNextTime;
    private GestureDetector mGestureDetector;
    private boolean mHasAddScrollEvent;
    private boolean mIsHostAttachedToWindow;
    private Point mLastReport;
    private int mOffsetAccuracy;
    private View.OnAttachStateChangeListener mOnAttachStateChangeListener;
    protected int mOrientation;
    private FrameLayout mRealView;
    private List<WXComponent> mRefreshs;
    private ScrollStartEndHelper mScrollStartEndHelper;
    private FrameLayout mScrollerView;
    private Map<String, Map<String, WXComponent>> mStickyMap;
    private boolean pageEnable;
    private int pageSize;
    private WXStickyHelper stickyHelper;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXScroller$Creator.class */
    public static class Creator implements ComponentCreator {
        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            wXSDKInstance.setUseScroller(true);
            return new DCWXScroller(wXSDKInstance, wXVContainer, basicComponentData);
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXScroller$MyGestureDetector.class */
    public class MyGestureDetector extends GestureDetector.SimpleOnGestureListener {
        private final DCWXHorizontalScrollView scrollView;
        final DCWXScroller this$0;

        MyGestureDetector(DCWXScroller dCWXScroller, DCWXHorizontalScrollView dCWXHorizontalScrollView) {
            this.this$0 = dCWXScroller;
            this.scrollView = dCWXHorizontalScrollView;
        }

        public DCWXHorizontalScrollView getScrollView() {
            return this.scrollView;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
            int size = this.this$0.mChildren.size();
            try {
                if (motionEvent.getX() - motionEvent2.getX() > 5.0f && Math.abs(f2) > 300.0f) {
                    int i2 = this.this$0.pageSize;
                    DCWXScroller dCWXScroller = this.this$0;
                    int i3 = dCWXScroller.mActiveFeature;
                    int i4 = size - 1;
                    int i5 = i4;
                    if (i3 < i4) {
                        i5 = this.this$0.mActiveFeature + 1;
                    }
                    dCWXScroller.mActiveFeature = i5;
                    this.scrollView.smoothScrollTo(this.this$0.mActiveFeature * i2, 0);
                    return true;
                } else if (motionEvent2.getX() - motionEvent.getX() <= 5.0f || Math.abs(f2) <= 300.0f) {
                    return false;
                } else {
                    int i6 = this.this$0.pageSize;
                    DCWXScroller dCWXScroller2 = this.this$0;
                    dCWXScroller2.mActiveFeature = dCWXScroller2.mActiveFeature > 0 ? this.this$0.mActiveFeature - 1 : 0;
                    this.scrollView.smoothScrollTo(this.this$0.mActiveFeature * i6, 0);
                    return true;
                }
            } catch (Exception e2) {
                WXLogUtils.e("There was an error processing the Fling event:" + e2.getMessage());
                return false;
            }
        }
    }

    public DCWXScroller(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
        this.mOrientation = 1;
        this.mRefreshs = new ArrayList();
        this.mChildrenLayoutOffset = 0;
        this.mForceLoadmoreNextTime = false;
        this.mOffsetAccuracy = 10;
        this.mLastReport = new Point(-1, -1);
        this.mHasAddScrollEvent = false;
        this.mActiveFeature = 0;
        this.pageSize = 0;
        this.pageEnable = false;
        this.mIsHostAttachedToWindow = false;
        this.isAnimation = false;
        this.canScroll2Top = false;
        this.mAppearanceComponents = new HashMap();
        this.mStickyMap = new HashMap();
        this.mContentHeight = 0;
        this.mContentWidth = 0;
        this.handler = new Handler(Looper.getMainLooper());
        this.isScrollable = true;
        this.childens = new HashMap();
        this.isViewLayoutFinished = new AtomicBoolean(false);
        this.stickyHelper = new WXStickyHelper(this);
        wXSDKInstance.getApmForInstance().updateDiffStats(WXInstanceApm.KEY_PAGE_STATS_SCROLLER_NUM, 1.0d);
    }

    @Deprecated
    public DCWXScroller(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, basicComponentData);
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x003e, code lost:
        if (r0 < getLayoutWidth()) goto L_0x0041;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0041, code lost:
        r7 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x006b, code lost:
        if (r0 < getLayoutHeight()) goto L_0x0041;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private boolean checkItemVisibleInScroller(com.taobao.weex.ui.component.WXComponent r5) {
        /*
            r4 = this;
            r0 = 0
            r7 = r0
        L_0x0002:
            r0 = r5
            if (r0 == 0) goto L_0x0079
            r0 = r5
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.DCWXScroller
            if (r0 != 0) goto L_0x0079
            r0 = r5
            com.taobao.weex.ui.component.WXVContainer r0 = r0.getParent()
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.DCWXScroller
            if (r0 == 0) goto L_0x0071
            r0 = r4
            int r0 = r0.mOrientation
            if (r0 != 0) goto L_0x004b
            r0 = r5
            com.taobao.weex.ui.action.GraphicPosition r0 = r0.getLayoutPosition()
            float r0 = r0.getLeft()
            int r0 = (int) r0
            r1 = r4
            int r1 = r1.getScrollX()
            int r0 = r0 - r1
            float r0 = (float) r0
            r6 = r0
            r0 = r6
            r1 = 0
            r2 = r5
            float r2 = r2.getLayoutWidth()
            float r1 = r1 - r2
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0046
            r0 = r6
            r1 = r4
            float r1 = r1.getLayoutWidth()
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0046
        L_0x0041:
            r0 = 1
            r7 = r0
            goto L_0x0071
        L_0x0046:
            r0 = 0
            r7 = r0
            goto L_0x0071
        L_0x004b:
            r0 = r5
            com.taobao.weex.ui.action.GraphicPosition r0 = r0.getLayoutPosition()
            float r0 = r0.getTop()
            int r0 = (int) r0
            r1 = r4
            int r1 = r1.getScrollY()
            int r0 = r0 - r1
            float r0 = (float) r0
            r6 = r0
            r0 = r6
            r1 = 0
            r2 = r5
            float r2 = r2.getLayoutHeight()
            float r1 = r1 - r2
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0046
            r0 = r6
            r1 = r4
            float r1 = r1.getLayoutHeight()
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0046
            goto L_0x0041
        L_0x0071:
            r0 = r5
            com.taobao.weex.ui.component.WXVContainer r0 = r0.getParent()
            r5 = r0
            goto L_0x0002
        L_0x0079:
            r0 = r7
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.DCWXScroller.checkItemVisibleInScroller(com.taobao.weex.ui.component.WXComponent):boolean");
    }

    private boolean checkRefreshOrLoading(WXComponent wXComponent) {
        boolean z2 = true;
        if (!(wXComponent instanceof WXRefresh) || getHostView() == 0) {
            z2 = false;
        } else {
            ((BaseBounceView) getHostView()).setOnRefreshListener((WXRefresh) wXComponent);
            this.handler.postDelayed(WXThread.secure(new Runnable(this, wXComponent) { // from class: com.taobao.weex.ui.component.DCWXScroller.3
                final DCWXScroller this$0;
                final WXComponent val$child;

                {
                    this.this$0 = r4;
                    this.val$child = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    ((BaseBounceView) this.this$0.getHostView()).setHeaderView(this.val$child);
                }
            }), 100);
            z2 = true;
        }
        if ((wXComponent instanceof WXLoading) && getHostView() != 0) {
            ((BaseBounceView) getHostView()).setOnLoadingListener((WXLoading) wXComponent);
            this.handler.postDelayed(WXThread.secure(new Runnable(this, wXComponent) { // from class: com.taobao.weex.ui.component.DCWXScroller.4
                final DCWXScroller this$0;
                final WXComponent val$child;

                {
                    this.this$0 = r4;
                    this.val$child = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    ((BaseBounceView) this.this$0.getHostView()).setFooterView(this.val$child);
                }
            }), 100);
        }
        return z2;
    }

    public void dispatchDisappearEvent() {
        int appearStatus;
        for (Map.Entry<String, AppearanceHelper> entry : this.mAppearanceComponents.entrySet()) {
            AppearanceHelper value = entry.getValue();
            if (value.isWatch() && (appearStatus = value.setAppearStatus(false)) != 0) {
                value.getAwareChild().notifyAppearStateChange(appearStatus == 1 ? Constants.Event.APPEAR : Constants.Event.DISAPPEAR, "");
            }
        }
    }

    public void fireScrollEvent(Rect rect, int i2, int i3, int i4, int i5) {
        fireEvent("scroll", getScrollEvent(i2, i3, i4, i5));
    }

    private WXComponent getViewById(String str) {
        if (this.childens.containsKey(str)) {
            return this.childens.get(str);
        }
        for (WXComponent wXComponent : this.childens.values()) {
            if (wXComponent.getAttrs().containsKey("id") && wXComponent.getAttrs().get("id").equals(str)) {
                return wXComponent;
            }
        }
        return null;
    }

    public void procAppear(int i2, int i3, int i4, int i5) {
        int appearStatus;
        if (this.mIsHostAttachedToWindow) {
            int i6 = i3 - i5;
            int i7 = i2 - i4;
            String str = i6 > 0 ? "up" : i6 < 0 ? "down" : null;
            String str2 = str;
            if (this.mOrientation == 0) {
                str2 = str;
                if (i7 != 0) {
                    str2 = i7 > 0 ? "right" : "left";
                }
            }
            for (Map.Entry<String, AppearanceHelper> entry : this.mAppearanceComponents.entrySet()) {
                AppearanceHelper value = entry.getValue();
                if (value.isWatch() && (appearStatus = value.setAppearStatus(checkItemVisibleInScroller(value.getAwareChild()))) != 0) {
                    value.getAwareChild().notifyAppearStateChange(appearStatus == 1 ? Constants.Event.APPEAR : Constants.Event.DISAPPEAR, str2);
                }
            }
        }
    }

    private void setWatch(int i2, WXComponent wXComponent, boolean z2) {
        AppearanceHelper appearanceHelper = this.mAppearanceComponents.get(wXComponent.getRef());
        AppearanceHelper appearanceHelper2 = appearanceHelper;
        if (appearanceHelper == null) {
            appearanceHelper2 = new AppearanceHelper(wXComponent);
            this.mAppearanceComponents.put(wXComponent.getRef(), appearanceHelper2);
        }
        appearanceHelper2.setWatchEvent(i2, z2);
        procAppear(0, 0, 0, 0);
    }

    public boolean shouldReport(int i2, int i3) {
        if (this.mLastReport.x == -1 && this.mLastReport.y == -1) {
            this.mLastReport.x = i2;
            this.mLastReport.y = i3;
            return true;
        } else if (this.mOrientation == 0 && Math.abs(i2 - this.mLastReport.x) >= this.mOffsetAccuracy) {
            this.mLastReport.x = i2;
            this.mLastReport.y = i3;
            return true;
        } else if (this.mOrientation != 1 || Math.abs(i3 - this.mLastReport.y) < this.mOffsetAccuracy) {
            return false;
        } else {
            this.mLastReport.x = i2;
            this.mLastReport.y = i3;
            return true;
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addChild(WXComponent wXComponent, int i2) {
        if (wXComponent.getAttrs().containsKey("id")) {
            this.childens.put(wXComponent.getAttrs().get("id").toString(), wXComponent);
        }
        if ((wXComponent instanceof WXBaseRefresh) && checkRefreshOrLoading(wXComponent)) {
            this.mRefreshs.add(wXComponent);
        }
        addChild(wXComponent, i2);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        addEvent(str);
        if (DCScrollStartEndHelper.isScrollEvent(str) && getInnerView() != null && !this.mHasAddScrollEvent) {
            this.mHasAddScrollEvent = true;
            if (getInnerView() instanceof DCWXScrollView) {
                ((DCWXScrollView) getInnerView()).addScrollViewListener(new DCWXScrollView.WXScrollViewListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.1
                    final DCWXScroller this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                    public void onScroll(DCWXScrollView dCWXScrollView, int i2, int i3) {
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                    public void onScrollChanged(DCWXScrollView dCWXScrollView, int i2, int i3, int i4, int i5) {
                        this.this$0.getScrollStartEndHelper().onScrolled(i2, i3);
                        if (this.this$0.getEvents().contains("scroll") && this.this$0.shouldReport(i2, i3)) {
                            this.this$0.fireScrollEvent(dCWXScrollView.getContentFrame(), i2, i3, i4, i5);
                        }
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                    public void onScrollStopped(DCWXScrollView dCWXScrollView, int i2, int i3) {
                        this.this$0.getScrollStartEndHelper().onScrolled(i2, i3);
                        if (this.this$0.getEvents().contains("scroll")) {
                            this.this$0.fireScrollEvent(dCWXScrollView.getContentFrame(), i2, i3, 0, 0);
                        }
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                    public void onScrollToBottom(DCWXScrollView dCWXScrollView, int i2, int i3) {
                        HashMap hashMap = new HashMap(1);
                        hashMap.put("direction", "bottom");
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("scrolltolower", hashMap2);
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                    public void onScrollToTop(DCWXScrollView dCWXScrollView, int i2, int i3) {
                        HashMap hashMap = new HashMap(1);
                        hashMap.put("direction", "top");
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("scrolltoupper", hashMap2);
                    }
                });
            } else if (getInnerView() instanceof DCWXHorizontalScrollView) {
                ((DCWXHorizontalScrollView) getInnerView()).addScrollViewListener(new DCWXHorizontalScrollView.ScrollViewListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.2
                    final DCWXScroller this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                    public void onScrollChanged(DCWXHorizontalScrollView dCWXHorizontalScrollView, int i2, int i3, int i4, int i5) {
                        this.this$0.getScrollStartEndHelper().onScrolled(i2, i3);
                        if (this.this$0.getEvents().contains("scroll") && this.this$0.shouldReport(i2, i3)) {
                            this.this$0.fireScrollEvent(dCWXHorizontalScrollView.getContentFrame(), i2, i3, i4, i5);
                        }
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                    public void onScrollToBottom() {
                        HashMap hashMap = new HashMap(1);
                        hashMap.put("direction", "bottom");
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("scrolltolower", hashMap2);
                    }

                    @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                    public void onScrolltoTop() {
                        HashMap hashMap = new HashMap(1);
                        hashMap.put("direction", "top");
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("scrolltoupper", hashMap2);
                    }
                });
            }
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addSubView(View view, int i2) {
        FrameLayout frameLayout;
        if (view != null && (frameLayout = this.mRealView) != null && !(view instanceof WXBaseRefreshLayout)) {
            int i3 = i2;
            if (i2 >= frameLayout.getChildCount()) {
                i3 = -1;
            }
            if (view.getParent() != null) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            if (i3 == -1) {
                this.mRealView.addView(view);
            } else {
                this.mRealView.addView(view, i3);
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void bindAppearEvent(WXComponent wXComponent) {
        setWatch(0, wXComponent, true);
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void bindDisappearEvent(WXComponent wXComponent) {
        setWatch(1, wXComponent, true);
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void bindStickStyle(WXComponent wXComponent) {
        this.stickyHelper.bindStickStyle(wXComponent, this.mStickyMap);
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public void createViewImpl() {
        createViewImpl();
        for (int i2 = 0; i2 < this.mRefreshs.size(); i2++) {
            WXComponent wXComponent = this.mRefreshs.get(i2);
            wXComponent.createViewImpl();
            checkRefreshOrLoading(wXComponent);
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        if (getInnerView() != null && (getInnerView() instanceof IWXScroller)) {
            ((IWXScroller) getInnerView()).destroy();
        }
        Map<String, AppearanceHelper> map = this.mAppearanceComponents;
        if (map != null) {
            map.clear();
        }
        Map<String, Map<String, WXComponent>> map2 = this.mStickyMap;
        if (map2 != null) {
            map2.clear();
        }
        if (!(this.mOnAttachStateChangeListener == null || getInnerView() == null)) {
            getInnerView().removeOnAttachStateChangeListener(this.mOnAttachStateChangeListener);
        }
        destroy();
    }

    @Override // com.taobao.weex.ui.component.WXVContainer, io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public int getChildrenLayoutTopOffset() {
        int size;
        if (this.mChildrenLayoutOffset == 0 && (size = this.mRefreshs.size()) > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.mChildrenLayoutOffset += this.mRefreshs.get(i2).getLayoutTopOffsetForSibling();
            }
        }
        return this.mChildrenLayoutOffset;
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller
    public ViewGroup getInnerView() {
        if (getHostView() == 0) {
            return null;
        }
        return getHostView() instanceof DCBounceScrollerView ? ((DCBounceScrollerView) getHostView()).getInnerView() : (ViewGroup) getHostView();
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public int getOrientation() {
        return this.mOrientation;
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public ViewGroup getRealView() {
        return this.mScrollerView;
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller
    public Map<String, Object> getScrollEvent(int i2, int i3) {
        Rect rect = new Rect();
        if (getInnerView() instanceof DCWXScrollView) {
            rect = ((DCWXScrollView) getInnerView()).getContentFrame();
        } else if (getInnerView() instanceof DCWXHorizontalScrollView) {
            rect = ((DCWXHorizontalScrollView) getInnerView()).getContentFrame();
        }
        HashMap hashMap = new HashMap(2);
        HashMap hashMap2 = new HashMap(2);
        HashMap hashMap3 = new HashMap(2);
        float instanceViewPortWidthWithFloat = getInstance().getInstanceViewPortWidthWithFloat();
        hashMap2.put("width", Float.valueOf(WXViewUtils.getWebPxByWidth((float) rect.width(), instanceViewPortWidthWithFloat)));
        hashMap2.put("height", Float.valueOf(WXViewUtils.getWebPxByWidth((float) rect.height(), instanceViewPortWidthWithFloat)));
        hashMap3.put(Constants.Name.X, Float.valueOf(WXViewUtils.getWebPxByWidth((float) i2, instanceViewPortWidthWithFloat)));
        hashMap3.put(Constants.Name.Y, Float.valueOf(WXViewUtils.getWebPxByWidth((float) i3, instanceViewPortWidthWithFloat)));
        hashMap.put(Constants.Name.CONTENT_SIZE, hashMap2);
        hashMap.put(Constants.Name.CONTENT_OFFSET, hashMap3);
        return hashMap;
    }

    public Map<String, Object> getScrollEvent(int i2, int i3, int i4, int i5) {
        int i6;
        Rect rect = new Rect();
        int i7 = 0;
        if (getInnerView() instanceof DCWXScrollView) {
            rect = ((DCWXScrollView) getInnerView()).getContentFrame();
            i6 = getInnerView().getScrollY();
        } else if (getInnerView() instanceof DCWXHorizontalScrollView) {
            rect = ((DCWXHorizontalScrollView) getInnerView()).getContentFrame();
            i7 = getInnerView().getScrollX();
            i6 = 0;
        } else {
            i6 = 0;
        }
        HashMap hashMap = new HashMap(2);
        HashMap hashMap2 = new HashMap(6);
        new HashMap(2);
        float instanceViewPortWidthWithFloat = getInstance().getInstanceViewPortWidthWithFloat();
        hashMap2.put("scrollWidth", Float.valueOf(WXViewUtils.getWebPxByWidth((float) rect.width(), instanceViewPortWidthWithFloat)));
        hashMap2.put("scrollHeight", Float.valueOf(WXViewUtils.getWebPxByWidth((float) rect.height(), instanceViewPortWidthWithFloat)));
        hashMap2.put(Constants.Name.SCROLL_LEFT, Float.valueOf(WXViewUtils.getWebPxByWidth((float) i7, instanceViewPortWidthWithFloat)));
        hashMap2.put(Constants.Name.SCROLL_TOP, Float.valueOf(WXViewUtils.getWebPxByWidth((float) i6, instanceViewPortWidthWithFloat)));
        hashMap2.put("deltaX", Float.valueOf(WXViewUtils.getWebPxByWidth((float) i4, instanceViewPortWidthWithFloat)));
        hashMap2.put("deltaY", Float.valueOf(WXViewUtils.getWebPxByWidth((float) i5, instanceViewPortWidthWithFloat)));
        hashMap.put("detail", hashMap2);
        return hashMap;
    }

    public ScrollStartEndHelper getScrollStartEndHelper() {
        if (this.mScrollStartEndHelper == null) {
            this.mScrollStartEndHelper = new ScrollStartEndHelper(this);
        }
        return this.mScrollStartEndHelper;
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public int getScrollX() {
        return getInnerView() == null ? 0 : getInnerView().getScrollX();
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public int getScrollY() {
        return getInnerView() == null ? 0 : getInnerView().getScrollY();
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller
    public Map<String, Map<String, WXComponent>> getStickMap() {
        return this.mStickyMap;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.taobao.weex.ui.component.WXComponent
    public ViewGroup initComponentHostView(Context context) {
        String str;
        boolean z2;
        boolean z3;
        boolean z4;
        DCBounceScrollerView dCBounceScrollerView;
        boolean z5;
        String str2 = "vertical";
        if (getAttrs().isEmpty()) {
            z3 = true;
            z4 = false;
            z2 = false;
            str = str2;
        } else {
            boolean parseBoolean = getAttrs().containsKey("scrollX") ? Boolean.parseBoolean(getAttrs().get("scrollX").toString()) : false;
            boolean parseBoolean2 = getAttrs().containsKey("scrollY") ? Boolean.parseBoolean(getAttrs().get("scrollY").toString()) : false;
            if (parseBoolean2) {
                z5 = !getAttrs().get("scrollY").equals(AbsoluteConst.FALSE);
            } else if (parseBoolean) {
                z5 = !getAttrs().get("scrollX").equals(AbsoluteConst.FALSE);
                str2 = Constants.Value.HORIZONTAL;
            } else {
                if (getAttrs().containsKey(Constants.Name.SCROLL_DIRECTION)) {
                    str2 = getAttrs().getScrollDirection();
                }
                z5 = true;
            }
            Object obj = getAttrs().get(Constants.Name.PAGE_ENABLED);
            this.pageEnable = obj != null && Boolean.parseBoolean(obj.toString());
            Object obj2 = getAttrs().get(Constants.Name.PAGE_SIZE);
            z4 = parseBoolean;
            str = str2;
            z3 = z5;
            z2 = parseBoolean2;
            if (obj2 != null) {
                float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(obj2), getInstance().getInstanceViewPortWidth());
                z4 = parseBoolean;
                str = str2;
                z3 = z5;
                z2 = parseBoolean2;
                if (realPxByWidth != 0.0f) {
                    this.pageSize = (int) realPxByWidth;
                    z2 = parseBoolean2;
                    z3 = z5;
                    str = str2;
                    z4 = parseBoolean;
                }
            }
        }
        if (Constants.Value.HORIZONTAL.equals(str)) {
            this.mOrientation = 0;
            DCWXHorizontalScrollView dCWXHorizontalScrollView = new DCWXHorizontalScrollView(context);
            dCWXHorizontalScrollView.setWAScroller(this);
            dCWXHorizontalScrollView.setScrollable(z3);
            this.mRealView = new FrameLayout(context);
            dCWXHorizontalScrollView.setScrollViewListener(new DCWXHorizontalScrollView.ScrollViewListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.5
                final DCWXScroller this$0;

                {
                    this.this$0 = r4;
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                public void onScrollChanged(DCWXHorizontalScrollView dCWXHorizontalScrollView2, int i2, int i3, int i4, int i5) {
                    if (this.this$0.getInstance() != null) {
                        this.this$0.procAppear(i2, i3, i4, i5);
                        this.this$0.onLoadMore(dCWXHorizontalScrollView2, i2, i3);
                    }
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                public void onScrollToBottom() {
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXHorizontalScrollView.ScrollViewListener
                public void onScrolltoTop() {
                }
            });
            dCWXHorizontalScrollView.addView(this.mRealView, new FrameLayout.LayoutParams(-1, -1));
            dCWXHorizontalScrollView.setHorizontalScrollBarEnabled(true);
            this.mScrollerView = dCWXHorizontalScrollView;
            dCWXHorizontalScrollView.setScrollBarSize(DensityUtils.dip2px(getInstance().getContext(), 4.0f));
            this.mRealView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(this, new View.OnLayoutChangeListener(this, dCWXHorizontalScrollView, this) { // from class: com.taobao.weex.ui.component.DCWXScroller.6
                final DCWXScroller this$0;
                final DCWXScroller val$component;
                final DCWXHorizontalScrollView val$scrollView;

                {
                    this.this$0 = r4;
                    this.val$scrollView = r5;
                    this.val$component = r6;
                }

                @Override // android.view.View.OnLayoutChangeListener
                public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                    this.val$scrollView.post(new Runnable(this, view) { // from class: com.taobao.weex.ui.component.DCWXScroller.6.1
                        final AnonymousClass6 this$1;
                        final View val$frameLayout;

                        {
                            this.this$1 = r4;
                            this.val$frameLayout = r5;
                        }

                        @Override // java.lang.Runnable
                        public void run() {
                            if (this.this$1.this$0.isLayoutRTL()) {
                                this.this$1.val$scrollView.scrollTo(this.val$frameLayout.getMeasuredWidth(), this.this$1.val$component.getScrollY());
                                return;
                            }
                            this.this$1.val$scrollView.scrollTo(0, this.this$1.val$component.getScrollY());
                        }
                    });
                    if (this.this$0.mRealView != null) {
                        this.this$0.mRealView.removeOnLayoutChangeListener(this);
                    }
                }
            }) { // from class: com.taobao.weex.ui.component.DCWXScroller.7
                final DCWXScroller this$0;
                final View.OnLayoutChangeListener val$listener;

                {
                    this.this$0 = r4;
                    this.val$listener = r5;
                }

                @Override // android.view.View.OnAttachStateChangeListener
                public void onViewAttachedToWindow(View view) {
                    view.addOnLayoutChangeListener(this.val$listener);
                }

                @Override // android.view.View.OnAttachStateChangeListener
                public void onViewDetachedFromWindow(View view) {
                    view.removeOnLayoutChangeListener(this.val$listener);
                }
            });
            dCBounceScrollerView = dCWXHorizontalScrollView;
            if (this.pageEnable) {
                this.mGestureDetector = new GestureDetector(new MyGestureDetector(this, dCWXHorizontalScrollView));
                dCWXHorizontalScrollView.setOnTouchListener(new View.OnTouchListener(this, dCWXHorizontalScrollView) { // from class: com.taobao.weex.ui.component.DCWXScroller.8
                    final DCWXScroller this$0;
                    final DCWXHorizontalScrollView val$scrollView;

                    {
                        this.this$0 = r4;
                        this.val$scrollView = r5;
                    }

                    @Override // android.view.View.OnTouchListener
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (this.this$0.pageSize == 0) {
                            this.this$0.pageSize = view.getMeasuredWidth();
                        }
                        if (this.this$0.mGestureDetector.onTouchEvent(motionEvent)) {
                            return true;
                        }
                        if (motionEvent.getAction() != 1 && motionEvent.getAction() != 3) {
                            return false;
                        }
                        int scrollX = this.this$0.getScrollX();
                        int i2 = this.this$0.pageSize;
                        this.this$0.mActiveFeature = (scrollX + (i2 / 2)) / i2;
                        this.val$scrollView.smoothScrollTo(this.this$0.mActiveFeature * i2, 0);
                        return true;
                    }
                });
                dCBounceScrollerView = dCWXHorizontalScrollView;
            }
        } else {
            this.mOrientation = 1;
            DCBounceScrollerView dCBounceScrollerView2 = new DCBounceScrollerView(context, this.mOrientation, this);
            this.mRealView = new FrameLayout(context);
            DCWXScrollView innerView = dCBounceScrollerView2.getInnerView();
            innerView.addScrollViewListener(this);
            if (z4 || z2) {
                innerView.setScrollable(z3);
            } else {
                innerView.setScrollable(false);
            }
            innerView.addView(this.mRealView, new FrameLayout.LayoutParams(-1, -1));
            innerView.setVerticalScrollBarEnabled(true);
            this.mScrollerView = innerView;
            innerView.setNestedScrollingEnabled(WXUtils.getBoolean(getAttrs().get(Constants.Name.NEST_SCROLLING_ENABLED), true).booleanValue());
            innerView.addScrollViewListener(new DCWXScrollView.WXScrollViewListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.9
                final DCWXScroller this$0;

                {
                    this.this$0 = r4;
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                public void onScroll(DCWXScrollView dCWXScrollView, int i2, int i3) {
                    List<OnWXScrollListener> wXScrollListeners;
                    if (!(this.this$0.getInstance() == null || (wXScrollListeners = this.this$0.getInstance().getWXScrollListeners()) == null || wXScrollListeners.size() <= 0)) {
                        for (OnWXScrollListener onWXScrollListener : wXScrollListeners) {
                            if (onWXScrollListener != null) {
                                if (!(onWXScrollListener instanceof ICheckBindingScroller)) {
                                    onWXScrollListener.onScrolled(dCWXScrollView, i2, i3);
                                } else if (((ICheckBindingScroller) onWXScrollListener).isNeedScroller(this.this$0.getRef(), null)) {
                                    onWXScrollListener.onScrolled(dCWXScrollView, i2, i3);
                                }
                            }
                        }
                    }
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                public void onScrollChanged(DCWXScrollView dCWXScrollView, int i2, int i3, int i4, int i5) {
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                public void onScrollStopped(DCWXScrollView dCWXScrollView, int i2, int i3) {
                    if (this.this$0.getInstance() != null) {
                        List<OnWXScrollListener> wXScrollListeners = this.this$0.getInstance().getWXScrollListeners();
                        if (wXScrollListeners != null && wXScrollListeners.size() > 0) {
                            for (OnWXScrollListener onWXScrollListener : wXScrollListeners) {
                                if (onWXScrollListener != null) {
                                    onWXScrollListener.onScrollStateChanged(dCWXScrollView, i2, i3, 0);
                                }
                            }
                        }
                        this.this$0.getScrollStartEndHelper().onScrollStateChanged(0);
                    }
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                public void onScrollToBottom(DCWXScrollView dCWXScrollView, int i2, int i3) {
                }

                @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
                public void onScrollToTop(DCWXScrollView dCWXScrollView, int i2, int i3) {
                }
            });
            dCBounceScrollerView = dCBounceScrollerView2;
        }
        dCBounceScrollerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.10
            final DCWXScroller this$0;

            {
                this.this$0 = r4;
            }

            /* JADX WARN: Type inference failed for: r0v4, types: [android.view.View] */
            /* JADX WARN: Unknown variable types count: 1 */
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            /* Code decompiled incorrectly, please refer to instructions dump */
            public void onGlobalLayout() {
                /*
                    r6 = this;
                    r0 = r6
                    com.taobao.weex.ui.component.DCWXScroller r0 = r0.this$0
                    r1 = 0
                    r2 = 0
                    r3 = 0
                    r4 = 0
                    com.taobao.weex.ui.component.DCWXScroller.access$200(r0, r1, r2, r3, r4)
                    r0 = r6
                    com.taobao.weex.ui.component.DCWXScroller r0 = r0.this$0
                    android.view.View r0 = r0.getHostView()
                    r7 = r0
                    r0 = r7
                    if (r0 == 0) goto L_0x002c
                    r0 = r6
                    com.taobao.weex.ui.component.DCWXScroller r0 = r0.this$0
                    com.taobao.weex.WXSDKInstance r0 = r0.getInstance()
                    if (r0 != 0) goto L_0x0024
                    goto L_0x002c
                L_0x0024:
                    r0 = r7
                    android.view.ViewTreeObserver r0 = r0.getViewTreeObserver()
                    r1 = r6
                    r0.removeOnGlobalLayoutListener(r1)
                L_0x002c:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.DCWXScroller.AnonymousClass10.onGlobalLayout():void");
            }
        });
        AnonymousClass11 r02 = new View.OnAttachStateChangeListener(this) { // from class: com.taobao.weex.ui.component.DCWXScroller.11
            final DCWXScroller this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewAttachedToWindow(View view) {
                this.this$0.mIsHostAttachedToWindow = true;
                DCWXScroller dCWXScroller = this.this$0;
                dCWXScroller.procAppear(dCWXScroller.getScrollX(), this.this$0.getScrollY(), this.this$0.getScrollX(), this.this$0.getScrollY());
            }

            @Override // android.view.View.OnAttachStateChangeListener
            public void onViewDetachedFromWindow(View view) {
                this.this$0.mIsHostAttachedToWindow = false;
                this.this$0.dispatchDisappearEvent();
            }
        };
        this.mOnAttachStateChangeListener = r02;
        dCBounceScrollerView.addOnAttachStateChangeListener(r02);
        return dCBounceScrollerView;
    }

    @WXComponentProp(name = "enable-back-to-top")
    public void isEnableBackToTop(boolean z2) {
        this.canScroll2Top = z2;
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public boolean isScrollable() {
        return this.isScrollable;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected WXComponent.MeasureOutput measure(int i2, int i3) {
        WXComponent.MeasureOutput measureOutput = new WXComponent.MeasureOutput();
        if (this.mOrientation == 0) {
            int screenWidth = WXViewUtils.getScreenWidth(WXEnvironment.sApplication);
            int weexWidth = WXViewUtils.getWeexWidth(getInstanceId());
            if (weexWidth < screenWidth) {
                screenWidth = weexWidth;
            }
            int i4 = i2;
            if (i2 > screenWidth) {
                i4 = -1;
            }
            measureOutput.width = i4;
            measureOutput.height = i3;
        } else {
            int screenHeight = WXViewUtils.getScreenHeight(WXEnvironment.sApplication);
            int weexHeight = WXViewUtils.getWeexHeight(getInstanceId());
            if (weexHeight < screenHeight) {
                screenHeight = weexHeight;
            }
            int i5 = i3;
            if (i3 > screenHeight) {
                i5 = -1;
            }
            measureOutput.height = i5;
            measureOutput.width = i2;
        }
        return measureOutput;
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public void notifyAppearStateChange(String str, String str2) {
        if (containsEvent(Constants.Event.APPEAR) || containsEvent(Constants.Event.DISAPPEAR)) {
            HashMap hashMap = new HashMap();
            hashMap.put("direction", str2);
            fireEvent(str, hashMap);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void onFinishLayout() {
        onFinishLayout();
    }

    protected void onLoadMore(FrameLayout frameLayout, int i2, int i3) {
        try {
            String loadMoreOffset = getAttrs().getLoadMoreOffset();
            if (!TextUtils.isEmpty(loadMoreOffset)) {
                int realPxByWidth = (int) WXViewUtils.getRealPxByWidth(Float.parseFloat(loadMoreOffset), getInstance().getInstanceViewPortWidth());
                if (frameLayout instanceof DCWXHorizontalScrollView) {
                    int width = frameLayout.getChildAt(0).getWidth();
                    if ((width - i2) - frameLayout.getWidth() >= realPxByWidth) {
                        return;
                    }
                    if (this.mContentWidth != width || this.mForceLoadmoreNextTime) {
                        fireEvent(Constants.Event.LOADMORE);
                        this.mContentWidth = width;
                        this.mForceLoadmoreNextTime = false;
                        return;
                    }
                    return;
                }
                int height = frameLayout.getChildAt(0).getHeight();
                int height2 = (height - i3) - frameLayout.getHeight();
                if (height2 < realPxByWidth) {
                    if (WXEnvironment.isApkDebugable()) {
                        WXLogUtils.d("[WXScroller-onScroll] offScreenY :" + height2);
                    }
                    if (this.mContentHeight != height || this.mForceLoadmoreNextTime) {
                        fireEvent(Constants.Event.LOADMORE);
                        this.mContentHeight = height;
                        this.mForceLoadmoreNextTime = false;
                    }
                }
            }
        } catch (Exception e2) {
            WXLogUtils.d("[DCWXScroller-onScroll] ", e2);
        }
    }

    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
    public void onScroll(DCWXScrollView dCWXScrollView, int i2, int i3) {
        onLoadMore(dCWXScrollView, i2, i3);
    }

    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
    public void onScrollChanged(DCWXScrollView dCWXScrollView, int i2, int i3, int i4, int i5) {
        procAppear(i2, i3, i4, i5);
    }

    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
    public void onScrollStopped(DCWXScrollView dCWXScrollView, int i2, int i3) {
    }

    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
    public void onScrollToBottom(DCWXScrollView dCWXScrollView, int i2, int i3) {
    }

    @Override // io.dcloud.feature.weex_scroller.view.DCWXScrollView.WXScrollViewListener
    public void onScrollToTop(DCWXScrollView dCWXScrollView, int i2, int i3) {
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void remove(WXComponent wXComponent, boolean z2) {
        remove(wXComponent, z2);
        if (wXComponent instanceof WXLoading) {
            ((BaseBounceView) getHostView()).removeFooterView(wXComponent);
        } else if (wXComponent instanceof WXRefresh) {
            ((BaseBounceView) getHostView()).removeHeaderView(wXComponent);
        }
    }

    @JSMethod
    public void resetLoadmore() {
        this.mForceLoadmoreNextTime = true;
    }

    public void scrollBy(int i2, int i3) {
        scrollBy(i2, i3, false);
    }

    public void scrollBy(int i2, int i3, boolean z2) {
        if (getInnerView() != null) {
            getInnerView().postDelayed(new Runnable(this, z2, i3, i2) { // from class: com.taobao.weex.ui.component.DCWXScroller.16
                final DCWXScroller this$0;
                final boolean val$smooth;
                final int val$x;
                final int val$y;

                {
                    this.this$0 = r4;
                    this.val$smooth = r5;
                    this.val$y = r6;
                    this.val$x = r7;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (this.this$0.mOrientation == 1) {
                        if (this.val$smooth) {
                            ((DCWXScrollView) this.this$0.getInnerView()).smoothScrollBy(0, this.val$y);
                        } else {
                            ((DCWXScrollView) this.this$0.getInnerView()).scrollBy(0, this.val$y);
                        }
                    } else if (this.val$smooth) {
                        ((DCWXHorizontalScrollView) this.this$0.getInnerView()).smoothScrollBy(this.val$x, 0);
                    } else {
                        ((DCWXHorizontalScrollView) this.this$0.getInnerView()).scrollBy(this.val$x, 0);
                    }
                    this.this$0.getInnerView().invalidate();
                }
            }, 16);
        }
    }

    @JSMethod
    public void scrollTo(int i2) {
        float realPxByWidth = WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidth());
        if (getInnerView() instanceof DCWXScrollView) {
            ((DCWXScrollView) getInnerView()).smoothScrollTo(0, (int) realPxByWidth);
        } else if (getInnerView() instanceof DCWXHorizontalScrollView) {
            ((DCWXHorizontalScrollView) getInnerView()).smoothScrollTo((int) realPxByWidth, 0);
        }
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void scrollTo(WXComponent wXComponent, Map<String, Object> map) {
        int i2;
        boolean z2 = true;
        float f2 = 0.0f;
        if (map != null) {
            String obj = map.get("offset") == null ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT : map.get("offset").toString();
            boolean booleanValue = WXUtils.getBoolean(map.get(Constants.Name.ANIMATED), true).booleanValue();
            f2 = 0.0f;
            z2 = booleanValue;
            if (obj != null) {
                try {
                    f2 = WXViewUtils.getRealPxByWidth(Float.parseFloat(obj), getInstance().getInstanceViewPortWidth());
                    z2 = booleanValue;
                } catch (Exception e2) {
                    WXLogUtils.e("Float parseFloat error :" + e2.getMessage());
                    z2 = booleanValue;
                    f2 = 0.0f;
                }
            }
        }
        if (this.pageEnable) {
            this.mActiveFeature = this.mChildren.indexOf(wXComponent);
        }
        int absoluteY = wXComponent.getAbsoluteY();
        int absoluteY2 = getAbsoluteY();
        if (isLayoutRTL()) {
            if (getInnerView().getChildCount() > 0) {
                i2 = (getInnerView().getChildAt(0).getWidth() - (wXComponent.getAbsoluteX() - getAbsoluteX())) - getInnerView().getMeasuredWidth();
            } else {
                i2 = wXComponent.getAbsoluteX() - getAbsoluteX();
            }
            f2 = -f2;
        } else {
            i2 = wXComponent.getAbsoluteX() - getAbsoluteX();
        }
        int i3 = (int) f2;
        scrollBy((i2 - getScrollX()) + i3, ((absoluteY - absoluteY2) - getScrollY()) + i3, z2);
    }

    @JSMethod
    public void scrollTo(String str, JSCallback jSCallback) {
        float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(JSON.parseObject(str).getString(Constants.Name.SCROLL_TOP)), getInstance().getInstanceViewPortWidth());
        if (getInnerView() instanceof DCWXScrollView) {
            ((DCWXScrollView) getInnerView()).smoothScrollTo(0, (int) realPxByWidth);
        } else if (getInnerView() instanceof DCWXHorizontalScrollView) {
            ((DCWXHorizontalScrollView) getInnerView()).smoothScrollTo((int) realPxByWidth, 0);
        }
        if (jSCallback != null) {
            HashMap hashMap = new HashMap();
            hashMap.put("type", WXImage.SUCCEED);
            jSCallback.invoke(hashMap);
        }
    }

    @JSMethod
    public void scrollToTop() {
        if ((getInnerView() instanceof DCWXScrollView) && this.canScroll2Top) {
            ((DCWXScrollView) getInnerView()).smoothScrollTo(0, 0);
        }
    }

    @WXComponentProp(name = "decelerationRate")
    public void setDecelerationRate(float f2) {
        if (getInnerView() instanceof DCWXScrollView) {
            ((DCWXScrollView) getInnerView()).setRate(f2);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void setLayout(WXComponent wXComponent) {
        if (!TextUtils.isEmpty(wXComponent.getComponentType()) && !TextUtils.isEmpty(wXComponent.getRef()) && wXComponent.getLayoutPosition() != null && wXComponent.getLayoutSize() != null) {
            if (wXComponent.getHostView() != null) {
                ViewCompat.setLayoutDirection(wXComponent.getHostView(), wXComponent.isLayoutRTL() ? 1 : 0);
            }
            setLayout(wXComponent);
        }
    }

    @WXComponentProp(name = "lowerThreshold")
    public void setLowwerHeight(int i2) {
        ViewGroup innerView = getInnerView();
        float realPxByWidth = WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidth());
        if (innerView instanceof DCWXHorizontalScrollView) {
            ((DCWXHorizontalScrollView) innerView).setLowwerLength(realPxByWidth);
        } else if (innerView instanceof DCWXScrollView) {
            ((DCWXScrollView) innerView).setLowwerLength(realPxByWidth);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void setMarginsSupportRTL(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, int i3, int i4, int i5) {
        marginLayoutParams.setMargins(i2, i3, i4, i5);
        marginLayoutParams.setMarginStart(i2);
        marginLayoutParams.setMarginEnd(i4);
    }

    @WXComponentProp(name = Constants.Name.OFFSET_ACCURACY)
    public void setOffsetAccuracy(int i2) {
        this.mOffsetAccuracy = (int) WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidth());
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -223520855:
                if (str.equals(Constants.Name.SHOW_SCROLLBAR)) {
                    c2 = 0;
                    break;
                }
                break;
            case -101546095:
                if (str.equals("scrollWithAnimation")) {
                    c2 = 1;
                    break;
                }
                break;
            case -5620052:
                if (str.equals(Constants.Name.OFFSET_ACCURACY)) {
                    c2 = 2;
                    break;
                }
                break;
            case 66669991:
                if (str.equals(Constants.Name.SCROLLABLE)) {
                    c2 = 3;
                    break;
                }
                break;
            case 1926689579:
                if (str.equals("scrollX")) {
                    c2 = 4;
                    break;
                }
                break;
            case 1926689580:
                if (str.equals("scrollY")) {
                    c2 = 5;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                setShowScrollbar(bool.booleanValue());
                return true;
            case 1:
                setScrollWithAnimation(WXUtils.getBoolean(obj, false).booleanValue());
                break;
            case 2:
                setOffsetAccuracy(WXUtils.getInteger(obj, 10).intValue());
                return true;
            case 3:
                setScrollable(WXUtils.getBoolean(obj, true).booleanValue());
                return true;
            case 4:
            case 5:
                setScrollable(!String.valueOf(obj).equals(AbsoluteConst.FALSE));
                return true;
        }
        return setProperty(str, obj);
    }

    @WXComponentProp(name = "scrollIntoView")
    public void setScrollIntoView(String str) {
        if (!this.isViewLayoutFinished.get()) {
            getInnerView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this, str) { // from class: com.taobao.weex.ui.component.DCWXScroller.12
                final DCWXScroller this$0;
                final String val$ref;

                {
                    this.this$0 = r4;
                    this.val$ref = r5;
                }

                @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                public void onGlobalLayout() {
                    if (this.this$0.getInstance() != null) {
                        WXComponent wXComponentById = WXSDKManager.getInstance().getWXRenderManager().getWXComponentById(this.this$0.getInstanceId(), this.val$ref);
                        if (wXComponentById != null) {
                            this.this$0.scrollTo(wXComponentById, JSONObject.parseObject("{'animated':false}"));
                        }
                        this.this$0.isViewLayoutFinished.set(true);
                        this.this$0.handler.postDelayed(new Runnable(this, this) { // from class: com.taobao.weex.ui.component.DCWXScroller.12.1
                            final AnonymousClass12 this$1;
                            final ViewTreeObserver.OnGlobalLayoutListener val$that;

                            {
                                this.this$1 = r4;
                                this.val$that = r5;
                            }

                            @Override // java.lang.Runnable
                            public void run() {
                                this.this$1.this$0.getInnerView().getViewTreeObserver().removeOnGlobalLayoutListener(this.val$that);
                            }
                        }, 100);
                    }
                }
            });
            return;
        }
        WXComponent wXComponentById = WXSDKManager.getInstance().getWXRenderManager().getWXComponentById(getInstanceId(), str);
        if (wXComponentById != null) {
            scrollTo(wXComponentById, JSONObject.parseObject(StringUtil.format("{'animated':%b}", Boolean.valueOf(this.isAnimation))));
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLL_LEFT)
    public void setScrollLeft(String str) {
        if (getInnerView() instanceof DCWXHorizontalScrollView) {
            float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(str), getInstance().getInstanceViewPortWidth());
            if (!this.isViewLayoutFinished.get()) {
                getInnerView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this, realPxByWidth) { // from class: com.taobao.weex.ui.component.DCWXScroller.15
                    final DCWXScroller this$0;
                    final float val$realPx;

                    {
                        this.this$0 = r4;
                        this.val$realPx = r5;
                    }

                    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                    public void onGlobalLayout() {
                        ObjectAnimator.ofInt(this.this$0.getInnerView(), "scrollX", this.this$0.getInnerView().getScrollX(), (int) this.val$realPx).setDuration(1L).start();
                        this.this$0.isViewLayoutFinished.set(true);
                        this.this$0.handler.postDelayed(new Runnable(this, this) { // from class: com.taobao.weex.ui.component.DCWXScroller.15.1
                            final AnonymousClass15 this$1;
                            final ViewTreeObserver.OnGlobalLayoutListener val$that;

                            {
                                this.this$1 = r4;
                                this.val$that = r5;
                            }

                            @Override // java.lang.Runnable
                            public void run() {
                                this.this$1.this$0.getInnerView().getViewTreeObserver().removeOnGlobalLayoutListener(this.val$that);
                            }
                        }, 100);
                    }
                });
                return;
            }
            if (this.isAnimation) {
                if (getInnerView() instanceof DCWXHorizontalScrollView) {
                    ((DCWXHorizontalScrollView) getInnerView()).stopScroll();
                }
                ObjectAnimator.ofInt(getInnerView(), "scrollX", getInnerView().getScrollX(), (int) realPxByWidth).setDuration(200L).start();
            } else {
                ((DCWXHorizontalScrollView) getInnerView()).smoothScrollTo((int) realPxByWidth, 0);
            }
            this.isViewLayoutFinished.set(true);
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLL_TOP)
    public void setScrollTop(String str) {
        if (getInnerView() instanceof DCWXScrollView) {
            float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(str), getInstance().getInstanceViewPortWidth());
            if (!this.isViewLayoutFinished.get()) {
                getInnerView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this, realPxByWidth) { // from class: com.taobao.weex.ui.component.DCWXScroller.13
                    final DCWXScroller this$0;
                    final float val$realPy;

                    {
                        this.this$0 = r4;
                        this.val$realPy = r5;
                    }

                    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                    public void onGlobalLayout() {
                        this.this$0.getInnerView().scrollTo(0, (int) this.val$realPy);
                        this.this$0.isViewLayoutFinished.set(true);
                        this.this$0.handler.postDelayed(new Runnable(this, this) { // from class: com.taobao.weex.ui.component.DCWXScroller.13.1
                            final AnonymousClass13 this$1;
                            final ViewTreeObserver.OnGlobalLayoutListener val$that;

                            {
                                this.this$1 = r4;
                                this.val$that = r5;
                            }

                            @Override // java.lang.Runnable
                            public void run() {
                                this.this$1.this$0.getInnerView().getViewTreeObserver().removeOnGlobalLayoutListener(this.val$that);
                            }
                        }, 100);
                    }
                });
                return;
            }
            if (this.isAnimation) {
                if (getInnerView() instanceof DCWXScrollView) {
                    ((DCWXScrollView) getInnerView()).stopScroll();
                }
                ObjectAnimator.ofInt(getInnerView(), "scrollY", getInnerView().getScrollY(), (int) realPxByWidth).setDuration(200L).start();
            } else {
                getInnerView().post(new Runnable(this, realPxByWidth) { // from class: com.taobao.weex.ui.component.DCWXScroller.14
                    final DCWXScroller this$0;
                    final float val$realPy;

                    {
                        this.this$0 = r4;
                        this.val$realPy = r5;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        this.this$0.getInnerView().scrollTo(0, (int) this.val$realPy);
                    }
                });
            }
            this.isViewLayoutFinished.set(true);
        }
    }

    @WXComponentProp(name = "scrollWithAnimation")
    public void setScrollWithAnimation(boolean z2) {
        this.isAnimation = z2;
    }

    public void setScrollable(boolean z2) {
        this.isScrollable = z2;
        ViewGroup innerView = getInnerView();
        if (innerView instanceof DCWXHorizontalScrollView) {
            ((DCWXHorizontalScrollView) innerView).setScrollable(z2);
        } else if (innerView instanceof DCWXScrollView) {
            ((DCWXScrollView) innerView).setScrollable(z2);
        }
    }

    @WXComponentProp(name = Constants.Name.SHOW_SCROLLBAR)
    public void setShowScrollbar(boolean z2) {
        if (getInnerView() != null) {
            if (this.mOrientation == 1) {
                getInnerView().setVerticalScrollBarEnabled(z2);
            } else {
                getInnerView().setHorizontalScrollBarEnabled(z2);
            }
        }
    }

    @WXComponentProp(name = "upperThreshold")
    public void setUpperHeight(int i2) {
        ViewGroup innerView = getInnerView();
        float realPxByWidth = WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidth());
        if (innerView instanceof DCWXHorizontalScrollView) {
            ((DCWXHorizontalScrollView) innerView).setUpperLength(realPxByWidth);
        } else if (innerView instanceof DCWXScrollView) {
            ((DCWXScrollView) innerView).setUpperLength(realPxByWidth);
        }
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void unbindAppearEvent(WXComponent wXComponent) {
        setWatch(0, wXComponent, false);
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void unbindDisappearEvent(WXComponent wXComponent) {
        setWatch(1, wXComponent, false);
    }

    @Override // com.taobao.weex.ui.component.WXBaseScroller, com.taobao.weex.ui.component.Scrollable
    public void unbindStickStyle(WXComponent wXComponent) {
        this.stickyHelper.unbindStickStyle(wXComponent, this.mStickyMap);
    }
}
