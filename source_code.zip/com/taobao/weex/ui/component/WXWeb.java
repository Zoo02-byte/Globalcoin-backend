package com.taobao.weex.ui.component;

import android.content.Context;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.view.IWebView;
import com.taobao.weex.ui.view.WXWebView;
import com.taobao.weex.utils.WXUtils;
import io.dcloud.common.constant.AbsoluteConst;
import java.util.HashMap;
import java.util.Map;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXWeb.class */
public class WXWeb extends WXComponent {
    public static final String GO_BACK = "goBack";
    public static final String GO_FORWARD = "goForward";
    public static final String POST_MESSAGE = "postMessage";
    public static final String RELOAD = "reload";
    protected IWebView mWebView;

    @Deprecated
    public WXWeb(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXWeb(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        createWebView();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fireEvent(String str, Object obj) {
        if (getEvents().contains("error")) {
            HashMap hashMap = new HashMap();
            hashMap.put("type", str);
            hashMap.put("errorMsg", obj);
            fireEvent("error", (Map<String, Object>) hashMap);
        }
    }

    private IWebView getWebView() {
        return this.mWebView;
    }

    private void loadDataWithBaseURL(String str) {
        getWebView().loadDataWithBaseURL(str);
    }

    protected void createWebView() {
        String str;
        try {
            Uri parse = Uri.parse(WXSDKManager.getInstance().getSDKInstance(getInstanceId()).getBundleUrl());
            String scheme = parse.getScheme();
            String authority = parse.getAuthority();
            str = null;
            if (!TextUtils.isEmpty(scheme)) {
                str = null;
                if (!TextUtils.isEmpty(authority)) {
                    str = scheme + "://" + authority;
                }
            }
        } catch (Exception e2) {
            str = null;
        }
        this.mWebView = new WXWebView(getContext(), str);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        getWebView().destroy();
        this.mWebView = null;
    }

    @JSMethod
    public void goBack() {
        getWebView().goBack();
    }

    @JSMethod
    public void goForward() {
        getWebView().goForward();
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected View initComponentHostView(Context context) {
        this.mWebView.setOnErrorListener(new IWebView.OnErrorListener(this) { // from class: com.taobao.weex.ui.component.WXWeb.1
            final WXWeb this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.IWebView.OnErrorListener
            public void onError(String str, Object obj) {
                this.this$0.fireEvent(str, obj);
            }
        });
        this.mWebView.setOnPageListener(new IWebView.OnPageListener(this) { // from class: com.taobao.weex.ui.component.WXWeb.2
            final WXWeb this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.IWebView.OnPageListener
            public void onPageFinish(String str, boolean z2, boolean z3) {
                if (this.this$0.getEvents().contains(Constants.Event.PAGEFINISH)) {
                    HashMap hashMap = new HashMap();
                    hashMap.put("url", str);
                    hashMap.put("canGoBack", Boolean.valueOf(z2));
                    hashMap.put("canGoForward", Boolean.valueOf(z3));
                    this.this$0.fireEvent(Constants.Event.PAGEFINISH, (Map<String, Object>) hashMap);
                }
            }

            @Override // com.taobao.weex.ui.view.IWebView.OnPageListener
            public void onPageStart(String str) {
                if (this.this$0.getEvents().contains(Constants.Event.PAGESTART)) {
                    HashMap hashMap = new HashMap();
                    hashMap.put("url", str);
                    this.this$0.fireEvent(Constants.Event.PAGESTART, (Map<String, Object>) hashMap);
                }
            }

            @Override // com.taobao.weex.ui.view.IWebView.OnPageListener
            public void onReceivedTitle(String str) {
                if (this.this$0.getEvents().contains(Constants.Event.RECEIVEDTITLE)) {
                    HashMap hashMap = new HashMap();
                    hashMap.put(AbsoluteConst.JSON_KEY_TITLE, str);
                    this.this$0.fireEvent(Constants.Event.RECEIVEDTITLE, (Map<String, Object>) hashMap);
                }
            }
        });
        this.mWebView.setOnMessageListener(new IWebView.OnMessageListener(this) { // from class: com.taobao.weex.ui.component.WXWeb.3
            final WXWeb this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.IWebView.OnMessageListener
            public void onMessage(Map<String, Object> map) {
                this.this$0.fireEvent("message", map);
            }
        });
        return this.mWebView.getView();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void loadUrl(String str) {
        getWebView().loadUrl(str);
    }

    @JSMethod
    public void postMessage(Object obj) {
        getWebView().postMessage(obj);
    }

    @JSMethod
    public void reload() {
        getWebView().reload();
    }

    public void setAction(String str, Object obj) {
        if (TextUtils.isEmpty(str)) {
            return;
        }
        if (str.equals(GO_BACK)) {
            goBack();
        } else if (str.equals(GO_FORWARD)) {
            goForward();
        } else if (str.equals(RELOAD)) {
            reload();
        } else if (str.equals(POST_MESSAGE)) {
            postMessage(obj);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -896505829:
                if (str.equals("source")) {
                    c2 = 0;
                    break;
                }
                break;
            case 114148:
                if (str.equals("src")) {
                    c2 = 1;
                    break;
                }
                break;
            case 537088620:
                if (str.equals(Constants.Name.SHOW_LOADING)) {
                    c2 = 2;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setSource(string);
                return true;
            case 1:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setUrl(string2);
                return true;
            case 2:
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                setShowLoading(bool.booleanValue());
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @WXComponentProp(name = Constants.Name.SHOW_LOADING)
    public void setShowLoading(boolean z2) {
        getWebView().setShowLoading(z2);
    }

    @WXComponentProp(name = "source")
    public void setSource(String str) {
        if (!TextUtils.isEmpty(str) && getHostView() != null) {
            loadDataWithBaseURL(str);
        }
    }

    @WXComponentProp(name = "src")
    public void setUrl(String str) {
        if (!TextUtils.isEmpty(str) && getHostView() != null && !TextUtils.isEmpty(str)) {
            loadUrl(getInstance().rewriteUri(Uri.parse(str), "web").toString());
        }
    }
}
