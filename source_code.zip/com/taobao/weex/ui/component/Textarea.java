package com.taobao.weex.ui.component;

import android.text.TextUtils;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.view.WXEditText;
import com.taobao.weex.utils.WXUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/Textarea.class */
public class Textarea extends AbstractEditComponent {
    public static final int DEFAULT_ROWS = 2;
    private int mNumberOfLines = 2;

    public Textarea(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.AbstractEditComponent
    public void appleStyleAfterCreated(WXEditText wXEditText) {
        appleStyleAfterCreated(wXEditText);
        String str = (String) getStyles().get(Constants.Name.ROWS);
        int i2 = 2;
        try {
            if (!TextUtils.isEmpty(str)) {
                i2 = Integer.parseInt(str);
            }
        } catch (NumberFormatException e2) {
            e2.printStackTrace();
            i2 = 2;
        }
        wXEditText.setLines(i2);
        wXEditText.setMinLines(i2);
    }

    @Override // com.taobao.weex.ui.component.AbstractEditComponent
    protected float getMeasureHeight() {
        return getMeasuredLineHeight() * ((float) this.mNumberOfLines);
    }

    @Override // com.taobao.weex.ui.component.AbstractEditComponent
    protected int getVerticalGravity() {
        return 48;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.AbstractEditComponent
    public void onHostViewInitialized(WXEditText wXEditText) {
        wXEditText.setAllowDisableMovement(false);
        onHostViewInitialized(wXEditText);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.AbstractEditComponent, com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        if (!str.equals(Constants.Name.ROWS)) {
            return setProperty(str, obj);
        }
        Integer integer = WXUtils.getInteger(obj, null);
        if (integer == null) {
            return true;
        }
        setRows(integer.intValue());
        return true;
    }

    @WXComponentProp(name = Constants.Name.ROWS)
    public void setRows(int i2) {
        WXEditText hostView = getHostView();
        if (hostView != null && i2 > 0) {
            hostView.setLines(i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.AbstractEditComponent
    public void updateStyleAndAttrs() {
        updateStyleAndAttrs();
        Object obj = getAttrs().get(Constants.Name.ROWS);
        if (obj != null) {
            if (obj instanceof String) {
                try {
                    int parseInt = Integer.parseInt((String) obj);
                    if (parseInt > 0) {
                        this.mNumberOfLines = parseInt;
                    }
                } catch (NumberFormatException e2) {
                    e2.printStackTrace();
                }
            } else if (obj instanceof Integer) {
                this.mNumberOfLines = ((Integer) obj).intValue();
            }
        }
    }
}
