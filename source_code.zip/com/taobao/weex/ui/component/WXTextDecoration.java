package com.taobao.weex.ui.component;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXTextDecoration.class */
public enum WXTextDecoration {
    INVALID,
    NONE,
    UNDERLINE,
    LINETHROUGH
}
