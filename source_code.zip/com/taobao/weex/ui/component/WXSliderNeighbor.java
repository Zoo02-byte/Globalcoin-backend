package com.taobao.weex.ui.component;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.viewpager.widget.ViewPager;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.ui.ComponentCreator;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.view.BaseFrameLayout;
import com.taobao.weex.ui.view.WXCircleIndicator;
import com.taobao.weex.ui.view.WXCirclePageAdapter;
import com.taobao.weex.ui.view.WXCircleViewPager;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSliderNeighbor.class */
public class WXSliderNeighbor extends WXSlider {
    public static final String CURRENT_ITEM_SCALE = "currentItemScale";
    private static final float DEFAULT_CURRENT_ITEM_SCALE = 0.9f;
    private static final float DEFAULT_NEIGHBOR_ALPHA = 0.6f;
    private static final float DEFAULT_NEIGHBOR_SCALE = 0.8f;
    private static final int DEFAULT_NEIGHBOR_SPACE = 25;
    public static final String NEIGHBOR_ALPHA = "neighborAlpha";
    public static final String NEIGHBOR_SCALE = "neighborScale";
    public static final String NEIGHBOR_SPACE = "neighborSpace";
    private ZoomTransformer mCachedTransformer;
    private float mNeighborScale = DEFAULT_NEIGHBOR_SCALE;
    private float mNeighborAlpha = DEFAULT_NEIGHBOR_ALPHA;
    private float mNeighborSpace = 25.0f;
    private float mCurrentItemScale = DEFAULT_CURRENT_ITEM_SCALE;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSliderNeighbor$Creator.class */
    public static class Creator implements ComponentCreator {
        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            return new WXSliderNeighbor(wXSDKInstance, wXVContainer, basicComponentData);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSliderNeighbor$ZoomTransformer.class */
    public class ZoomTransformer implements ViewPager.PageTransformer {
        final WXSliderNeighbor this$0;

        ZoomTransformer(WXSliderNeighbor wXSliderNeighbor) {
            this.this$0 = wXSliderNeighbor;
        }

        @Override // androidx.viewpager.widget.ViewPager.PageTransformer
        public void transformPage(View view, float f2) {
            View childAt;
            int pagePosition = this.this$0.mAdapter.getPagePosition(view);
            int currentItem = this.this$0.mViewPager.getCurrentItem();
            int realCount = this.this$0.mAdapter.getRealCount();
            boolean z2 = (currentItem == 0 || currentItem == realCount - 1 || Math.abs(pagePosition - currentItem) <= 1) ? false : true;
            boolean z3 = z2;
            if (currentItem == 0) {
                z3 = z2;
                if (pagePosition < realCount - 1) {
                    z3 = z2;
                    if (pagePosition > 1) {
                        z3 = true;
                    }
                }
            }
            int i2 = realCount - 1;
            boolean z4 = z3;
            if (currentItem == i2) {
                z4 = z3;
                if (pagePosition < realCount - 2) {
                    z4 = z3;
                    if (pagePosition > 0) {
                        z4 = true;
                    }
                }
            }
            if (!z4 && (childAt = ((ViewGroup) view).getChildAt(0)) != null) {
                float f3 = f2;
                if (f2 <= ((float) ((-realCount) + 1))) {
                    f3 = f2 + ((float) realCount);
                }
                float f4 = f3;
                if (f3 >= ((float) i2)) {
                    f4 = f3 - ((float) realCount);
                }
                if (f4 >= -1.0f && f4 <= 1.0f) {
                    float abs = Math.abs(Math.abs(f4) - 1.0f);
                    float f5 = this.this$0.mNeighborScale + ((this.this$0.mCurrentItemScale - this.this$0.mNeighborScale) * abs);
                    float f6 = this.this$0.mNeighborAlpha;
                    float f7 = this.this$0.mNeighborAlpha;
                    float calculateTranslation = this.this$0.calculateTranslation(view);
                    int i3 = (f4 > 0.0f ? 1 : (f4 == 0.0f ? 0 : -1));
                    if (i3 > 0) {
                        float f8 = -(f4 * calculateTranslation);
                        childAt.setTranslationX(f8);
                        view.setTranslationX(f8);
                    } else if (i3 == 0) {
                        view.setTranslationX(0.0f);
                        childAt.setTranslationX(0.0f);
                        WXSliderNeighbor wXSliderNeighbor = this.this$0;
                        wXSliderNeighbor.updateAdapterScaleAndAlpha(wXSliderNeighbor.mNeighborAlpha, this.this$0.mNeighborScale);
                    } else if (realCount != 2 || Math.abs(f4) != 1.0f) {
                        float f9 = (-f4) * calculateTranslation;
                        childAt.setTranslationX(f9);
                        view.setTranslationX(f9);
                    } else {
                        return;
                    }
                    childAt.setScaleX(f5);
                    childAt.setScaleY(f5);
                    childAt.setAlpha(((1.0f - f6) * abs) + f7);
                }
            }
        }
    }

    public WXSliderNeighbor(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float calculateTranslation(View view) {
        if (!(view instanceof ViewGroup)) {
            return 0.0f;
        }
        View childAt = ((ViewGroup) view).getChildAt(0);
        return ((((float) view.getMeasuredWidth()) - (((float) childAt.getMeasuredWidth()) * this.mNeighborScale)) / 4.0f) + ((((((float) view.getMeasuredWidth()) - (((float) childAt.getMeasuredWidth()) * this.mCurrentItemScale)) / 2.0f) - WXViewUtils.getRealPxByWidth(this.mNeighborSpace, getInstance().getInstanceViewPortWidthWithFloat())) / 2.0f);
    }

    private void moveLeft(View view, float f2, float f3, float f4) {
        ViewGroup viewGroup = (ViewGroup) view;
        updateScaleAndAlpha(viewGroup.getChildAt(0), f3, f4);
        view.setTranslationX(f2);
        viewGroup.getChildAt(0).setTranslationX(f2);
    }

    private void moveRight(View view, float f2, float f3, float f4) {
        moveLeft(view, -f2, f3, f4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateAdapterScaleAndAlpha(float f2, float f3) {
        List<View> views = this.mAdapter.getViews();
        int currentItem = this.mViewPager.getCurrentItem();
        if (views.size() > 0) {
            View view = views.get(currentItem);
            updateScaleAndAlpha(((ViewGroup) view).getChildAt(0), 1.0f, this.mCurrentItemScale);
            if (views.size() >= 2) {
                view.postDelayed(WXThread.secure(new Runnable(this, view, f2, f3) { // from class: com.taobao.weex.ui.component.WXSliderNeighbor.2
                    final WXSliderNeighbor this$0;
                    final float val$alpha;
                    final View val$currentPage;
                    final float val$scale;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.this$0 = r4;
                        this.val$currentPage = r5;
                        this.val$alpha = r6;
                        this.val$scale = r7;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        this.this$0.updateNeighbor(this.val$currentPage, this.val$alpha, this.val$scale);
                    }
                }), 17);
                int size = currentItem == 0 ? views.size() - 1 : currentItem - 1;
                int i2 = currentItem == views.size() - 1 ? 0 : currentItem + 1;
                for (int i3 = 0; i3 < this.mAdapter.getRealCount(); i3++) {
                    if (!(i3 == size || i3 == currentItem || i3 == i2)) {
                        ((ViewGroup) views.get(i3)).getChildAt(0).setAlpha(0.0f);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateNeighbor(View view, float f2, float f3) {
        List<View> views = this.mAdapter.getViews();
        int currentItem = this.mViewPager.getCurrentItem();
        float calculateTranslation = calculateTranslation(view);
        View view2 = views.get(currentItem == 0 ? views.size() - 1 : currentItem - 1);
        View view3 = views.get(currentItem == views.size() - 1 ? 0 : currentItem + 1);
        if (views.size() != 2) {
            moveLeft(view2, calculateTranslation, f2, f3);
            moveRight(view3, calculateTranslation, f2, f3);
        } else if (currentItem == 0) {
            moveRight(view3, calculateTranslation, f2, f3);
        } else if (currentItem == 1) {
            moveLeft(view2, calculateTranslation, f2, f3);
        }
    }

    private void updateScaleAndAlpha(View view, float f2, float f3) {
        if (view != null) {
            if (f2 >= 0.0f && view.getAlpha() != f2) {
                view.setAlpha(f2);
            }
            if (f3 >= 0.0f && view.getScaleX() != f3) {
                view.setScaleX(f3);
                view.setScaleY(f3);
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXSlider, io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addSubView(View view, int i2) {
        if (view != null && this.mAdapter != null && !(view instanceof WXCircleIndicator)) {
            FrameLayout frameLayout = new FrameLayout(getContext());
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 17;
            view.setLayoutParams(layoutParams);
            frameLayout.addView(view);
            addSubView(frameLayout, i2);
            updateAdapterScaleAndAlpha(this.mNeighborAlpha, this.mNeighborScale);
            this.mViewPager.postDelayed(WXThread.secure(new Runnable(this, i2) { // from class: com.taobao.weex.ui.component.WXSliderNeighbor.1
                final WXSliderNeighbor this$0;
                final int val$index;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$0 = r4;
                    this.val$index = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    WXSliderNeighbor wXSliderNeighbor;
                    try {
                        try {
                            if (this.this$0.mViewPager.getRealCount() > 0 && this.val$index > 2) {
                                this.this$0.mViewPager.beginFakeDrag();
                                this.this$0.mViewPager.fakeDragBy(1.0f);
                            }
                            wXSliderNeighbor = this.this$0;
                        } catch (IndexOutOfBoundsException e2) {
                            wXSliderNeighbor = this.this$0;
                        } catch (Throwable th) {
                            try {
                                this.this$0.mViewPager.endFakeDrag();
                            } catch (Exception e3) {
                            }
                            throw th;
                        }
                        wXSliderNeighbor.mViewPager.endFakeDrag();
                    } catch (Exception e4) {
                    }
                }
            }), 50);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void bindData(WXComponent wXComponent) {
        bindData(wXComponent);
    }

    ZoomTransformer createTransformer() {
        if (this.mCachedTransformer == null) {
            this.mCachedTransformer = new ZoomTransformer(this);
        }
        return this.mCachedTransformer;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXSlider, com.taobao.weex.ui.component.WXComponent
    public BaseFrameLayout initComponentHostView(Context context) {
        BaseFrameLayout baseFrameLayout = new BaseFrameLayout(context);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.gravity = 17;
        this.mViewPager = new WXCircleViewPager(getContext());
        this.mViewPager.setLayoutParams(layoutParams);
        this.mAdapter = new WXCirclePageAdapter();
        this.mViewPager.setAdapter(this.mAdapter);
        baseFrameLayout.addView(this.mViewPager);
        this.mViewPager.addOnPageChangeListener(this.mPageChangeListener);
        this.mViewPager.setOverScrollMode(2);
        registerActivityStateListener();
        this.mViewPager.setPageTransformer(false, createTransformer());
        return baseFrameLayout;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    @com.taobao.weex.ui.component.WXComponentProp(name = com.taobao.weex.ui.component.WXSliderNeighbor.CURRENT_ITEM_SCALE)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void setCurrentItemScale(java.lang.String r5) {
        /*
            r4 = this;
            r0 = r5
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x000f
            r0 = r5
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: NumberFormatException -> 0x002b
            r6 = r0
            goto L_0x0012
        L_0x000f:
            r0 = 1063675494(0x3f666666, float:0.9)
            r6 = r0
        L_0x0012:
            r0 = r4
            float r0 = r0.mCurrentItemScale
            r1 = r6
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x002a
            r0 = r4
            r1 = r6
            r0.mCurrentItemScale = r1
            r0 = r4
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            r2 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0.updateAdapterScaleAndAlpha(r1, r2)
        L_0x002a:
            return
        L_0x002b:
            r5 = move-exception
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXSliderNeighbor.setCurrentItemScale(java.lang.String):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    @com.taobao.weex.ui.component.WXComponentProp(name = com.taobao.weex.ui.component.WXSliderNeighbor.NEIGHBOR_ALPHA)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void setNeighborAlpha(java.lang.String r5) {
        /*
            r4 = this;
            r0 = r5
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x000f
            r0 = r5
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: NumberFormatException -> 0x0029
            r6 = r0
            goto L_0x0012
        L_0x000f:
            r0 = 1058642330(0x3f19999a, float:0.6)
            r6 = r0
        L_0x0012:
            r0 = r4
            float r0 = r0.mNeighborAlpha
            r1 = r6
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x0028
            r0 = r4
            r1 = r6
            r0.mNeighborAlpha = r1
            r0 = r4
            r1 = r6
            r2 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0.updateAdapterScaleAndAlpha(r1, r2)
        L_0x0028:
            return
        L_0x0029:
            r5 = move-exception
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXSliderNeighbor.setNeighborAlpha(java.lang.String):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    @com.taobao.weex.ui.component.WXComponentProp(name = com.taobao.weex.ui.component.WXSliderNeighbor.NEIGHBOR_SCALE)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void setNeighborScale(java.lang.String r5) {
        /*
            r4 = this;
            r0 = r5
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x000f
            r0 = r5
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: NumberFormatException -> 0x0029
            r6 = r0
            goto L_0x0012
        L_0x000f:
            r0 = 1061997773(0x3f4ccccd, float:0.8)
            r6 = r0
        L_0x0012:
            r0 = r4
            float r0 = r0.mNeighborScale
            r1 = r6
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x0028
            r0 = r4
            r1 = r6
            r0.mNeighborScale = r1
            r0 = r4
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            r2 = r6
            r0.updateAdapterScaleAndAlpha(r1, r2)
        L_0x0028:
            return
        L_0x0029:
            r5 = move-exception
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXSliderNeighbor.setNeighborScale(java.lang.String):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    @com.taobao.weex.ui.component.WXComponentProp(name = com.taobao.weex.ui.component.WXSliderNeighbor.NEIGHBOR_SPACE)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void setNeighborSpace(java.lang.String r4) {
        /*
            r3 = this;
            r0 = r4
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x000f
            r0 = r4
            float r0 = java.lang.Float.parseFloat(r0)     // Catch: NumberFormatException -> 0x0021
            r5 = r0
            goto L_0x0012
        L_0x000f:
            r0 = 1103626240(0x41c80000, float:25.0)
            r5 = r0
        L_0x0012:
            r0 = r3
            float r0 = r0.mNeighborSpace
            r1 = r5
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x0020
            r0 = r3
            r1 = r5
            r0.mNeighborSpace = r1
        L_0x0020:
            return
        L_0x0021:
            r4 = move-exception
            goto L_0x000f
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.WXSliderNeighbor.setNeighborSpace(java.lang.String):void");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXSlider, com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1763701364:
                if (str.equals(NEIGHBOR_ALPHA)) {
                    c2 = 0;
                    break;
                }
                break;
            case -1747360392:
                if (str.equals(NEIGHBOR_SCALE)) {
                    c2 = 1;
                    break;
                }
                break;
            case -1746973388:
                if (str.equals(NEIGHBOR_SPACE)) {
                    c2 = 2;
                    break;
                }
                break;
            case -1013904258:
                if (str.equals(CURRENT_ITEM_SCALE)) {
                    c2 = 3;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setNeighborAlpha(string);
                return true;
            case 1:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setNeighborScale(string2);
                return true;
            case 2:
                String string3 = WXUtils.getString(obj, null);
                if (string3 == null) {
                    return true;
                }
                setNeighborSpace(string3);
                return true;
            case 3:
                String string4 = WXUtils.getString(obj, null);
                if (string4 == null) {
                    return true;
                }
                setCurrentItemScale(string4);
                return true;
            default:
                return setProperty(str, obj);
        }
    }
}
