package com.taobao.weex.ui.component.list;

import java.util.regex.Pattern;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/RecyclerTransform.class */
public class RecyclerTransform {
    private static final String TAG = "RecyclerTransform";
    public static final String TRANSFORM = "transform";
    private static final Pattern transformPattern = Pattern.compile("([a-z]+)\\(([0-9\\.]+),?([0-9\\.]+)?\\)");

    /* JADX WARN: Removed duplicated region for block: B:74:0x0193 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00d7 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public static androidx.recyclerview.widget.RecyclerView.ItemDecoration parseTransforms(int r10, java.lang.String r11) {
        /*
        // Method dump skipped, instructions count: 530
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.list.RecyclerTransform.parseTransforms(int, java.lang.String):androidx.recyclerview.widget.RecyclerView$ItemDecoration");
    }
}
