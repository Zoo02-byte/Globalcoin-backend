package com.taobao.weex.ui.component.list;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.utils.WXLogUtils;
import io.dcloud.common.DHInterface.IApp;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/DefaultDragHelper.class */
public class DefaultDragHelper implements DragHelper {
    private static final String EVENT_END_DRAG = "dragend";
    private static final String EVENT_START_DRAG = "dragstart";
    private static final String TAG = "WXListExComponent";
    private static final String TAG_EXCLUDED = "drag_excluded";
    private boolean isDraggable = false;
    private final List<WXComponent> mDataSource;
    private final EventTrigger mEventTrigger;
    private ItemTouchHelper mItemTouchHelper;
    private boolean mLongPressEnabled;
    private final RecyclerView mRecyclerView;

    /* JADX INFO: Access modifiers changed from: package-private */
    public DefaultDragHelper(List<WXComponent> list, RecyclerView recyclerView, EventTrigger eventTrigger) {
        this.mDataSource = list;
        this.mEventTrigger = eventTrigger;
        this.mRecyclerView = recyclerView;
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new DragSupportCallback(this, true));
        this.mItemTouchHelper = itemTouchHelper;
        try {
            itemTouchHelper.attachToRecyclerView(recyclerView);
        } catch (Throwable th) {
        }
    }

    private Map<String, Object> buildEvent(String str, int i2, int i3) {
        HashMap hashMap = new HashMap(4);
        String str2 = str;
        if (str == null) {
            str2 = "unknown";
        }
        hashMap.put(IApp.ConfigProperty.CONFIG_TARGET, str2);
        hashMap.put("fromIndex", Integer.valueOf(i2));
        hashMap.put("toIndex", Integer.valueOf(i3));
        hashMap.put("timestamp", Long.valueOf(System.currentTimeMillis()));
        return hashMap;
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public boolean isDragExcluded(RecyclerView.ViewHolder viewHolder) {
        if (viewHolder.itemView != null) {
            boolean z2 = false;
            if (viewHolder.itemView.getTag() != null) {
                z2 = false;
                if (TAG_EXCLUDED.equals(viewHolder.itemView.getTag())) {
                    z2 = true;
                }
            }
            return z2;
        } else if (!WXEnvironment.isApkDebugable()) {
            return false;
        } else {
            WXLogUtils.e(TAG, "[error] viewHolder.itemView is null");
            return false;
        }
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public boolean isDraggable() {
        return this.isDraggable;
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public boolean isLongPressDragEnabled() {
        return this.mLongPressEnabled;
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void onDragEnd(WXComponent wXComponent, int i2, int i3) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d(TAG, "list on drag end : from index " + i2 + " to index " + i3);
        }
        this.mEventTrigger.triggerEvent(EVENT_END_DRAG, buildEvent(wXComponent.getRef(), i2, i3));
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void onDragStart(WXComponent wXComponent, int i2) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d(TAG, "list on drag start : from index " + i2);
        }
        this.mEventTrigger.triggerEvent(EVENT_START_DRAG, buildEvent(wXComponent.getRef(), i2, -1));
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void onDragging(int i2, int i3) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d(TAG, "list on dragging : from index " + i2 + " to index " + i3);
        }
        RecyclerView.Adapter adapter = this.mRecyclerView.getAdapter();
        if (adapter == null) {
            WXLogUtils.e(TAG, "drag failed because of RecyclerView#Adapter is not bound");
        } else if (i2 >= 0 && i2 <= this.mDataSource.size() - 1 && i3 >= 0 && i3 <= this.mDataSource.size() - 1) {
            Collections.swap(this.mDataSource, i2, i3);
            adapter.notifyItemMoved(i2, i3);
        }
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void setDragExcluded(RecyclerView.ViewHolder viewHolder, boolean z2) {
        if (viewHolder.itemView == null) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.e(TAG, "[error] viewHolder.itemView is null");
            }
        } else if (z2) {
            viewHolder.itemView.setTag(TAG_EXCLUDED);
        } else {
            viewHolder.itemView.setTag(null);
        }
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void setDraggable(boolean z2) {
        this.isDraggable = z2;
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void setLongPressDragEnabled(boolean z2) {
        this.mLongPressEnabled = z2;
    }

    @Override // com.taobao.weex.ui.component.list.DragHelper
    public void startDrag(RecyclerView.ViewHolder viewHolder) {
        if (this.isDraggable) {
            this.mItemTouchHelper.startDrag(viewHolder);
        }
    }
}
