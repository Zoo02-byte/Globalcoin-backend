package com.taobao.weex.ui.component.list.template;

import android.os.AsyncTask;
import android.os.Looper;
import android.os.MessageQueue;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.ui.component.list.WXCell;
import java.util.Iterator;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/AsyncCellLoadTask.class */
public class AsyncCellLoadTask extends AsyncTask<Void, Void, Void> {
    private WXCell source;
    private String template;
    private WXRecyclerTemplateList templateList;

    public AsyncCellLoadTask(String str, WXCell wXCell, WXRecyclerTemplateList wXRecyclerTemplateList) {
        this.template = str;
        this.source = wXCell;
        this.templateList = wXRecyclerTemplateList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isDestory() {
        if (this.source.getInstance() == null || this.source.getInstance().isDestroy()) {
            return true;
        }
        return this.templateList.isDestoryed();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public Void doInBackground(Void... voidArr) {
        TemplateCache templateCache = this.templateList.getTemplatesCache().get(this.template);
        if (templateCache == null || templateCache.cells == null) {
            return null;
        }
        while (templateCache.cells.size() < this.templateList.getTemplateCacheSize()) {
            System.currentTimeMillis();
            WXCell wXCell = (WXCell) this.templateList.copyComponentFromSourceCell(this.source);
            WXEnvironment.isOpenDebugLog();
            if (wXCell == null || isDestory()) {
                return null;
            }
            templateCache.cells.add(wXCell);
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void onPostExecute(Void r7) {
        TemplateCache templateCache;
        if (isDestory() || (templateCache = this.templateList.getTemplatesCache().get(this.template)) == null) {
            return;
        }
        if (templateCache.cells == null || templateCache.cells.size() == 0) {
            templateCache.isLoadIng = false;
            return;
        }
        Looper.myQueue().addIdleHandler(new MessageQueue.IdleHandler(this, templateCache) { // from class: com.taobao.weex.ui.component.list.template.AsyncCellLoadTask.1
            final AsyncCellLoadTask this$0;
            final TemplateCache val$cellCache;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$cellCache = r5;
            }

            @Override // android.os.MessageQueue.IdleHandler
            public boolean queueIdle() {
                if (this.this$0.isDestory()) {
                    return false;
                }
                Iterator<WXCell> it = this.val$cellCache.cells.iterator();
                while (it.hasNext()) {
                    WXCell next = it.next();
                    if (next.isLazy()) {
                        WXRecyclerTemplateList unused = this.this$0.templateList;
                        WXRecyclerTemplateList.doCreateCellViewBindData(next, this.this$0.template, true);
                        return it.hasNext();
                    }
                }
                return false;
            }
        });
        templateCache.isLoadIng = false;
    }

    public void startTask() {
        executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }
}
