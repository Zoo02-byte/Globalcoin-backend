package com.taobao.weex.ui.component.list.template;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/VirtualComponentLifecycle.class */
public class VirtualComponentLifecycle {
    public static final String ATTACH = "attach";
    public static final String CREATE = "create";
    public static final String DETACH = "detach";
    public static final String LIFECYCLE = "lifecycle";
    public static final String SYNSTATE = "syncState";
}
