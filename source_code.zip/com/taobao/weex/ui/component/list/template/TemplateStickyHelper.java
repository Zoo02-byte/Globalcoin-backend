package com.taobao.weex.ui.component.list.template;

import androidx.collection.ArrayMap;
import java.util.ArrayList;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/TemplateStickyHelper.class */
public class TemplateStickyHelper {
    private WXRecyclerTemplateList recyclerTemplateList;
    private List<Integer> stickyPositions = new ArrayList();
    private ArrayMap<Integer, TemplateViewHolder> stickyHolderCache = new ArrayMap<>();
    private List<String> mStickyTypes = new ArrayList(8);

    public TemplateStickyHelper(WXRecyclerTemplateList wXRecyclerTemplateList) {
        this.recyclerTemplateList = wXRecyclerTemplateList;
    }

    public List<Integer> getStickyPositions() {
        if (this.stickyPositions == null) {
            this.stickyPositions = new ArrayList();
        }
        return this.stickyPositions;
    }

    public List<String> getStickyTypes() {
        return this.mStickyTypes;
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x01bb, code lost:
        if (((com.taobao.weex.ui.component.list.template.TemplateViewHolder) r0.getTag()).getHolderPosition() != r8) goto L_0x01be;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void onBeforeScroll(int r6, int r7) {
        /*
        // Method dump skipped, instructions count: 1157
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.list.template.TemplateStickyHelper.onBeforeScroll(int, int):void");
    }
}
