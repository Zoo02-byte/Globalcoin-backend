package com.taobao.weex.ui.component.list.template.jni;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/jni/NativeRenderLayoutDirection.class */
public class NativeRenderLayoutDirection {
    public static final int inherit = 0;
    public static final int ltr = 1;
    public static final int rtl = 2;
}
