package com.taobao.weex.ui.component.list.template;

import android.text.TextUtils;
import androidx.collection.ArrayMap;
import com.alibaba.fastjson.JSONArray;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.utils.WXUtils;
import java.util.HashMap;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/CellDataManager.class */
public class CellDataManager {
    public static final String SUB_COMPONENT_TEMPLATE_ID;
    public static final String VIRTUAL_COMPONENT_ID;
    private static final String VIRTUAL_COMPONENT_SEPRATOR;
    JSONArray listData;
    private Map<Integer, CellRenderState> renderStates = new ArrayMap();
    public final WXRecyclerTemplateList templateList;
    private Map<String, CellRenderState> virtualComponentRenderStates;

    public CellDataManager(WXRecyclerTemplateList wXRecyclerTemplateList) {
        this.templateList = wXRecyclerTemplateList;
    }

    private void cleanRenderState(CellRenderState cellRenderState) {
        if (cellRenderState != null && cellRenderState.hasVirtualComponents()) {
            for (String str : cellRenderState.getVirtualComponentIds().values()) {
                Map<String, CellRenderState> map = this.virtualComponentRenderStates;
                if (map != null) {
                    map.remove(str);
                }
                WXBridgeManager.getInstance().asyncCallJSEventVoidResult(WXBridgeManager.METHD_COMPONENT_HOOK_SYNC, this.templateList.getInstanceId(), null, str, VirtualComponentLifecycle.LIFECYCLE, "detach", null);
            }
        }
    }

    public static String createVirtualComponentId(String str, String str2, long j2) {
        return str + VIRTUAL_COMPONENT_SEPRATOR + str2 + VIRTUAL_COMPONENT_SEPRATOR + j2;
    }

    public static String getListRef(String str) {
        if (str == null) {
            return null;
        }
        return str.split(VIRTUAL_COMPONENT_SEPRATOR)[0];
    }

    public void createVirtualComponentData(int i2, String str, Object obj) {
        if (this.virtualComponentRenderStates == null) {
            this.virtualComponentRenderStates = new HashMap(8);
        }
        CellRenderState cellRenderState = this.renderStates.get(Integer.valueOf(i2));
        cellRenderState.getVirtualComponentDatas().put(str, obj);
        this.virtualComponentRenderStates.put(str, cellRenderState);
    }

    public CellRenderState getRenderState(int i2) {
        CellRenderState cellRenderState = this.renderStates.get(Integer.valueOf(i2));
        CellRenderState cellRenderState2 = cellRenderState;
        if (cellRenderState == null) {
            cellRenderState2 = new CellRenderState();
            cellRenderState2.position = i2;
            this.renderStates.put(Integer.valueOf(i2), cellRenderState2);
        }
        if (i2 != cellRenderState2.position) {
            cellRenderState2.position = i2;
            cellRenderState2.hasPositionChange = true;
        }
        return cellRenderState2;
    }

    public boolean insertData(int i2, Object obj) {
        this.listData.add(i2, obj);
        boolean z2 = false;
        for (int size = this.listData.size(); size >= i2; size--) {
            CellRenderState remove = this.renderStates.remove(Integer.valueOf(size));
            if (remove != null) {
                this.renderStates.put(Integer.valueOf(size + 1), remove);
                z2 = true;
            }
        }
        return z2;
    }

    public boolean insertRange(int i2, JSONArray jSONArray) {
        this.listData.addAll(i2, jSONArray);
        boolean z2 = false;
        for (int size = this.listData.size() - 1; size >= i2; size--) {
            CellRenderState remove = this.renderStates.remove(Integer.valueOf(size));
            if (remove != null) {
                this.renderStates.put(Integer.valueOf(size + 1), remove);
                z2 = true;
            }
        }
        return z2;
    }

    public void removeData(Integer num) {
        this.listData.remove(num.intValue());
        cleanRenderState(this.renderStates.remove(num));
        int size = this.listData.size();
        int intValue = num.intValue();
        while (true) {
            intValue++;
            if (intValue < size + 1) {
                CellRenderState remove = this.renderStates.remove(Integer.valueOf(intValue));
                if (remove != null) {
                    this.renderStates.put(Integer.valueOf(intValue - 1), remove);
                }
            } else {
                return;
            }
        }
    }

    public void setListData(JSONArray jSONArray) {
        JSONArray jSONArray2 = this.listData;
        if (jSONArray2 != jSONArray) {
            if (jSONArray2 != null && WXUtils.getBoolean(this.templateList.getAttrs().get("exitDetach"), true).booleanValue()) {
                for (int i2 = 0; i2 < this.listData.size(); i2++) {
                    cleanRenderState(this.renderStates.remove(Integer.valueOf(i2)));
                }
            }
            this.listData = jSONArray;
            this.renderStates.clear();
            Map<String, CellRenderState> map = this.virtualComponentRenderStates;
            if (map != null) {
                map.clear();
            }
        }
    }

    public boolean updateData(Object obj, int i2) {
        boolean equals = TextUtils.equals(this.templateList.getTemplateKey(i2), this.templateList.getTemplateKey(obj));
        this.listData.set(i2, obj);
        if (!equals) {
            cleanRenderState(this.renderStates.remove(Integer.valueOf(i2)));
        } else {
            CellRenderState cellRenderState = this.renderStates.get(Integer.valueOf(i2));
            if (cellRenderState != null) {
                cellRenderState.hasDataUpdate = true;
            }
        }
        return equals;
    }

    public void updateVirtualComponentData(String str, Object obj) {
        Map<String, CellRenderState> map = this.virtualComponentRenderStates;
        if (map != null) {
            CellRenderState cellRenderState = map.get(str);
            if (cellRenderState != null) {
                cellRenderState.getVirtualComponentDatas().put(str, obj);
                cellRenderState.hasVirtualCompoentUpdate = true;
            } else if (WXEnvironment.isApkDebugable()) {
                throw new IllegalArgumentException("virtualComponentDatas illegal state empty render state" + str);
            }
        } else if (WXEnvironment.isApkDebugable()) {
            throw new IllegalArgumentException("virtualComponentDatas illegal state " + str);
        }
    }
}
