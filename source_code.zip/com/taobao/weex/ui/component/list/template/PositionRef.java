package com.taobao.weex.ui.component.list.template;

import com.alibaba.fastjson.JSONAware;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/PositionRef.class */
public class PositionRef extends Number implements JSONAware {
    private CellRenderState renderState;

    public PositionRef(CellRenderState cellRenderState) {
        this.renderState = cellRenderState;
    }

    private int getPosition() {
        CellRenderState cellRenderState = this.renderState;
        if (cellRenderState == null) {
            return -1;
        }
        return cellRenderState.position;
    }

    @Override // java.lang.Number
    public double doubleValue() {
        return (double) getPosition();
    }

    @Override // java.lang.Number
    public float floatValue() {
        return (float) getPosition();
    }

    @Override // java.lang.Number
    public int intValue() {
        return getPosition();
    }

    @Override // java.lang.Number
    public long longValue() {
        return (long) getPosition();
    }

    @Override // com.alibaba.fastjson.JSONAware
    public String toJSONString() {
        return String.valueOf(getPosition());
    }

    @Override // java.lang.Object
    public String toString() {
        return String.valueOf(getPosition());
    }
}
