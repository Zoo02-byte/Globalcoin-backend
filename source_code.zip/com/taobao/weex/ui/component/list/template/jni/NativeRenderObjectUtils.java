package com.taobao.weex.ui.component.list.template.jni;

import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/template/jni/NativeRenderObjectUtils.class */
public class NativeRenderObjectUtils {
    public static native void nativeAddChildRenderObject(long j2, long j3);

    public static native long nativeCopyRenderObject(long j2);

    public static native long nativeGetRenderObject(String str, String str2);

    public static native int nativeLayoutRenderObject(long j2, float f2, float f3);

    public static native int nativeRenderObjectChildCount(long j2);

    public static native void nativeRenderObjectChildWaste(long j2, boolean z2);

    public static native long nativeRenderObjectGetChild(long j2, int i2);

    public static native int nativeRenderObjectGetLayoutDirectionFromPathNode(long j2);

    public static native boolean nativeRenderObjectHasNewLayout(long j2);

    public static native void nativeRenderObjectUpdateComponent(long j2, WXComponent wXComponent);

    public static native void nativeUpdateRenderObjectAttr(long j2, String str, String str2);

    public static native void nativeUpdateRenderObjectStyle(long j2, String str, String str2);

    public static void updateComponentSize(WXComponent wXComponent, float f2, float f3, float f4, float f5, float f6, float f7) {
        wXComponent.updateDemission(f2, f3, f4, f5, f6, f7);
        wXComponent.applyLayoutOnly();
    }
}
