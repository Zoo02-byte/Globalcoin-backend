package com.taobao.weex.ui.component.list;

import androidx.recyclerview.widget.RecyclerView;
import com.taobao.weex.ui.component.WXComponent;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/DragHelper.class */
public interface DragHelper {
    boolean isDragExcluded(RecyclerView.ViewHolder viewHolder);

    boolean isDraggable();

    boolean isLongPressDragEnabled();

    void onDragEnd(WXComponent wXComponent, int i2, int i3);

    void onDragStart(WXComponent wXComponent, int i2);

    void onDragging(int i2, int i3);

    void setDragExcluded(RecyclerView.ViewHolder viewHolder, boolean z2);

    void setDraggable(boolean z2);

    void setLongPressDragEnabled(boolean z2);

    void startDrag(RecyclerView.ViewHolder viewHolder);
}
