package com.taobao.weex.ui.component.list;

import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/EventTrigger.class */
interface EventTrigger {
    void triggerEvent(String str, Map<String, Object> map);
}
