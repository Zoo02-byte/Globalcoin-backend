package com.taobao.weex.ui.component.list;

import android.content.Context;
import android.graphics.Point;
import android.graphics.PointF;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.collection.ArrayMap;
import androidx.core.view.MotionEventCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.ICheckBindingScroller;
import com.taobao.weex.common.IWXObject;
import com.taobao.weex.common.OnWXScrollListener;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.AppearanceHelper;
import com.taobao.weex.ui.component.Scrollable;
import com.taobao.weex.ui.component.WXBaseRefresh;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXComponentProp;
import com.taobao.weex.ui.component.WXHeader;
import com.taobao.weex.ui.component.WXImage;
import com.taobao.weex.ui.component.WXLoading;
import com.taobao.weex.ui.component.WXRefresh;
import com.taobao.weex.ui.component.WXVContainer;
import com.taobao.weex.ui.component.helper.ScrollStartEndHelper;
import com.taobao.weex.ui.component.helper.WXStickyHelper;
import com.taobao.weex.ui.component.list.ListComponentView;
import com.taobao.weex.ui.view.listview.WXRecyclerView;
import com.taobao.weex.ui.view.listview.adapter.IOnLoadMoreListener;
import com.taobao.weex.ui.view.listview.adapter.IRecyclerAdapterListener;
import com.taobao.weex.ui.view.listview.adapter.ListBaseViewHolder;
import com.taobao.weex.ui.view.listview.adapter.RecyclerViewBaseAdapter;
import com.taobao.weex.ui.view.listview.adapter.WXRecyclerViewOnScrollListener;
import com.taobao.weex.ui.view.refresh.wrapper.BounceRecyclerView;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.constant.AbsoluteConst;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/BasicListComponent.class */
public abstract class BasicListComponent<T extends ViewGroup & ListComponentView> extends WXVContainer<T> implements IRecyclerAdapterListener<ListBaseViewHolder>, IOnLoadMoreListener, Scrollable {
    private static final boolean DEFAULT_EXCLUDED;
    private static final String DEFAULT_TRIGGER_TYPE;
    private static final String DRAG_ANCHOR;
    private static final String DRAG_TRIGGER_TYPE;
    private static final String EXCLUDED;
    public static final String LOADMOREOFFSET;
    private static final int MAX_VIEWTYPE_ALLOW_CACHE;
    public static final String TRANSFORM;
    ListStanceCell listStanceObject;
    private DragHelper mDragHelper;
    private RecyclerView.ItemAnimator mItemAnimator;
    private ArrayMap<String, Long> mRefToViewType;
    private ScrollStartEndHelper mScrollStartEndHelper;
    private String mTriggerType;
    private SparseArray<ArrayList<WXComponent>> mViewTypes;
    private static final Pattern transformPattern = Pattern.compile("([a-z]+)\\(([0-9\\.]+),?([0-9\\.]+)?\\)");
    private static boolean mAllowCacheViewHolder = true;
    private static boolean mDownForBidCacheViewHolder = false;
    private String TAG = "BasicListComponent";
    private int mListCellCount = 0;
    private boolean mForceLoadmoreNextTime = false;
    private Map<String, AppearanceHelper> mAppearComponents = new HashMap();
    private Runnable mAppearChangeRunnable = null;
    private long mAppearChangeRunnableDelay = 50;
    private boolean isScrollable = true;
    private WXRecyclerViewOnScrollListener mViewOnScrollListener = new WXRecyclerViewOnScrollListener(this);
    protected int mLayoutType = 1;
    protected int mColumnCount = 1;
    protected float mColumnGap = 0.0f;
    protected float mColumnWidth = 0.0f;
    protected float mLeftGap = 0.0f;
    protected float mRightGap = 0.0f;
    private int mOffsetAccuracy = 10;
    private Point mLastReport = new Point(-1, -1);
    private boolean mHasAddScrollEvent = false;
    private Map<String, Map<String, WXComponent>> mStickyMap = new HashMap();
    private WXComponent keepPositionCell = null;
    private Runnable keepPositionCellRunnable = null;
    private long keepPositionLayoutDelay = 150;
    boolean isThisGroupFinished = false;
    private WXStickyHelper stickyHelper = new WXStickyHelper(this);

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/BasicListComponent$DragTriggerType.class */
    interface DragTriggerType {
        public static final String LONG_PRESS;
        public static final String PAN;
    }

    public BasicListComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
    }

    private void bindViewType(WXComponent wXComponent) {
        int generateViewType = generateViewType(wXComponent);
        if (this.mViewTypes == null) {
            this.mViewTypes = new SparseArray<>();
        }
        ArrayList<WXComponent> arrayList = this.mViewTypes.get(generateViewType);
        ArrayList<WXComponent> arrayList2 = arrayList;
        if (arrayList == null) {
            arrayList2 = new ArrayList<>();
            this.mViewTypes.put(generateViewType, arrayList2);
        }
        arrayList2.add(wXComponent);
    }

    private void checkRecycledViewPool(int i2) {
        try {
            if (this.mViewTypes.size() > 9) {
                mAllowCacheViewHolder = false;
            }
            if (!(!mDownForBidCacheViewHolder || getHostView() == 0 || ((ListComponentView) ((ViewGroup) getHostView())).getInnerView() == null)) {
                ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().getRecycledViewPool().setMaxRecycledViews(i2, 0);
            }
            if (!(mDownForBidCacheViewHolder || mAllowCacheViewHolder || getHostView() == 0 || ((ListComponentView) ((ViewGroup) getHostView())).getInnerView() == null)) {
                for (int i3 = 0; i3 < this.mViewTypes.size(); i3++) {
                    ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().getRecycledViewPool().setMaxRecycledViews(this.mViewTypes.keyAt(i3), 0);
                }
                mDownForBidCacheViewHolder = true;
            }
        } catch (Exception e2) {
            WXLogUtils.e(this.TAG, "Clear recycledViewPool error!");
        }
    }

    private ListBaseViewHolder createVHForFakeComponent(int i2) {
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setBackgroundColor(-1);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(0, 0));
        return new ListBaseViewHolder(frameLayout, i2);
    }

    private ListBaseViewHolder createVHForRefreshComponent(int i2) {
        FrameLayout frameLayout = new FrameLayout(getContext());
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, 1));
        return new ListBaseViewHolder(frameLayout, i2);
    }

    private WXComponent findComponentByAnchorName(WXComponent wXComponent, String str) {
        String string;
        long currentTimeMillis = WXEnvironment.isApkDebugable() ? System.currentTimeMillis() : 0;
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.add(wXComponent);
        while (!arrayDeque.isEmpty()) {
            WXComponent wXComponent2 = (WXComponent) arrayDeque.removeFirst();
            if (wXComponent2 != null && (string = WXUtils.getString(wXComponent2.getAttrs().get(str), null)) != null && string.equals(AbsoluteConst.TRUE)) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("dragPerf", "findComponentByAnchorName time: " + (System.currentTimeMillis() - currentTimeMillis) + "ms");
                }
                return wXComponent2;
            } else if (wXComponent2 instanceof WXVContainer) {
                WXVContainer wXVContainer = (WXVContainer) wXComponent2;
                int childCount = wXVContainer.childCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    arrayDeque.add(wXVContainer.getChild(i2));
                }
            }
        }
        if (!WXEnvironment.isApkDebugable()) {
            return null;
        }
        WXLogUtils.d("dragPerf", "findComponentByAnchorName elapsed time: " + (System.currentTimeMillis() - currentTimeMillis) + "ms");
        return null;
    }

    private WXComponent findDirectListChild(WXComponent wXComponent) {
        WXVContainer parent;
        if (wXComponent == null || (parent = wXComponent.getParent()) == null) {
            return null;
        }
        return parent instanceof BasicListComponent ? wXComponent : findDirectListChild(parent);
    }

    public void fireScrollEvent(RecyclerView recyclerView, int i2, int i3) {
        if (getInstance() != null) {
            fireEvent("scroll", getScrollEvent(recyclerView, i2, i3));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Type inference failed for: r7v6 */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private int generateViewType(com.taobao.weex.common.IWXObject r6) {
        /*
            r5 = this;
            r0 = -1
            r9 = r0
            r0 = r6
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.list.ListStanceCell     // Catch: RuntimeException -> 0x007d
            if (r0 == 0) goto L_0x0012
            r0 = r9
            r7 = r0
            goto L_0x0093
        L_0x0012:
            r0 = r9
            r7 = r0
            r0 = r6
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.WXComponent     // Catch: RuntimeException -> 0x007d
            if (r0 == 0) goto L_0x0093
            r0 = r6
            com.taobao.weex.ui.component.WXComponent r0 = (com.taobao.weex.ui.component.WXComponent) r0     // Catch: RuntimeException -> 0x007d
            r6 = r0
            r0 = r6
            java.lang.String r0 = r0.getRef()     // Catch: RuntimeException -> 0x007d
            int r0 = java.lang.Integer.parseInt(r0)     // Catch: RuntimeException -> 0x007d
            long r0 = (long) r0     // Catch: RuntimeException -> 0x007d
            r7 = r0
            r0 = r6
            com.taobao.weex.dom.WXAttr r0 = r0.getAttrs()     // Catch: RuntimeException -> 0x007d
            java.lang.String r0 = r0.getScope()     // Catch: RuntimeException -> 0x007d
            r6 = r0
            r0 = r6
            boolean r0 = android.text.TextUtils.isEmpty(r0)     // Catch: RuntimeException -> 0x007d
            if (r0 != 0) goto L_0x007a
            r0 = r5
            androidx.collection.ArrayMap<java.lang.String, java.lang.Long> r0 = r0.mRefToViewType     // Catch: RuntimeException -> 0x007d
            if (r0 != 0) goto L_0x0050
            androidx.collection.ArrayMap r0 = new androidx.collection.ArrayMap     // Catch: RuntimeException -> 0x007d
            r11 = r0
            r0 = r11
            r0.<init>()     // Catch: RuntimeException -> 0x007d
            r0 = r5
            r1 = r11
            r0.mRefToViewType = r1     // Catch: RuntimeException -> 0x007d
        L_0x0050:
            r0 = r5
            androidx.collection.ArrayMap<java.lang.String, java.lang.Long> r0 = r0.mRefToViewType     // Catch: RuntimeException -> 0x007d
            r1 = r6
            boolean r0 = r0.containsKey(r1)     // Catch: RuntimeException -> 0x007d
            if (r0 != 0) goto L_0x0068
            r0 = r5
            androidx.collection.ArrayMap<java.lang.String, java.lang.Long> r0 = r0.mRefToViewType     // Catch: RuntimeException -> 0x007d
            r1 = r6
            r2 = r7
            java.lang.Long r2 = java.lang.Long.valueOf(r2)     // Catch: RuntimeException -> 0x007d
            java.lang.Object r0 = r0.put(r1, r2)     // Catch: RuntimeException -> 0x007d
        L_0x0068:
            r0 = r5
            androidx.collection.ArrayMap<java.lang.String, java.lang.Long> r0 = r0.mRefToViewType     // Catch: RuntimeException -> 0x007d
            r1 = r6
            java.lang.Object r0 = r0.get(r1)     // Catch: RuntimeException -> 0x007d
            java.lang.Long r0 = (java.lang.Long) r0     // Catch: RuntimeException -> 0x007d
            long r0 = r0.longValue()     // Catch: RuntimeException -> 0x007d
            r7 = r0
            goto L_0x0093
        L_0x007a:
            goto L_0x0093
        L_0x007d:
            r6 = move-exception
            r0 = r5
            java.lang.String r0 = r0.TAG
            r1 = r6
            com.taobao.weex.utils.WXLogUtils.eTag(r0, r1)
            r0 = r5
            java.lang.String r0 = r0.TAG
            java.lang.String r1 = "getItemViewType: NO ID, this will crash the whole render system of WXListRecyclerView"
            com.taobao.weex.utils.WXLogUtils.e(r0, r1)
            r0 = r9
            r7 = r0
        L_0x0093:
            r0 = r7
            int r0 = (int) r0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.list.BasicListComponent.generateViewType(com.taobao.weex.common.IWXObject):int");
    }

    private float getListChildLayoutHeight(int i2) {
        float f2;
        WXComponent wXComponent;
        IWXObject listChild = getListChild(i2);
        if (listChild != null) {
            if (listChild instanceof ListStanceCell) {
                f2 = 1.0f;
            } else if ((listChild instanceof WXComponent) && (wXComponent = (WXComponent) listChild) != null) {
                f2 = wXComponent.getLayoutHeight();
            }
            return f2;
        }
        f2 = 0.0f;
        return f2;
    }

    private IWXObject getListStanceCell(String str) {
        if (this.listStanceObject == null) {
            this.listStanceObject = new ListStanceCell(str);
        }
        return this.listStanceObject;
    }

    private String getTriggerType(WXComponent wXComponent) {
        String string = "longpress";
        if (wXComponent == null) {
            return "longpress";
        }
        string = WXUtils.getString(wXComponent.getAttrs().get(DRAG_TRIGGER_TYPE), "longpress");
        if ("longpress".equals(string) || !"pan".equals(string)) {
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d(this.TAG, "trigger type is " + string);
        }
        return string;
    }

    private void relocateAppearanceHelper() {
        for (Map.Entry<String, AppearanceHelper> entry : this.mAppearComponents.entrySet()) {
            AppearanceHelper value = entry.getValue();
            value.setCellPosition(this.mChildren.indexOf(findDirectListChild(value.getAwareChild())));
        }
    }

    private void setAppearanceWatch(WXComponent wXComponent, int i2, boolean z2) {
        int indexOf;
        AppearanceHelper appearanceHelper = this.mAppearComponents.get(wXComponent.getRef());
        if (appearanceHelper != null) {
            appearanceHelper.setWatchEvent(i2, z2);
        } else if (z2 && (indexOf = this.mChildren.indexOf(findDirectListChild(wXComponent))) != -1) {
            AppearanceHelper appearanceHelper2 = new AppearanceHelper(wXComponent, indexOf);
            appearanceHelper2.setWatchEvent(i2, true);
            this.mAppearComponents.put(wXComponent.getRef(), appearanceHelper2);
        }
    }

    public boolean shouldReport(int i2, int i3) {
        if (this.mLastReport.x == -1 && this.mLastReport.y == -1) {
            this.mLastReport.x = i2;
            this.mLastReport.y = i3;
            return true;
        }
        int abs = Math.abs(this.mLastReport.x - i2);
        int abs2 = Math.abs(this.mLastReport.y - i3);
        int i4 = this.mOffsetAccuracy;
        if (abs < i4 && abs2 < i4) {
            return false;
        }
        this.mLastReport.x = i2;
        this.mLastReport.y = i3;
        return true;
    }

    private void unBindViewType(WXComponent wXComponent) {
        ArrayList<WXComponent> arrayList;
        int generateViewType = generateViewType(wXComponent);
        SparseArray<ArrayList<WXComponent>> sparseArray = this.mViewTypes;
        if (sparseArray != null && (arrayList = sparseArray.get(generateViewType)) != null) {
            arrayList.remove(wXComponent);
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addChild(WXComponent wXComponent) {
        addChild(wXComponent, -1);
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addChild(WXComponent wXComponent, int i2) {
        boolean z2;
        addChild(wXComponent, i2);
        if (wXComponent != null && i2 >= -1) {
            int i3 = i2;
            if (i2 >= this.mChildren.size()) {
                i3 = -1;
            }
            bindViewType(wXComponent);
            if (this.isThisGroupFinished || !isRenderFromBottom()) {
                z2 = false;
            } else if (wXComponent.getAttrs().containsKey("renderReversePosition")) {
                z2 = true;
            } else {
                return;
            }
            this.isThisGroupFinished = true;
            int size = i3 == -1 ? this.mChildren.size() - 1 : i3;
            ViewGroup viewGroup = (ViewGroup) getHostView();
            if (viewGroup != null) {
                if (getBasicComponentData() == null || !"default".equals(getAttrs().get(Constants.Name.INSERT_CELL_ANIMATION))) {
                    ((ListComponentView) viewGroup).getInnerView().setItemAnimator(null);
                } else {
                    ((ListComponentView) viewGroup).getInnerView().setItemAnimator(this.mItemAnimator);
                }
                boolean z3 = false;
                if (wXComponent.getBasicComponentData() != null) {
                    z3 = false;
                    if (WXUtils.getBoolean(wXComponent.getAttrs().get(Constants.Name.KEEP_SCROLL_POSITION), false).booleanValue()) {
                        z3 = false;
                        if (i3 <= getChildCount()) {
                            z3 = false;
                            if (i3 > -1) {
                                z3 = true;
                            }
                        }
                    }
                }
                boolean z4 = z3;
                if (!z3) {
                    z4 = z3;
                    if (z2) {
                        z4 = true;
                    }
                }
                if (z4) {
                    ListComponentView listComponentView = (ListComponentView) viewGroup;
                    if (listComponentView.getInnerView().getLayoutManager() instanceof LinearLayoutManager) {
                        if (this.keepPositionCell == null) {
                            ListBaseViewHolder listBaseViewHolder = (ListBaseViewHolder) listComponentView.getInnerView().findViewHolderForAdapterPosition(((LinearLayoutManager) listComponentView.getInnerView().getLayoutManager()).findLastCompletelyVisibleItemPosition());
                            if (listBaseViewHolder != null) {
                                this.keepPositionCell = listBaseViewHolder.getComponent();
                            }
                            if (this.keepPositionCell != null) {
                                if (!listComponentView.getInnerView().isLayoutFrozen()) {
                                    listComponentView.getInnerView().setLayoutFrozen(true);
                                }
                                Runnable runnable = this.keepPositionCellRunnable;
                                if (runnable != null) {
                                    viewGroup.removeCallbacks(runnable);
                                }
                                this.keepPositionCellRunnable = new Runnable(this, viewGroup) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.5
                                    final BasicListComponent this$0;
                                    final ViewGroup val$view;

                                    {
                                        this.this$0 = r4;
                                        this.val$view = r5;
                                    }

                                    @Override // java.lang.Runnable
                                    public void run() {
                                        if (this.this$0.keepPositionCell != null) {
                                            BasicListComponent basicListComponent = this.this$0;
                                            int indexOf = basicListComponent.indexOf(basicListComponent.keepPositionCell);
                                            int top = this.this$0.keepPositionCell.getHostView() != null ? this.this$0.keepPositionCell.getHostView().getTop() : 0;
                                            if (top > 0) {
                                                ((LinearLayoutManager) ((ListComponentView) this.val$view).getInnerView().getLayoutManager()).scrollToPositionWithOffset(indexOf, top);
                                            } else {
                                                ((ListComponentView) this.val$view).getInnerView().getLayoutManager().scrollToPosition(indexOf);
                                            }
                                            ((ListComponentView) this.val$view).getInnerView().setLayoutFrozen(false);
                                            this.this$0.keepPositionCell = null;
                                            this.this$0.keepPositionCellRunnable = null;
                                        }
                                    }
                                };
                            }
                        }
                        if (this.keepPositionCellRunnable == null) {
                            int findLastVisibleItemPosition = ((LinearLayoutManager) listComponentView.getInnerView().getLayoutManager()).findLastVisibleItemPosition();
                            if (z2) {
                                findLastVisibleItemPosition = i3;
                            }
                            listComponentView.getInnerView().scrollToPosition(findLastVisibleItemPosition);
                        }
                    }
                    listComponentView.getRecyclerViewBaseAdapter().notifyItemRangeInserted(size, 20);
                    Runnable runnable2 = this.keepPositionCellRunnable;
                    if (runnable2 != null) {
                        viewGroup.removeCallbacks(runnable2);
                        viewGroup.postDelayed(this.keepPositionCellRunnable, this.keepPositionLayoutDelay);
                    }
                } else {
                    ((ListComponentView) viewGroup).getRecyclerViewBaseAdapter().notifyDataSetChanged();
                }
            }
            relocateAppearanceHelper();
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        addEvent(str);
        if (ScrollStartEndHelper.isScrollEvent(str) && getHostView() != 0 && ((ListComponentView) ((ViewGroup) getHostView())).getInnerView() != null && !this.mHasAddScrollEvent) {
            this.mHasAddScrollEvent = true;
            ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().addOnScrollListener(new RecyclerView.OnScrollListener(this) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.7
                private boolean mFirstEvent = true;
                private int offsetXCorrection;
                private int offsetYCorrection;
                final BasicListComponent this$0;

                {
                    this.this$0 = r4;
                }

                @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                public void onScrolled(RecyclerView recyclerView, int i2, int i3) {
                    int i4;
                    int i5;
                    onScrolled(recyclerView, i2, i3);
                    int computeHorizontalScrollOffset = recyclerView.computeHorizontalScrollOffset();
                    int computeVerticalScrollOffset = recyclerView.computeVerticalScrollOffset();
                    if (i2 == 0 && i3 == 0) {
                        this.offsetXCorrection = computeHorizontalScrollOffset;
                        this.offsetYCorrection = computeVerticalScrollOffset;
                        i4 = 0;
                        i5 = 0;
                    } else {
                        i4 = computeHorizontalScrollOffset - this.offsetXCorrection;
                        i5 = computeVerticalScrollOffset - this.offsetYCorrection;
                    }
                    this.this$0.getScrollStartEndHelper().onScrolled(i4, i5);
                    if (this.this$0.getEvents().contains("scroll")) {
                        if (this.mFirstEvent) {
                            this.mFirstEvent = false;
                            return;
                        }
                        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                        if (this.this$0.getOrientation() == 1) {
                            if (!layoutManager.canScrollVertically()) {
                                return;
                            }
                        } else if (this.this$0.getOrientation() == 0 && !layoutManager.canScrollHorizontally()) {
                            return;
                        }
                        if (this.this$0.shouldReport(i4, i5)) {
                            this.this$0.fireScrollEvent(recyclerView, i4, i5);
                        }
                    }
                }
            });
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void addSubView(View view, int i2) {
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void bindAppearEvent(WXComponent wXComponent) {
        setAppearanceWatch(wXComponent, 0, true);
        if (this.mAppearChangeRunnable == null) {
            this.mAppearChangeRunnable = new Runnable(this) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.4
                final BasicListComponent this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (this.this$0.mAppearChangeRunnable != null) {
                        this.this$0.notifyAppearStateChange(0, 0, 0, 0);
                    }
                }
            };
        }
        if (getHostView() != 0) {
            ((ViewGroup) getHostView()).removeCallbacks(this.mAppearChangeRunnable);
            ((ViewGroup) getHostView()).postDelayed(this.mAppearChangeRunnable, this.mAppearChangeRunnableDelay);
        }
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void bindDisappearEvent(WXComponent wXComponent) {
        setAppearanceWatch(wXComponent, 1, true);
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void bindStickStyle(WXComponent wXComponent) {
        this.stickyHelper.bindStickStyle(wXComponent, this.mStickyMap);
    }

    public int calcContentOffset(RecyclerView recyclerView) {
        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        int i2 = -1;
        if (layoutManager instanceof LinearLayoutManager) {
            int findFirstVisibleItemPosition = ((LinearLayoutManager) layoutManager).findFirstVisibleItemPosition();
            if (findFirstVisibleItemPosition == -1) {
                return 0;
            }
            View findViewByPosition = layoutManager.findViewByPosition(findFirstVisibleItemPosition);
            int top = findViewByPosition != null ? findViewByPosition.getTop() : 0;
            int i3 = 0;
            for (int i4 = 0; i4 < findFirstVisibleItemPosition; i4++) {
                i3 = (int) (((float) i3) - getListChildLayoutHeight(i4));
            }
            int i5 = i3;
            if (layoutManager instanceof GridLayoutManager) {
                i5 = i3 / ((GridLayoutManager) layoutManager).getSpanCount();
            }
            return i5 + top;
        }
        if (layoutManager instanceof StaggeredGridLayoutManager) {
            StaggeredGridLayoutManager staggeredGridLayoutManager = (StaggeredGridLayoutManager) layoutManager;
            int spanCount = staggeredGridLayoutManager.getSpanCount();
            int i6 = staggeredGridLayoutManager.findFirstVisibleItemPositions(null)[0];
            if (i6 == -1) {
                return 0;
            }
            View findViewByPosition2 = layoutManager.findViewByPosition(i6);
            int top2 = findViewByPosition2 != null ? findViewByPosition2.getTop() : 0;
            int i7 = 0;
            for (int i8 = 0; i8 < i6; i8++) {
                i7 = (int) (((float) i7) - getListChildLayoutHeight(i8));
            }
            i2 = (i7 / spanCount) + top2;
        }
        return i2;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void computeVisiblePointInViewCoordinate(PointF pointF) {
        WXRecyclerView innerView = ((ListComponentView) ((ViewGroup) getHostView())).getInnerView();
        pointF.set((float) innerView.computeHorizontalScrollOffset(), (float) innerView.computeVerticalScrollOffset());
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer, com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        if (!(this.mAppearChangeRunnable == null || getHostView() == 0)) {
            ((ViewGroup) getHostView()).removeCallbacks(this.mAppearChangeRunnable);
            this.mAppearChangeRunnable = null;
        }
        if (!(getHostView() == 0 || ((ListComponentView) ((ViewGroup) getHostView())).getInnerView() == null)) {
            ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().clearOnScrollListeners();
        }
        destroy();
        Map<String, Map<String, WXComponent>> map = this.mStickyMap;
        if (map != null) {
            map.clear();
        }
        SparseArray<ArrayList<WXComponent>> sparseArray = this.mViewTypes;
        if (sparseArray != null) {
            sparseArray.clear();
        }
        ArrayMap<String, Long> arrayMap = this.mRefToViewType;
        if (arrayMap != null) {
            arrayMap.clear();
        }
    }

    abstract T generateListView(Context context, int i2);

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public int getChildCount() {
        WXComponent child = getChild(0);
        return (child == null || !(child instanceof WXRefresh) || this.mColumnCount <= 1) ? getChildCount() : getChildCount() + (this.mColumnCount - 1);
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public ViewGroup.LayoutParams getChildLayoutParams(WXComponent wXComponent, View view, int i2, int i3, int i4, int i5, int i6, int i7) {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        if ((wXComponent instanceof WXBaseRefresh) && marginLayoutParams2 == null) {
            marginLayoutParams = new LinearLayout.LayoutParams(i2, i3);
        } else if (marginLayoutParams2 == null) {
            marginLayoutParams = new RecyclerView.LayoutParams(i2, i3);
        } else {
            marginLayoutParams2.width = i2;
            marginLayoutParams2.height = i3;
            setMarginsSupportRTL(marginLayoutParams2, i4, 0, i5, 0);
            marginLayoutParams = marginLayoutParams2;
        }
        return marginLayoutParams;
    }

    @Override // com.taobao.weex.ui.component.WXVContainer, io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public int getChildrenLayoutTopOffset() {
        return 0;
    }

    @Override // com.taobao.weex.ui.view.listview.adapter.IRecyclerAdapterListener
    public int getItemCount() {
        if (this.isThisGroupFinished) {
            return getChildCount();
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Unknown variable types count: 1 */
    @Override // com.taobao.weex.ui.view.listview.adapter.IRecyclerAdapterListener
    /* Code decompiled incorrectly, please refer to instructions dump */
    public long getItemId(int r4) {
        /*
            r3 = this;
            r0 = -1
            r7 = r0
            r0 = r3
            r1 = r4
            com.taobao.weex.common.IWXObject r0 = r0.getListChild(r1)     // Catch: RuntimeException -> 0x0034
            r9 = r0
            r0 = r9
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.list.ListStanceCell     // Catch: RuntimeException -> 0x0034
            if (r0 == 0) goto L_0x001a
            r0 = r7
            r5 = r0
            goto L_0x0045
        L_0x001a:
            r0 = r7
            r5 = r0
            r0 = r9
            boolean r0 = r0 instanceof com.taobao.weex.ui.component.WXComponent     // Catch: RuntimeException -> 0x0034
            if (r0 == 0) goto L_0x0045
            r0 = r9
            com.taobao.weex.ui.component.WXComponent r0 = (com.taobao.weex.ui.component.WXComponent) r0     // Catch: RuntimeException -> 0x0034
            java.lang.String r0 = r0.getRef()     // Catch: RuntimeException -> 0x0034
            long r0 = java.lang.Long.parseLong(r0)     // Catch: RuntimeException -> 0x0034
            r5 = r0
            goto L_0x0045
        L_0x0034:
            r9 = move-exception
            r0 = r3
            java.lang.String r0 = r0.TAG
            r1 = r9
            java.lang.String r1 = com.taobao.weex.utils.WXLogUtils.getStackTrace(r1)
            com.taobao.weex.utils.WXLogUtils.e(r0, r1)
            r0 = r7
            r5 = r0
        L_0x0045:
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.list.BasicListComponent.getItemId(int):long");
    }

    @Override // com.taobao.weex.ui.view.listview.adapter.IRecyclerAdapterListener
    public int getItemViewType(int i2) {
        return generateViewType(getListChild(i2));
    }

    public IWXObject getListChild(int i2) {
        int i3;
        WXComponent child = getChild(0);
        return i2 == 0 ? child : (child == null || !(child instanceof WXRefresh) || (i3 = this.mColumnCount) <= 1) ? getChild(i2) : i2 - i3 < 0 ? getListStanceCell(child.getStyles().getBackgroundColor()) : getChild(i2 - (i3 - 1));
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public int getOrientation() {
        return 1;
    }

    public Map<String, Object> getScrollEvent(RecyclerView recyclerView, int i2, int i3) {
        boolean z2 = true;
        if (getOrientation() == 1) {
            i3 = -calcContentOffset(recyclerView);
        }
        int measuredWidth = recyclerView.getMeasuredWidth();
        int computeHorizontalScrollRange = recyclerView.computeHorizontalScrollRange();
        int i4 = 0;
        for (int i5 = 0; i5 < getChildCount(); i5++) {
            i4 = (int) (((float) i4) + getListChildLayoutHeight(i5));
        }
        HashMap hashMap = new HashMap(3);
        HashMap hashMap2 = new HashMap(3);
        HashMap hashMap3 = new HashMap(3);
        hashMap2.put("width", Float.valueOf(WXViewUtils.getWebPxByWidth((float) (measuredWidth + computeHorizontalScrollRange), getInstance().getInstanceViewPortWidthWithFloat())));
        hashMap2.put("height", Float.valueOf(WXViewUtils.getWebPxByWidth((float) i4, getInstance().getInstanceViewPortWidthWithFloat())));
        hashMap3.put(Constants.Name.X, Float.valueOf(-WXViewUtils.getWebPxByWidth((float) i2, getInstance().getInstanceViewPortWidthWithFloat())));
        hashMap3.put(Constants.Name.Y, Float.valueOf(-WXViewUtils.getWebPxByWidth((float) i3, getInstance().getInstanceViewPortWidthWithFloat())));
        hashMap.put(Constants.Name.CONTENT_SIZE, hashMap2);
        hashMap.put(Constants.Name.CONTENT_OFFSET, hashMap3);
        if (recyclerView.getScrollState() != 1) {
            z2 = false;
        }
        hashMap.put(Constants.Name.ISDRAGGING, Boolean.valueOf(z2));
        return hashMap;
    }

    public ScrollStartEndHelper getScrollStartEndHelper() {
        if (this.mScrollStartEndHelper == null) {
            this.mScrollStartEndHelper = new ScrollStartEndHelper(this);
        }
        return this.mScrollStartEndHelper;
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public int getScrollX() {
        ViewGroup viewGroup = (ViewGroup) getHostView();
        return viewGroup == null ? 0 : ((ListComponentView) viewGroup).getInnerView().getScrollX();
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public int getScrollY() {
        ViewGroup viewGroup = (ViewGroup) getHostView();
        return viewGroup == null ? 0 : ((ListComponentView) viewGroup).getInnerView().getScrollY();
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected T initComponentHostView(Context context) {
        T generateListView = generateListView(context, getOrientation());
        String attrByKey = getAttrByKey("transform");
        if (attrByKey != null) {
            generateListView.getInnerView().addItemDecoration(RecyclerTransform.parseTransforms(getOrientation(), attrByKey));
        }
        if (getAttrs().get(Constants.Name.KEEP_POSITION_LAYOUT_DELAY) != null) {
            this.keepPositionLayoutDelay = (long) WXUtils.getNumberInt(getAttrs().get(Constants.Name.KEEP_POSITION_LAYOUT_DELAY), (int) this.keepPositionLayoutDelay);
        }
        if (getAttrs().get("appearActionDelay") != null) {
            this.mAppearChangeRunnableDelay = (long) WXUtils.getNumberInt(getAttrs().get("appearActionDelay"), (int) this.mAppearChangeRunnableDelay);
        }
        T t2 = generateListView;
        this.mItemAnimator = t2.getInnerView().getItemAnimator();
        RecyclerViewBaseAdapter recyclerViewBaseAdapter = new RecyclerViewBaseAdapter(this);
        recyclerViewBaseAdapter.setHasStableIds(true);
        t2.setRecyclerViewBaseAdapter(recyclerViewBaseAdapter);
        t2.getInnerView().addOnScrollListener(this.mViewOnScrollListener);
        if (getAttrs().get(Constants.Name.HAS_FIXED_SIZE) != null) {
            t2.getInnerView().setHasFixedSize(WXUtils.getBoolean(getAttrs().get(Constants.Name.HAS_FIXED_SIZE), false).booleanValue());
        }
        t2.getInnerView().addOnScrollListener(new RecyclerView.OnScrollListener(this) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.2
            final BasicListComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrollStateChanged(RecyclerView recyclerView, int i2) {
                int size;
                View childAt;
                onScrollStateChanged(recyclerView, i2);
                this.this$0.getScrollStartEndHelper().onScrollStateChanged(i2);
                List<OnWXScrollListener> wXScrollListeners = this.this$0.getInstance().getWXScrollListeners();
                if (wXScrollListeners != null && (size = wXScrollListeners.size()) > 0) {
                    int i3 = 0;
                    while (i3 < size && i3 < wXScrollListeners.size()) {
                        OnWXScrollListener onWXScrollListener = wXScrollListeners.get(i3);
                        if (!(onWXScrollListener == null || (childAt = recyclerView.getChildAt(0)) == null)) {
                            onWXScrollListener.onScrollStateChanged(recyclerView, 0, childAt.getTop(), i2);
                        }
                        i3++;
                    }
                }
            }

            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrolled(RecyclerView recyclerView, int i2, int i3) {
                onScrolled(recyclerView, i2, i3);
                List<OnWXScrollListener> wXScrollListeners = this.this$0.getInstance().getWXScrollListeners();
                if (wXScrollListeners != null && wXScrollListeners.size() > 0) {
                    try {
                        for (OnWXScrollListener onWXScrollListener : wXScrollListeners) {
                            if (onWXScrollListener != null) {
                                if (!(onWXScrollListener instanceof ICheckBindingScroller)) {
                                    onWXScrollListener.onScrolled(recyclerView, i2, i3);
                                } else if (((ICheckBindingScroller) onWXScrollListener).isNeedScroller(this.this$0.getRef(), null)) {
                                    onWXScrollListener.onScrolled(recyclerView, i2, i3);
                                }
                            }
                        }
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            }
        });
        generateListView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.3
            final BasicListComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                ViewGroup viewGroup = (ViewGroup) this.this$0.getHostView();
                if (viewGroup != null) {
                    this.this$0.mViewOnScrollListener.onScrolled(((ListComponentView) viewGroup).getInnerView(), 0, 0);
                    viewGroup.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                }
            }
        });
        return generateListView;
    }

    protected boolean isRenderFromBottom() {
        return false;
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public boolean isScrollable() {
        return this.isScrollable;
    }

    protected void markComponentUsable() {
        Iterator it = this.mChildren.iterator();
        while (it.hasNext()) {
            ((WXComponent) it.next()).setUsing(false);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected WXComponent.MeasureOutput measure(int i2, int i3) {
        return measure(i2, i3);
    }

    @Override // com.taobao.weex.ui.view.listview.adapter.IOnLoadMoreListener
    public void notifyAppearStateChange(int i2, int i3, int i4, int i5) {
        View hostView;
        String str = null;
        if (this.mAppearChangeRunnable != null) {
            ((ViewGroup) getHostView()).removeCallbacks(this.mAppearChangeRunnable);
            this.mAppearChangeRunnable = null;
        }
        if (i5 > 0) {
            str = "up";
        } else if (i5 < 0) {
            str = "down";
        }
        String str2 = str;
        if (getOrientation() == 0) {
            str2 = str;
            if (i4 != 0) {
                str2 = i4 > 0 ? "left" : "right";
            }
        }
        for (AppearanceHelper appearanceHelper : this.mAppearComponents.values()) {
            WXComponent awareChild = appearanceHelper.getAwareChild();
            if (appearanceHelper.isWatch() && (hostView = awareChild.getHostView()) != null) {
                int appearStatus = appearanceHelper.setAppearStatus(ViewCompat.isAttachedToWindow(hostView) && appearanceHelper.isViewVisible(true));
                if (appearStatus != 0) {
                    boolean isApkDebugable = WXEnvironment.isApkDebugable();
                    String str3 = Constants.Event.APPEAR;
                    if (isApkDebugable) {
                        WXLogUtils.d(Constants.Event.APPEAR, "item " + appearanceHelper.getCellPositionINScollable() + " result " + appearStatus);
                    }
                    if (appearStatus != 1) {
                        str3 = Constants.Event.DISAPPEAR;
                    }
                    awareChild.notifyAppearStateChange(str3, str2);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x01d6  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x01ee  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x01fd  */
    @Override // com.taobao.weex.ui.view.listview.adapter.IOnLoadMoreListener
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void onBeforeScroll(int r5, int r6) {
        /*
        // Method dump skipped, instructions count: 580
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.list.BasicListComponent.onBeforeScroll(int, int):void");
    }

    public void onBindViewHolder(ListBaseViewHolder listBaseViewHolder, int i2) {
        if (listBaseViewHolder != null) {
            listBaseViewHolder.setComponentUsing(true);
            IWXObject listChild = getListChild(i2);
            if (listChild instanceof ListStanceCell) {
                listBaseViewHolder.getView().setBackgroundColor(WXResourceUtils.getColor(((ListStanceCell) listChild).getBackgroundColor(), -1));
                listBaseViewHolder.getView().setVisibility(0);
                listBaseViewHolder.getView().postInvalidate();
            } else if (listChild instanceof WXComponent) {
                WXComponent wXComponent = (WXComponent) listChild;
                if (wXComponent == null || (wXComponent instanceof WXRefresh) || (wXComponent instanceof WXLoading) || wXComponent.isFixed()) {
                    if (WXEnvironment.isApkDebugable()) {
                        WXLogUtils.d(this.TAG, "Bind WXRefresh & WXLoading " + listBaseViewHolder);
                    }
                    if ((wXComponent instanceof WXBaseRefresh) && listBaseViewHolder.getView() != null) {
                        if (wXComponent.getAttrs().get("holderBackground") != null || wXComponent.getStyles().containsKey("backgroundColor")) {
                            Object obj = wXComponent.getAttrs().get("holderBackground");
                            listBaseViewHolder.getView().setBackgroundColor(obj != null ? WXResourceUtils.getColor(obj.toString(), -1) : WXResourceUtils.getColor(wXComponent.getStyles().getBackgroundColor(), -1));
                            listBaseViewHolder.getView().setVisibility(0);
                            listBaseViewHolder.getView().postInvalidate();
                        }
                    }
                } else if (listBaseViewHolder.getComponent() != null && (listBaseViewHolder.getComponent() instanceof WXCell)) {
                    if (listBaseViewHolder.isRecycled()) {
                        listBaseViewHolder.bindData(wXComponent);
                        wXComponent.onRenderFinish(1);
                    }
                    DragHelper dragHelper = this.mDragHelper;
                    if (dragHelper != null && dragHelper.isDraggable()) {
                        String str = this.mTriggerType;
                        String str2 = str;
                        if (str == null) {
                            str2 = "longpress";
                        }
                        this.mTriggerType = str2;
                        WXCell wXCell = (WXCell) listBaseViewHolder.getComponent();
                        boolean booleanValue = WXUtils.getBoolean(wXCell.getAttrs().get(EXCLUDED), false).booleanValue();
                        this.mDragHelper.setDragExcluded(listBaseViewHolder, booleanValue);
                        if ("pan".equals(this.mTriggerType)) {
                            this.mDragHelper.setLongPressDragEnabled(false);
                            WXComponent findComponentByAnchorName = findComponentByAnchorName(wXCell, DRAG_ANCHOR);
                            if (findComponentByAnchorName != null && findComponentByAnchorName.getHostView() != null && !booleanValue) {
                                findComponentByAnchorName.getHostView().setOnTouchListener(new View.OnTouchListener(this, listBaseViewHolder) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.6
                                    final BasicListComponent this$0;
                                    final ListBaseViewHolder val$holder;

                                    {
                                        this.this$0 = r4;
                                        this.val$holder = r5;
                                    }

                                    @Override // android.view.View.OnTouchListener
                                    public boolean onTouch(View view, MotionEvent motionEvent) {
                                        if (MotionEventCompat.getActionMasked(motionEvent) != 0) {
                                            return true;
                                        }
                                        this.this$0.mDragHelper.startDrag(this.val$holder);
                                        return true;
                                    }
                                });
                            } else if (!WXEnvironment.isApkDebugable()) {
                            } else {
                                if (!booleanValue) {
                                    WXLogUtils.e(this.TAG, "[error] onBindViewHolder: the anchor component or view is not found");
                                } else {
                                    WXLogUtils.d(this.TAG, "onBindViewHolder: position " + i2 + " is drag excluded");
                                }
                            }
                        } else if ("longpress".equals(this.mTriggerType)) {
                            this.mDragHelper.setLongPressDragEnabled(true);
                        }
                    }
                }
            }
        }
    }

    @Override // com.taobao.weex.ui.view.listview.adapter.IRecyclerAdapterListener
    public ListBaseViewHolder onCreateViewHolder(ViewGroup viewGroup, int i2) {
        if (((long) i2) == -1) {
            return createVHForRefreshComponent(i2);
        }
        if (this.mChildren != null) {
            SparseArray<ArrayList<WXComponent>> sparseArray = this.mViewTypes;
            if (sparseArray == null) {
                return createVHForFakeComponent(i2);
            }
            ArrayList<WXComponent> arrayList = sparseArray.get(i2);
            checkRecycledViewPool(i2);
            if (arrayList == null) {
                return createVHForFakeComponent(i2);
            }
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                WXComponent wXComponent = arrayList.get(i3);
                if (wXComponent != null && !wXComponent.isUsing()) {
                    if (wXComponent.isFixed()) {
                        return createVHForFakeComponent(i2);
                    } else {
                        if (wXComponent instanceof WXCell) {
                            if (wXComponent.getRealView() != null) {
                                return new ListBaseViewHolder(wXComponent, i2);
                            }
                            wXComponent.lazy(false);
                            wXComponent.createView();
                            wXComponent.applyLayoutAndEvent(wXComponent);
                            return new ListBaseViewHolder(wXComponent, i2, true);
                        } else if (wXComponent instanceof WXBaseRefresh) {
                            return createVHForRefreshComponent(i2);
                        } else {
                            WXLogUtils.e(this.TAG, "List cannot include element except cell、header、fixed、refresh and loading");
                            return createVHForFakeComponent(i2);
                        }
                    }
                }
            }
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.e(this.TAG, "Cannot find request viewType: " + i2);
        }
        return createVHForFakeComponent(i2);
    }

    public boolean onFailedToRecycleView(ListBaseViewHolder listBaseViewHolder) {
        if (!WXEnvironment.isApkDebugable()) {
            return false;
        }
        WXLogUtils.d(this.TAG, "Failed to recycle " + listBaseViewHolder);
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.taobao.weex.ui.component.WXComponent
    public /* bridge */ /* synthetic */ void onHostViewInitialized(View view) {
        onHostViewInitialized((BasicListComponent<T>) ((ViewGroup) view));
    }

    protected void onHostViewInitialized(T t2) {
        onHostViewInitialized((BasicListComponent<T>) t2);
        WXRecyclerView innerView = t2.getInnerView();
        if (innerView == null || innerView.getAdapter() == null) {
            WXLogUtils.e(this.TAG, "RecyclerView is not found or Adapter is not bound");
            return;
        }
        if (WXUtils.getBoolean(getAttrs().get("prefetchGapDisable"), false).booleanValue() && innerView.getLayoutManager() != null) {
            innerView.getLayoutManager().setItemPrefetchEnabled(false);
        }
        if (this.mChildren == null) {
            WXLogUtils.e(this.TAG, "children is null");
            return;
        }
        this.mDragHelper = new DefaultDragHelper(this.mChildren, innerView, new EventTrigger(this) { // from class: com.taobao.weex.ui.component.list.BasicListComponent.1
            final BasicListComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.component.list.EventTrigger
            public void triggerEvent(String str, Map<String, Object> map) {
                this.this$0.fireEvent(str, map);
            }
        });
        this.mTriggerType = getTriggerType(this);
    }

    @Override // com.taobao.weex.ui.view.listview.adapter.IOnLoadMoreListener
    public void onLoadMore(int i2) {
        try {
            String loadMoreOffset = getAttrs().getLoadMoreOffset();
            String str = loadMoreOffset;
            if (TextUtils.isEmpty(loadMoreOffset)) {
                str = WXInstanceApm.VALUE_ERROR_CODE_DEFAULT;
            }
            if (((float) i2) <= WXViewUtils.getRealPxByWidth((float) WXUtils.getInt(str), getInstance().getInstanceViewPortWidthWithFloat()) && getEvents().contains(Constants.Event.LOADMORE)) {
                if (this.mListCellCount != this.mChildren.size() || this.mForceLoadmoreNextTime) {
                    fireEvent(Constants.Event.LOADMORE);
                    this.mListCellCount = this.mChildren.size();
                    this.mForceLoadmoreNextTime = false;
                }
            }
        } catch (Exception e2) {
            WXLogUtils.d(this.TAG + "onLoadMore :", e2);
        }
    }

    public void onViewRecycled(ListBaseViewHolder listBaseViewHolder) {
        long currentTimeMillis = System.currentTimeMillis();
        listBaseViewHolder.setComponentUsing(false);
        if (listBaseViewHolder == null || !listBaseViewHolder.canRecycled() || listBaseViewHolder.getComponent() == null || listBaseViewHolder.getComponent().isUsing()) {
            WXLogUtils.w(this.TAG, "this holder can not be allowed to  recycled");
        } else {
            listBaseViewHolder.recycled();
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d(this.TAG, "Recycle holder " + (System.currentTimeMillis() - currentTimeMillis) + "  Thread:" + Thread.currentThread().getName());
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsVContainer
    public void remove(WXComponent wXComponent, boolean z2) {
        int indexOf = this.mChildren.indexOf(wXComponent);
        if (z2) {
            wXComponent.detachViewAndClearPreInfo();
        }
        unBindViewType(wXComponent);
        ViewGroup viewGroup = (ViewGroup) getHostView();
        if (viewGroup != null) {
            if ("default".equals(wXComponent.getAttrs().get(Constants.Name.DELETE_CELL_ANIMATION))) {
                ((ListComponentView) viewGroup).getInnerView().setItemAnimator(this.mItemAnimator);
            } else {
                ((ListComponentView) viewGroup).getInnerView().setItemAnimator(null);
            }
            ((ListComponentView) viewGroup).getRecyclerViewBaseAdapter().notifyItemRemoved(indexOf);
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d(this.TAG, "removeChild child at " + indexOf);
            }
            remove(wXComponent, z2);
        }
    }

    @JSMethod
    public void resetLoadmore() {
        this.mForceLoadmoreNextTime = true;
        this.mListCellCount = 0;
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void scrollTo(WXComponent wXComponent, Map<String, Object> map) {
        WXCell wXCell;
        int indexOf;
        boolean z2 = true;
        float f2 = 0.0f;
        if (map != null) {
            String obj = map.get("offset") == null ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT : map.get("offset").toString();
            boolean booleanValue = WXUtils.getBoolean(map.get(Constants.Name.ANIMATED), true).booleanValue();
            f2 = 0.0f;
            z2 = booleanValue;
            if (obj != null) {
                try {
                    f2 = WXViewUtils.getRealPxByWidth(Float.parseFloat(obj), getInstance().getInstanceViewPortWidthWithFloat());
                    z2 = booleanValue;
                } catch (Exception e2) {
                    WXLogUtils.e("Float parseFloat error :" + e2.getMessage());
                    z2 = booleanValue;
                    f2 = 0.0f;
                }
            }
        }
        int i2 = (int) f2;
        ViewGroup viewGroup = (ViewGroup) getHostView();
        if (viewGroup != null) {
            while (true) {
                if (wXComponent == null) {
                    wXCell = null;
                    break;
                } else if (wXComponent instanceof WXCell) {
                    wXCell = (WXCell) wXComponent;
                    break;
                } else {
                    wXComponent = wXComponent.getParent();
                }
            }
            if (wXCell != null && (indexOf = this.mChildren.indexOf(wXCell)) != -1) {
                ((ListComponentView) viewGroup).getInnerView().scrollTo(z2, indexOf, i2, getOrientation());
            }
        }
    }

    @JSMethod
    public void scrollTo(String str, JSCallback jSCallback) {
        float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(JSON.parseObject(str).getString(Constants.Name.SCROLL_TOP)), getInstance().getInstanceViewPortWidthWithFloat());
        ViewGroup viewGroup = (ViewGroup) getHostView();
        if (viewGroup != null) {
            WXRecyclerView innerView = ((ListComponentView) viewGroup).getInnerView();
            if (getOrientation() == 1) {
                innerView.scrollTo(0, (int) realPxByWidth, getOrientation());
            } else {
                innerView.scrollTo((int) realPxByWidth, 0, getOrientation());
            }
            if (jSCallback != null) {
                HashMap hashMap = new HashMap();
                hashMap.put("type", WXImage.SUCCEED);
                jSCallback.invoke(hashMap);
            }
        }
    }

    @WXComponentProp(name = "bounce")
    public void setBounce(String str) {
        WXRecyclerView innerView = ((ListComponentView) ((ViewGroup) getHostView())).getInnerView();
        if (Boolean.valueOf(str).booleanValue()) {
            innerView.setOverScrollMode(0);
        } else {
            innerView.setOverScrollMode(2);
        }
    }

    @WXComponentProp(name = Constants.Name.DRAGGABLE)
    public void setDraggable(boolean z2) {
        DragHelper dragHelper = this.mDragHelper;
        if (dragHelper != null) {
            dragHelper.setDraggable(z2);
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("set draggable : " + z2);
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsBasicComponent
    public void setIsLayoutRTL(boolean z2) {
        setIsLayoutRTL(z2);
        this.mViewOnScrollListener.setLayoutRTL(z2);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void setLayout(WXComponent wXComponent) {
        if (wXComponent.getHostView() != null) {
            ViewCompat.setLayoutDirection(wXComponent.getHostView(), wXComponent.isLayoutRTL() ? 1 : 0);
        }
        setLayout(wXComponent);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void setMarginsSupportRTL(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, int i3, int i4, int i5) {
        marginLayoutParams.setMargins(i2, i3, i4, i5);
        marginLayoutParams.setMarginStart(i2);
        marginLayoutParams.setMarginEnd(i4);
    }

    @WXComponentProp(name = Constants.Name.OFFSET_ACCURACY)
    public void setOffsetAccuracy(int i2) {
        this.mOffsetAccuracy = (int) WXViewUtils.getRealPxByWidth((float) i2, getInstance().getInstanceViewPortWidthWithFloat());
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -304480883:
                if (str.equals(Constants.Name.DRAGGABLE)) {
                    c2 = 0;
                    break;
                }
                break;
            case -223520855:
                if (str.equals(Constants.Name.SHOW_SCROLLBAR)) {
                    c2 = 1;
                    break;
                }
                break;
            case -112563826:
                if (str.equals("loadmoreoffset")) {
                    c2 = 2;
                    break;
                }
                break;
            case -5620052:
                if (str.equals(Constants.Name.OFFSET_ACCURACY)) {
                    c2 = 3;
                    break;
                }
                break;
            case 66669991:
                if (str.equals(Constants.Name.SCROLLABLE)) {
                    c2 = 4;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                setDraggable(WXUtils.getBoolean(obj, false).booleanValue());
                return true;
            case 1:
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                setShowScrollbar(bool.booleanValue());
                return true;
            case 2:
                return true;
            case 3:
                setOffsetAccuracy(WXUtils.getInteger(obj, 10).intValue());
                return true;
            case 4:
                setScrollable(WXUtils.getBoolean(obj, true).booleanValue());
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLL_LEFT)
    public void setScrollLeft(String str) {
        ViewGroup viewGroup = (ViewGroup) getHostView();
        if (viewGroup != null) {
            ((ListComponentView) viewGroup).getInnerView().scrollTo((int) WXViewUtils.getRealPxByWidth(WXUtils.getFloat(str), getInstance().getInstanceViewPortWidthWithFloat()), 0, getOrientation());
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLL_TOP)
    public void setScrollTop(String str) {
        ViewGroup viewGroup = (ViewGroup) getHostView();
        if (viewGroup != null) {
            ((ListComponentView) viewGroup).getInnerView().scrollTo(0, (int) WXViewUtils.getRealPxByWidth(WXUtils.getFloat(str), getInstance().getInstanceViewPortWidthWithFloat()), getOrientation());
        }
    }

    @WXComponentProp(name = Constants.Name.SCROLLABLE)
    public void setScrollable(boolean z2) {
        this.isScrollable = z2;
        WXRecyclerView innerView = ((ListComponentView) ((ViewGroup) getHostView())).getInnerView();
        if (innerView != null) {
            innerView.setScrollable(z2);
        }
    }

    @WXComponentProp(name = Constants.Name.SHOW_SCROLLBAR)
    public void setShowScrollbar(boolean z2) {
        if (getHostView() != 0 && ((ListComponentView) ((ViewGroup) getHostView())).getInnerView() != null) {
            if (getOrientation() == 1) {
                ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().setVerticalScrollBarEnabled(z2);
            } else {
                ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().setHorizontalScrollBarEnabled(z2);
            }
        }
    }

    @JSMethod
    public void setSpecialEffects(JSONObject jSONObject) {
        if (getHostView() != 0 && (getHostView() instanceof BounceRecyclerView)) {
            if (jSONObject == null || !jSONObject.containsKey("id")) {
                ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().setNestInfo(null);
                return;
            }
            String string = jSONObject.getString("id");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("isNestParent", (Object) false);
            jSONObject2.put("instanceId", (Object) getInstance().getInstanceId());
            jSONObject2.put("listParentId", (Object) string);
            ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().setNestInfo(jSONObject2);
            ((ListComponentView) ((ViewGroup) getHostView())).getInnerView().callBackNestParent(getRef(), getInstance().getInstanceId(), WXViewUtils.getRealPxByWidth(WXUtils.getFloat(jSONObject.getString("headerHeight")), getInstance().getInstanceViewPortWidthWithFloat()));
        }
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void unbindAppearEvent(WXComponent wXComponent) {
        setAppearanceWatch(wXComponent, 0, false);
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void unbindDisappearEvent(WXComponent wXComponent) {
        setAppearanceWatch(wXComponent, 1, false);
    }

    @Override // com.taobao.weex.ui.component.Scrollable
    public void unbindStickStyle(WXComponent wXComponent) {
        this.stickyHelper.unbindStickStyle(wXComponent, this.mStickyMap);
        WXHeader wXHeader = (WXHeader) findTypeParent(wXComponent, WXHeader.class);
        if (wXHeader != null && getHostView() != 0) {
            ((ListComponentView) ((ViewGroup) getHostView())).notifyStickyRemove(wXHeader);
        }
    }
}
