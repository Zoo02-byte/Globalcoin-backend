package com.taobao.weex.ui.component.list;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.taobao.weex.ui.view.listview.adapter.ListBaseViewHolder;
import com.taobao.weex.utils.WXLogUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/list/DragSupportCallback.class */
class DragSupportCallback extends ItemTouchHelper.Callback {
    private static final String TAG = "WXListExComponent";
    private int dragFrom;
    private int dragTo;
    private final DragHelper mDragHelper;
    private boolean mEnableDifferentViewTypeDrag;

    DragSupportCallback(DragHelper dragHelper) {
        this.dragFrom = -1;
        this.dragTo = -1;
        this.mDragHelper = dragHelper;
        this.mEnableDifferentViewTypeDrag = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DragSupportCallback(DragHelper dragHelper, boolean z2) {
        this.dragFrom = -1;
        this.dragTo = -1;
        this.mDragHelper = dragHelper;
        this.mEnableDifferentViewTypeDrag = z2;
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        clearView(recyclerView, viewHolder);
        if (viewHolder instanceof ListBaseViewHolder) {
            ListBaseViewHolder listBaseViewHolder = (ListBaseViewHolder) viewHolder;
            if (!(listBaseViewHolder.getComponent() == null || this.dragFrom == -1 || this.dragTo == -1)) {
                this.mDragHelper.onDragEnd(listBaseViewHolder.getComponent(), this.dragFrom, this.dragTo);
            }
        }
        this.dragTo = -1;
        this.dragFrom = -1;
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        return ((recyclerView.getLayoutManager() instanceof GridLayoutManager) || (recyclerView.getLayoutManager() instanceof StaggeredGridLayoutManager)) ? makeMovementFlags(15, 0) : makeMovementFlags(3, 48);
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public boolean isItemViewSwipeEnabled() {
        return false;
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public boolean isLongPressDragEnabled() {
        return this.mDragHelper.isDraggable() && this.mDragHelper.isLongPressDragEnabled();
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
        if (viewHolder == null || viewHolder2 == null) {
            return false;
        }
        if ((!this.mEnableDifferentViewTypeDrag && viewHolder.getItemViewType() != viewHolder2.getItemViewType()) || this.mDragHelper.isDragExcluded(viewHolder)) {
            return false;
        }
        try {
            int adapterPosition = viewHolder.getAdapterPosition();
            int adapterPosition2 = viewHolder2.getAdapterPosition();
            if (this.dragFrom == -1) {
                this.dragFrom = adapterPosition;
            }
            this.dragTo = adapterPosition2;
            this.mDragHelper.onDragging(adapterPosition, adapterPosition2);
            return true;
        } catch (Exception e2) {
            WXLogUtils.e(TAG, e2.getMessage());
            return false;
        }
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int i2) {
        if (i2 != 0 && (viewHolder instanceof ListBaseViewHolder)) {
            ListBaseViewHolder listBaseViewHolder = (ListBaseViewHolder) viewHolder;
            if (listBaseViewHolder.getComponent() != null) {
                this.mDragHelper.onDragStart(listBaseViewHolder.getComponent(), listBaseViewHolder.getAdapterPosition());
            }
        }
        onSelectedChanged(viewHolder, i2);
    }

    @Override // androidx.recyclerview.widget.ItemTouchHelper.Callback
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int i2) {
    }
}
