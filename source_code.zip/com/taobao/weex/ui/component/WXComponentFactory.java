package com.taobao.weex.ui.component;

import android.text.TextUtils;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.ui.IFComponentHolder;
import com.taobao.weex.ui.WXComponentRegistry;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXLogUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXComponentFactory.class */
public class WXComponentFactory {
    public static WXComponent newInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        if (wXSDKInstance == null || TextUtils.isEmpty(basicComponentData.mComponentType)) {
            return null;
        }
        IFComponentHolder component = WXComponentRegistry.getComponent(basicComponentData.mComponentType);
        IFComponentHolder iFComponentHolder = component;
        if (component == null) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.e("WXComponentFactory error type:[" + basicComponentData.mComponentType + "] class not found");
            }
            IFComponentHolder component2 = WXComponentRegistry.getComponent(WXBasicComponentType.CONTAINER);
            iFComponentHolder = component2;
            if (component2 == null) {
                WXExceptionUtils.commitCriticalExceptionRT(wXSDKInstance.getInstanceId(), WXErrorCode.WX_RENDER_ERR_COMPONENT_NOT_REGISTER, "createComponent", basicComponentData.mComponentType + " not registered", null);
                return null;
            }
        }
        try {
            return iFComponentHolder.createInstance(wXSDKInstance, wXVContainer, basicComponentData);
        } catch (Throwable th) {
            WXLogUtils.e("WXComponentFactory Exception type:[" + basicComponentData.mComponentType + "] ", th);
            return null;
        }
    }
}
