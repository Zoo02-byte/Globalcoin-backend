package com.taobao.weex.ui.component;

import android.content.Context;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.taobao.weex.ui.view.WXEditText;
import io.dcloud.common.DHInterface.IApp;
import io.dcloud.common.DHInterface.ISysEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/ConfirmBar.class */
public class ConfirmBar {
    private static ConfirmBar instance;
    private int height;
    private ViewGroup rootView;
    private RelativeLayout rtl;
    private List<WXComponent> editText = new ArrayList();
    private AtomicReference<ISysEventListener> listener = null;

    public static ConfirmBar getInstance() {
        if (instance == null) {
            synchronized (ConfirmBar.class) {
                try {
                    if (instance == null) {
                        instance = new ConfirmBar();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return instance;
    }

    public void showConfirm(boolean z2, int i2) {
        try {
            if (this.rtl != null) {
                ViewGroup viewGroup = this.rootView;
                View findViewWithTag = viewGroup != null ? viewGroup.findViewWithTag("AppRootView") : null;
                if (z2) {
                    if (this.rootView != null) {
                        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) findViewWithTag.getLayoutParams();
                        layoutParams.bottomMargin = this.height;
                        findViewWithTag.setLayoutParams(layoutParams);
                    }
                    FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) this.rtl.getLayoutParams();
                    layoutParams2.topMargin = i2;
                    this.rtl.setLayoutParams(layoutParams2);
                    this.rtl.setVisibility(0);
                    this.rtl.bringToFront();
                    return;
                }
                this.rtl.setVisibility(4);
                if (findViewWithTag != null) {
                    FrameLayout.LayoutParams layoutParams3 = (FrameLayout.LayoutParams) findViewWithTag.getLayoutParams();
                    layoutParams3.bottomMargin = 0;
                    findViewWithTag.setLayoutParams(layoutParams3);
                }
            }
        } catch (Exception e2) {
        }
    }

    public void addComponent(WXComponent wXComponent) {
        try {
            this.editText.add(wXComponent);
        } catch (Exception e2) {
        }
    }

    public void createConfirmBar(Context context, IApp iApp) {
        try {
            if (this.listener == null) {
                AtomicReference<ISysEventListener> atomicReference = new AtomicReference<>(new ISysEventListener(this, context) { // from class: com.taobao.weex.ui.component.ConfirmBar.1
                    final ConfirmBar this$0;
                    final Context val$context;

                    {
                        this.this$0 = r4;
                        this.val$context = r5;
                    }

                    @Override // io.dcloud.common.DHInterface.ISysEventListener
                    public boolean onExecute(ISysEventListener.SysEventType sysEventType, Object obj) {
                        if (sysEventType == ISysEventListener.SysEventType.onSizeChanged) {
                            int[] iArr = (int[]) obj;
                            int i2 = this.val$context.getResources().getDisplayMetrics().heightPixels;
                            int i3 = this.val$context.getResources().getDisplayMetrics().heightPixels / 4;
                            if (Math.abs(iArr[1] - i2) <= i3 && Math.abs(iArr[1] - iArr[3]) <= i3) {
                                return false;
                            }
                            int i4 = iArr[1];
                            int i5 = iArr[3];
                            if (i4 <= i5 || Math.abs(i4 - i5) <= i3) {
                                for (WXComponent wXComponent : this.this$0.editText) {
                                    if (!wXComponent.getHostView().hasFocus() || !(wXComponent instanceof DCTextArea) || !((DCTextArea) wXComponent).isShowConfirm) {
                                        ConfirmBar.getInstance().showConfirm(false, iArr[1]);
                                    } else {
                                        ConfirmBar.getInstance().showConfirm(true, iArr[1]);
                                        return false;
                                    }
                                }
                                return false;
                            }
                            ConfirmBar.getInstance().showConfirm(false, iArr[1]);
                            return false;
                        } else if (sysEventType != ISysEventListener.SysEventType.onWebAppStop) {
                            return false;
                        } else {
                            this.this$0.listener = null;
                            this.this$0.rtl = null;
                            this.this$0.rootView = null;
                            return false;
                        }
                    }
                });
                this.listener = atomicReference;
                iApp.registerSysEventListener(atomicReference.get(), ISysEventListener.SysEventType.onSizeChanged);
                iApp.registerSysEventListener(this.listener.get(), ISysEventListener.SysEventType.onWebAppStop);
            }
            this.height = (int) TypedValue.applyDimension(1, 44.0f, context.getResources().getDisplayMetrics());
            if (this.rtl == null) {
                this.rtl = new RelativeLayout(context);
                ViewGroup viewGroup = (ViewGroup) iApp.obtainWebAppRootView().obtainMainView().getParent();
                this.rootView = viewGroup;
                if (viewGroup != null) {
                    this.rootView.addView(this.rtl, new FrameLayout.LayoutParams(-1, this.height));
                }
                Button button = new Button(context);
                button.setText(17039370);
                button.setGravity(17);
                button.setTextColor(Color.argb(255, 50, 205, 50));
                button.setTextSize(TypedValue.applyDimension(2, 6.0f, context.getResources().getDisplayMetrics()));
                button.setBackground(null);
                button.setOnClickListener(new View.OnClickListener(this) { // from class: com.taobao.weex.ui.component.ConfirmBar.2
                    final ConfirmBar this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        WXComponent wXComponent;
                        if (this.this$0.editText.size() > 0) {
                            Iterator it = this.this$0.editText.iterator();
                            while (true) {
                                if (!it.hasNext()) {
                                    wXComponent = null;
                                    break;
                                }
                                wXComponent = (WXComponent) it.next();
                                if ((wXComponent.getHostView() instanceof WXEditText) && wXComponent.getHostView().hasFocus()) {
                                    break;
                                }
                            }
                            if (wXComponent != null) {
                                HashMap hashMap = new HashMap(1);
                                HashMap hashMap2 = new HashMap(1);
                                hashMap2.put("value", ((WXEditText) wXComponent.getHostView()).getText().toString());
                                hashMap.put("detail", hashMap2);
                                wXComponent.fireEvent("confirm", hashMap);
                                if (wXComponent.getParent() != null) {
                                    wXComponent.getParent().interceptFocus();
                                }
                                wXComponent.getHostView().clearFocus();
                                ((DCTextArea) wXComponent).hideSoftKeyboard();
                            }
                        }
                    }
                });
                this.rtl.addView(button, new RelativeLayout.LayoutParams(-2, -1));
                this.rtl.setBackgroundColor(Color.argb(255, 220, 220, 220));
                this.rtl.setTag("ConfirmBar");
                this.rtl.setVisibility(4);
            }
        } catch (Exception e2) {
        }
    }

    public void removeComponent(WXComponent wXComponent) {
        try {
            this.editText.remove(wXComponent);
        } catch (Exception e2) {
        }
    }
}
