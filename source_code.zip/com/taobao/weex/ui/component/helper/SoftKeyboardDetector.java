package com.taobao.weex.ui.component.helper;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXViewUtils;
import java.lang.ref.WeakReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/SoftKeyboardDetector.class */
public class SoftKeyboardDetector {
    private static final int KEYBOARD_VISIBLE_THRESHOLD_DIP = 100;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/SoftKeyboardDetector$DefaultUnRegister.class */
    public static final class DefaultUnRegister implements Unregister {
        private WeakReference<Activity> activityRef;
        private WeakReference<ViewTreeObserver.OnGlobalLayoutListener> listenerRef;

        public DefaultUnRegister(Activity activity, ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
            this.activityRef = new WeakReference<>(activity);
            this.listenerRef = new WeakReference<>(onGlobalLayoutListener);
        }

        @Override // com.taobao.weex.ui.component.helper.SoftKeyboardDetector.Unregister
        public void execute() {
            View activityRoot;
            Activity activity = this.activityRef.get();
            ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener = this.listenerRef.get();
            if (!(activity == null || onGlobalLayoutListener == null || (activityRoot = SoftKeyboardDetector.getActivityRoot(activity)) == null)) {
                activityRoot.getViewTreeObserver().removeOnGlobalLayoutListener(onGlobalLayoutListener);
            }
            this.activityRef.clear();
            this.listenerRef.clear();
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/SoftKeyboardDetector$OnKeyboardEventListener.class */
    public interface OnKeyboardEventListener {
        void onKeyboardEvent(boolean z2);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/SoftKeyboardDetector$Unregister.class */
    public interface Unregister {
        void execute();
    }

    public static View getActivityRoot(Activity activity) {
        if (activity != null) {
            return activity.findViewById(16908290);
        }
        return null;
    }

    public static boolean isKeyboardVisible(Activity activity) {
        Rect rect = new Rect();
        View activityRoot = getActivityRoot(activity);
        boolean z2 = false;
        if (activityRoot != null) {
            activityRoot.getWindowVisibleDisplayFrame(rect);
            z2 = false;
            if (activityRoot.getRootView().getHeight() - rect.height() > WXViewUtils.dip2px(100.0f)) {
                z2 = true;
            }
        }
        return z2;
    }

    public static Unregister registerKeyboardEventListener(Activity activity, OnKeyboardEventListener onKeyboardEventListener) {
        WindowManager.LayoutParams attributes;
        int i2;
        if (activity == null || onKeyboardEventListener == null) {
            WXLogUtils.e("Activity or listener is null!");
            return null;
        } else if (activity.getWindow() == null || (attributes = activity.getWindow().getAttributes()) == null || !((i2 = attributes.softInputMode) == 48 || i2 == 32)) {
            View activityRoot = getActivityRoot(activity);
            if (activityRoot == null) {
                WXLogUtils.e("Activity root is null!");
                return null;
            }
            AnonymousClass1 r02 = new ViewTreeObserver.OnGlobalLayoutListener(activityRoot, onKeyboardEventListener) { // from class: com.taobao.weex.ui.component.helper.SoftKeyboardDetector.1
                final View val$activityRoot;
                final OnKeyboardEventListener val$listener;
                private final Rect visibleFrame = new Rect();
                private final int threshold = WXViewUtils.dip2px(100.0f);
                private boolean wasKeyboardOpened = false;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.val$activityRoot = r5;
                    this.val$listener = r6;
                }

                @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                public void onGlobalLayout() {
                    this.val$activityRoot.getWindowVisibleDisplayFrame(this.visibleFrame);
                    boolean z2 = this.val$activityRoot.getRootView().getHeight() - this.visibleFrame.height() > this.threshold;
                    if (z2 != this.wasKeyboardOpened) {
                        this.wasKeyboardOpened = z2;
                        this.val$listener.onKeyboardEvent(z2);
                    }
                }
            };
            activityRoot.getViewTreeObserver().addOnGlobalLayoutListener(r02);
            return new DefaultUnRegister(activity, r02);
        } else {
            WXLogUtils.e("SoftKeyboard detector can't work with softInputMode is SOFT_INPUT_ADJUST_NOTHING or SOFT_INPUT_ADJUST_PAN");
            return null;
        }
    }
}
