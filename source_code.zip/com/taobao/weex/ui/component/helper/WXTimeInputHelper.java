package com.taobao.weex.ui.component.helper;

import android.widget.TextView;
import com.taobao.weex.appfram.pickers.DatePickerImpl;
import com.taobao.weex.ui.component.AbstractEditComponent;
import com.taobao.weex.ui.view.WXEditText;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/WXTimeInputHelper.class */
public class WXTimeInputHelper {
    public static void pickDate(String str, String str2, AbstractEditComponent abstractEditComponent) {
        WXEditText hostView = abstractEditComponent.getHostView();
        DatePickerImpl.pickDate(hostView.getContext(), hostView.getText().toString(), str, str2, new DatePickerImpl.OnPickListener(hostView, abstractEditComponent) { // from class: com.taobao.weex.ui.component.helper.WXTimeInputHelper.1
            final AbstractEditComponent val$component;
            final TextView val$target;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$target = r4;
                this.val$component = r5;
            }

            @Override // com.taobao.weex.appfram.pickers.DatePickerImpl.OnPickListener
            public void onPick(boolean z2, String str3) {
                if (z2) {
                    this.val$target.setText(str3);
                    this.val$component.performOnChange(str3);
                }
            }
        }, null);
    }

    public static void pickTime(AbstractEditComponent abstractEditComponent) {
        WXEditText hostView = abstractEditComponent.getHostView();
        DatePickerImpl.pickTime(hostView.getContext(), hostView.getText().toString(), new DatePickerImpl.OnPickListener(hostView, abstractEditComponent) { // from class: com.taobao.weex.ui.component.helper.WXTimeInputHelper.2
            final AbstractEditComponent val$component;
            final TextView val$target;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$target = r4;
                this.val$component = r5;
            }

            @Override // com.taobao.weex.appfram.pickers.DatePickerImpl.OnPickListener
            public void onPick(boolean z2, String str) {
                if (z2) {
                    this.val$target.setText(str);
                    this.val$component.performOnChange(str);
                }
            }
        }, null);
    }
}
