package com.taobao.weex.ui.component.helper;

import com.taobao.weex.ui.component.Scrollable;
import com.taobao.weex.ui.component.WXComponent;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/helper/WXStickyHelper.class */
public class WXStickyHelper {
    private Scrollable scrollable;

    public WXStickyHelper(Scrollable scrollable) {
        this.scrollable = scrollable;
    }

    public void bindStickStyle(WXComponent wXComponent, Map<String, Map<String, WXComponent>> map) {
        Scrollable parentScroller = wXComponent.getParentScroller();
        if (parentScroller != null) {
            Map<String, WXComponent> map2 = map.get(parentScroller.getRef());
            Map<String, WXComponent> map3 = map2;
            if (map2 == null) {
                map3 = new ConcurrentHashMap<>();
            }
            if (!map3.containsKey(wXComponent.getRef())) {
                map3.put(wXComponent.getRef(), wXComponent);
                map.put(parentScroller.getRef(), map3);
            }
        }
    }

    public void unbindStickStyle(WXComponent wXComponent, Map<String, Map<String, WXComponent>> map) {
        Map<String, WXComponent> map2;
        Scrollable parentScroller = wXComponent.getParentScroller();
        if (parentScroller != null && (map2 = map.get(parentScroller.getRef())) != null) {
            map2.remove(wXComponent.getRef());
        }
    }
}
