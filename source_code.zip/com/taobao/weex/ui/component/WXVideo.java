package com.taobao.weex.ui.component;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.FrameLayout;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.view.WXVideoView;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import java.util.HashMap;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXVideo.class */
public class WXVideo extends WXComponent<FrameLayout> {
    private boolean mAutoPlay;
    private boolean mError;
    boolean mPrepared;
    private boolean mStopped;
    private WXVideoView.Wrapper mWrapper;

    @Deprecated
    public WXVideo(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXVideo(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void notify(String str, String str2) {
        HashMap hashMap = new HashMap(2);
        hashMap.put(Constants.Name.PLAY_STATUS, str2);
        hashMap.put("timeStamp", Long.valueOf(System.currentTimeMillis()));
        HashMap hashMap2 = new HashMap();
        HashMap hashMap3 = new HashMap();
        hashMap3.put(Constants.Name.PLAY_STATUS, str2);
        hashMap2.put(TemplateDom.KEY_ATTRS, hashMap3);
        WXSDKManager.getInstance().fireEvent(getInstanceId(), getRef(), str, hashMap, hashMap2);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void bindData(WXComponent wXComponent) {
        bindData(wXComponent);
        addEvent(Constants.Event.APPEAR);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public FrameLayout initComponentHostView(Context context) {
        WXVideoView.Wrapper wrapper = new WXVideoView.Wrapper(context);
        wrapper.setOnErrorListener(new MediaPlayer.OnErrorListener(this, wrapper) { // from class: com.taobao.weex.ui.component.WXVideo.1
            final WXVideo this$0;
            final WXVideoView.Wrapper val$video;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$video = r5;
            }

            @Override // android.media.MediaPlayer.OnErrorListener
            public boolean onError(MediaPlayer mediaPlayer, int i2, int i3) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("Video", "onError:" + i2);
                }
                this.val$video.getProgressBar().setVisibility(8);
                this.this$0.mPrepared = false;
                this.this$0.mError = true;
                if (!this.this$0.getEvents().contains(Constants.Event.FAIL)) {
                    return true;
                }
                this.this$0.notify(Constants.Event.FAIL, Constants.Value.STOP);
                return true;
            }
        });
        wrapper.setOnPreparedListener(new MediaPlayer.OnPreparedListener(this, wrapper) { // from class: com.taobao.weex.ui.component.WXVideo.2
            final WXVideo this$0;
            final WXVideoView.Wrapper val$video;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$video = r5;
            }

            @Override // android.media.MediaPlayer.OnPreparedListener
            public void onPrepared(MediaPlayer mediaPlayer) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("Video", "onPrepared");
                }
                this.val$video.getProgressBar().setVisibility(8);
                this.this$0.mPrepared = true;
                if (this.this$0.mAutoPlay) {
                    this.val$video.start();
                }
                this.val$video.getVideoView().seekTo(5);
                if (this.val$video.getMediaController() != null) {
                    if (!this.this$0.mStopped) {
                        this.val$video.getMediaController().show(3);
                    } else {
                        this.val$video.getMediaController().hide();
                    }
                }
                this.this$0.mStopped = false;
            }
        });
        wrapper.setOnCompletionListener(new MediaPlayer.OnCompletionListener(this) { // from class: com.taobao.weex.ui.component.WXVideo.3
            final WXVideo this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.media.MediaPlayer.OnCompletionListener
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("Video", "onCompletion");
                }
                if (this.this$0.getEvents().contains(Constants.Event.FINISH)) {
                    this.this$0.notify(Constants.Event.FINISH, Constants.Value.STOP);
                }
            }
        });
        wrapper.setOnVideoPauseListener(new WXVideoView.VideoPlayListener(this) { // from class: com.taobao.weex.ui.component.WXVideo.4
            final WXVideo this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.WXVideoView.VideoPlayListener
            public void onPause() {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("Video", "onPause");
                }
                if (this.this$0.getEvents().contains("pause")) {
                    this.this$0.notify("pause", "pause");
                }
            }

            @Override // com.taobao.weex.ui.view.WXVideoView.VideoPlayListener
            public void onStart() {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("Video", "onStart");
                }
                if (this.this$0.getEvents().contains("start")) {
                    this.this$0.notify("start", Constants.Value.PLAY);
                }
            }
        });
        this.mWrapper = wrapper;
        return wrapper;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void notifyAppearStateChange(String str, String str2) {
        notifyAppearStateChange(str, str2);
        this.mWrapper.createVideoViewIfVisible();
    }

    @WXComponentProp(name = Constants.Name.AUTO_PLAY)
    public void setAutoPlay(boolean z2) {
        this.mAutoPlay = z2;
        if (z2) {
            this.mWrapper.createIfNotExist();
            this.mWrapper.start();
        }
    }

    @WXComponentProp(name = Constants.Name.CONTROLS)
    public void setControls(String str) {
        if (TextUtils.equals(Constants.Name.CONTROLS, str)) {
            this.mWrapper.setControls(true);
        } else if (TextUtils.equals("nocontrols", str)) {
            this.mWrapper.setControls(false);
        }
    }

    @WXComponentProp(name = Constants.Name.PLAY_STATUS)
    public void setPlaystatus(String str) {
        if (!this.mPrepared || this.mError || this.mStopped) {
            if ((this.mError || this.mStopped) && str.equals(Constants.Value.PLAY)) {
                this.mError = false;
                this.mWrapper.resume();
                this.mWrapper.getProgressBar().setVisibility(0);
            }
        } else if (str.equals(Constants.Value.PLAY)) {
            this.mWrapper.start();
        } else if (str.equals("pause")) {
            this.mWrapper.pause();
        } else if (str.equals(Constants.Value.STOP)) {
            this.mWrapper.stopPlayback();
            this.mStopped = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -167173695:
                if (str.equals(Constants.Name.ZORDERTOP)) {
                    c2 = 0;
                    break;
                }
                break;
            case 114148:
                if (str.equals("src")) {
                    c2 = 1;
                    break;
                }
                break;
            case 1438608771:
                if (str.equals(Constants.Name.AUTO_PLAY)) {
                    c2 = 2;
                    break;
                }
                break;
            case 1439562083:
                if (str.equals(Constants.Name.AUTOPLAY)) {
                    c2 = 3;
                    break;
                }
                break;
            case 1582764102:
                if (str.equals(Constants.Name.PLAY_STATUS)) {
                    c2 = 4;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                this.mWrapper.getVideoView().setZOrderOnTop(bool.booleanValue());
                return true;
            case 1:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setSrc(string);
                return true;
            case 2:
            case 3:
                Boolean bool2 = WXUtils.getBoolean(obj, null);
                if (bool2 == null) {
                    return true;
                }
                setAutoPlay(bool2.booleanValue());
                return true;
            case 4:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setPlaystatus(string2);
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @WXComponentProp(name = "src")
    public void setSrc(String str) {
        if (!TextUtils.isEmpty(str) && getHostView() != null && !TextUtils.isEmpty(str)) {
            this.mWrapper.setVideoURI(getInstance().rewriteUri(Uri.parse(str), "video"));
            this.mWrapper.getProgressBar().setVisibility(0);
        }
    }
}
