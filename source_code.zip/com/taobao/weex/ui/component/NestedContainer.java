package com.taobao.weex.ui.component;

import android.view.ViewGroup;
import com.taobao.weex.WXSDKInstance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/NestedContainer.class */
public interface NestedContainer {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/NestedContainer$OnNestedInstanceEventListener.class */
    public interface OnNestedInstanceEventListener {
        void onCreated(NestedContainer nestedContainer, WXSDKInstance wXSDKInstance);

        void onException(NestedContainer nestedContainer, String str, String str2);

        boolean onPreCreate(NestedContainer nestedContainer, String str);

        String transformUrl(String str);
    }

    ViewGroup getViewContainer();

    void reload();

    void renderNewURL(String str);

    void setOnNestEventListener(OnNestedInstanceEventListener onNestedInstanceEventListener);
}
