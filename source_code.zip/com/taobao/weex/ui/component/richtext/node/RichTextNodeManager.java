package com.taobao.weex.ui.component.richtext.node;

import android.content.Context;
import androidx.collection.ArrayMap;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.ui.component.richtext.node.ANode;
import com.taobao.weex.ui.component.richtext.node.ImgNode;
import com.taobao.weex.ui.component.richtext.node.SpanNode;
import com.taobao.weex.utils.WXLogUtils;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/richtext/node/RichTextNodeManager.class */
public class RichTextNodeManager {
    private static final Map<String, RichTextNodeCreator> registeredTextNodes;

    static {
        ArrayMap arrayMap = new ArrayMap();
        registeredTextNodes = arrayMap;
        arrayMap.put(SpanNode.NODE_TYPE, new SpanNode.SpanNodeCreator());
        arrayMap.put("image", new ImgNode.ImgNodeCreator());
        arrayMap.put("a", new ANode.ANodeCreator());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static RichTextNode createRichTextNode(Context context, String str, String str2, JSONObject jSONObject) {
        RichTextNode richTextNode = null;
        if (jSONObject != null) {
            try {
                richTextNode = registeredTextNodes.get(jSONObject.getString("type")).createRichTextNode(context, str, str2);
                richTextNode.parse(context, str, str2, jSONObject);
            } catch (Exception e2) {
                WXLogUtils.e("Richtext", WXLogUtils.getStackTrace(e2));
                richTextNode = null;
            }
        }
        return richTextNode;
    }

    public static RichTextNode createRichTextNode(Context context, String str, String str2, String str3, String str4, Map<String, String> map, Map<String, String> map2) {
        RichTextNode richTextNode;
        try {
            richTextNode = registeredTextNodes.get(str4).createRichTextNode(context, str, str2, str3, map, map2);
        } catch (Exception e2) {
            WXLogUtils.e("Richtext", WXLogUtils.getStackTrace(e2));
            richTextNode = null;
        }
        return richTextNode;
    }

    public static void registerTextNode(String str, RichTextNodeCreator richTextNodeCreator) {
        registeredTextNodes.put(str, richTextNodeCreator);
    }
}
