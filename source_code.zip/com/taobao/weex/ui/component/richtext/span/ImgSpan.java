package com.taobao.weex.ui.component.richtext.span;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.style.ReplacementSpan;
import android.view.View;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IDrawableLoader;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/richtext/span/ImgSpan.class */
public class ImgSpan extends ReplacementSpan implements IDrawableLoader.StaticTarget {
    private int height;
    private String instanceId;
    private Drawable mDrawable;
    private View mView;
    private String ref;
    private int width;

    public ImgSpan(int i2, int i3, String str, String str2) {
        this.width = i2;
        this.height = i3;
        this.instanceId = str;
        this.ref = str2;
    }

    private void setCallback() {
        View view;
        Drawable drawable = this.mDrawable;
        if (drawable != null && (view = this.mView) != null) {
            drawable.setCallback(view);
        }
    }

    @Override // android.text.style.ReplacementSpan
    public void draw(Canvas canvas, CharSequence charSequence, int i2, int i3, float f2, int i4, int i5, int i6, Paint paint) {
        if (this.mDrawable != null) {
            canvas.save();
            canvas.translate(f2, (float) ((i6 - this.mDrawable.getBounds().bottom) - paint.getFontMetricsInt().descent));
            this.mDrawable.draw(canvas);
            canvas.restore();
        }
    }

    @Override // android.text.style.ReplacementSpan
    public int getSize(Paint paint, CharSequence charSequence, int i2, int i3, Paint.FontMetricsInt fontMetricsInt) {
        WXComponent wXComponent;
        if (this.mView == null && (wXComponent = WXSDKManager.getInstance().getWXRenderManager().getWXComponent(this.instanceId, this.ref)) != null && wXComponent.getHostView() != null && this.width > wXComponent.getHostView().getWidth() && wXComponent.getHostView().getWidth() > 0) {
            int width = wXComponent.getHostView().getWidth();
            int i4 = (this.height * width) / this.width;
            this.height = i4;
            this.width = width;
            Drawable drawable = this.mDrawable;
            if (drawable != null) {
                drawable.setBounds(0, 0, width, i4);
            }
        }
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = -this.height;
            fontMetricsInt.descent = 0;
            fontMetricsInt.top = fontMetricsInt.ascent;
            fontMetricsInt.bottom = 0;
        }
        return this.width;
    }

    @Override // com.taobao.weex.adapter.IDrawableLoader.StaticTarget, com.taobao.weex.adapter.IDrawableLoader.DrawableTarget
    public void setDrawable(Drawable drawable, boolean z2) {
        this.mDrawable = drawable;
        if (z2) {
            drawable.setBounds(0, 0, this.width, this.height);
        }
        setCallback();
        this.mDrawable.invalidateSelf();
    }

    public void setView(View view) {
        this.mView = view;
        setCallback();
    }
}
