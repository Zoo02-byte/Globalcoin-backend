package com.taobao.weex.ui.component;

import android.graphics.Rect;
import android.view.View;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/AppearanceHelper.class */
public class AppearanceHelper {
    public static final int APPEAR = 0;
    public static final int DISAPPEAR = 1;
    public static final int RESULT_APPEAR = 1;
    public static final int RESULT_DISAPPEAR = -1;
    public static final int RESULT_NO_CHANGE = 0;
    private boolean mAppearStatus;
    private final WXComponent mAwareChild;
    private int mCellPositionInScrollable;
    private Rect mVisibleRect;
    private boolean[] mWatchFlags;

    public AppearanceHelper(WXComponent wXComponent) {
        this(wXComponent, 0);
    }

    public AppearanceHelper(WXComponent wXComponent, int i2) {
        this.mAppearStatus = false;
        this.mWatchFlags = new boolean[]{false, false};
        this.mVisibleRect = new Rect();
        this.mAwareChild = wXComponent;
        this.mCellPositionInScrollable = i2;
    }

    public WXComponent getAwareChild() {
        return this.mAwareChild;
    }

    public int getCellPositionINScollable() {
        return this.mCellPositionInScrollable;
    }

    public boolean isAppear() {
        return this.mAppearStatus;
    }

    public boolean isViewVisible(View view) {
        boolean z2 = true;
        if (view.getVisibility() == 0 && view.getMeasuredHeight() == 0) {
            return true;
        }
        if (view == null || !view.getLocalVisibleRect(this.mVisibleRect)) {
            z2 = false;
        }
        return z2;
    }

    public boolean isViewVisible(boolean z2) {
        View hostView = this.mAwareChild.getHostView();
        boolean z3 = true;
        if (z2 && hostView.getVisibility() == 0 && hostView.getMeasuredHeight() == 0) {
            return true;
        }
        if (hostView == null || !hostView.getLocalVisibleRect(this.mVisibleRect)) {
            z3 = false;
        }
        return z3;
    }

    public boolean isWatch() {
        boolean[] zArr = this.mWatchFlags;
        boolean z2 = false;
        if (zArr[0] || zArr[1]) {
            z2 = true;
        }
        return z2;
    }

    public int setAppearStatus(boolean z2) {
        if (this.mAppearStatus == z2) {
            return 0;
        }
        this.mAppearStatus = z2;
        return z2 ? 1 : -1;
    }

    public void setCellPosition(int i2) {
        this.mCellPositionInScrollable = i2;
    }

    public void setWatchEvent(int i2, boolean z2) {
        this.mWatchFlags[i2] = z2;
    }
}
