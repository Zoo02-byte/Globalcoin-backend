package com.taobao.weex.ui.component;

import android.content.Context;
import android.view.View;
import android.widget.CompoundButton;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.common.Constants;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.view.WXSwitchView;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import java.util.HashMap;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXSwitch.class */
public class WXSwitch extends WXComponent<WXSwitchView> {
    private CompoundButton.OnCheckedChangeListener mListener;

    @Deprecated
    public WXSwitch(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXSwitch(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        setContentBoxMeasurement(new ContentBoxMeasurement(this, wXSDKInstance) { // from class: com.taobao.weex.ui.component.WXSwitch.1
            final WXSwitch this$0;
            final WXSDKInstance val$instance;

            {
                this.this$0 = r4;
                this.val$instance = r5;
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutAfter(float f2, float f3) {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutBefore() {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void measureInternal(float f2, float f3, int i2, int i3) {
                this.mMeasureWidth = 0.0f;
                this.mMeasureHeight = 0.0f;
                try {
                    WXSwitchView wXSwitchView = new WXSwitchView(this.val$instance.getContext());
                    wXSwitchView.measure(Float.isNaN(f2) ? View.MeasureSpec.makeMeasureSpec(0, 0) : View.MeasureSpec.makeMeasureSpec((int) f2, Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(0, 0));
                    this.mMeasureWidth = (float) wXSwitchView.getMeasuredWidth();
                    this.mMeasureHeight = (float) wXSwitchView.getMeasuredHeight();
                } catch (RuntimeException e2) {
                    WXLogUtils.e(WXLogUtils.getStackTrace(e2));
                }
            }
        });
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        addEvent(str);
        if (str != null && str.equals(Constants.Event.CHANGE) && getHostView() != null) {
            if (this.mListener == null) {
                this.mListener = new CompoundButton.OnCheckedChangeListener(this) { // from class: com.taobao.weex.ui.component.WXSwitch.2
                    final WXSwitch this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.widget.CompoundButton.OnCheckedChangeListener
                    public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                        HashMap hashMap = new HashMap(2);
                        hashMap.put("value", Boolean.valueOf(z2));
                        HashMap hashMap2 = new HashMap();
                        HashMap hashMap3 = new HashMap();
                        hashMap3.put(Constants.Name.CHECKED, Boolean.toString(z2));
                        hashMap2.put(TemplateDom.KEY_ATTRS, hashMap3);
                        this.this$0.fireEvent(Constants.Event.CHANGE, hashMap, hashMap2);
                    }
                };
            }
            getHostView().setOnCheckedChangeListener(this.mListener);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public WXSwitchView initComponentHostView(Context context) {
        return new WXSwitchView(context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public void removeEventFromView(String str) {
        removeEventFromView(str);
        if (getHostView() != null && Constants.Event.CHANGE.equals(str)) {
            getHostView().setOnCheckedChangeListener(null);
        }
    }

    @WXComponentProp(name = Constants.Name.CHECKED)
    public void setChecked(boolean z2) {
        getHostView().setOnCheckedChangeListener(null);
        getHostView().setChecked(z2);
        getHostView().setOnCheckedChangeListener(this.mListener);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        if (!str.equals(Constants.Name.CHECKED)) {
            return setProperty(str, obj);
        }
        Boolean bool = WXUtils.getBoolean(obj, null);
        if (bool == null) {
            return true;
        }
        setChecked(bool.booleanValue());
        return true;
    }
}
