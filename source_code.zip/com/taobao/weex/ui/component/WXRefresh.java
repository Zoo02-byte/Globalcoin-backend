package com.taobao.weex.ui.component;

import android.content.Context;
import android.text.TextUtils;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.list.WXListComponent;
import com.taobao.weex.ui.view.WXFrameLayout;
import com.taobao.weex.ui.view.WXRefreshLayout;
import com.taobao.weex.ui.view.refresh.core.WXSwipeLayout;
import com.taobao.weex.ui.view.refresh.wrapper.BaseBounceView;
import com.taobao.weex.utils.WXUtils;
import java.util.HashMap;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXRefresh.class */
public class WXRefresh extends WXBaseRefresh implements WXSwipeLayout.WXOnRefreshListener {
    public static final String HIDE;

    @Deprecated
    public WXRefresh(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    public WXRefresh(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean canRecycled() {
        return false;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public int getLayoutTopOffsetForSibling() {
        return getParent() instanceof Scrollable ? -Math.round(getLayoutHeight()) : 0;
    }

    @Override // com.taobao.weex.ui.component.WXBaseRefresh, com.taobao.weex.ui.component.WXComponent
    public WXFrameLayout initComponentHostView(Context context) {
        return new WXRefreshLayout(context);
    }

    @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXOnRefreshListener
    public void onPullingDown(float f2, int i2, float f3) {
        if (getEvents() != null && getEvents().contains(Constants.Event.ONPULLING_DOWN)) {
            HashMap hashMap = new HashMap();
            hashMap.put(Constants.Name.DISTANCE_Y, Float.valueOf(f2));
            hashMap.put(Constants.Name.PULLING_DISTANCE, Integer.valueOf(i2));
            hashMap.put(Constants.Name.VIEW_HEIGHT, Float.valueOf(f3));
            fireEvent(Constants.Event.ONPULLING_DOWN, hashMap);
        }
    }

    @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXOnRefreshListener
    public void onRefresh() {
        if (!isDestoryed() && getEvents().contains("refresh")) {
            fireEvent("refresh");
        }
    }

    @WXComponentProp(name = "display")
    public void setDisplay(String str) {
        if (!TextUtils.isEmpty(str) && str.equals("hide")) {
            if (((getParent() instanceof WXListComponent) || (getParent() instanceof WXBaseScroller)) && ((BaseBounceView) getParent().getHostView()).getSwipeLayout().isRefreshing()) {
                ((BaseBounceView) getParent().getHostView()).finishPullRefresh();
                ((BaseBounceView) getParent().getHostView()).onRefreshingComplete();
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        if (!str.equals("display")) {
            return setProperty(str, obj);
        }
        String string = WXUtils.getString(obj, null);
        if (string == null) {
            return true;
        }
        setDisplay(string);
        return true;
    }
}
