package com.taobao.weex.ui.component;

import android.content.Context;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.view.refresh.circlebar.CircleProgressBar;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXLoadingIndicator.class */
public class WXLoadingIndicator extends WXComponent<CircleProgressBar> {
    private static final String ANIMATING = "animating";

    public WXLoadingIndicator(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
    }

    private void setAnimatingSp(boolean z2) {
        if (z2) {
            getHostView().start();
        } else {
            getHostView().stop();
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        if (getHostView() != null) {
            getHostView().destory();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public CircleProgressBar initComponentHostView(Context context) {
        return new CircleProgressBar(context);
    }

    @WXComponentProp(name = "animating")
    public void setAnimating(boolean z2) {
        if (z2) {
            getHostView().start();
        } else {
            getHostView().stop();
        }
    }

    @WXComponentProp(name = "color")
    public void setColor(String str) {
        if (str != null && !str.equals("")) {
            getHostView().setColorSchemeColors(WXResourceUtils.getColor(str, -65536));
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case 93090825:
                if (str.equals("arrow")) {
                    c2 = 0;
                    break;
                }
                break;
            case 94842723:
                if (str.equals("color")) {
                    c2 = 1;
                    break;
                }
                break;
            case 1118509918:
                if (str.equals("animating")) {
                    c2 = 2;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                getHostView().setShowArrow(WXUtils.getBoolean(obj, true).booleanValue());
                return true;
            case 1:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setColor(string);
                return true;
            case 2:
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null) {
                    return true;
                }
                setAnimating(bool.booleanValue());
                return true;
            default:
                return setProperty(str, obj);
        }
    }
}
