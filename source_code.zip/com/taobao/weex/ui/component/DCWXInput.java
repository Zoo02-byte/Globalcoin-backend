package com.taobao.weex.ui.component;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.alibaba.fastjson.JSONObject;
import com.facebook.common.callercontext.ContextChain;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.dom.CSSConstants;
import com.taobao.weex.dom.WXAttr;
import com.taobao.weex.dom.WXStyle;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.action.GraphicSize;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.view.WXEditText;
import com.taobao.weex.utils.FontDO;
import com.taobao.weex.utils.TypefaceUtil;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.core.ui.DCKeyboardManager;
import io.dcloud.common.core.ui.keyboard.DCEditText;
import io.dcloud.common.util.PdrUtil;
import io.dcloud.feature.uniapp.annotation.UniJSMethod;
import io.dcloud.feature.uniapp.common.UniConstants;
import io.dcloud.feature.uniapp.utils.UniUtils;
import io.dcloud.feature.uniapp.utils.UniViewUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXInput.class */
public class DCWXInput extends WXComponent<WXEditText> {
    private static final int MAX_TEXT_FORMAT_REPEAT = 3;
    private List<TextView.OnEditorActionListener> mEditorActionListeners;
    private String mFontFamily;
    private WXSDKInstance.FrameViewEventListener mFrameViewEventListener;
    private TextWatcher mTextChangedEventDispatcher;
    private List<TextWatcher> mTextChangedListeners;
    private BroadcastReceiver mTypefaceObserver;
    private String placeholderTextAlign;
    private String mBeforeText = "";
    protected String mType = "text";
    private boolean isPassword = false;
    private int mEditorAction = 6;
    private String mReturnKeyType = null;
    private boolean mListeningConfirm = false;
    private boolean mIgnoreNextOnInputEvent = false;
    private TextFormatter mFormatter = null;
    private int mFormatRepeatCount = 0;
    private TextPaint mPaint = new TextPaint();
    private int mLineHeight = -1;
    final String ADJUST_POSITION = "adjustPosition";
    final String PASSWORD = Constants.Value.PASSWORD;
    float keyboardHeight = 0.0f;
    boolean isConfirmHold = false;
    public boolean isNeedConfirm = true;
    private int cursor = -1;
    private int selectionStart = Integer.MAX_VALUE;
    private int selectionEnd = Integer.MAX_VALUE;
    private String textAlign = "left";
    private JSONObject placeholderStyle = new JSONObject();
    private float measureHeight = -1.0f;
    private float measureWidht = -1.0f;
    private WXComponent.OnFocusChangeListener mOnFocusChangeListener = new WXComponent.OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.DCWXInput.6
        int count = 0;
        final DCWXInput this$0;

        {
            this.this$0 = r4;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void fireEventForFocus(TextView textView) {
            this.this$0.getHostView().postDelayed(new Runnable(this, textView) { // from class: com.taobao.weex.ui.component.DCWXInput.6.1
                final AnonymousClass6 this$1;
                final TextView val$text;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$1 = r4;
                    this.val$text = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (this.this$1.this$0.keyboardHeight == 0.0f) {
                        this.this$1.count++;
                        if (this.this$1.count > 3) {
                            HashMap hashMap = new HashMap(1);
                            HashMap hashMap2 = new HashMap(1);
                            hashMap2.put("value", this.val$text.getText().toString());
                            hashMap2.put("height", Float.valueOf(this.this$1.this$0.keyboardHeight));
                            hashMap.put("detail", hashMap2);
                            this.this$1.this$0.fireEvent(Constants.Event.FOCUS, hashMap);
                            return;
                        }
                        this.this$1.fireEventForFocus(this.val$text);
                        return;
                    }
                    this.this$1.count = 0;
                    HashMap hashMap3 = new HashMap(1);
                    HashMap hashMap4 = new HashMap(1);
                    hashMap4.put("value", this.val$text.getText().toString());
                    hashMap4.put("height", Float.valueOf(this.this$1.this$0.keyboardHeight));
                    hashMap3.put("detail", hashMap4);
                    this.this$1.this$0.fireEvent(Constants.Event.FOCUS, hashMap3);
                }
            }, 200);
        }

        @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
        public void onFocusChange(boolean z2) {
            WXEditText hostView = this.this$0.getHostView();
            if (hostView != null) {
                HashMap hashMap = new HashMap(1);
                HashMap hashMap2 = new HashMap(1);
                hashMap2.put("value", hostView.getText().toString());
                if (!z2) {
                    hashMap.put("detail", hashMap2);
                    this.this$0.fireEvent(Constants.Event.BLUR, hashMap);
                } else if (this.this$0.keyboardHeight == 0.0f) {
                    fireEventForFocus(hostView);
                } else {
                    hashMap2.put("height", Float.valueOf(this.this$0.keyboardHeight));
                    hashMap2.put("value", hostView.getText().toString());
                    hashMap.put("detail", hashMap2);
                    this.this$0.fireEvent(Constants.Event.FOCUS, hashMap);
                }
            }
        }
    };
    private AtomicBoolean isLayoutFinished = new AtomicBoolean(false);
    private final InputMethodManager mInputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXInput$PatternWrapper.class */
    public static class PatternWrapper {
        private boolean global;
        private Pattern matcher;
        private String replace;

        private PatternWrapper() {
            this.global = false;
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXInput$ReturnTypes.class */
    private interface ReturnTypes {
        public static final String DEFAULT = "default";
        public static final String DONE = "done";
        public static final String GO = "go";
        public static final String NEXT = "next";
        public static final String SEARCH = "search";
        public static final String SEND = "send";
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/DCWXInput$TextFormatter.class */
    public static class TextFormatter {
        private PatternWrapper format;
        private PatternWrapper recover;

        private TextFormatter(PatternWrapper patternWrapper, PatternWrapper patternWrapper2) {
            this.format = patternWrapper;
            this.recover = patternWrapper2;
        }

        String format(String str) {
            try {
                PatternWrapper patternWrapper = this.format;
                if (patternWrapper != null) {
                    return patternWrapper.global ? this.format.matcher.matcher(str).replaceAll(this.format.replace) : this.format.matcher.matcher(str).replaceFirst(this.format.replace);
                }
            } catch (Throwable th) {
                WXLogUtils.w("WXInput", "[format] " + th.getMessage());
            }
            return str;
        }

        String recover(String str) {
            try {
                PatternWrapper patternWrapper = this.recover;
                if (patternWrapper != null) {
                    return patternWrapper.global ? this.recover.matcher.matcher(str).replaceAll(this.recover.replace) : this.recover.matcher.matcher(str).replaceFirst(this.recover.replace);
                }
            } catch (Throwable th) {
                WXLogUtils.w("WXInput", "[formatted] " + th.getMessage());
            }
            return str;
        }
    }

    public DCWXInput(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        interceptFocusAndBlurEvent();
        setContentBoxMeasurement(new ContentBoxMeasurement(this) { // from class: com.taobao.weex.ui.component.DCWXInput.1
            final DCWXInput this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutAfter(float f2, float f3) {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutBefore() {
                this.this$0.updateStyleAndAttrs();
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void measureInternal(float f2, float f3, int i2, int i3) {
                if (this.this$0.getBasicComponentData().getStyles() == null || this.this$0.getBasicComponentData().getStyles().size() == 0) {
                    this.this$0.measureWidht = f2;
                }
                if (CSSConstants.isUndefined(f3)) {
                    this.mMeasureHeight = WXViewUtils.getRealPxByWidth(((float) this.this$0.getInstance().getDefaultFontSize()) * 1.4f, this.this$0.getInstance().getInstanceViewPortWidthWithFloat());
                    this.this$0.measureHeight = this.mMeasureHeight;
                }
            }
        });
    }

    private final void addEditorActionListener(TextView.OnEditorActionListener onEditorActionListener) {
        WXEditText hostView;
        if (onEditorActionListener != null && (hostView = getHostView()) != null) {
            if (this.mEditorActionListeners == null) {
                this.mEditorActionListeners = new ArrayList();
                hostView.setOnEditorActionListener(new TextView.OnEditorActionListener(this) { // from class: com.taobao.weex.ui.component.DCWXInput.13
                    private boolean handled = true;
                    final DCWXInput this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.widget.TextView.OnEditorActionListener
                    public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
                        for (TextView.OnEditorActionListener onEditorActionListener2 : this.this$0.mEditorActionListeners) {
                            if (onEditorActionListener2 != null) {
                                this.handled = onEditorActionListener2.onEditorAction(textView, i2, keyEvent) & this.handled;
                            }
                        }
                        return this.handled;
                    }
                });
            }
            this.mEditorActionListeners.add(onEditorActionListener);
        }
    }

    private void addEditorChangeListener() {
        addEditorActionListener(new TextView.OnEditorActionListener(this) { // from class: com.taobao.weex.ui.component.DCWXInput.3
            final DCWXInput this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.widget.TextView.OnEditorActionListener
            public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
                if (!this.this$0.mListeningConfirm || i2 != this.this$0.mEditorAction) {
                    return this.this$0.isConfirmHold;
                }
                HashMap hashMap = new HashMap(1);
                HashMap hashMap2 = new HashMap(1);
                hashMap2.put("value", textView.getText().toString());
                hashMap.put("detail", hashMap2);
                this.this$0.fireEvent("confirm", hashMap);
                if (this.this$0.isConfirmHold) {
                    return true;
                }
                this.this$0.blur();
                return true;
            }
        });
    }

    private void addKeyboardListener(WXEditText wXEditText) {
        if (wXEditText != null && (wXEditText.getContext() instanceof Activity)) {
            getHostView().setkeyBoardHeightChangeListener(new DCEditText.OnKeyboardHeightChangeListener(this, wXEditText) { // from class: com.taobao.weex.ui.component.DCWXInput.14
                final DCWXInput this$0;
                final WXEditText val$host;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$0 = r4;
                    this.val$host = r5;
                }

                @Override // io.dcloud.common.core.ui.keyboard.DCEditText.OnKeyboardHeightChangeListener
                public void onChange(boolean z2, int i2) {
                    if (this.this$0.getInstance() != null && !this.this$0.getInstance().isDestroy() && this.val$host != null) {
                        DCWXInput dCWXInput = this.this$0;
                        dCWXInput.keyboardHeight = (float) ((int) WXViewUtils.getWebPxByWidth((float) i2, dCWXInput.getInstance().getInstanceViewPortWidthWithFloat()));
                        HashMap hashMap = new HashMap(2);
                        hashMap.put("height", Float.valueOf(this.this$0.keyboardHeight));
                        hashMap.put("duration", 0);
                        HashMap hashMap2 = new HashMap(1);
                        hashMap2.put("detail", hashMap);
                        this.this$0.fireEvent("keyboardheightchange", hashMap2);
                        if (this.val$host.isFocused()) {
                            String str = this.this$0.isPassword ? Constants.Value.PASSWORD : this.this$0.mType;
                            if (!z2 && !this.this$0.isConfirmHold && !str.equalsIgnoreCase(Constants.Value.PASSWORD) && !DCKeyboardManager.getInstance().getFrontInputType().equals(Constants.Value.PASSWORD)) {
                                this.this$0.blur();
                            }
                            if (z2) {
                                DCKeyboardManager.getInstance().setFrontInputType(str);
                            }
                        }
                        if (z2) {
                            DCWXInput dCWXInput2 = this.this$0;
                            dCWXInput2.keyboardHeight = dCWXInput2.keyboardHeight;
                        }
                    }
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void decideSoftKeyboard() {
        WXEditText hostView = getHostView();
        if (hostView != null) {
            Context context = getContext();
            if (context instanceof Activity) {
                hostView.postDelayed(WXThread.secure(new Runnable(this, context) { // from class: com.taobao.weex.ui.component.DCWXInput.12
                    final DCWXInput this$0;
                    final Context val$context;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.this$0 = r4;
                        this.val$context = r5;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        View currentFocus = ((Activity) this.val$context).getCurrentFocus();
                        if (currentFocus != null && !(currentFocus instanceof EditText) && !currentFocus.isFocused()) {
                            this.this$0.mInputMethodManager.hideSoftInputFromWindow(this.this$0.getHostView().getWindowToken(), 0);
                        }
                    }
                }), 16);
            }
        }
    }

    private int getInputType(String str) {
        str.hashCode();
        int i2 = 4;
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1034364087:
                if (str.equals("number")) {
                    c2 = 0;
                    break;
                }
                break;
            case 114715:
                if (str.equals(Constants.Value.TEL)) {
                    c2 = 1;
                    break;
                }
                break;
            case 116079:
                if (str.equals("url")) {
                    c2 = 2;
                    break;
                }
                break;
            case 3076014:
                if (str.equals("date")) {
                    c2 = 3;
                    break;
                }
                break;
            case 3556653:
                if (str.equals("text")) {
                    c2 = 4;
                    break;
                }
                break;
            case 3560141:
                if (str.equals(Constants.Value.TIME)) {
                    c2 = 5;
                    break;
                }
                break;
            case 95582509:
                if (str.equals("digit")) {
                    c2 = 6;
                    break;
                }
                break;
            case 96619420:
                if (str.equals("email")) {
                    c2 = 7;
                    break;
                }
                break;
            case 1216985755:
                if (str.equals(Constants.Value.PASSWORD)) {
                    c2 = '\b';
                    break;
                }
                break;
            case 1793702779:
                if (str.equals(Constants.Value.DATETIME)) {
                    c2 = '\t';
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                i2 = 2;
                break;
            case 1:
                i2 = 3;
                break;
            case 2:
                i2 = 17;
                break;
            case 3:
                getHostView().setFocusable(false);
                i2 = 0;
                break;
            case 4:
            default:
                i2 = 1;
                break;
            case 5:
                if (getHostView() != null) {
                    getHostView().setFocusable(false);
                }
                i2 = 0;
                break;
            case 6:
                i2 = 8194;
                break;
            case 7:
                i2 = 33;
                break;
            case '\b':
                if (getHostView() != null) {
                    getHostView().setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                i2 = 129;
                break;
            case '\t':
                break;
        }
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getTextAlign(String str) {
        boolean isLayoutRTL = isLayoutRTL();
        int i2 = GravityCompat.END;
        int i3 = isLayoutRTL ? GravityCompat.END : GravityCompat.START;
        if (TextUtils.isEmpty(str)) {
            return i3;
        }
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1364013995:
                if (str.equals("center")) {
                    c2 = 0;
                    break;
                }
                break;
            case 3317767:
                if (str.equals("left")) {
                    c2 = 1;
                    break;
                }
                break;
            case 108511772:
                if (str.equals("right")) {
                    c2 = 2;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                i2 = 17;
                break;
            case 1:
                i2 = GravityCompat.START;
                break;
            case 2:
                break;
            default:
                i2 = i3;
                break;
        }
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hostViewFocus(EditText editText) {
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
        editText.setCursorVisible(true);
        editText.requestFocus();
        showSoftKeyboard();
    }

    private PatternWrapper parseToPattern(String str, String str2) {
        Pattern pattern;
        if (str == null || str2 == null) {
            return null;
        }
        if (!Pattern.compile("/[\\S]+/[i]?[m]?[g]?").matcher(str).matches()) {
            WXLogUtils.w("WXInput", "Illegal js pattern syntax: " + str);
            return null;
        }
        String substring = str.substring(str.lastIndexOf(Operators.DIV) + 1);
        String substring2 = str.substring(str.indexOf(Operators.DIV) + 1, str.lastIndexOf(Operators.DIV));
        int i2 = substring.contains(ContextChain.TAG_INFRA) ? 2 : 0;
        int i3 = i2;
        if (substring.contains(WXComponent.PROP_FS_MATCH_PARENT)) {
            i3 = i2 | 32;
        }
        boolean contains = substring.contains("g");
        try {
            pattern = Pattern.compile(substring2, i3);
        } catch (PatternSyntaxException e2) {
            WXLogUtils.w("WXInput", "Pattern syntax error: " + substring2);
            pattern = null;
        }
        if (pattern == null) {
            return null;
        }
        PatternWrapper patternWrapper = new PatternWrapper();
        patternWrapper.global = contains;
        patternWrapper.matcher = pattern;
        patternWrapper.replace = str2;
        return patternWrapper;
    }

    private void registerTypefaceObserver(String str) {
        if (WXEnvironment.getApplication() == null) {
            WXLogUtils.w("WXText", "ApplicationContent is null on register typeface observer");
            return;
        }
        this.mFontFamily = str;
        if (this.mTypefaceObserver == null) {
            this.mTypefaceObserver = new BroadcastReceiver(this) { // from class: com.taobao.weex.ui.component.DCWXInput.7
                final DCWXInput this$0;

                {
                    this.this$0 = r4;
                }

                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    FontDO fontDO;
                    String stringExtra = intent.getStringExtra(Constants.Name.FONT_FAMILY);
                    if (this.this$0.mFontFamily.equals(stringExtra) && (fontDO = TypefaceUtil.getFontDO(stringExtra)) != null && fontDO.getTypeface() != null && this.this$0.getHostView() != null) {
                        this.this$0.getHostView().setTypeface(fontDO.getTypeface());
                    }
                }
            };
            LocalBroadcastManager.getInstance(WXEnvironment.getApplication()).registerReceiver(this.mTypefaceObserver, new IntentFilter(TypefaceUtil.ACTION_TYPE_FACE_AVAILABLE));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setSelectionRange(int i2, int i3) {
        WXEditText hostView;
        if (i3 != Integer.MAX_VALUE && i2 != Integer.MAX_VALUE && (hostView = getHostView()) != null) {
            int length = getHostView().length();
            if (i2 <= i3) {
                int i4 = 0;
                int i5 = i2;
                if (i2 < 0) {
                    i5 = 0;
                }
                i4 = i3;
                if (i3 > length) {
                    i4 = length;
                }
                if (i4 < 0) {
                }
                hostView.setSelection(i5, i4);
            }
        }
    }

    private void showSoftKeyboard() {
        if (getHostView() != null) {
            getHostView().postDelayed(WXThread.secure(new Runnable(this) { // from class: com.taobao.weex.ui.component.DCWXInput.10
                final DCWXInput this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mInputMethodManager.showSoftInput(this.this$0.getHostView(), 1);
                }
            }), 100);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateStyleAndAttrs() {
        if (getStyles().size() > 0) {
            int fontSize = getStyles().containsKey(Constants.Name.FONT_SIZE) ? WXStyle.getFontSize(getStyles(), getInstance().getDefaultFontSize(), (float) getViewPortWidth()) : -1;
            String fontFamily = getStyles().containsKey(Constants.Name.FONT_FAMILY) ? WXStyle.getFontFamily(getStyles()) : null;
            int fontStyle = getStyles().containsKey(Constants.Name.FONT_STYLE) ? WXStyle.getFontStyle(getStyles()) : -1;
            int fontWeight = getStyles().containsKey(Constants.Name.FONT_WEIGHT) ? WXStyle.getFontWeight(getStyles()) : -1;
            int lineHeight = WXStyle.getLineHeight(getStyles(), (float) getViewPortWidth());
            if (lineHeight != -1) {
                this.mLineHeight = lineHeight;
            }
            if (fontSize != -1) {
                this.mPaint.setTextSize((float) fontSize);
            }
            if (fontFamily != null) {
                TypefaceUtil.applyFontStyle(this.mPaint, fontStyle, fontWeight, fontFamily);
            }
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        if (getHostView() != null && !TextUtils.isEmpty(str)) {
            if (str.equals("input")) {
                addTextChangedListener(new TextWatcher(this) { // from class: com.taobao.weex.ui.component.DCWXInput.5
                    final DCWXInput this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.text.TextWatcher
                    public void afterTextChanged(Editable editable) {
                    }

                    @Override // android.text.TextWatcher
                    public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                    }

                    @Override // android.text.TextWatcher
                    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        if (this.this$0.mIgnoreNextOnInputEvent) {
                            this.this$0.mIgnoreNextOnInputEvent = false;
                            this.this$0.mBeforeText = charSequence.toString();
                            return;
                        }
                        HashMap hashMap = new HashMap(1);
                        HashMap hashMap2 = new HashMap(3);
                        hashMap2.put("value", charSequence.toString());
                        hashMap2.put("cursor", Integer.valueOf(this.this$0.getHostView().getSelectionEnd()));
                        try {
                            if (i3 == 0 && i4 != 0) {
                                String obj = charSequence.subSequence(i2, i4 + i2).toString();
                                hashMap2.put("keyCode", Integer.valueOf(Character.codePointAt(obj, obj.length() - 1)));
                            } else if (i3 != 0 && i4 == 0) {
                                String obj2 = this.this$0.mBeforeText.subSequence(i2, i3 + i2).toString();
                                hashMap2.put("keyCode", Integer.valueOf(Character.codePointAt(obj2, obj2.length() - 1)));
                            }
                        } catch (Exception e2) {
                            hashMap2.put("keyCode", WXInstanceApm.VALUE_ERROR_CODE_DEFAULT);
                        }
                        this.this$0.mBeforeText = charSequence.toString();
                        hashMap.put("detail", hashMap2);
                        this.this$0.fireEvent("input", hashMap);
                    }
                });
            }
            if ("confirm".equals(str)) {
                this.mListeningConfirm = true;
            }
            if (Constants.Event.FOCUS.equals(str) || Constants.Event.BLUR.equals(str)) {
                setFocusAndBlur();
            }
            addEvent(str);
        }
    }

    void addTextChangedListener(TextWatcher textWatcher) {
        if (this.mTextChangedListeners == null) {
            this.mTextChangedListeners = new ArrayList();
        }
        this.mTextChangedListeners.add(textWatcher);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void appleStyleAfterCreated(WXEditText wXEditText) {
        int textAlign = getTextAlign((String) getStyles().get(Constants.Name.TEXT_ALIGN));
        int i2 = textAlign;
        if (textAlign <= 0) {
            i2 = GravityCompat.START;
        }
        wXEditText.setGravity(i2 | getVerticalGravity());
        int color = WXResourceUtils.getColor("#999999");
        if (color != Integer.MIN_VALUE) {
            wXEditText.setHintTextColor(color);
        }
        AnonymousClass4 r02 = new TextWatcher(this, wXEditText) { // from class: com.taobao.weex.ui.component.DCWXInput.4
            final DCWXInput this$0;
            final WXEditText val$editText;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$editText = r5;
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.afterTextChanged(editable);
                    }
                }
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i3, int i4, int i5) {
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.beforeTextChanged(charSequence, i3, i4, i5);
                    }
                }
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i3, int i4, int i5) {
                if (this.this$0.mFormatter != null) {
                    String format = this.this$0.mFormatter.format(this.this$0.mFormatter.recover(charSequence.toString()));
                    if (format.equals(charSequence.toString()) || this.this$0.mFormatRepeatCount >= 3) {
                        this.this$0.mFormatRepeatCount = 0;
                    } else {
                        this.this$0.mFormatRepeatCount++;
                        int length = this.this$0.mFormatter.format(this.this$0.mFormatter.recover(charSequence.subSequence(0, this.val$editText.getSelectionStart()).toString())).length();
                        this.val$editText.setText(format);
                        this.val$editText.setSelection(length);
                        return;
                    }
                }
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.onTextChanged(charSequence, i3, i4, i5);
                    }
                }
            }
        };
        this.mTextChangedEventDispatcher = r02;
        wXEditText.addTextChangedListener(r02);
        wXEditText.setTextSize(0, (float) WXStyle.getFontSize(getStyles(), getInstance().getDefaultFontSize(), getInstance().getInstanceViewPortWidthWithFloat()));
        wXEditText.setSingleLine(true);
    }

    @JSMethod
    public void blur() {
        WXEditText hostView = getHostView();
        if (hostView != null && hostView.hasFocus()) {
            if (getParent() != null) {
                getParent().interceptFocus();
            }
            hostView.clearFocus();
            hideSoftKeyboard();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public Object convertEmptyProperty(String str, Object obj) {
        str.hashCode();
        return !str.equals("color") ? !str.equals(Constants.Name.FONT_SIZE) ? convertEmptyProperty(str, obj) : Integer.valueOf(getInstance().getDefaultFontSize()) : "black";
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        List<TextView.OnEditorActionListener> list = this.mEditorActionListeners;
        if (list != null) {
            list.clear();
        }
        List<TextWatcher> list2 = this.mTextChangedListeners;
        if (list2 != null) {
            list2.clear();
        }
        if (this.mTextChangedEventDispatcher != null) {
            this.mTextChangedEventDispatcher = null;
        }
        if (getHostView() != null) {
            getHostView().destroy();
        }
    }

    @JSMethod
    public void focus() {
        WXEditText hostView = getHostView();
        if (hostView != null && !hostView.hasFocus()) {
            if (getParent() != null) {
                getParent().ignoreFocus();
            }
            hostView.requestFocus();
            hostView.setFocusable(true);
            hostView.setFocusableInTouchMode(true);
            showSoftKeyboard();
        }
    }

    @UniJSMethod
    public void getCursor(JSCallback jSCallback) {
        HashMap hashMap = new HashMap(1);
        if (getHostView() == null || !getHostView().isFocused()) {
            hashMap.put("cursor", 0);
        } else {
            hashMap.put("cursor", Integer.valueOf(getHostView().getSelectionEnd()));
        }
        jSCallback.invoke(hashMap);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public float getMeasureHeight() {
        float f2 = 50.0f;
        if (getMeasuredLineHeight() >= 50.0f) {
            f2 = getMeasureHeight();
        }
        return WXViewUtils.getRealPxByWidth(f2, getInstance().getInstanceViewPortWidthWithFloat());
    }

    final float getMeasuredLineHeight() {
        int i2 = this.mLineHeight;
        return (i2 == -1 || i2 <= 0) ? this.mPaint.getFontMetrics(null) : (float) i2;
    }

    @UniJSMethod
    public void getSelectionRange(String str) {
        HashMap hashMap = new HashMap(2);
        WXEditText hostView = getHostView();
        if (hostView != null) {
            int selectionStart = hostView.getSelectionStart();
            int selectionEnd = hostView.getSelectionEnd();
            if (!hostView.hasFocus()) {
                selectionStart = 0;
                selectionEnd = 0;
            }
            hashMap.put(Constants.Name.SELECTION_START, Integer.valueOf(selectionStart));
            hashMap.put(Constants.Name.SELECTION_END, Integer.valueOf(selectionEnd));
        }
        WXBridgeManager.getInstance().callback(getInstanceId(), str, hashMap, false);
    }

    public String getValue() {
        return getHostView().getText().toString();
    }

    protected int getVerticalGravity() {
        return 16;
    }

    void hideSoftKeyboard() {
        if (getHostView() != null) {
            getHostView().postDelayed(WXThread.secure(new Runnable(this) { // from class: com.taobao.weex.ui.component.DCWXInput.11
                final DCWXInput this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mInputMethodManager.hideSoftInputFromWindow(this.this$0.getHostView().getWindowToken(), 0);
                }
            }), 16);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.taobao.weex.ui.component.WXComponent
    public WXEditText initComponentHostView(Context context) {
        WXEditText wXEditText = new WXEditText(context, getInstanceId());
        appleStyleAfterCreated(wXEditText);
        wXEditText.setImeOptions(6);
        return wXEditText;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected boolean isConsumeTouch() {
        return !isDisabled();
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected void layoutDirectionDidChanged(boolean z2) {
        int textAlign = getTextAlign((String) getStyles().get(Constants.Name.TEXT_ALIGN));
        int i2 = textAlign;
        if (textAlign <= 0) {
            i2 = GravityCompat.START;
        }
        if (getHostView() != null) {
            getHostView().setGravity(i2 | getVerticalGravity());
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    public void onHostViewInitialized(WXEditText wXEditText) {
        onHostViewInitialized((DCWXInput) wXEditText);
        if (this.measureWidht > 0.0f) {
            WXBridgeManager.getInstance().setStyleWidth(getInstanceId(), getRef(), this.measureWidht);
        }
        if (this.measureHeight > 0.0f) {
            WXBridgeManager.getInstance().setStyleHeight(getInstanceId(), getRef(), this.measureHeight);
        }
        addFocusChangeListener(new WXComponent.OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.DCWXInput.2
            final DCWXInput this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
            public void onFocusChange(boolean z2) {
                if (!z2) {
                    this.this$0.decideSoftKeyboard();
                }
                this.this$0.setPseudoClassStatus(Constants.PSEUDO.FOCUS, z2);
                if (z2) {
                    DCWXInput dCWXInput = this.this$0;
                    dCWXInput.setTextAlign(dCWXInput.textAlign);
                } else if (this.this$0.getHostView() != null && PdrUtil.isEmpty(this.this$0.getHostView().getText().toString())) {
                    DCWXInput dCWXInput2 = this.this$0;
                    int textAlign = dCWXInput2.getTextAlign(dCWXInput2.placeholderTextAlign == null ? this.this$0.textAlign : this.this$0.placeholderTextAlign);
                    if (textAlign > 0) {
                        this.this$0.getHostView().setGravity(textAlign | this.this$0.getVerticalGravity());
                    }
                }
            }
        });
        addKeyboardListener(wXEditText);
        if (this.isNeedConfirm) {
            addEditorChangeListener();
        }
    }

    @WXComponentProp(name = "adjustPosition")
    public void setAdjustPosition(Object obj) {
        if (getHostView() != null) {
            getHostView().setInputSoftMode(WXUtils.getBoolean(obj, true).booleanValue() ? DCKeyboardManager.SOFT_INPUT_MODE_ADJUST_PAN : DCKeyboardManager.SOFT_INPUT_MODE_ADJUST_NOTHING);
        }
    }

    @WXComponentProp(name = Constants.Name.AUTOFOCUS)
    public void setAutofocus(boolean z2) {
        if (getHostView() != null) {
            WXEditText hostView = getHostView();
            if (this.isLayoutFinished.get()) {
                if (z2) {
                    hostViewFocus(hostView);
                } else {
                    hideSoftKeyboard();
                }
                hostView.clearFocus();
            } else if (getInstance().isFrameViewShow()) {
                getHostView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(this, z2, hostView) { // from class: com.taobao.weex.ui.component.DCWXInput.8
                    final DCWXInput this$0;
                    final boolean val$autofocus;
                    final EditText val$inputView;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.this$0 = r4;
                        this.val$autofocus = r5;
                        this.val$inputView = r6;
                    }

                    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                    public void onGlobalLayout() {
                        if (this.this$0.getInstance() != null) {
                            if (this.val$autofocus) {
                                this.this$0.isLayoutFinished.set(true);
                                this.this$0.hostViewFocus(this.val$inputView);
                                DCWXInput dCWXInput = this.this$0;
                                dCWXInput.setSelectionRange(dCWXInput.selectionStart, this.this$0.selectionEnd);
                            } else {
                                this.val$inputView.clearFocus();
                            }
                            this.this$0.getHostView().getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        }
                    }
                });
            } else {
                if (this.mFrameViewEventListener != null) {
                    getInstance().removeFrameViewEventListener(this.mFrameViewEventListener);
                }
                this.mFrameViewEventListener = new WXSDKInstance.FrameViewEventListener(this, z2, hostView) { // from class: com.taobao.weex.ui.component.DCWXInput.9
                    final DCWXInput this$0;
                    final boolean val$autofocus;
                    final EditText val$inputView;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.this$0 = r4;
                        this.val$autofocus = r5;
                        this.val$inputView = r6;
                    }

                    @Override // com.taobao.weex.WXSDKInstance.FrameViewEventListener
                    public void onShowAnimationEnd() {
                        if (this.this$0.getInstance() != null) {
                            if (this.val$autofocus) {
                                this.this$0.isLayoutFinished.set(true);
                                this.this$0.hostViewFocus(this.val$inputView);
                                DCWXInput dCWXInput = this.this$0;
                                dCWXInput.setSelectionRange(dCWXInput.selectionStart, this.this$0.selectionEnd);
                            } else {
                                this.val$inputView.clearFocus();
                            }
                            this.this$0.getInstance().removeFrameViewEventListener(this);
                            this.this$0.mFrameViewEventListener = null;
                        }
                    }
                };
                getInstance().addFrameViewEventListener(this.mFrameViewEventListener);
            }
        }
    }

    @WXComponentProp(name = "color")
    public void setColor(String str) {
        int color;
        if (getHostView() != null && !TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setTextColor(color);
        }
    }

    @WXComponentProp(name = UniConstants.Name.CURSOR_SPACING)
    public void setCursorSpacing(String str) {
        if (getHostView() != null) {
            getHostView().setCursorSpacing(UniViewUtils.getRealPxByWidth(UniUtils.getFloat(str), getInstance().getInstanceViewPortWidthWithFloat()));
        }
    }

    protected void setFocusAndBlur() {
        if (!ismHasFocusChangeListener(this.mOnFocusChangeListener)) {
            addFocusChangeListener(this.mOnFocusChangeListener);
        }
    }

    @WXComponentProp(name = Constants.Name.FONT_SIZE)
    public void setFontSize(String str) {
        if (getHostView() != null && str != null) {
            HashMap hashMap = new HashMap(1);
            hashMap.put(Constants.Name.FONT_SIZE, str);
            getHostView().setTextSize(0, (float) WXStyle.getFontSize(hashMap, getInstance().getDefaultFontSize(), getInstance().getInstanceViewPortWidthWithFloat()));
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't rename method to resolve collision */
    public void setHostLayoutParams(WXEditText wXEditText, int i2, int i3, int i4, int i5, int i6, int i7) {
        setHostLayoutParams((DCWXInput) wXEditText, i2, i3, i4, i5, i6, i7);
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsBasicComponent
    protected void setLayoutSize(GraphicSize graphicSize) {
        setLayoutSize(graphicSize);
    }

    @WXComponentProp(name = Constants.Name.LINES)
    public void setLines(int i2) {
        if (getHostView() != null) {
            getHostView().setLines(i2);
        }
    }

    @WXComponentProp(name = Constants.Name.MAX_LENGTH)
    public void setMaxLength(int i2) {
        if (getHostView() != null) {
            int i3 = i2;
            if (i2 == -1) {
                i3 = Integer.MAX_VALUE;
            }
            getHostView().setFilters(new InputFilter[]{new InputFilter.LengthFilter(i3)});
        }
    }

    @WXComponentProp(name = Constants.Name.MAXLENGTH)
    @Deprecated
    public void setMaxlength(int i2) {
        setMaxLength(i2);
    }

    public void setPlaceholder(String str) {
        if (str != null && getHostView() != null) {
            getHostView().setHint(str);
            setPlaceholderStyle(this.placeholderStyle);
        }
    }

    @WXComponentProp(name = "placeholderClass")
    public void setPlaceholderClass(JSONObject jSONObject) {
        setPlaceholderStyle(jSONObject);
    }

    @WXComponentProp(name = Constants.Name.PLACEHOLDER_COLOR)
    public void setPlaceholderColor(String str) {
        int color;
        if (getHostView() != null && !TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setHintTextColor(color);
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @WXComponentProp(name = "placeholderStyle")
    public void setPlaceholderStyle(JSONObject jSONObject) {
        char c2;
        String str;
        char c3;
        JSONObject jSONObject2 = this.placeholderStyle;
        if (!(jSONObject2 == null || jSONObject2.isEmpty())) {
            CharSequence hint = getHostView().getHint();
            CharSequence charSequence = hint;
            if (hint == null) {
                charSequence = hint;
                if (getAttrs().containsKey(Constants.Name.PLACEHOLDER)) {
                    charSequence = WXUtils.getString(getAttrs().get(Constants.Name.PLACEHOLDER), "");
                }
            }
            SpannableString spannableString = new SpannableString(charSequence);
            AbsoluteSizeSpan absoluteSizeSpan = new AbsoluteSizeSpan((int) getHostView().getTextSize());
            ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(getHostView().getCurrentHintTextColor());
            BackgroundColorSpan backgroundColorSpan = null;
            StyleSpan styleSpan = null;
            for (Map.Entry<String, Object> entry : this.placeholderStyle.entrySet()) {
                String key = entry.getKey();
                key.hashCode();
                switch (key.hashCode()) {
                    case -1586082113:
                        if (key.equals("font-size")) {
                            c2 = 0;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case -1065511464:
                        if (key.equals(Constants.Name.TEXT_ALIGN)) {
                            c2 = 1;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case -734428249:
                        if (key.equals(Constants.Name.FONT_WEIGHT)) {
                            c2 = 2;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 94842723:
                        if (key.equals("color")) {
                            c2 = 3;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 365601008:
                        if (key.equals(Constants.Name.FONT_SIZE)) {
                            c2 = 4;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 598800822:
                        if (key.equals("font-weight")) {
                            c2 = 5;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 605322756:
                        if (key.equals("background-color")) {
                            c2 = 6;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 746232421:
                        if (key.equals("text-align")) {
                            c2 = 7;
                            break;
                        }
                        c2 = 65535;
                        break;
                    case 1287124693:
                        if (key.equals("backgroundColor")) {
                            c2 = '\b';
                            break;
                        }
                        c2 = 65535;
                        break;
                    default:
                        c2 = 65535;
                        break;
                }
                switch (c2) {
                    case 0:
                    case 4:
                        String valueOf = String.valueOf(entry.getValue());
                        if (valueOf.endsWith("px")) {
                            str = valueOf.replaceAll("px", "");
                        } else {
                            str = valueOf;
                            if (valueOf.endsWith("wx")) {
                                str = valueOf.replaceAll("wx", "");
                            }
                        }
                        HashMap hashMap = new HashMap(1);
                        hashMap.put(Constants.Name.FONT_SIZE, str);
                        absoluteSizeSpan = new AbsoluteSizeSpan(WXUtils.getInteger(Integer.valueOf(WXStyle.getFontSize(hashMap, getInstance().getDefaultFontSize(), getInstance().getInstanceViewPortWidthWithFloat())), Integer.valueOf(getInstance().getDefaultFontSize())).intValue());
                        break;
                    case 1:
                    case 7:
                        this.placeholderTextAlign = String.valueOf(entry.getValue());
                        int textAlign = getTextAlign(String.valueOf(entry.getValue()));
                        if (textAlign > 0) {
                            getHostView().setGravity(textAlign | getVerticalGravity());
                            break;
                        } else {
                            break;
                        }
                    case 2:
                    case 5:
                        String valueOf2 = String.valueOf(entry.getValue());
                        valueOf2.hashCode();
                        switch (valueOf2.hashCode()) {
                            case 53430:
                                if (!valueOf2.equals("600")) {
                                    c3 = 65535;
                                    break;
                                } else {
                                    c3 = 0;
                                    break;
                                }
                            case 54391:
                                if (!valueOf2.equals("700")) {
                                    c3 = 65535;
                                    break;
                                } else {
                                    c3 = 1;
                                    break;
                                }
                            case 55352:
                                if (!valueOf2.equals("800")) {
                                    c3 = 65535;
                                    break;
                                } else {
                                    c3 = 2;
                                    break;
                                }
                            case 56313:
                                if (!valueOf2.equals("900")) {
                                    c3 = 65535;
                                    break;
                                } else {
                                    c3 = 3;
                                    break;
                                }
                            case 3029637:
                                if (!valueOf2.equals(Constants.Value.BOLD)) {
                                    c3 = 65535;
                                    break;
                                } else {
                                    c3 = 4;
                                    break;
                                }
                            default:
                                c3 = 65535;
                                break;
                        }
                        switch (c3) {
                            case 0:
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                                styleSpan = new StyleSpan(1);
                                continue;
                            default:
                                styleSpan = new StyleSpan(0);
                                continue;
                        }
                    case 3:
                        int color = WXResourceUtils.getColor(String.valueOf(entry.getValue()));
                        if (color != Integer.MIN_VALUE) {
                            foregroundColorSpan = new ForegroundColorSpan(color);
                            break;
                        } else {
                            break;
                        }
                    case 6:
                    case '\b':
                        int color2 = WXResourceUtils.getColor(String.valueOf(entry.getValue()));
                        if (color2 != Integer.MIN_VALUE) {
                            backgroundColorSpan = new BackgroundColorSpan(color2);
                            break;
                        } else {
                            break;
                        }
                }
            }
            spannableString.setSpan(absoluteSizeSpan, 0, spannableString.length(), 33);
            if (backgroundColorSpan != null) {
                spannableString.setSpan(backgroundColorSpan, 0, spannableString.length(), 33);
            }
            if (styleSpan != null) {
                spannableString.setSpan(styleSpan, 0, spannableString.length(), 33);
            }
            spannableString.setSpan(foregroundColorSpan, 0, spannableString.length(), 33);
            getHostView().setHint(spannableString);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x0266, code lost:
        if (r5.equals(com.taobao.weex.common.Constants.Name.SELECTION_START) == false) goto L_0x00d0;
     */
    @Override // com.taobao.weex.ui.component.WXComponent
    /* Code decompiled incorrectly, please refer to instructions dump */
    public boolean setProperty(java.lang.String r5, java.lang.Object r6) {
        /*
        // Method dump skipped, instructions count: 1226
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.component.DCWXInput.setProperty(java.lang.String, java.lang.Object):boolean");
    }

    @WXComponentProp(name = Constants.Name.RETURN_KEY_TYPE)
    public void setReturnKeyType(String str) {
        if (getHostView() != null && !str.equals(this.mReturnKeyType)) {
            this.mReturnKeyType = str;
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -906336856:
                    if (str.equals("search")) {
                        c2 = 0;
                        break;
                    }
                    break;
                case 3304:
                    if (str.equals("go")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 3089282:
                    if (str.equals("done")) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 3377907:
                    if (str.equals("next")) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 3526536:
                    if (str.equals("send")) {
                        c2 = 4;
                        break;
                    }
                    break;
                case 1544803905:
                    if (str.equals("default")) {
                        c2 = 5;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    this.mEditorAction = 3;
                    break;
                case 1:
                    this.mEditorAction = 2;
                    break;
                case 2:
                    this.mEditorAction = 6;
                    break;
                case 3:
                    this.mEditorAction = 5;
                    break;
                case 4:
                    this.mEditorAction = 4;
                    break;
                case 5:
                    this.mEditorAction = 0;
                    break;
            }
            blur();
            getHostView().setImeOptions(this.mEditorAction);
        }
    }

    @WXComponentProp(name = Constants.Name.SINGLELINE)
    public void setSingleLine(boolean z2) {
        if (getHostView() != null) {
            getHostView().setSingleLine(z2);
        }
    }

    @WXComponentProp(name = "value")
    public void setText(String str) {
        WXEditText hostView = getHostView();
        if (hostView != null && !TextUtils.equals(hostView.getText(), str)) {
            this.mIgnoreNextOnInputEvent = true;
            hostView.setText(str);
            int i2 = this.cursor;
            if (i2 <= 0) {
                i2 = str.length();
            }
            if (str == null) {
                i2 = 0;
            }
            hostView.setSelection(i2);
        }
    }

    @WXComponentProp(name = Constants.Name.TEXT_ALIGN)
    public void setTextAlign(String str) {
        this.textAlign = str;
        int textAlign = getTextAlign(str);
        if (textAlign > 0) {
            getHostView().setGravity(textAlign | getVerticalGravity());
        }
    }

    @JSMethod
    public void setTextFormatter(JSONObject jSONObject) {
        try {
            String string = jSONObject.getString("formatRule");
            String string2 = jSONObject.getString("formatReplace");
            String string3 = jSONObject.getString("recoverRule");
            String string4 = jSONObject.getString("recoverReplace");
            PatternWrapper parseToPattern = parseToPattern(string, string2);
            PatternWrapper parseToPattern2 = parseToPattern(string3, string4);
            if (parseToPattern != null && parseToPattern2 != null) {
                this.mFormatter = new TextFormatter(parseToPattern, parseToPattern2);
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public void setType(String str) {
        Log.e("weex", "setType=" + str);
        if (str != null && getHostView() != null && !this.mType.equals(str)) {
            this.mType = str;
            getHostView().setInputType(getInputType(this.mType));
        }
    }

    @JSMethod
    public void setValue(String str) {
        getHostView().setText(str);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void updateProperties(Map<String, Object> map) {
        String str;
        if (map != null && map.size() > 0) {
            setType(map.containsKey("type") ? String.valueOf(map.get("type")) : this.mType);
            String str2 = this.mType;
            if (str2 != null && str2.equals("text") && map.containsKey("confirmType")) {
                if (map.containsKey("confirmType")) {
                    str = String.valueOf(map.get("confirmType"));
                } else {
                    String str3 = this.mReturnKeyType;
                    str = str3;
                    if (str3 == null) {
                        str = "done";
                    }
                }
                setReturnKeyType(str);
            }
            WXAttr attrs = getAttrs();
            String str4 = Constants.Value.PASSWORD;
            if (attrs.containsKey(Constants.Value.PASSWORD)) {
                boolean booleanValue = WXUtils.getBoolean(getAttrs().get(Constants.Value.PASSWORD), false).booleanValue();
                this.isPassword = booleanValue;
                if (!booleanValue) {
                    str4 = this.mType;
                }
                if (str4 != null && getHostView() != null) {
                    getHostView().setInputType(getInputType(str4));
                } else {
                    return;
                }
            }
            if (map.containsKey("cursor")) {
                this.cursor = WXUtils.getInteger(map.get("cursor"), 0).intValue();
            }
            if (map.containsKey(Constants.Name.SELECTION_START)) {
                this.selectionStart = WXUtils.getInteger(map.get(Constants.Name.SELECTION_START), Integer.MAX_VALUE).intValue();
            }
            if (map.containsKey(Constants.Name.SELECTION_END)) {
                this.selectionEnd = WXUtils.getInteger(map.get(Constants.Name.SELECTION_END), Integer.MAX_VALUE).intValue();
            }
            if (map.containsKey(Constants.Name.PLACEHOLDER)) {
                setPlaceholder(WXUtils.getString(map.get(Constants.Name.PLACEHOLDER), ""));
            }
            if (map.containsKey("placeholderClass")) {
                this.placeholderStyle.putAll((JSONObject) JSONObject.parse(WXUtils.getString(map.get("placeholderClass"), "{}")));
            }
            if (map.containsKey("placeholderStyle")) {
                this.placeholderStyle.putAll((JSONObject) JSONObject.parse(WXUtils.getString(map.get("placeholderStyle"), "{}")));
            }
            if (map.containsKey("adjustPosition")) {
                setAdjustPosition(map.get("adjustPosition"));
            }
        }
        updateProperties(map);
    }
}
