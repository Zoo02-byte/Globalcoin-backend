package com.taobao.weex.ui.component;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.Layout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.layout.measurefunc.TextContentBoxMeasurement;
import com.taobao.weex.ui.ComponentCreator;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.flat.FlatComponent;
import com.taobao.weex.ui.flat.widget.TextWidget;
import com.taobao.weex.ui.view.WXTextView;
import com.taobao.weex.utils.FontDO;
import com.taobao.weex.utils.TypefaceUtil;
import com.taobao.weex.utils.WXLogUtils;
import java.lang.reflect.InvocationTargetException;
@Component(lazyload = false)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXText.class */
public class WXText extends WXComponent<WXTextView> implements FlatComponent<TextWidget> {
    private String mFontFamily;
    private TextWidget mTextWidget;
    private BroadcastReceiver mTypefaceObserver;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/WXText$Creator.class */
    public static class Creator implements ComponentCreator {
        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            return new WXText(wXSDKInstance, wXVContainer, basicComponentData);
        }
    }

    public WXText(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, basicComponentData);
        setContentBoxMeasurement(new TextContentBoxMeasurement(this));
    }

    @Deprecated
    public WXText(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, String str, boolean z2, BasicComponentData basicComponentData) {
        this(wXSDKInstance, wXVContainer, basicComponentData);
    }

    public void forceRelayout() {
        WXBridgeManager.getInstance().post(new Runnable(this) { // from class: com.taobao.weex.ui.component.WXText.2
            final WXText this$0;

            {
                this.this$0 = r4;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.contentBoxMeasurement instanceof TextContentBoxMeasurement) {
                    ((TextContentBoxMeasurement) this.this$0.contentBoxMeasurement).forceRelayout();
                }
            }
        });
    }

    private void registerTypefaceObserver(String str) {
        if (WXEnvironment.getApplication() == null) {
            WXLogUtils.w("WXText", "ApplicationContent is null on register typeface observer");
            return;
        }
        this.mFontFamily = str;
        if (this.mTypefaceObserver == null) {
            this.mTypefaceObserver = new BroadcastReceiver(this) { // from class: com.taobao.weex.ui.component.WXText.1
                final WXText this$0;

                {
                    this.this$0 = r4;
                }

                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    FontDO fontDO;
                    String stringExtra = intent.getStringExtra(Constants.Name.FONT_FAMILY);
                    if (this.this$0.mFontFamily.equals(stringExtra) && (fontDO = TypefaceUtil.getFontDO(stringExtra)) != null && fontDO.getTypeface() != null && this.this$0.getHostView() != null) {
                        Layout textLayout = this.this$0.getHostView().getTextLayout();
                        if (textLayout != null) {
                            textLayout.getPaint().setTypeface(fontDO.getTypeface());
                        } else {
                            WXLogUtils.d("WXText", "Layout not created");
                        }
                        WXBridgeManager.getInstance().markDirty(this.this$0.getInstanceId(), this.this$0.getRef(), true);
                        this.this$0.forceRelayout();
                    }
                }
            };
            LocalBroadcastManager.getInstance(WXEnvironment.getApplication()).registerReceiver(this.mTypefaceObserver, new IntentFilter(TypefaceUtil.ACTION_TYPE_FACE_AVAILABLE));
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public Object convertEmptyProperty(String str, Object obj) {
        str.hashCode();
        return !str.equals("color") ? !str.equals(Constants.Name.FONT_SIZE) ? convertEmptyProperty(str, obj) : Integer.valueOf(getInstance().getDefaultFontSize()) : "black";
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void createViewImpl() {
        if (promoteToView(true)) {
            createViewImpl();
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        if (WXEnvironment.getApplication() != null && this.mTypefaceObserver != null) {
            WXLogUtils.d("WXText", "Unregister the typeface observer");
            LocalBroadcastManager.getInstance(WXEnvironment.getApplication()).unregisterReceiver(this.mTypefaceObserver);
            this.mTypefaceObserver = null;
        }
    }

    @Override // com.taobao.weex.ui.flat.FlatComponent
    public TextWidget getOrCreateFlatWidget() {
        if (this.mTextWidget == null) {
            this.mTextWidget = new TextWidget(getInstance().getFlatUIContext());
        }
        return this.mTextWidget;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public WXTextView initComponentHostView(Context context) {
        WXTextView wXTextView = new WXTextView(context);
        wXTextView.holdComponent(this);
        return wXTextView;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean isVirtualComponent() {
        return true ^ promoteToView(true);
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected void layoutDirectionDidChanged(boolean z2) {
        forceRelayout();
    }

    @Override // com.taobao.weex.ui.flat.FlatComponent
    public boolean promoteToView(boolean z2) {
        if (getInstance().getFlatUIContext() != null) {
            return getInstance().getFlatUIContext().promoteToView(this, z2, WXText.class);
        }
        return false;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void refreshData(WXComponent wXComponent) {
        refreshData(wXComponent);
        if (wXComponent instanceof WXText) {
            updateExtra(wXComponent.getExtra());
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected void setAriaLabel(String str) {
        WXTextView hostView = getHostView();
        if (hostView != null) {
            hostView.setAriaLabel(str);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1550943582:
                if (str.equals(Constants.Name.FONT_STYLE)) {
                    c2 = 0;
                    break;
                }
                break;
            case -1224696685:
                if (str.equals(Constants.Name.FONT_FAMILY)) {
                    c2 = 1;
                    break;
                }
                break;
            case -1065511464:
                if (str.equals(Constants.Name.TEXT_ALIGN)) {
                    c2 = 2;
                    break;
                }
                break;
            case -879295043:
                if (str.equals(Constants.Name.TEXT_DECORATION)) {
                    c2 = 3;
                    break;
                }
                break;
            case -734428249:
                if (str.equals(Constants.Name.FONT_WEIGHT)) {
                    c2 = 4;
                    break;
                }
                break;
            case -515807685:
                if (str.equals(Constants.Name.LINE_HEIGHT)) {
                    c2 = 5;
                    break;
                }
                break;
            case 94842723:
                if (str.equals("color")) {
                    c2 = 6;
                    break;
                }
                break;
            case 102977279:
                if (str.equals(Constants.Name.LINES)) {
                    c2 = 7;
                    break;
                }
                break;
            case 111972721:
                if (str.equals("value")) {
                    c2 = '\b';
                    break;
                }
                break;
            case 261414991:
                if (str.equals(Constants.Name.TEXT_OVERFLOW)) {
                    c2 = '\t';
                    break;
                }
                break;
            case 365601008:
                if (str.equals(Constants.Name.FONT_SIZE)) {
                    c2 = '\n';
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case '\b':
            case '\t':
            case '\n':
                return true;
            case 1:
                if (obj == null) {
                    return true;
                }
                registerTypefaceObserver(obj.toString());
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @Override // io.dcloud.feature.uniapp.ui.component.AbsBasicComponent
    public void updateExtra(Object obj) {
        updateExtra(obj);
        if (obj instanceof Layout) {
            Layout layout = (Layout) obj;
            if (!promoteToView(true)) {
                getOrCreateFlatWidget().updateTextDrawable(layout);
            } else if (getHostView() != null && !obj.equals(getHostView().getTextLayout())) {
                getHostView().setTextLayout(layout);
                getHostView().invalidate();
            }
        }
    }
}
