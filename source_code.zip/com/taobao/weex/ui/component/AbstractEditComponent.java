package com.taobao.weex.ui.component;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import com.alibaba.fastjson.JSONObject;
import com.facebook.common.callercontext.ContextChain;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.dom.CSSConstants;
import com.taobao.weex.dom.WXEvent;
import com.taobao.weex.dom.WXStyle;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.layout.MeasureMode;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.helper.SoftKeyboardDetector;
import com.taobao.weex.ui.component.helper.WXTimeInputHelper;
import com.taobao.weex.ui.component.list.template.TemplateDom;
import com.taobao.weex.ui.view.WXEditText;
import com.taobao.weex.utils.TypefaceUtil;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/AbstractEditComponent.class */
public abstract class AbstractEditComponent extends WXComponent<WXEditText> {
    private static final int MAX_TEXT_FORMAT_REPEAT;
    private boolean mAutoFocus;
    private List<TextView.OnEditorActionListener> mEditorActionListeners;
    private TextWatcher mTextChangedEventDispatcher;
    private List<TextWatcher> mTextChangedListeners;
    private SoftKeyboardDetector.Unregister mUnregister;
    private String mBeforeText = "";
    private String mType = "text";
    private String mMax = null;
    private String mMin = null;
    private String mLastValue = "";
    private int mEditorAction = 6;
    private String mReturnKeyType = null;
    private boolean mListeningKeyboard = false;
    private boolean mIgnoreNextOnInputEvent = false;
    private boolean mKeepSelectionIndex = false;
    private TextFormatter mFormatter = null;
    private int mFormatRepeatCount = 0;
    private TextPaint mPaint = new TextPaint();
    private int mLineHeight = -1;
    private WXComponent.OnClickListener mOnClickListener = new WXComponent.OnClickListener(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.3
        final AbstractEditComponent this$0;

        {
            this.this$0 = r4;
        }

        @Override // com.taobao.weex.ui.component.WXComponent.OnClickListener
        public void onHostViewClick() {
            String str = this.this$0.mType;
            str.hashCode();
            if (str.equals("date")) {
                this.this$0.hideSoftKeyboard();
                if (this.this$0.getParent() != null) {
                    this.this$0.getParent().interceptFocus();
                }
                WXTimeInputHelper.pickDate(this.this$0.mMax, this.this$0.mMin, this.this$0);
            } else if (str.equals(Constants.Value.TIME)) {
                this.this$0.hideSoftKeyboard();
                if (this.this$0.getParent() != null) {
                    this.this$0.getParent().interceptFocus();
                }
                WXTimeInputHelper.pickTime(this.this$0);
            }
        }
    };
    private final InputMethodManager mInputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/AbstractEditComponent$PatternWrapper.class */
    public static class PatternWrapper {
        private boolean global;
        private Pattern matcher;
        private String replace;

        private PatternWrapper() {
            this.global = false;
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/AbstractEditComponent$ReturnTypes.class */
    private interface ReturnTypes {
        public static final String DEFAULT;
        public static final String DONE;
        public static final String GO;
        public static final String NEXT;
        public static final String SEARCH;
        public static final String SEND;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/component/AbstractEditComponent$TextFormatter.class */
    public static class TextFormatter {
        private PatternWrapper format;
        private PatternWrapper recover;

        private TextFormatter(PatternWrapper patternWrapper, PatternWrapper patternWrapper2) {
            this.format = patternWrapper;
            this.recover = patternWrapper2;
        }

        public String format(String str) {
            try {
                PatternWrapper patternWrapper = this.format;
                if (patternWrapper != null) {
                    return patternWrapper.global ? this.format.matcher.matcher(str).replaceAll(this.format.replace) : this.format.matcher.matcher(str).replaceFirst(this.format.replace);
                }
            } catch (Throwable th) {
                WXLogUtils.w("WXInput", "[format] " + th.getMessage());
            }
            return str;
        }

        public String recover(String str) {
            try {
                PatternWrapper patternWrapper = this.recover;
                if (patternWrapper != null) {
                    return patternWrapper.global ? this.recover.matcher.matcher(str).replaceAll(this.recover.replace) : this.recover.matcher.matcher(str).replaceFirst(this.recover.replace);
                }
            } catch (Throwable th) {
                WXLogUtils.w("WXInput", "[formatted] " + th.getMessage());
            }
            return str;
        }
    }

    public AbstractEditComponent(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, boolean z2, BasicComponentData basicComponentData) {
        super(wXSDKInstance, wXVContainer, z2, basicComponentData);
        setContentBoxMeasurement(new ContentBoxMeasurement(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.1
            final AbstractEditComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutAfter(float f2, float f3) {
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void layoutBefore() {
                this.this$0.updateStyleAndAttrs();
            }

            @Override // com.taobao.weex.layout.ContentBoxMeasurement
            public void measureInternal(float f2, float f3, int i2, int i3) {
                if (CSSConstants.isUndefined(f2) || i2 == MeasureMode.UNSPECIFIED) {
                    f2 = 0.0f;
                }
                this.mMeasureWidth = f2;
                this.mMeasureHeight = this.this$0.getMeasureHeight();
            }
        });
    }

    private void addKeyboardListener(WXEditText wXEditText) {
        Context context;
        if (wXEditText != null && (context = wXEditText.getContext()) != null && (context instanceof Activity)) {
            this.mUnregister = SoftKeyboardDetector.registerKeyboardEventListener((Activity) context, new SoftKeyboardDetector.OnKeyboardEventListener(this, context) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.13
                final AbstractEditComponent this$0;
                final Context val$context;

                {
                    this.this$0 = r4;
                    this.val$context = r5;
                }

                @Override // com.taobao.weex.ui.component.helper.SoftKeyboardDetector.OnKeyboardEventListener
                public void onKeyboardEvent(boolean z2) {
                    if (this.this$0.mListeningKeyboard) {
                        if (this.this$0.getInstance() != null && !this.this$0.getInstance().isDestroy()) {
                            HashMap hashMap = new HashMap(1);
                            hashMap.put("isShow", Boolean.valueOf(z2));
                            if (z2) {
                                Rect rect = new Rect();
                                ((Activity) this.val$context).getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
                                hashMap.put("keyboardSize", Float.valueOf(WXViewUtils.getWebPxByWidth((float) (WXViewUtils.getScreenHeight(this.val$context) - (rect.bottom - rect.top)), this.this$0.getInstance().getInstanceViewPortWidthWithFloat())));
                            }
                            this.this$0.fireEvent(Constants.Event.KEYBOARD, hashMap);
                        } else {
                            return;
                        }
                    }
                    if (!z2) {
                        this.this$0.blur();
                    }
                }
            });
        }
    }

    private void applyOnClickListener() {
        addClickListener(this.mOnClickListener);
    }

    public void decideSoftKeyboard() {
        Context context;
        WXEditText hostView = getHostView();
        if (hostView != null && (context = getContext()) != null && (context instanceof Activity)) {
            hostView.postDelayed(WXThread.secure(new Runnable(this, context) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.11
                final AbstractEditComponent this$0;
                final Context val$context;

                {
                    this.this$0 = r4;
                    this.val$context = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    View currentFocus = ((Activity) this.val$context).getCurrentFocus();
                    if (currentFocus != null && !(currentFocus instanceof EditText) && !currentFocus.isFocused()) {
                        this.this$0.mInputMethodManager.hideSoftInputFromWindow(this.this$0.getHostView().getWindowToken(), 0);
                    }
                }
            }), 16);
        }
    }

    public void fireEvent(String str, String str2) {
        if (str != null) {
            HashMap hashMap = new HashMap(2);
            hashMap.put("value", str2);
            hashMap.put("timeStamp", Long.valueOf(System.currentTimeMillis()));
            HashMap hashMap2 = new HashMap();
            HashMap hashMap3 = new HashMap();
            hashMap3.put("value", str2);
            hashMap2.put(TemplateDom.KEY_ATTRS, hashMap3);
            WXSDKManager.getInstance().fireEvent(getInstanceId(), getRef(), str, hashMap, hashMap2);
        }
    }

    private int getInputType(String str) {
        str.hashCode();
        int i2 = 4;
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1034364087:
                if (str.equals("number")) {
                    c2 = 0;
                    break;
                }
                break;
            case 114715:
                if (str.equals(Constants.Value.TEL)) {
                    c2 = 1;
                    break;
                }
                break;
            case 116079:
                if (str.equals("url")) {
                    c2 = 2;
                    break;
                }
                break;
            case 3076014:
                if (str.equals("date")) {
                    c2 = 3;
                    break;
                }
                break;
            case 3556653:
                if (str.equals("text")) {
                    c2 = 4;
                    break;
                }
                break;
            case 3560141:
                if (str.equals(Constants.Value.TIME)) {
                    c2 = 5;
                    break;
                }
                break;
            case 96619420:
                if (str.equals("email")) {
                    c2 = 6;
                    break;
                }
                break;
            case 1216985755:
                if (str.equals(Constants.Value.PASSWORD)) {
                    c2 = 7;
                    break;
                }
                break;
            case 1793702779:
                if (str.equals(Constants.Value.DATETIME)) {
                    c2 = '\b';
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                i2 = 8194;
                break;
            case 1:
                i2 = 3;
                break;
            case 2:
                i2 = 17;
                break;
            case 3:
                getHostView().setFocusable(false);
                i2 = 0;
                break;
            case 4:
            default:
                i2 = 1;
                break;
            case 5:
                if (getHostView() != null) {
                    getHostView().setFocusable(false);
                }
                i2 = 0;
                break;
            case 6:
                i2 = 33;
                break;
            case 7:
                if (getHostView() != null) {
                    getHostView().setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                i2 = 129;
                break;
            case '\b':
                break;
        }
        return i2;
    }

    private int getTextAlign(String str) {
        boolean isLayoutRTL = isLayoutRTL();
        int i2 = GravityCompat.END;
        i2 = isLayoutRTL ? GravityCompat.END : GravityCompat.START;
        if (TextUtils.isEmpty(str)) {
            return i2;
        }
        if (str.equals("left")) {
            i2 = GravityCompat.START;
        } else if (str.equals("center")) {
            i2 = 17;
        } else if (str.equals("right")) {
        }
        return i2;
    }

    public void hideSoftKeyboard() {
        if (getHostView() != null) {
            getHostView().postDelayed(WXThread.secure(new Runnable(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.10
                final AbstractEditComponent this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mInputMethodManager.hideSoftInputFromWindow(this.this$0.getHostView().getWindowToken(), 0);
                }
            }), 16);
        }
    }

    private PatternWrapper parseToPattern(String str, String str2) {
        Pattern pattern;
        if (str == null || str2 == null) {
            return null;
        }
        if (!Pattern.compile("/[\\S]+/[i]?[m]?[g]?").matcher(str).matches()) {
            WXLogUtils.w("WXInput", "Illegal js pattern syntax: " + str);
            return null;
        }
        String substring = str.substring(str.lastIndexOf(Operators.DIV) + 1);
        String substring2 = str.substring(str.indexOf(Operators.DIV) + 1, str.lastIndexOf(Operators.DIV));
        int i2 = substring.contains(ContextChain.TAG_INFRA) ? 2 : 0;
        int i3 = i2;
        if (substring.contains(WXComponent.PROP_FS_MATCH_PARENT)) {
            i3 = i2 | 32;
        }
        boolean contains = substring.contains("g");
        try {
            pattern = Pattern.compile(substring2, i3);
        } catch (PatternSyntaxException e2) {
            WXLogUtils.w("WXInput", "Pattern syntax error: " + substring2);
            pattern = null;
        }
        if (pattern == null) {
            return null;
        }
        PatternWrapper patternWrapper = new PatternWrapper();
        patternWrapper.global = contains;
        patternWrapper.matcher = pattern;
        patternWrapper.replace = str2;
        return patternWrapper;
    }

    private boolean showSoftKeyboard() {
        if (getHostView() == null) {
            return false;
        }
        getHostView().postDelayed(WXThread.secure(new Runnable(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.9
            final AbstractEditComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.this$0.mInputMethodManager.showSoftInput(this.this$0.getHostView(), 1);
            }
        }), 100);
        return true;
    }

    protected final void addEditorActionListener(TextView.OnEditorActionListener onEditorActionListener) {
        WXEditText hostView;
        if (onEditorActionListener != null && (hostView = getHostView()) != null) {
            if (this.mEditorActionListeners == null) {
                this.mEditorActionListeners = new ArrayList();
                hostView.setOnEditorActionListener(new TextView.OnEditorActionListener(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.12
                    private boolean handled = true;
                    final AbstractEditComponent this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.widget.TextView.OnEditorActionListener
                    public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
                        for (TextView.OnEditorActionListener onEditorActionListener2 : this.this$0.mEditorActionListeners) {
                            if (onEditorActionListener2 != null) {
                                this.handled = onEditorActionListener2.onEditorAction(textView, i2, keyEvent) & this.handled;
                            }
                        }
                        return this.handled;
                    }
                });
            }
            this.mEditorActionListeners.add(onEditorActionListener);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void addEvent(String str) {
        addEvent(str);
        if (getHostView() != null && !TextUtils.isEmpty(str)) {
            WXEditText hostView = getHostView();
            if (str.equals(Constants.Event.CHANGE)) {
                addFocusChangeListener(new WXComponent.OnFocusChangeListener(this, hostView) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.5
                    final AbstractEditComponent this$0;
                    final TextView val$text;

                    {
                        this.this$0 = r4;
                        this.val$text = r5;
                    }

                    @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
                    public void onFocusChange(boolean z2) {
                        if (z2) {
                            this.this$0.mLastValue = this.val$text.getText().toString();
                            return;
                        }
                        CharSequence text = this.val$text.getText();
                        CharSequence charSequence = text;
                        if (text == null) {
                            charSequence = "";
                        }
                        if (!charSequence.toString().equals(this.this$0.mLastValue)) {
                            this.this$0.fireEvent(Constants.Event.CHANGE, charSequence.toString());
                            this.this$0.mLastValue = this.val$text.getText().toString();
                        }
                    }
                });
                addEditorActionListener(new TextView.OnEditorActionListener(this, hostView) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.6
                    final AbstractEditComponent this$0;
                    final TextView val$text;

                    {
                        this.this$0 = r4;
                        this.val$text = r5;
                    }

                    @Override // android.widget.TextView.OnEditorActionListener
                    public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
                        if (i2 != this.this$0.mEditorAction) {
                            return false;
                        }
                        CharSequence text = this.val$text.getText();
                        CharSequence charSequence = text;
                        if (text == null) {
                            charSequence = "";
                        }
                        if (!charSequence.toString().equals(this.this$0.mLastValue)) {
                            this.this$0.fireEvent(Constants.Event.CHANGE, charSequence.toString());
                            this.this$0.mLastValue = this.val$text.getText().toString();
                        }
                        if (this.this$0.getParent() != null) {
                            this.this$0.getParent().interceptFocus();
                        }
                        this.this$0.hideSoftKeyboard();
                        return true;
                    }
                });
            } else if (str.equals("input")) {
                addTextChangedListener(new TextWatcher(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.7
                    final AbstractEditComponent this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.text.TextWatcher
                    public void afterTextChanged(Editable editable) {
                    }

                    @Override // android.text.TextWatcher
                    public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                    }

                    @Override // android.text.TextWatcher
                    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                        if (this.this$0.mIgnoreNextOnInputEvent) {
                            this.this$0.mIgnoreNextOnInputEvent = false;
                            this.this$0.mBeforeText = charSequence.toString();
                        } else if (!this.this$0.mBeforeText.equals(charSequence.toString())) {
                            this.this$0.mBeforeText = charSequence.toString();
                            this.this$0.fireEvent("input", charSequence.toString());
                        }
                    }
                });
            }
            if (Constants.Event.RETURN.equals(str)) {
                addEditorActionListener(new TextView.OnEditorActionListener(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.8
                    final AbstractEditComponent this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // android.widget.TextView.OnEditorActionListener
                    public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
                        if (i2 != this.this$0.mEditorAction) {
                            return false;
                        }
                        HashMap hashMap = new HashMap(2);
                        hashMap.put(Constants.Name.RETURN_KEY_TYPE, this.this$0.mReturnKeyType);
                        hashMap.put("value", textView.getText().toString());
                        this.this$0.fireEvent(Constants.Event.RETURN, hashMap);
                        return true;
                    }
                });
            }
            if (Constants.Event.KEYBOARD.equals(str)) {
                this.mListeningKeyboard = true;
            }
        }
    }

    public final void addTextChangedListener(TextWatcher textWatcher) {
        if (this.mTextChangedListeners == null) {
            this.mTextChangedListeners = new ArrayList();
        }
        this.mTextChangedListeners.add(textWatcher);
    }

    public void appleStyleAfterCreated(WXEditText wXEditText) {
        int textAlign = getTextAlign((String) getStyles().get(Constants.Name.TEXT_ALIGN));
        int i2 = textAlign;
        if (textAlign <= 0) {
            i2 = GravityCompat.START;
        }
        wXEditText.setGravity(i2 | getVerticalGravity());
        int color = WXResourceUtils.getColor("#999999");
        if (color != Integer.MIN_VALUE) {
            wXEditText.setHintTextColor(color);
        }
        AnonymousClass4 r02 = new TextWatcher(this, wXEditText) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.4
            final AbstractEditComponent this$0;
            final WXEditText val$editText;

            {
                this.this$0 = r4;
                this.val$editText = r5;
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.afterTextChanged(editable);
                    }
                }
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i3, int i4, int i5) {
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.beforeTextChanged(charSequence, i3, i4, i5);
                    }
                }
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i3, int i4, int i5) {
                if (this.this$0.mFormatter != null) {
                    String format = this.this$0.mFormatter.format(this.this$0.mFormatter.recover(charSequence.toString()));
                    if (format.equals(charSequence.toString()) || this.this$0.mFormatRepeatCount >= 3) {
                        this.this$0.mFormatRepeatCount = 0;
                    } else {
                        this.this$0.mFormatRepeatCount++;
                        int length = this.this$0.mFormatter.format(this.this$0.mFormatter.recover(charSequence.subSequence(0, this.val$editText.getSelectionStart()).toString())).length();
                        this.val$editText.setText(format);
                        this.val$editText.setSelection(length);
                        return;
                    }
                }
                if (this.this$0.mTextChangedListeners != null) {
                    for (TextWatcher textWatcher : this.this$0.mTextChangedListeners) {
                        textWatcher.onTextChanged(charSequence, i3, i4, i5);
                    }
                }
            }
        };
        this.mTextChangedEventDispatcher = r02;
        wXEditText.addTextChangedListener(r02);
        wXEditText.setTextSize(0, (float) WXStyle.getFontSize(getStyles(), getInstance().getDefaultFontSize(), getInstance().getInstanceViewPortWidthWithFloat()));
    }

    @JSMethod
    public void blur() {
        WXEditText hostView = getHostView();
        if (hostView != null && hostView.hasFocus()) {
            if (getParent() != null) {
                getParent().interceptFocus();
            }
            hostView.clearFocus();
            hideSoftKeyboard();
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public Object convertEmptyProperty(String str, Object obj) {
        str.hashCode();
        return !str.equals("color") ? !str.equals(Constants.Name.FONT_SIZE) ? convertEmptyProperty(str, obj) : Integer.valueOf(getInstance().getDefaultFontSize()) : "black";
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public void destroy() {
        destroy();
        if (getHostView() != null) {
            getHostView().destroy();
        }
        SoftKeyboardDetector.Unregister unregister = this.mUnregister;
        if (unregister != null) {
            try {
                unregister.execute();
                this.mUnregister = null;
            } catch (Throwable th) {
                WXLogUtils.w("Unregister throw ", th);
            }
        }
    }

    @JSMethod
    public void focus() {
        WXEditText hostView = getHostView();
        if (hostView != null && !hostView.hasFocus()) {
            if (getParent() != null) {
                getParent().ignoreFocus();
            }
            hostView.requestFocus();
            hostView.setFocusable(true);
            hostView.setFocusableInTouchMode(true);
            showSoftKeyboard();
        }
    }

    protected float getMeasureHeight() {
        return getMeasuredLineHeight();
    }

    protected final float getMeasuredLineHeight() {
        int i2 = this.mLineHeight;
        return (i2 == -1 || i2 <= 0) ? this.mPaint.getFontMetrics(null) : (float) i2;
    }

    @JSMethod
    public void getSelectionRange(String str) {
        HashMap hashMap = new HashMap(2);
        WXEditText hostView = getHostView();
        if (hostView != null) {
            int selectionStart = hostView.getSelectionStart();
            int selectionEnd = hostView.getSelectionEnd();
            if (!hostView.hasFocus()) {
                selectionStart = 0;
                selectionEnd = 0;
            }
            hashMap.put(Constants.Name.SELECTION_START, Integer.valueOf(selectionStart));
            hashMap.put(Constants.Name.SELECTION_END, Integer.valueOf(selectionEnd));
        }
        WXBridgeManager.getInstance().callback(getInstanceId(), str, hashMap, false);
    }

    protected int getVerticalGravity() {
        return 16;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public WXEditText initComponentHostView(Context context) {
        WXEditText wXEditText = new WXEditText(context, getInstanceId());
        appleStyleAfterCreated(wXEditText);
        return wXEditText;
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected boolean isConsumeTouch() {
        return !isDisabled();
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    protected void layoutDirectionDidChanged(boolean z2) {
        int textAlign = getTextAlign((String) getStyles().get(Constants.Name.TEXT_ALIGN));
        int i2 = textAlign;
        if (textAlign <= 0) {
            i2 = GravityCompat.START;
        }
        if (getHostView() instanceof WXEditText) {
            getHostView().setGravity(i2 | getVerticalGravity());
        }
    }

    public void onHostViewInitialized(WXEditText wXEditText) {
        onHostViewInitialized((AbstractEditComponent) wXEditText);
        addFocusChangeListener(new WXComponent.OnFocusChangeListener(this) { // from class: com.taobao.weex.ui.component.AbstractEditComponent.2
            final AbstractEditComponent this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.component.WXComponent.OnFocusChangeListener
            public void onFocusChange(boolean z2) {
                if (!z2) {
                    this.this$0.decideSoftKeyboard();
                }
                this.this$0.setPseudoClassStatus(Constants.PSEUDO.FOCUS, z2);
            }
        });
        addKeyboardListener(wXEditText);
    }

    public void performOnChange(String str) {
        if (getEvents() != null) {
            WXEvent events = getEvents();
            String str2 = Constants.Event.CHANGE;
            if (!events.contains(Constants.Event.CHANGE)) {
                str2 = null;
            }
            fireEvent(str2, str);
        }
    }

    @WXComponentProp(name = Constants.Name.AUTOFOCUS)
    public void setAutofocus(boolean z2) {
        if (getHostView() != null) {
            this.mAutoFocus = z2;
            WXEditText hostView = getHostView();
            if (this.mAutoFocus) {
                hostView.setFocusable(true);
                hostView.requestFocus();
                hostView.setFocusableInTouchMode(true);
                showSoftKeyboard();
                return;
            }
            hideSoftKeyboard();
        }
    }

    @WXComponentProp(name = "color")
    public void setColor(String str) {
        int color;
        if (getHostView() != null && !TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setTextColor(color);
        }
    }

    @WXComponentProp(name = Constants.Name.FONT_SIZE)
    public void setFontSize(String str) {
        if (getHostView() != null && str != null) {
            HashMap hashMap = new HashMap(1);
            hashMap.put(Constants.Name.FONT_SIZE, str);
            getHostView().setTextSize(0, (float) WXStyle.getFontSize(hashMap, getInstance().getDefaultFontSize(), getInstance().getInstanceViewPortWidthWithFloat()));
        }
    }

    @WXComponentProp(name = Constants.Name.LINES)
    public void setLines(int i2) {
        if (getHostView() != null) {
            getHostView().setLines(i2);
        }
    }

    @WXComponentProp(name = "max")
    public void setMax(String str) {
        this.mMax = str;
    }

    @WXComponentProp(name = Constants.Name.MAX_LENGTH)
    public void setMaxLength(int i2) {
        if (getHostView() != null) {
            getHostView().setFilters(new InputFilter[]{new InputFilter.LengthFilter(i2)});
        }
    }

    @WXComponentProp(name = Constants.Name.MAXLENGTH)
    @Deprecated
    public void setMaxlength(int i2) {
        setMaxLength(i2);
    }

    @WXComponentProp(name = Constants.Name.MIN)
    public void setMin(String str) {
        this.mMin = str;
    }

    @WXComponentProp(name = Constants.Name.PLACEHOLDER)
    public void setPlaceholder(String str) {
        if (str != null && getHostView() != null) {
            getHostView().setHint(str);
        }
    }

    @WXComponentProp(name = Constants.Name.PLACEHOLDER_COLOR)
    public void setPlaceholderColor(String str) {
        int color;
        if (getHostView() != null && !TextUtils.isEmpty(str) && (color = WXResourceUtils.getColor(str)) != Integer.MIN_VALUE) {
            getHostView().setHintTextColor(color);
        }
    }

    @Override // com.taobao.weex.ui.component.WXComponent
    public boolean setProperty(String str, Object obj) {
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1898657397:
                if (str.equals(Constants.Name.KEEP_SELECTION_INDEX)) {
                    c2 = 0;
                    break;
                }
                break;
            case -1576785488:
                if (str.equals(Constants.Name.PLACEHOLDER_COLOR)) {
                    c2 = 1;
                    break;
                }
                break;
            case -1065511464:
                if (str.equals(Constants.Name.TEXT_ALIGN)) {
                    c2 = 2;
                    break;
                }
                break;
            case -791400086:
                if (str.equals(Constants.Name.MAX_LENGTH)) {
                    c2 = 3;
                    break;
                }
                break;
            case 107876:
                if (str.equals("max")) {
                    c2 = 4;
                    break;
                }
                break;
            case 108114:
                if (str.equals(Constants.Name.MIN)) {
                    c2 = 5;
                    break;
                }
                break;
            case 3575610:
                if (str.equals("type")) {
                    c2 = 6;
                    break;
                }
                break;
            case 94842723:
                if (str.equals("color")) {
                    c2 = 7;
                    break;
                }
                break;
            case 102977279:
                if (str.equals(Constants.Name.LINES)) {
                    c2 = '\b';
                    break;
                }
                break;
            case 124732746:
                if (str.equals(Constants.Name.MAXLENGTH)) {
                    c2 = '\t';
                    break;
                }
                break;
            case 270940796:
                if (str.equals(Constants.Name.DISABLED)) {
                    c2 = '\n';
                    break;
                }
                break;
            case 365601008:
                if (str.equals(Constants.Name.FONT_SIZE)) {
                    c2 = 11;
                    break;
                }
                break;
            case 598246771:
                if (str.equals(Constants.Name.PLACEHOLDER)) {
                    c2 = '\f';
                    break;
                }
                break;
            case 914346044:
                if (str.equals(Constants.Name.SINGLELINE)) {
                    c2 = '\r';
                    break;
                }
                break;
            case 947486441:
                if (str.equals(Constants.Name.RETURN_KEY_TYPE)) {
                    c2 = 14;
                    break;
                }
                break;
            case 1625554645:
                if (str.equals(Constants.Name.ALLOW_COPY_PASTE)) {
                    c2 = 15;
                    break;
                }
                break;
            case 1667607689:
                if (str.equals(Constants.Name.AUTOFOCUS)) {
                    c2 = 16;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                this.mKeepSelectionIndex = WXUtils.getBoolean(obj, false).booleanValue();
                return true;
            case 1:
                String string = WXUtils.getString(obj, null);
                if (string == null) {
                    return true;
                }
                setPlaceholderColor(string);
                return true;
            case 2:
                String string2 = WXUtils.getString(obj, null);
                if (string2 == null) {
                    return true;
                }
                setTextAlign(string2);
                return true;
            case 3:
                Integer integer = WXUtils.getInteger(obj, null);
                if (integer == null) {
                    return true;
                }
                setMaxLength(integer.intValue());
                return true;
            case 4:
                setMax(String.valueOf(obj));
                return true;
            case 5:
                setMin(String.valueOf(obj));
                return true;
            case 6:
                String string3 = WXUtils.getString(obj, null);
                if (string3 == null) {
                    return true;
                }
                setType(string3);
                return true;
            case 7:
                String string4 = WXUtils.getString(obj, null);
                if (string4 == null) {
                    return true;
                }
                setColor(string4);
                return true;
            case '\b':
                Integer integer2 = WXUtils.getInteger(obj, null);
                if (integer2 == null) {
                    return true;
                }
                setLines(integer2.intValue());
                return true;
            case '\t':
                Integer integer3 = WXUtils.getInteger(obj, null);
                if (integer3 == null) {
                    return true;
                }
                setMaxLength(integer3.intValue());
                return true;
            case '\n':
                Boolean bool = WXUtils.getBoolean(obj, null);
                if (bool == null || this.mHost == null) {
                    return true;
                }
                if (bool.booleanValue()) {
                    ((WXEditText) this.mHost).setFocusable(false);
                    ((WXEditText) this.mHost).setFocusableInTouchMode(false);
                    return true;
                }
                ((WXEditText) this.mHost).setFocusableInTouchMode(true);
                ((WXEditText) this.mHost).setFocusable(true);
                return true;
            case 11:
                String string5 = WXUtils.getString(obj, null);
                if (string5 == null) {
                    return true;
                }
                setFontSize(string5);
                return true;
            case '\f':
                String string6 = WXUtils.getString(obj, null);
                if (string6 == null) {
                    return true;
                }
                setPlaceholder(string6);
                return true;
            case '\r':
                Boolean bool2 = WXUtils.getBoolean(obj, null);
                if (bool2 == null) {
                    return true;
                }
                setSingleLine(bool2.booleanValue());
                return true;
            case 14:
                setReturnKeyType(String.valueOf(obj));
                return true;
            case 15:
                boolean booleanValue = WXUtils.getBoolean(obj, true).booleanValue();
                if (getHostView() == null) {
                    return true;
                }
                getHostView().setAllowCopyPaste(booleanValue);
                return true;
            case 16:
                Boolean bool3 = WXUtils.getBoolean(obj, null);
                if (bool3 == null) {
                    return true;
                }
                setAutofocus(bool3.booleanValue());
                return true;
            default:
                return setProperty(str, obj);
        }
    }

    @WXComponentProp(name = Constants.Name.RETURN_KEY_TYPE)
    public void setReturnKeyType(String str) {
        if (getHostView() != null && !str.equals(this.mReturnKeyType)) {
            this.mReturnKeyType = str;
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case -906336856:
                    if (str.equals("search")) {
                        c2 = 0;
                        break;
                    }
                    break;
                case 3304:
                    if (str.equals("go")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 3089282:
                    if (str.equals("done")) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 3377907:
                    if (str.equals("next")) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 3526536:
                    if (str.equals("send")) {
                        c2 = 4;
                        break;
                    }
                    break;
                case 1544803905:
                    if (str.equals("default")) {
                        c2 = 5;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    this.mEditorAction = 3;
                    break;
                case 1:
                    this.mEditorAction = 2;
                    break;
                case 2:
                    this.mEditorAction = 6;
                    break;
                case 3:
                    this.mEditorAction = 5;
                    break;
                case 4:
                    this.mEditorAction = 4;
                    break;
                case 5:
                    this.mEditorAction = 0;
                    break;
            }
            blur();
            getHostView().setImeOptions(this.mEditorAction);
        }
    }

    @JSMethod
    public void setSelectionRange(int i2, int i3) {
        int length;
        WXEditText hostView = getHostView();
        if (hostView != null && i2 <= (length = getHostView().length()) && i3 <= length) {
            focus();
            hostView.setSelection(i2, i3);
        }
    }

    @WXComponentProp(name = Constants.Name.SINGLELINE)
    public void setSingleLine(boolean z2) {
        if (getHostView() != null) {
            getHostView().setSingleLine(z2);
        }
    }

    @WXComponentProp(name = Constants.Name.TEXT_ALIGN)
    public void setTextAlign(String str) {
        int textAlign = getTextAlign(str);
        if (textAlign > 0) {
            getHostView().setGravity(textAlign | getVerticalGravity());
        }
    }

    @JSMethod
    public void setTextFormatter(JSONObject jSONObject) {
        try {
            String string = jSONObject.getString("formatRule");
            String string2 = jSONObject.getString("formatReplace");
            String string3 = jSONObject.getString("recoverRule");
            String string4 = jSONObject.getString("recoverReplace");
            PatternWrapper parseToPattern = parseToPattern(string, string2);
            PatternWrapper parseToPattern2 = parseToPattern(string3, string4);
            if (parseToPattern != null && parseToPattern2 != null) {
                this.mFormatter = new TextFormatter(parseToPattern, parseToPattern2);
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    @WXComponentProp(name = "type")
    public void setType(String str) {
        Log.e("weex", "setType=" + str);
        if (str != null && getHostView() != null && !this.mType.equals(str)) {
            this.mType = str;
            getHostView().setInputType(getInputType(this.mType));
            String str2 = this.mType;
            str2.hashCode();
            if (str2.equals("date") || str2.equals(Constants.Value.TIME)) {
                applyOnClickListener();
            }
        }
    }

    @WXComponentProp(name = "value")
    public void setValue(String str) {
        WXEditText hostView = getHostView();
        if (hostView != null && !TextUtils.equals(hostView.getText(), str)) {
            this.mIgnoreNextOnInputEvent = true;
            int selectionStart = hostView.getSelectionStart();
            hostView.setText(str);
            if (!this.mKeepSelectionIndex) {
                selectionStart = str.length();
            }
            if (str == null) {
                selectionStart = 0;
            }
            hostView.setSelection(selectionStart);
        }
    }

    public void updateStyleAndAttrs() {
        if (getStyles().size() > 0) {
            int fontSize = getStyles().containsKey(Constants.Name.FONT_SIZE) ? WXStyle.getFontSize(getStyles(), getInstance().getDefaultFontSize(), getViewPortWidthForFloat()) : -1;
            String fontFamily = getStyles().containsKey(Constants.Name.FONT_FAMILY) ? WXStyle.getFontFamily(getStyles()) : null;
            int fontStyle = getStyles().containsKey(Constants.Name.FONT_STYLE) ? WXStyle.getFontStyle(getStyles()) : -1;
            int fontWeight = getStyles().containsKey(Constants.Name.FONT_WEIGHT) ? WXStyle.getFontWeight(getStyles()) : -1;
            int lineHeight = WXStyle.getLineHeight(getStyles(), getViewPortWidthForFloat());
            if (lineHeight != -1) {
                this.mLineHeight = lineHeight;
            }
            if (fontSize != -1) {
                this.mPaint.setTextSize((float) fontSize);
            }
            if (fontFamily != null) {
                TypefaceUtil.applyFontStyle(this.mPaint, fontStyle, fontWeight, fontFamily);
            }
        }
    }
}
