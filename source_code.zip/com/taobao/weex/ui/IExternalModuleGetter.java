package com.taobao.weex.ui;

import android.content.Context;
import com.taobao.weex.common.WXModule;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/IExternalModuleGetter.class */
public interface IExternalModuleGetter {
    Class<? extends WXModule> getExternalModuleClass(String str, Context context);
}
