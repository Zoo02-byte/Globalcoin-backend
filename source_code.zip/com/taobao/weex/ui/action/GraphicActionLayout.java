package com.taobao.weex.ui.action;

import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicActionLayout.class */
public class GraphicActionLayout extends BasicGraphicAction {
    private final boolean mIsLayoutRTL;
    private final GraphicPosition mLayoutPosition;
    private final GraphicSize mLayoutSize;

    public GraphicActionLayout(WXSDKInstance wXSDKInstance, String str, GraphicPosition graphicPosition, GraphicSize graphicSize, boolean z2) {
        super(wXSDKInstance, str);
        this.mLayoutPosition = graphicPosition;
        this.mLayoutSize = graphicSize;
        this.mIsLayoutRTL = z2;
    }

    @Override // com.taobao.weex.ui.action.IExecutable
    public void executeAction() {
        WXComponent wXComponent = WXSDKManager.getInstance().getWXRenderManager().getWXComponent(getPageId(), getRef());
        if (wXComponent != null) {
            wXComponent.setIsLayoutRTL(this.mIsLayoutRTL);
            wXComponent.setDemission(this.mLayoutSize, this.mLayoutPosition);
            wXComponent.setSafeLayout(wXComponent);
            wXComponent.setPadding(wXComponent.getPadding(), wXComponent.getBorder());
        }
    }
}
