package com.taobao.weex.ui.action;

import android.text.TextUtils;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.utils.WXLogUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/BasicGraphicAction.class */
public abstract class BasicGraphicAction implements IExecutable, Runnable {
    public static final int ActionTypeBatchBegin;
    public static final int ActionTypeBatchEnd;
    public static final int ActionTypeNormal;
    private WXSDKInstance mInstance;
    private final String mRef;
    public int mActionType = 0;
    public boolean mIsRunByBatch = false;

    public BasicGraphicAction(WXSDKInstance wXSDKInstance, String str) {
        this.mInstance = wXSDKInstance;
        this.mRef = str;
    }

    public void executeActionOnRender() {
        WXSDKInstance wXSDKInstance = this.mInstance;
        if (wXSDKInstance == null) {
            return;
        }
        if (TextUtils.isEmpty(wXSDKInstance.getInstanceId())) {
            WXLogUtils.e("[BasicGraphicAction] pageId can not be null");
            if (WXEnvironment.isApkDebugable()) {
                throw new RuntimeException(Operators.ARRAY_START_STR + getClass().getName() + "] pageId can not be null");
            }
            return;
        }
        WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(this.mInstance.getInstanceId(), this);
    }

    public final String getPageId() {
        WXSDKInstance wXSDKInstance = this.mInstance;
        return wXSDKInstance != null ? wXSDKInstance.getInstanceId() : null;
    }

    public final String getRef() {
        return this.mRef;
    }

    public final WXSDKInstance getWXSDKIntance() {
        return this.mInstance;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            executeAction();
        } catch (Throwable th) {
            if (!WXEnvironment.isApkDebugable()) {
                WXLogUtils.w("BasicGraphicAction", th);
            } else {
                WXLogUtils.e("BasicGraphicAction", "SafeRunnable run throw expection:" + th.getMessage());
                throw th;
            }
        }
    }
}
