package com.taobao.weex.ui.action;

import com.taobao.weex.WXSDKInstance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicActionBatchBegin.class */
public class GraphicActionBatchBegin extends BasicGraphicAction {
    public GraphicActionBatchBegin(WXSDKInstance wXSDKInstance, String str) {
        super(wXSDKInstance, str);
        this.mActionType = 1;
    }

    @Override // com.taobao.weex.ui.action.IExecutable
    public void executeAction() {
    }
}
