package com.taobao.weex.ui.action;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/IExecutable.class */
public interface IExecutable {
    void executeAction();
}
