package com.taobao.weex.ui.action;

import com.taobao.weex.WXSDKInstance;
import java.util.ArrayList;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicActionBatchAction.class */
public class GraphicActionBatchAction extends BasicGraphicAction {
    private List<BasicGraphicAction> mActions;

    public GraphicActionBatchAction(WXSDKInstance wXSDKInstance, String str, List<BasicGraphicAction> list) {
        super(wXSDKInstance, str);
        this.mActions = new ArrayList(list);
    }

    @Override // com.taobao.weex.ui.action.IExecutable
    public void executeAction() {
        for (int i2 = 0; i2 < this.mActions.size(); i2++) {
            this.mActions.get(i2).executeAction();
        }
    }
}
