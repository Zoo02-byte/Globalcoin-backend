package com.taobao.weex.ui.action;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicSize.class */
public class GraphicSize {
    private float mHeight;
    private float mWidth;

    public GraphicSize(float f2, float f3) {
        this.mWidth = f2;
        this.mHeight = f3;
    }

    public float getHeight() {
        return this.mHeight;
    }

    public float getWidth() {
        return this.mWidth;
    }

    public void setHeight(float f2) {
        this.mHeight = f2;
    }

    public void setWidth(float f2) {
        this.mWidth = f2;
    }

    public void update(float f2, float f3) {
        this.mWidth = f2;
        this.mHeight = f3;
    }
}
