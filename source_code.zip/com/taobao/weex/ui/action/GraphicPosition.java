package com.taobao.weex.ui.action;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicPosition.class */
public class GraphicPosition {
    private float mBottom;
    private float mLeft;
    private float mRight;
    private float mTop;

    public GraphicPosition(float f2, float f3, float f4, float f5) {
        this.mLeft = f2;
        this.mTop = f3;
        this.mRight = f4;
        this.mBottom = f5;
    }

    public float getBottom() {
        return this.mBottom;
    }

    public float getLeft() {
        return this.mLeft;
    }

    public float getRight() {
        return this.mRight;
    }

    public float getTop() {
        return this.mTop;
    }

    public void setBottom(float f2) {
        this.mBottom = f2;
    }

    public void setLeft(float f2) {
        this.mLeft = f2;
    }

    public void setRight(float f2) {
        this.mRight = f2;
    }

    public void setTop(float f2) {
        this.mTop = f2;
    }

    public void update(float f2, float f3, float f4, float f5) {
        this.mTop = f2;
        this.mBottom = f3;
        this.mLeft = f4;
        this.mRight = f5;
    }
}
