package com.taobao.weex.ui.action;

import com.taobao.weex.WXSDKInstance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicActionBatchEnd.class */
public class GraphicActionBatchEnd extends BasicGraphicAction {
    public GraphicActionBatchEnd(WXSDKInstance wXSDKInstance, String str) {
        super(wXSDKInstance, str);
        this.mActionType = 2;
    }

    @Override // com.taobao.weex.ui.action.IExecutable
    public void executeAction() {
    }
}
