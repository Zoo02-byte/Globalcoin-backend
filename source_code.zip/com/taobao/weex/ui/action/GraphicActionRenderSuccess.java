package com.taobao.weex.ui.action;

import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/action/GraphicActionRenderSuccess.class */
public class GraphicActionRenderSuccess extends BasicGraphicAction {
    public GraphicActionRenderSuccess(WXSDKInstance wXSDKInstance) {
        super(wXSDKInstance, "");
    }

    @Override // com.taobao.weex.ui.action.IExecutable
    public void executeAction() {
        int i2;
        int i3;
        WXSDKInstance wXSDKIntance = getWXSDKIntance();
        if (wXSDKIntance != null && wXSDKIntance.getContext() != null) {
            WXComponent rootComponent = wXSDKIntance.getRootComponent();
            if (rootComponent != null) {
                i3 = (int) rootComponent.getLayoutWidth();
                i2 = (int) rootComponent.getLayoutHeight();
            } else {
                i3 = 0;
                i2 = 0;
            }
            wXSDKIntance.onRenderSuccess(i3, i2);
        }
    }
}
