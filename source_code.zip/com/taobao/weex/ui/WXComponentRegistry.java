package com.taobao.weex.ui;

import android.text.TextUtils;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.WXException;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.cache.RegisterCache;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/WXComponentRegistry.class */
public class WXComponentRegistry {
    private static Map<String, IFComponentHolder> sTypeComponentMap = new ConcurrentHashMap();
    private static ArrayList<Map<String, Object>> sComponentInfos = new ArrayList<>();

    public static IFComponentHolder getComponent(String str) {
        return sTypeComponentMap.get(str);
    }

    public static boolean registerComponent(String str, IFComponentHolder iFComponentHolder, Map<String, Object> map) throws WXException {
        synchronized (WXComponentRegistry.class) {
            if (iFComponentHolder != null) {
                try {
                    if (!TextUtils.isEmpty(str)) {
                        if (RegisterCache.getInstance().cacheComponent(str, iFComponentHolder, map)) {
                            return true;
                        }
                        WXBridgeManager.getInstance().post(new Runnable(map, str, iFComponentHolder) { // from class: com.taobao.weex.ui.WXComponentRegistry.2
                            final Map val$componentInfo;
                            final IFComponentHolder val$holder;
                            final String val$type;

                            {
                                this.val$componentInfo = r4;
                                this.val$type = r5;
                                this.val$holder = r6;
                            }

                            @Override // java.lang.Runnable
                            public void run() {
                                try {
                                    Map map2 = this.val$componentInfo;
                                    Map map3 = map2;
                                    if (map2 == null) {
                                        map3 = new HashMap();
                                    }
                                    map3.put("type", this.val$type);
                                    map3.put("methods", this.val$holder.getMethods());
                                    WXComponentRegistry.registerNativeComponent(this.val$type, this.val$holder);
                                    WXComponentRegistry.registerJSComponent(map3);
                                    WXComponentRegistry.sComponentInfos.add(map3);
                                } catch (WXException e2) {
                                    WXLogUtils.e("register component error:", e2);
                                }
                            }
                        });
                        return true;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            return false;
        }
    }

    public static boolean registerComponent(Map<String, RegisterCache.ComponentCache> map) {
        synchronized (WXComponentRegistry.class) {
            try {
                if (map.isEmpty()) {
                    return true;
                }
                WXBridgeManager.getInstance().post(new Runnable(map.entrySet().iterator()) { // from class: com.taobao.weex.ui.WXComponentRegistry.1
                    final Iterator val$iterator;

                    {
                        this.val$iterator = r4;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        ArrayList arrayList = new ArrayList();
                        while (this.val$iterator.hasNext()) {
                            try {
                                RegisterCache.ComponentCache componentCache = (RegisterCache.ComponentCache) ((Map.Entry) this.val$iterator.next()).getValue();
                                Map<String, Object> map2 = componentCache.componentInfo;
                                Map<String, Object> map3 = map2;
                                if (map2 == null) {
                                    map3 = new HashMap<>();
                                }
                                map3.put("type", componentCache.type);
                                map3.put("methods", componentCache.holder.getMethods());
                                WXComponentRegistry.registerNativeComponent(componentCache.type, componentCache.holder);
                                WXComponentRegistry.sComponentInfos.add(map3);
                                arrayList.add(map3);
                            } catch (WXException e2) {
                                e2.printStackTrace();
                            }
                        }
                        WXSDKManager.getInstance().registerComponents(arrayList);
                    }
                });
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static boolean registerJSComponent(Map<String, Object> map) throws WXException {
        ArrayList arrayList = new ArrayList();
        arrayList.add(map);
        WXSDKManager.getInstance().registerComponents(arrayList);
        return true;
    }

    public static boolean registerNativeComponent(String str, IFComponentHolder iFComponentHolder) throws WXException {
        try {
            iFComponentHolder.loadIfNonLazy();
            sTypeComponentMap.put(str, iFComponentHolder);
            return true;
        } catch (ArrayStoreException e2) {
            e2.printStackTrace();
            return true;
        }
    }

    public static void reload() {
        WXBridgeManager.getInstance().post(new Runnable() { // from class: com.taobao.weex.ui.WXComponentRegistry.3
            @Override // java.lang.Runnable
            public void run() {
                try {
                    Iterator it = WXComponentRegistry.sComponentInfos.iterator();
                    while (it.hasNext()) {
                        WXComponentRegistry.registerJSComponent((Map) it.next());
                    }
                } catch (WXException e2) {
                    WXLogUtils.e("", e2);
                }
            }
        });
    }
}
