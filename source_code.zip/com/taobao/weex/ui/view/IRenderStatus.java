package com.taobao.weex.ui.view;

import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IRenderStatus.class */
public interface IRenderStatus<T extends WXComponent> {
    void holdComponent(T t2);
}
