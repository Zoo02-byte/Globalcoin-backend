package com.taobao.weex.ui.view;

import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IRenderResult.class */
public interface IRenderResult<T extends WXComponent> {
    T getComponent();
}
