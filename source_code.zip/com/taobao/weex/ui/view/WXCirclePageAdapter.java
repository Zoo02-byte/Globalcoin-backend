package com.taobao.weex.ui.view;

import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.utils.WXLogUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXCirclePageAdapter.class */
public class WXCirclePageAdapter extends PagerAdapter {
    public boolean isRTL;
    private boolean needLoop;
    private List<View> originalViews;
    private List<View> shadow;
    private List<View> views;

    public WXCirclePageAdapter() {
        this(true);
    }

    public WXCirclePageAdapter(List<View> list, boolean z2) {
        this.views = new ArrayList();
        this.shadow = new ArrayList();
        this.needLoop = true;
        this.isRTL = false;
        this.originalViews = new ArrayList();
        this.views = new ArrayList(list);
        this.originalViews = new ArrayList(list);
        this.needLoop = z2;
    }

    public WXCirclePageAdapter(boolean z2) {
        this.views = new ArrayList();
        this.shadow = new ArrayList();
        this.needLoop = true;
        this.isRTL = false;
        this.originalViews = new ArrayList();
        this.needLoop = z2;
    }

    private void ensureShadow() {
        ArrayList arrayList = new ArrayList();
        if (!this.needLoop || this.views.size() <= 2) {
            arrayList.addAll(this.views);
        } else {
            List<View> list = this.views;
            arrayList.add(0, list.get(list.size() - 1));
            for (View view : this.views) {
                if (view.getParent() != null) {
                    ((ViewGroup) view.getParent()).removeView(view);
                }
                arrayList.add(view);
            }
            arrayList.add(this.views.get(0));
        }
        this.shadow.clear();
        notifyDataSetChanged();
        this.shadow.addAll(arrayList);
        notifyDataSetChanged();
    }

    public void addPageView(View view) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("onPageSelected >>>> addPageView");
        }
        this.originalViews.add(view);
        if (this.isRTL) {
            this.views.add(0, view);
        } else {
            this.views.add(view);
        }
        ensureShadow();
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public void destroyItem(ViewGroup viewGroup, int i2, Object obj) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("onPageSelected >>>> destroyItem >>>>> position:" + i2);
        }
        if (!this.needLoop) {
            viewGroup.removeView((View) obj);
        }
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getCount() {
        return this.shadow.size();
    }

    public int getFirst() {
        return (!this.needLoop || this.views.size() <= 2) ? 0 : 1;
    }

    public int getItemIndex(Object obj) {
        if (obj instanceof View) {
            return this.views.indexOf(obj);
        }
        return -1;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public int getItemPosition(Object obj) {
        return -2;
    }

    public int getPagePosition(View view) {
        return this.views.indexOf(view);
    }

    public int getRealCount() {
        return this.views.size();
    }

    public int getRealPosition(int i2) {
        if (i2 < 0 || i2 >= this.shadow.size()) {
            return -1;
        }
        return getItemIndex(this.shadow.get(i2));
    }

    public List<View> getViews() {
        return this.views;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public Object instantiateItem(ViewGroup viewGroup, int i2) {
        Exception e2;
        View view = null;
        try {
            view = this.shadow.get(i2);
            try {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("onPageSelected >>>> instantiateItem >>>>> position:" + i2 + ",position % getRealCount()" + (i2 % getRealCount()));
                }
                if (view.getParent() == null) {
                    viewGroup.addView(view);
                } else {
                    ((ViewGroup) view.getParent()).removeView(view);
                    viewGroup.addView(view);
                }
            } catch (Exception e3) {
                e2 = e3;
                view = view;
                WXLogUtils.e("[CirclePageAdapter] instantiateItem: ", e2);
                return view;
            }
        } catch (Exception e4) {
            e2 = e4;
        }
        return view;
    }

    @Override // androidx.viewpager.widget.PagerAdapter
    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public void removePageView(View view) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("onPageSelected >>>> removePageView");
        }
        this.views.remove(view);
        this.originalViews.remove(view);
        ensureShadow();
    }

    public void replacePageView(View view, View view2) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("onPageSelected >>>> replacePageView");
        }
        int indexOf = this.views.indexOf(view);
        this.views.remove(indexOf);
        this.views.add(indexOf, view2);
        ensureShadow();
        int indexOf2 = this.originalViews.indexOf(view);
        this.originalViews.remove(indexOf2);
        this.originalViews.add(indexOf2, view2);
    }

    public void setLayoutDirectionRTL(boolean z2) {
        if (z2 != this.isRTL) {
            this.isRTL = z2;
            ArrayList arrayList = new ArrayList(this.originalViews);
            this.views = arrayList;
            if (z2) {
                Collections.reverse(arrayList);
            }
            ensureShadow();
        }
    }
}
