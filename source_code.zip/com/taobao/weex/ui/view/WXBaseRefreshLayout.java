package com.taobao.weex.ui.view;

import android.content.Context;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXBaseRefreshLayout.class */
public class WXBaseRefreshLayout extends WXFrameLayout {
    public WXBaseRefreshLayout(Context context) {
        super(context);
    }
}
