package com.taobao.weex.ui.view;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWXScroller.class */
public interface IWXScroller {
    void destroy();
}
