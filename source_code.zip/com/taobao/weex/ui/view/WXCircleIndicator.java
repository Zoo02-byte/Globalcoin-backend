package com.taobao.weex.ui.view;

import android.content.Context;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXCircleIndicator.class */
public class WXCircleIndicator extends WXBaseCircleIndicator {
    public WXCircleIndicator(Context context) {
        super(context);
    }
}
