package com.taobao.weex.ui.view.refresh.circlebar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.widget.ImageView;
import androidx.core.view.ViewCompat;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/circlebar/CircleProgressBar.class */
public class CircleProgressBar extends ImageView {
    public static final int DEFAULT_CIRCLE_BG_LIGHT;
    public static final int DEFAULT_CIRCLE_COLOR;
    private static final int DEFAULT_CIRCLE_DIAMETER;
    private static final int FILL_SHADOW_COLOR;
    private static final int KEY_SHADOW_COLOR;
    private static final int SHADOW_ELEVATION;
    private static final float SHADOW_RADIUS;
    private static final int STROKE_WIDTH_LARGE;
    private static final float X_OFFSET;
    private static final float Y_OFFSET;
    private int mArrowHeight;
    private int mArrowWidth;
    private int mBackGroundColor;
    private ShapeDrawable mBgCircle;
    private boolean mCircleBackgroundEnabled;
    private int mDiameter;
    private int mInnerRadius;
    private Animation.AnimationListener mListener;
    private int mMax;
    private int mProgress;
    private int mProgressColor;
    public MaterialProgressDrawable mProgressDrawable;
    private int mProgressStokeWidth;
    private int mShadowRadius;
    private boolean mShowArrow;
    private int[] mColors = {-16777216};
    private boolean isLayoutFinished = false;
    private Handler mHandler = new Handler(this) { // from class: com.taobao.weex.ui.view.refresh.circlebar.CircleProgressBar.1
        final CircleProgressBar this$0;

        {
            this.this$0 = r4;
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            handleMessage(message);
            if (message.what != 10010) {
                return;
            }
            if (!this.this$0.isLayoutFinished || this.this$0.mProgressDrawable == null) {
                postDelayed(new Runnable(this) { // from class: com.taobao.weex.ui.view.refresh.circlebar.CircleProgressBar.1.1
                    final AnonymousClass1 this$1;

                    {
                        this.this$1 = r4;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        this.this$1.this$0.mHandler.sendEmptyMessage(10010);
                    }
                }, 100);
            } else {
                this.this$0.mProgressDrawable.start();
            }
        }
    };

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/circlebar/CircleProgressBar$OvalShadow.class */
    private class OvalShadow extends OvalShape {
        private int mCircleDiameter;
        private RadialGradient mRadialGradient;
        private Paint mShadowPaint = new Paint();
        private int mShadowRadius;
        final CircleProgressBar this$0;

        public OvalShadow(CircleProgressBar circleProgressBar, int i2, int i3) {
            this.this$0 = circleProgressBar;
            this.mShadowRadius = i2;
            this.mCircleDiameter = i3;
            int i4 = this.mCircleDiameter;
            RadialGradient radialGradient = new RadialGradient((float) (i4 / 2), (float) (i4 / 2), (float) this.mShadowRadius, new int[]{CircleProgressBar.FILL_SHADOW_COLOR, 0}, (float[]) null, Shader.TileMode.CLAMP);
            this.mRadialGradient = radialGradient;
            this.mShadowPaint.setShader(radialGradient);
        }

        @Override // android.graphics.drawable.shapes.OvalShape, android.graphics.drawable.shapes.Shape, android.graphics.drawable.shapes.RectShape
        public void draw(Canvas canvas, Paint paint) {
            int width = this.this$0.getWidth();
            float f2 = (float) (width / 2);
            float height = (float) (this.this$0.getHeight() / 2);
            canvas.drawCircle(f2, height, (float) ((this.mCircleDiameter / 2) + this.mShadowRadius), this.mShadowPaint);
            canvas.drawCircle(f2, height, (float) (this.mCircleDiameter / 2), paint);
        }
    }

    public CircleProgressBar(Context context) {
        super(context);
        init(context, null, 0);
    }

    public CircleProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet, 0);
    }

    public CircleProgressBar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        init(context, attributeSet, i2);
    }

    private boolean elevationSupported() {
        return true;
    }

    private void init(Context context, AttributeSet attributeSet, int i2) {
        float f2 = getContext().getResources().getDisplayMetrics().density;
        this.mBackGroundColor = DEFAULT_CIRCLE_BG_LIGHT;
        this.mProgressColor = DEFAULT_CIRCLE_COLOR;
        this.mColors = new int[]{DEFAULT_CIRCLE_COLOR};
        this.mInnerRadius = -1;
        this.mProgressStokeWidth = (int) (f2 * 3.0f);
        this.mArrowWidth = -1;
        this.mArrowHeight = -1;
        this.mShowArrow = true;
        this.mCircleBackgroundEnabled = true;
        this.mProgress = 0;
        this.mMax = 100;
        MaterialProgressDrawable materialProgressDrawable = new MaterialProgressDrawable(getContext(), this);
        this.mProgressDrawable = materialProgressDrawable;
        setImageDrawable(materialProgressDrawable);
    }

    public boolean circleBackgroundEnabled() {
        return this.mCircleBackgroundEnabled;
    }

    public void destory() {
        this.mProgressDrawable.stop();
        this.mProgressDrawable = null;
    }

    public int getMax() {
        return this.mMax;
    }

    public int getProgress() {
        return this.mProgress;
    }

    public int getProgressStokeWidth() {
        return this.mProgressStokeWidth;
    }

    public boolean isShowArrow() {
        return this.mShowArrow;
    }

    @Override // android.view.View
    public void onAnimationEnd() {
        onAnimationEnd();
        Animation.AnimationListener animationListener = this.mListener;
        if (animationListener != null) {
            animationListener.onAnimationEnd(getAnimation());
        }
    }

    @Override // android.view.View
    public void onAnimationStart() {
        onAnimationStart();
        Animation.AnimationListener animationListener = this.mListener;
        if (animationListener != null) {
            animationListener.onAnimationStart(getAnimation());
        }
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onAttachedToWindow() {
        onAttachedToWindow();
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.stop();
            this.mProgressDrawable.setVisible(getVisibility() == 0, false);
        }
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDetachedFromWindow() {
        onDetachedFromWindow();
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.stop();
            this.mProgressDrawable.setVisible(false, false);
        }
    }

    @Override // android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        onLayout(z2, i2, i3, i4, i5);
        float f2 = getContext().getResources().getDisplayMetrics().density;
        int min = Math.min(getMeasuredWidth(), getMeasuredHeight());
        this.mDiameter = min;
        if (min <= 0) {
            this.mDiameter = ((int) f2) * 40;
        }
        if (getBackground() == null && this.mCircleBackgroundEnabled) {
            int i6 = (int) (Y_OFFSET * f2);
            int i7 = (int) (f2 * 0.0f);
            this.mShadowRadius = (int) (SHADOW_RADIUS * f2);
            if (elevationSupported()) {
                this.mBgCircle = new ShapeDrawable(new OvalShape());
                ViewCompat.setElevation(this, f2 * 4.0f);
            } else {
                int i8 = this.mShadowRadius;
                ShapeDrawable shapeDrawable = new ShapeDrawable(new OvalShadow(this, i8, this.mDiameter - (i8 * 2)));
                this.mBgCircle = shapeDrawable;
                ViewCompat.setLayerType(this, 1, shapeDrawable.getPaint());
                this.mBgCircle.getPaint().setShadowLayer((float) this.mShadowRadius, (float) i7, (float) i6, KEY_SHADOW_COLOR);
                int i9 = this.mShadowRadius;
                setPadding(i9, i9, i9, i9);
            }
            this.mBgCircle.getPaint().setColor(this.mBackGroundColor);
            setBackgroundDrawable(this.mBgCircle);
        }
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.setBackgroundColor(this.mBackGroundColor);
            this.mProgressDrawable.setColorSchemeColors(this.mColors);
            if (isShowArrow()) {
                this.mProgressDrawable.setArrowScale(1.0f);
                this.mProgressDrawable.showArrow(true);
            }
            setImageDrawable(null);
            setImageDrawable(this.mProgressDrawable);
            this.mProgressDrawable.setAlpha(255);
            if (getVisibility() == 0) {
                this.mProgressDrawable.setStartEndTrim(0.0f, 0.8f);
            }
            this.isLayoutFinished = true;
        }
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onMeasure(int i2, int i3) {
        onMeasure(i2, i3);
        if (!elevationSupported()) {
            setMeasuredDimension(getMeasuredWidth() + (this.mShadowRadius * 2), getMeasuredHeight() + (this.mShadowRadius * 2));
        }
    }

    public void setAnimationListener(Animation.AnimationListener animationListener) {
        this.mListener = animationListener;
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        if (getBackground() instanceof ShapeDrawable) {
            ((ShapeDrawable) getBackground()).getPaint().setColor(i2);
        }
    }

    public void setBackgroundColorResource(int i2) {
        if (getBackground() instanceof ShapeDrawable) {
            ((ShapeDrawable) getBackground()).getPaint().setColor(getResources().getColor(i2));
        }
    }

    public void setCircleBackgroundEnabled(boolean z2) {
        this.mCircleBackgroundEnabled = z2;
    }

    public void setColorSchemeColors(int... iArr) {
        this.mColors = iArr;
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.setColorSchemeColors(iArr);
        }
    }

    public void setMax(int i2) {
        this.mMax = i2;
    }

    public void setProgress(int i2) {
        if (getMax() > 0) {
            this.mProgress = i2;
        }
        invalidate();
    }

    public void setProgressBackGroundColor(int i2) {
        this.mBackGroundColor = i2;
    }

    public void setProgressRotation(float f2) {
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.setProgressRotation(f2);
        }
    }

    public void setProgressStokeWidth(int i2) {
        this.mProgressStokeWidth = (int) (((float) i2) * getContext().getResources().getDisplayMetrics().density);
    }

    public void setShowArrow(boolean z2) {
        this.mShowArrow = z2;
    }

    public void setStartEndTrim(float f2, float f3) {
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.setStartEndTrim(f2, f3);
        }
    }

    public void start() {
        this.mHandler.sendEmptyMessage(10010);
    }

    public void stop() {
        MaterialProgressDrawable materialProgressDrawable = this.mProgressDrawable;
        if (materialProgressDrawable != null) {
            materialProgressDrawable.stop();
        }
        this.mHandler.removeMessages(10010);
    }
}
