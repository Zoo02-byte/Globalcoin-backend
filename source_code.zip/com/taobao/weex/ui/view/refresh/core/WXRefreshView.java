package com.taobao.weex.ui.view.refresh.core;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.ui.view.refresh.circlebar.CircleProgressBar;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXRefreshView.class */
public class WXRefreshView extends FrameLayout {
    private CircleProgressBar circleProgressBar;
    private LinearLayout linearLayout;

    public WXRefreshView(Context context) {
        super(context);
        setupViews();
    }

    public WXRefreshView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setupViews();
    }

    public WXRefreshView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        setupViews();
    }

    private void setupViews() {
        this.linearLayout = new LinearLayout(getContext());
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        this.linearLayout.setOrientation(1);
        this.linearLayout.setGravity(17);
        addView(this.linearLayout, layoutParams);
    }

    public void setContentGravity(int i2) {
        LinearLayout linearLayout = this.linearLayout;
        if (linearLayout != null) {
            linearLayout.setGravity(i2);
        }
    }

    public void setProgressBgColor(int i2) {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.setBackgroundColor(i2);
        }
    }

    public void setProgressColor(int i2) {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.setColorSchemeColors(i2);
        }
    }

    public void setProgressRotation(float f2) {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.setProgressRotation(f2);
        }
    }

    public void setRefreshView(View view) {
        if (view != null) {
            post(WXThread.secure(new Runnable(this, view) { // from class: com.taobao.weex.ui.view.refresh.core.WXRefreshView.1
                final WXRefreshView this$0;
                final View val$view;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$0 = r4;
                    this.val$view = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    View view2 = this.val$view;
                    if (view2.getParent() != null) {
                        ((ViewGroup) this.val$view.getParent()).removeView(this.val$view);
                    }
                    this.this$0.linearLayout.removeAllViews();
                    int i2 = 0;
                    while (true) {
                        ViewGroup viewGroup = (ViewGroup) view2;
                        if (i2 < viewGroup.getChildCount()) {
                            View childAt = viewGroup.getChildAt(i2);
                            if (childAt instanceof CircleProgressBar) {
                                this.this$0.circleProgressBar = (CircleProgressBar) childAt;
                            }
                            i2++;
                        } else {
                            this.this$0.linearLayout.addView(view2);
                            return;
                        }
                    }
                }
            }));
        }
    }

    public void setStartEndTrim(float f2, float f3) {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.setStartEndTrim(f2, f3);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void startAnimation() {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void stopAnimation() {
        CircleProgressBar circleProgressBar = this.circleProgressBar;
        if (circleProgressBar != null) {
            circleProgressBar.stop();
        }
    }
}
