package com.taobao.weex.ui.view.refresh.core;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import androidx.core.view.NestedScrollingChild;
import androidx.core.view.NestedScrollingChildHelper;
import androidx.core.view.NestedScrollingParent;
import androidx.core.view.NestedScrollingParentHelper;
import androidx.core.view.ViewCompat;
import androidx.core.view.ViewParentCompat;
import com.taobao.weex.ui.view.listview.WXRecyclerView;
import java.util.LinkedList;
import java.util.List;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXSwipeLayout.class */
public class WXSwipeLayout extends FrameLayout implements NestedScrollingParent, NestedScrollingChild {
    private static final float DAMPING;
    private static final int INVALID;
    private static final int LOAD_MORE;
    private static final int PULL_REFRESH;
    private static final float overFlow;
    private WXRefreshView footerView;
    private WXRefreshView headerView;
    private boolean isConfirm;
    private volatile float loadingViewFlowHeight;
    private volatile float loadingViewHeight;
    private int mCurrentAction;
    private ViewParent mNestedScrollAcceptedParent;
    private boolean mNestedScrollInProgress;
    private NestedScrollingChildHelper mNestedScrollingChildHelper;
    private NestedScrollingParentHelper mNestedScrollingParentHelper;
    private final int[] mParentOffsetInWindow;
    private final int[] mParentScrollConsumed;
    private int mProgressBgColor;
    private int mProgressColor;
    private boolean mPullLoadEnable;
    private boolean mPullRefreshEnable;
    private final List<OnRefreshOffsetChangedListener> mRefreshOffsetChangedListeners;
    private int mRefreshViewBgColor;
    private volatile boolean mRefreshing;
    private View mTargetView;
    private WXOnLoadingListener onLoadingListener;
    private WXOnRefreshListener onRefreshListener;
    private volatile float refreshViewFlowHeight;
    private volatile float refreshViewHeight;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXSwipeLayout$OnRefreshOffsetChangedListener.class */
    public interface OnRefreshOffsetChangedListener {
        void onOffsetChanged(int i2);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXSwipeLayout$WXOnLoadingListener.class */
    public interface WXOnLoadingListener {
        void onLoading();

        void onPullingUp(float f2, int i2, float f3);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXSwipeLayout$WXOnRefreshListener.class */
    public interface WXOnRefreshListener {
        void onPullingDown(float f2, int i2, float f3);

        void onRefresh();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/refresh/core/WXSwipeLayout$WXRefreshAnimatorListener.class */
    public static class WXRefreshAnimatorListener implements Animator.AnimatorListener {
        WXRefreshAnimatorListener() {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationRepeat(Animator animator) {
        }

        @Override // android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
        }
    }

    public WXSwipeLayout(Context context) {
        super(context);
        this.mParentScrollConsumed = new int[2];
        this.mParentOffsetInWindow = new int[2];
        this.mRefreshOffsetChangedListeners = new LinkedList();
        this.mPullRefreshEnable = false;
        this.mPullLoadEnable = false;
        this.mRefreshing = false;
        this.refreshViewHeight = 0.0f;
        this.loadingViewHeight = 0.0f;
        this.refreshViewFlowHeight = 0.0f;
        this.loadingViewFlowHeight = 0.0f;
        this.mCurrentAction = -1;
        this.isConfirm = false;
        initAttrs(context, null);
    }

    public WXSwipeLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mParentScrollConsumed = new int[2];
        this.mParentOffsetInWindow = new int[2];
        this.mRefreshOffsetChangedListeners = new LinkedList();
        this.mPullRefreshEnable = false;
        this.mPullLoadEnable = false;
        this.mRefreshing = false;
        this.refreshViewHeight = 0.0f;
        this.loadingViewHeight = 0.0f;
        this.refreshViewFlowHeight = 0.0f;
        this.loadingViewFlowHeight = 0.0f;
        this.mCurrentAction = -1;
        this.isConfirm = false;
        initAttrs(context, attributeSet);
    }

    public WXSwipeLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.mParentScrollConsumed = new int[2];
        this.mParentOffsetInWindow = new int[2];
        this.mRefreshOffsetChangedListeners = new LinkedList();
        this.mPullRefreshEnable = false;
        this.mPullLoadEnable = false;
        this.mRefreshing = false;
        this.refreshViewHeight = 0.0f;
        this.loadingViewHeight = 0.0f;
        this.refreshViewFlowHeight = 0.0f;
        this.loadingViewFlowHeight = 0.0f;
        this.mCurrentAction = -1;
        this.isConfirm = false;
        initAttrs(context, attributeSet);
    }

    public WXSwipeLayout(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.mParentScrollConsumed = new int[2];
        this.mParentOffsetInWindow = new int[2];
        this.mRefreshOffsetChangedListeners = new LinkedList();
        this.mPullRefreshEnable = false;
        this.mPullLoadEnable = false;
        this.mRefreshing = false;
        this.refreshViewHeight = 0.0f;
        this.loadingViewHeight = 0.0f;
        this.refreshViewFlowHeight = 0.0f;
        this.loadingViewFlowHeight = 0.0f;
        this.mCurrentAction = -1;
        this.isConfirm = false;
        initAttrs(context, attributeSet);
    }

    /* JADX WARN: Type inference failed for: r0v8, types: [double] */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Unknown variable types count: 2 */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private double calculateDistanceY(android.view.View r6, int r7) {
        /*
            r5 = this;
            r0 = r6
            int r0 = r0.getMeasuredHeight()
            r12 = r0
            r0 = r12
            float r0 = (float) r0
            r1 = r6
            float r1 = r1.getY()
            float r1 = java.lang.Math.abs(r1)
            float r0 = r0 - r1
            double r0 = (double) r0
            r1 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            double r0 = r0 / r1
            r1 = r12
            double r1 = (double) r1
            double r0 = r0 / r1
            r1 = 4600877379429072896(0x3fd99999a0000000, double:0.4000000059604645)
            double r0 = r0 * r1
            r10 = r0
            r0 = r10
            r8 = r0
            r0 = r10
            r1 = 4576918229304087675(0x3f847ae147ae147b, double:0.01)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 > 0) goto L_0x002e
            r0 = 4576918229304087675(0x3f847ae147ae147b, double:0.01)
            r8 = r0
        L_0x002e:
            r0 = r8
            r1 = r7
            double r1 = (double) r1
            double r0 = r0 * r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.calculateDistanceY(android.view.View, int):double");
    }

    private void handlerAction() {
        if (!isRefreshing()) {
            this.isConfirm = false;
            if (this.mPullRefreshEnable && this.mCurrentAction == 0) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.headerView.getLayoutParams();
                if (((float) layoutParams.height) >= this.refreshViewHeight) {
                    startRefresh(layoutParams.height);
                } else if (layoutParams.height > 0) {
                    resetHeaderView(layoutParams.height);
                } else {
                    resetRefreshState();
                }
            }
            if (this.mPullLoadEnable && this.mCurrentAction == 1) {
                FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) this.footerView.getLayoutParams();
                if (((float) layoutParams2.height) >= this.loadingViewHeight) {
                    startLoadmore(layoutParams2.height);
                } else if (layoutParams2.height > 0) {
                    resetFootView(layoutParams2.height);
                } else {
                    resetLoadmoreState();
                }
            }
        }
    }

    private void initAttrs(Context context, AttributeSet attributeSet) {
        if (getChildCount() <= 1) {
            this.mNestedScrollingParentHelper = new NestedScrollingParentHelper(this);
            this.mNestedScrollingChildHelper = new NestedScrollingChildHelper(this);
            setNestedScrollingEnabled(false);
            if (!isInEditMode() || attributeSet != null) {
                this.mRefreshViewBgColor = 0;
                this.mProgressBgColor = 0;
                this.mProgressColor = -65536;
                return;
            }
            return;
        }
        throw new RuntimeException("WXSwipeLayout should not have more than one child");
    }

    private boolean moveSpinner(float f2) {
        if (this.mRefreshing) {
            return false;
        }
        if (!canChildScrollUp() && this.mPullRefreshEnable && this.mCurrentAction == 0) {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.headerView.getLayoutParams();
            layoutParams.height = (int) (((float) layoutParams.height) + f2);
            if (layoutParams.height < 0) {
                layoutParams.height = 0;
            }
            if (layoutParams.height == 0) {
                this.isConfirm = false;
                this.mCurrentAction = -1;
            }
            this.headerView.setLayoutParams(layoutParams);
            this.onRefreshListener.onPullingDown(f2, layoutParams.height, this.refreshViewFlowHeight);
            notifyOnRefreshOffsetChangedListener(layoutParams.height);
            this.headerView.setProgressRotation(((float) layoutParams.height) / this.refreshViewFlowHeight);
            moveTargetView((float) layoutParams.height);
            return true;
        } else if (canChildScrollDown() || !this.mPullLoadEnable || this.mCurrentAction != 1) {
            return false;
        } else {
            FrameLayout.LayoutParams layoutParams2 = (FrameLayout.LayoutParams) this.footerView.getLayoutParams();
            layoutParams2.height = (int) (((float) layoutParams2.height) - f2);
            if (layoutParams2.height < 0) {
                layoutParams2.height = 0;
            }
            if (layoutParams2.height == 0) {
                this.isConfirm = false;
                this.mCurrentAction = -1;
            }
            this.footerView.setLayoutParams(layoutParams2);
            this.onLoadingListener.onPullingUp(f2, layoutParams2.height, this.loadingViewFlowHeight);
            this.footerView.setProgressRotation(((float) layoutParams2.height) / this.loadingViewFlowHeight);
            moveTargetView((float) (-layoutParams2.height));
            return true;
        }
    }

    public void moveTargetView(float f2) {
        this.mTargetView.setTranslationY(f2);
    }

    public void notifyOnRefreshOffsetChangedListener(int i2) {
        int size = this.mRefreshOffsetChangedListeners.size();
        int i3 = 0;
        while (i3 < size && i3 < this.mRefreshOffsetChangedListeners.size()) {
            OnRefreshOffsetChangedListener onRefreshOffsetChangedListener = this.mRefreshOffsetChangedListeners.get(i3);
            if (onRefreshOffsetChangedListener != null) {
                onRefreshOffsetChangedListener.onOffsetChanged(i2);
            }
            i3++;
        }
    }

    private void resetFootView(int i2) {
        this.footerView.stopAnimation();
        this.footerView.setStartEndTrim(0.5f, 1.25f);
        ValueAnimator ofFloat = ValueAnimator.ofFloat((float) i2, 0.0f);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.7
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.this$0.footerView.getLayoutParams();
                layoutParams.height = (int) ((Float) valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.footerView.setLayoutParams(layoutParams);
                this.this$0.moveTargetView((float) (-layoutParams.height));
            }
        });
        ofFloat.addListener(new WXRefreshAnimatorListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.8
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXRefreshAnimatorListener, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                this.this$0.resetLoadmoreState();
            }
        });
        ofFloat.setDuration(300L);
        ofFloat.start();
    }

    private void resetHeaderView(int i2) {
        this.headerView.stopAnimation();
        this.headerView.setStartEndTrim(0.0f, 0.75f);
        ValueAnimator ofFloat = ValueAnimator.ofFloat((float) i2, 0.0f);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.3
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.this$0.headerView.getLayoutParams();
                layoutParams.height = (int) ((Float) valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.notifyOnRefreshOffsetChangedListener(layoutParams.height);
                this.this$0.headerView.setLayoutParams(layoutParams);
                this.this$0.moveTargetView((float) layoutParams.height);
            }
        });
        ofFloat.addListener(new WXRefreshAnimatorListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.4
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXRefreshAnimatorListener, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                this.this$0.resetRefreshState();
            }
        });
        ofFloat.setDuration(300L);
        ofFloat.start();
    }

    public void resetLoadmoreState() {
        this.mRefreshing = false;
        this.isConfirm = false;
        this.mCurrentAction = -1;
    }

    public void resetRefreshState() {
        this.mRefreshing = false;
        this.isConfirm = false;
        this.mCurrentAction = -1;
    }

    private void setRefreshView() {
        ViewGroup.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, 0);
        WXRefreshView wXRefreshView = new WXRefreshView(getContext());
        this.headerView = wXRefreshView;
        wXRefreshView.setStartEndTrim(0.0f, 0.75f);
        this.headerView.setBackgroundColor(this.mRefreshViewBgColor);
        this.headerView.setProgressBgColor(this.mProgressBgColor);
        this.headerView.setProgressColor(this.mProgressColor);
        this.headerView.setContentGravity(80);
        addView(this.headerView, layoutParams);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, 0);
        layoutParams2.gravity = 80;
        WXRefreshView wXRefreshView2 = new WXRefreshView(getContext());
        this.footerView = wXRefreshView2;
        wXRefreshView2.setStartEndTrim(0.5f, 1.25f);
        this.footerView.setBackgroundColor(this.mRefreshViewBgColor);
        this.footerView.setProgressBgColor(this.mProgressBgColor);
        this.footerView.setProgressColor(this.mProgressColor);
        this.footerView.setContentGravity(48);
        addView(this.footerView, layoutParams2);
    }

    private void startLoadmore(int i2) {
        this.mRefreshing = true;
        ValueAnimator ofFloat = ValueAnimator.ofFloat((float) i2, this.loadingViewHeight);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.5
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.this$0.footerView.getLayoutParams();
                layoutParams.height = (int) ((Float) valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.footerView.setLayoutParams(layoutParams);
                this.this$0.moveTargetView((float) (-layoutParams.height));
            }
        });
        ofFloat.addListener(new WXRefreshAnimatorListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.6
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXRefreshAnimatorListener, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                this.this$0.footerView.startAnimation();
                if (this.this$0.onLoadingListener != null) {
                    this.this$0.onLoadingListener.onLoading();
                }
            }
        });
        ofFloat.setDuration(300L);
        ofFloat.start();
    }

    private void startRefresh(int i2) {
        this.mRefreshing = true;
        ValueAnimator ofFloat = ValueAnimator.ofFloat((float) i2, this.refreshViewHeight);
        ofFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.1
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.this$0.headerView.getLayoutParams();
                layoutParams.height = (int) ((Float) valueAnimator.getAnimatedValue()).floatValue();
                this.this$0.notifyOnRefreshOffsetChangedListener(layoutParams.height);
                this.this$0.headerView.setLayoutParams(layoutParams);
                this.this$0.moveTargetView((float) layoutParams.height);
            }
        });
        ofFloat.addListener(new WXRefreshAnimatorListener(this) { // from class: com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.2
            final WXSwipeLayout this$0;

            {
                this.this$0 = r4;
            }

            @Override // com.taobao.weex.ui.view.refresh.core.WXSwipeLayout.WXRefreshAnimatorListener, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                this.this$0.headerView.startAnimation();
                if (this.this$0.onRefreshListener != null) {
                    this.this$0.onRefreshListener.onRefresh();
                }
            }
        });
        ofFloat.setDuration(300L);
        ofFloat.start();
    }

    public void addOnRefreshOffsetChangedListener(OnRefreshOffsetChangedListener onRefreshOffsetChangedListener) {
        if (onRefreshOffsetChangedListener != null && !this.mRefreshOffsetChangedListeners.contains(onRefreshOffsetChangedListener)) {
            this.mRefreshOffsetChangedListeners.add(onRefreshOffsetChangedListener);
        }
    }

    public void addTargetView(View view) {
        addView(view, new FrameLayout.LayoutParams(-1, -1));
        setRefreshView();
    }

    public boolean canChildScrollDown() {
        if (this.mTargetView == null) {
            return false;
        }
        return ViewCompat.canScrollVertically(this.mTargetView, 1);
    }

    public boolean canChildScrollUp() {
        if (this.mTargetView == null) {
            return false;
        }
        return ViewCompat.canScrollVertically(this.mTargetView, -1);
    }

    public float dipToPx(Context context, float f2) {
        return TypedValue.applyDimension(1, f2, context.getResources().getDisplayMetrics());
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return this.mNestedScrollingChildHelper.dispatchNestedFling(f2, f3, z2);
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.mNestedScrollingChildHelper.dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.mNestedScrollingChildHelper.dispatchNestedPreScroll(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.mNestedScrollingChildHelper.dispatchNestedScroll(i2, i3, i4, i5, iArr);
    }

    public void finishPullLoad() {
        if (this.mCurrentAction == 1) {
            WXRefreshView wXRefreshView = this.footerView;
            resetFootView(wXRefreshView == null ? 0 : wXRefreshView.getMeasuredHeight());
        }
    }

    public void finishPullRefresh() {
        if (this.mCurrentAction == 0) {
            WXRefreshView wXRefreshView = this.headerView;
            resetHeaderView(wXRefreshView == null ? 0 : wXRefreshView.getMeasuredHeight());
        }
    }

    public WXRefreshView getFooterView() {
        return this.footerView;
    }

    public WXRefreshView getHeaderView() {
        return this.headerView;
    }

    @Override // android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public int getNestedScrollAxes() {
        return this.mNestedScrollingParentHelper.getNestedScrollAxes();
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean hasNestedScrollingParent() {
        return this.mNestedScrollingChildHelper.hasNestedScrollingParent();
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean isNestedScrollingEnabled() {
        return this.mNestedScrollingChildHelper.isNestedScrollingEnabled();
    }

    public boolean isPullLoadEnable() {
        return this.mPullLoadEnable;
    }

    public boolean isPullRefreshEnable() {
        return this.mPullRefreshEnable;
    }

    public boolean isRefreshing() {
        return this.mRefreshing;
    }

    @Override // android.view.View, android.view.ViewGroup
    protected void onAttachedToWindow() {
        onAttachedToWindow();
        if (this.mTargetView == null && getChildCount() > 0) {
            this.mTargetView = getChildAt(0);
        }
        if (this.mTargetView == null) {
            return;
        }
        if (this.headerView == null || this.footerView == null) {
            setRefreshView();
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if ((this.mPullRefreshEnable || this.mPullLoadEnable) && isEnabled() && !canChildScrollUp() && !this.mRefreshing && !this.mNestedScrollInProgress) {
            return onInterceptTouchEvent(motionEvent);
        }
        return false;
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (isNestedScrollingEnabled()) {
            return dispatchNestedFling(f2, f3, z2);
        }
        return false;
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        if (isNestedScrollingEnabled()) {
            return dispatchNestedPreFling(f2, f3);
        }
        return false;
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        ViewParent viewParent;
        int[] iArr2 = this.mParentScrollConsumed;
        if (isNestedScrollingEnabled() && dispatchNestedPreScroll(i2 - iArr[0], i3 - iArr[1], iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        } else if (this.mPullRefreshEnable || this.mPullLoadEnable) {
            if (!canChildScrollUp() && isNestedScrollingEnabled() && (viewParent = this.mNestedScrollAcceptedParent) != null && viewParent != this.mTargetView) {
                ViewGroup viewGroup = (ViewGroup) viewParent;
                if (viewGroup.getChildCount() > 0) {
                    int childCount = viewGroup.getChildCount();
                    int i4 = 0;
                    while (true) {
                        if (i4 >= childCount) {
                            break;
                        }
                        View childAt = viewGroup.getChildAt(i4);
                        if (childAt.getVisibility() == 8 || childAt.getMeasuredHeight() <= 0) {
                            i4++;
                        } else if (childAt.getTop() < 0) {
                            return;
                        }
                    }
                }
            }
            int calculateDistanceY = (int) calculateDistanceY(view, i3);
            this.mRefreshing = false;
            if (!this.isConfirm) {
                if (calculateDistanceY < 0 && !canChildScrollUp()) {
                    this.mCurrentAction = 0;
                    this.isConfirm = true;
                } else if (calculateDistanceY > 0 && !canChildScrollDown() && !this.mRefreshing) {
                    this.mCurrentAction = 1;
                    this.isConfirm = true;
                }
            }
            if (!moveSpinner((float) (-calculateDistanceY))) {
                return;
            }
            if (!canChildScrollUp() && this.mPullRefreshEnable && this.mTargetView.getTranslationY() > 0.0f && i3 > 0) {
                iArr[1] = iArr[1] + i3;
            } else if (canChildScrollDown() || !this.mPullLoadEnable || this.mTargetView.getTranslationY() >= 0.0f || i3 >= 0) {
                iArr[1] = iArr[1] + calculateDistanceY;
            } else {
                iArr[1] = iArr[1] + i3;
            }
        }
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        if (isNestedScrollingEnabled()) {
            dispatchNestedScroll(i2, i3, i4, i5, this.mParentOffsetInWindow);
        }
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.mNestedScrollingParentHelper.onNestedScrollAccepted(view, view2, i2);
        if (isNestedScrollingEnabled()) {
            startNestedScroll(i2 & 2);
            this.mNestedScrollInProgress = true;
        }
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        boolean z2 = true;
        boolean z3 = isEnabled() && !this.mRefreshing && (i2 & 2) != 0;
        z2 = z3;
        if (view2 instanceof WXRecyclerView) {
            WXRecyclerView wXRecyclerView = (WXRecyclerView) view2;
            z2 = z3;
            if (wXRecyclerView.isNestScroll()) {
                if (!z3 || !wXRecyclerView.isScrollTop()) {
                    z2 = false;
                }
            }
        }
        return z2;
    }

    @Override // android.view.ViewParent, android.view.ViewGroup, androidx.core.view.NestedScrollingParent
    public void onStopNestedScroll(View view) {
        this.mNestedScrollingParentHelper.onStopNestedScroll(view);
        handlerAction();
        if (isNestedScrollingEnabled()) {
            this.mNestedScrollInProgress = true;
            stopNestedScroll();
        }
    }

    public boolean removeOnRefreshOffsetChangedListener(OnRefreshOffsetChangedListener onRefreshOffsetChangedListener) {
        if (onRefreshOffsetChangedListener != null) {
            return this.mRefreshOffsetChangedListeners.remove(onRefreshOffsetChangedListener);
        }
        return false;
    }

    public void setLoadingBgColor(int i2) {
        this.footerView.setBackgroundColor(i2);
    }

    public void setLoadingHeight(int i2) {
        this.loadingViewHeight = (float) i2;
        this.loadingViewFlowHeight = this.loadingViewHeight * overFlow;
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public void setNestedScrollingEnabled(boolean z2) {
        this.mNestedScrollingChildHelper.setNestedScrollingEnabled(z2);
    }

    public void setOnLoadingListener(WXOnLoadingListener wXOnLoadingListener) {
        this.onLoadingListener = wXOnLoadingListener;
    }

    public void setOnRefreshListener(WXOnRefreshListener wXOnRefreshListener) {
        this.onRefreshListener = wXOnRefreshListener;
    }

    public void setPullLoadEnable(boolean z2) {
        this.mPullLoadEnable = z2;
    }

    public void setPullRefreshEnable(boolean z2) {
        this.mPullRefreshEnable = z2;
    }

    public void setRefreshBgColor(int i2) {
        this.headerView.setBackgroundColor(i2);
    }

    public void setRefreshHeight(int i2) {
        this.refreshViewHeight = (float) i2;
        this.refreshViewFlowHeight = this.refreshViewHeight * overFlow;
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public boolean startNestedScroll(int i2) {
        boolean startNestedScroll = this.mNestedScrollingChildHelper.startNestedScroll(i2);
        if (startNestedScroll && this.mNestedScrollAcceptedParent == null) {
            ViewParent parent = getParent();
            View view = this;
            while (true) {
                if (parent == null) {
                    break;
                } else if (ViewParentCompat.onStartNestedScroll(parent, view, this, i2)) {
                    this.mNestedScrollAcceptedParent = parent;
                    break;
                } else {
                    if (parent instanceof View) {
                        view = (View) parent;
                    }
                    parent = parent.getParent();
                    view = view;
                }
            }
        }
        return startNestedScroll;
    }

    @Override // android.view.View, androidx.core.view.NestedScrollingChild
    public void stopNestedScroll() {
        this.mNestedScrollingChildHelper.stopNestedScroll();
        if (this.mNestedScrollAcceptedParent != null) {
            this.mNestedScrollAcceptedParent = null;
        }
    }
}
