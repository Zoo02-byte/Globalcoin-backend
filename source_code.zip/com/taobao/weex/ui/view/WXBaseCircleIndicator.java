package com.taobao.weex.ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import androidx.viewpager.widget.ViewPager;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import com.taobao.weex.utils.WXViewUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXBaseCircleIndicator.class */
public class WXBaseCircleIndicator extends FrameLayout implements WXGestureObservable {
    private float circlePadding;
    private WXCircleViewPager mCircleViewPager;
    private ViewPager.OnPageChangeListener mListener;
    private float radius;
    private int realCurrentItem;
    private WXGesture wxGesture;
    private final Paint mPaintPage = new Paint();
    private final Paint mPaintFill = new Paint();
    private int pageColor = -3355444;
    private int fillColor = -12303292;

    public WXBaseCircleIndicator(Context context) {
        super(context);
        init();
    }

    public WXBaseCircleIndicator(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    private void init() {
        this.radius = (float) WXViewUtils.dip2px(5.0f);
        this.circlePadding = (float) WXViewUtils.dip2px(5.0f);
        this.pageColor = -3355444;
        this.fillColor = -12303292;
        this.mPaintFill.setStyle(Paint.Style.FILL);
        this.mPaintFill.setAntiAlias(true);
        this.mPaintPage.setAntiAlias(true);
        this.mPaintPage.setColor(this.pageColor);
        this.mPaintFill.setStyle(Paint.Style.FILL);
        this.mPaintFill.setColor(this.fillColor);
        setWillNotDraw(false);
    }

    @Override // android.view.View, android.view.ViewGroup
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        boolean dispatchTouchEvent = dispatchTouchEvent(motionEvent);
        WXGesture wXGesture = this.wxGesture;
        boolean z2 = dispatchTouchEvent;
        if (wXGesture != null) {
            z2 = dispatchTouchEvent | wXGesture.onTouch(this, motionEvent);
        }
        return z2;
    }

    public int getCount() {
        WXCircleViewPager wXCircleViewPager = this.mCircleViewPager;
        if (wXCircleViewPager == null || wXCircleViewPager.getAdapter() == null) {
            return 0;
        }
        return this.mCircleViewPager.getRealCount();
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.wxGesture;
    }

    public int getRealCurrentItem() {
        return this.realCurrentItem;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        onDraw(canvas);
        float f2 = (this.circlePadding + this.radius) * 2.0f;
        float width = (float) (getWidth() / 2);
        float count = (((float) (getCount() - 1)) * f2) / 2.0f;
        float height = (float) ((getHeight() / 2) + getPaddingTop());
        for (int i2 = 0; i2 < getCount(); i2++) {
            float f3 = (((float) i2) * f2) + (width - count);
            if (i2 != this.realCurrentItem) {
                canvas.drawCircle(f3, height, this.radius, this.mPaintPage);
            } else {
                canvas.drawCircle(f3, height, this.radius, this.mPaintFill);
            }
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (mode != 1073741824) {
            size = ((int) (((float) getPaddingLeft()) + (this.radius * 2.0f * ((float) getCount())) + (this.circlePadding * ((float) (getCount() - 1))) + ((float) getPaddingRight()))) + 1;
        }
        if (mode2 != 1073741824) {
            size2 = ((int) (((float) getPaddingTop()) + (this.radius * 2.0f) + ((float) getPaddingBottom()))) + 1;
        }
        setMeasuredDimension(size, size2);
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.wxGesture = wXGesture;
    }

    public void setCircleViewPager(WXCircleViewPager wXCircleViewPager) {
        this.mCircleViewPager = wXCircleViewPager;
        if (wXCircleViewPager != null) {
            if (this.mListener == null) {
                this.mListener = new ViewPager.SimpleOnPageChangeListener(this) { // from class: com.taobao.weex.ui.view.WXBaseCircleIndicator.1
                    final WXBaseCircleIndicator this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // androidx.viewpager.widget.ViewPager.SimpleOnPageChangeListener, androidx.viewpager.widget.ViewPager.OnPageChangeListener
                    public void onPageSelected(int i2) {
                        WXBaseCircleIndicator wXBaseCircleIndicator = this.this$0;
                        wXBaseCircleIndicator.realCurrentItem = wXBaseCircleIndicator.mCircleViewPager.getRealCurrentItem();
                        this.this$0.invalidate();
                    }
                };
            }
            this.mCircleViewPager.addOnPageChangeListener(this.mListener);
            int realCurrentItem = this.mCircleViewPager.getRealCurrentItem();
            this.realCurrentItem = realCurrentItem;
            if (realCurrentItem < 0) {
                this.realCurrentItem = 0;
            }
        }
        requestLayout();
    }

    public void setFillColor(int i2) {
        this.fillColor = i2;
        this.mPaintFill.setColor(i2);
    }

    public void setPageColor(int i2) {
        this.pageColor = i2;
        this.mPaintPage.setColor(i2);
    }

    public void setRadius(float f2) {
        this.radius = f2;
    }

    public void setRealCurrentItem(int i2) {
        this.realCurrentItem = i2;
        invalidate();
    }
}
