package com.taobao.weex.ui.view;

import android.content.Context;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXRefreshLayout.class */
public class WXRefreshLayout extends WXBaseRefreshLayout {
    public WXRefreshLayout(Context context) {
        super(context);
    }
}
