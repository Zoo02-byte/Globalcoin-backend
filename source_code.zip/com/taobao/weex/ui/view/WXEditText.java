package com.taobao.weex.ui.view;

import android.content.Context;
import android.text.method.BaseMovementMethod;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewParent;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import io.dcloud.common.core.ui.keyboard.DCEditText;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXEditText.class */
public class WXEditText extends DCEditText implements WXGestureObservable {
    private WXGesture wxGesture;
    private int mLines = 1;
    private boolean mAllowDisableMovement = true;
    private boolean mAllowCopyPaste = true;

    public WXEditText(Context context, String str) {
        super(context, str);
        setBackground(null);
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.wxGesture;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        onSizeChanged(i2, i3, i4, i5);
        if (getLayout() != null) {
            int height = getLayout().getHeight();
            if (!this.mAllowDisableMovement || i3 >= height) {
                setMovementMethod(getDefaultMovementMethod());
            } else {
                setMovementMethod(new BaseMovementMethod());
            }
        }
    }

    @Override // android.widget.TextView
    public boolean onTextContextMenuItem(int i2) {
        return !this.mAllowCopyPaste || onTextContextMenuItem(i2);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = onTouchEvent(motionEvent);
        WXGesture wXGesture = this.wxGesture;
        boolean z2 = onTouchEvent;
        if (wXGesture != null) {
            z2 = onTouchEvent | wXGesture.onTouch(this, motionEvent);
        }
        ViewParent parent = getParent();
        if (parent != null) {
            int action = motionEvent.getAction() & 255;
            if (action != 0) {
                if (action == 1 || action == 3) {
                    parent.requestDisallowInterceptTouchEvent(false);
                }
            } else if (this.mLines < getLineCount()) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
        return z2;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.wxGesture = wXGesture;
    }

    public void setAllowCopyPaste(boolean z2) {
        this.mAllowCopyPaste = z2;
        if (z2) {
            setLongClickable(true);
            setCustomSelectionActionModeCallback(null);
            setCustomInsertionActionModeCallback(null);
            return;
        }
        setLongClickable(false);
        AnonymousClass1 r02 = new ActionMode.Callback(this) { // from class: com.taobao.weex.ui.view.WXEditText.1
            final WXEditText this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.view.ActionMode.Callback
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                return false;
            }

            @Override // android.view.ActionMode.Callback
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            @Override // android.view.ActionMode.Callback
            public void onDestroyActionMode(ActionMode actionMode) {
            }

            @Override // android.view.ActionMode.Callback
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }
        };
        setCustomInsertionActionModeCallback(r02);
        setCustomSelectionActionModeCallback(r02);
    }

    public void setAllowDisableMovement(boolean z2) {
        this.mAllowDisableMovement = z2;
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        setLines(i2);
        this.mLines = i2;
    }
}
