package com.taobao.weex.ui.view;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.animation.Interpolator;
import androidx.viewpager.widget.ViewPager;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import com.taobao.weex.utils.WXLogUtils;
import java.lang.reflect.Field;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXCircleViewPager.class */
public class WXCircleViewPager extends ViewPager implements WXGestureObservable {
    private boolean isAutoScroll;
    private WXSmoothScroller mScroller;
    private WXGesture wxGesture;
    private final int SCROLL_TO_NEXT = 1;
    private long intervalTime = 3000;
    private boolean needLoop = true;
    private boolean scrollable = true;
    private int mState = 0;
    private Handler mAutoScrollHandler = new Handler(this, Looper.getMainLooper()) { // from class: com.taobao.weex.ui.view.WXCircleViewPager.1
        final WXCircleViewPager this$0;

        {
            this.this$0 = r4;
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what == 1) {
                WXLogUtils.d("[CircleViewPager] trigger auto play action");
                this.this$0.showNextItem();
                sendEmptyMessageDelayed(1, this.this$0.intervalTime);
                return;
            }
            handleMessage(message);
        }
    };

    public WXCircleViewPager(Context context) {
        super(context);
        init();
    }

    public WXCircleViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    private void init() {
        setOverScrollMode(2);
        addOnPageChangeListener(new ViewPager.OnPageChangeListener(this) { // from class: com.taobao.weex.ui.view.WXCircleViewPager.2
            final WXCircleViewPager this$0;

            {
                this.this$0 = r4;
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i2) {
                this.this$0.mState = i2;
                WXCirclePageAdapter circlePageAdapter = this.this$0.getCirclePageAdapter();
                int currentItem = this.this$0.getCurrentItem();
                if (this.this$0.needLoop && i2 == 0 && circlePageAdapter.getCount() > 1) {
                    if (currentItem == circlePageAdapter.getCount() - 1) {
                        this.this$0.superSetCurrentItem(1, false);
                        circlePageAdapter.getViews().get(0).setTranslationY(0.0f);
                        circlePageAdapter.getViews().get(0).setTranslationX(0.0f);
                    } else if (currentItem == 0) {
                        this.this$0.superSetCurrentItem(circlePageAdapter.getCount() - 2, false);
                        try {
                            circlePageAdapter.getViews().get(circlePageAdapter.getCount() - 3).setTranslationY(0.0f);
                            circlePageAdapter.getViews().get(circlePageAdapter.getCount() - 3).setTranslationX(0.0f);
                        } catch (Exception e2) {
                        }
                    }
                }
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i2, float f2, int i3) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageSelected(int i2) {
            }
        });
        postInitViewPager();
    }

    private void postInitViewPager() {
        if (!isInEditMode()) {
            try {
                Field declaredField = ViewPager.class.getDeclaredField("mScroller");
                declaredField.setAccessible(true);
                Field declaredField2 = ViewPager.class.getDeclaredField("sInterpolator");
                declaredField2.setAccessible(true);
                WXSmoothScroller wXSmoothScroller = new WXSmoothScroller(getContext(), (Interpolator) declaredField2.get(null));
                this.mScroller = wXSmoothScroller;
                declaredField.set(this, wXSmoothScroller);
            } catch (Exception e2) {
                WXLogUtils.e("[CircleViewPager] postInitViewPager: ", e2);
            }
        }
    }

    private void setRealCurrentItem(int i2, boolean z2) {
        superSetCurrentItem(((WXCirclePageAdapter) getAdapter()).getFirst() + i2, z2);
    }

    public void showNextItem() {
        if (getCirclePageAdapter() == null || !getCirclePageAdapter().isRTL) {
            if (!this.needLoop && superGetCurrentItem() == getRealCount() - 1) {
                return;
            }
            if (getRealCount() == 2 && superGetCurrentItem() == 1) {
                superSetCurrentItem(0, true);
            } else {
                superSetCurrentItem(superGetCurrentItem() + 1, true);
            }
        } else if (!this.needLoop && superGetCurrentItem() == 0) {
        } else {
            if (getRealCount() == 2 && superGetCurrentItem() == 0) {
                superSetCurrentItem(1, true);
            } else {
                superSetCurrentItem(superGetCurrentItem() - 1, true);
            }
        }
    }

    public void superSetCurrentItem(int i2, boolean z2) {
        try {
            try {
                if (Math.abs(i2 - getRealCurrentItem()) > 3 && this.needLoop && getRealCount() > 2 && i2 == getCirclePageAdapter().getCount() - 2) {
                    setCurrentItem(i2 - 2, false);
                }
            } catch (Exception e2) {
            }
            setCurrentItem(i2, z2);
        } catch (IllegalStateException e3) {
            WXLogUtils.e(e3.toString());
            if (getAdapter() != null) {
                getAdapter().notifyDataSetChanged();
                setCurrentItem(i2, z2);
            }
        }
    }

    public void destory() {
        this.mAutoScrollHandler.removeCallbacksAndMessages(null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0015, code lost:
        if (r0 != 3) goto L_0x003a;
     */
    /* JADX WARN: Removed duplicated region for block: B:17:0x004f A[Catch: Exception -> 0x005e, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x005e, blocks: (B:14:0x003a, B:17:0x004f), top: B:23:0x003a }] */
    @Override // android.view.ViewGroup, android.view.View
    /* Code decompiled incorrectly, please refer to instructions dump */
    public boolean dispatchTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            r0 = r6
            int r0 = r0.getAction()
            r7 = r0
            r0 = r7
            if (r0 == 0) goto L_0x0032
            r0 = r7
            r1 = 1
            if (r0 == r1) goto L_0x001b
            r0 = r7
            r1 = 2
            if (r0 == r1) goto L_0x0032
            r0 = r7
            r1 = 3
            if (r0 == r1) goto L_0x001b
            goto L_0x003a
        L_0x001b:
            r0 = r5
            boolean r0 = r0.isAutoScroll()
            if (r0 == 0) goto L_0x003a
            r0 = r5
            android.os.Handler r0 = r0.mAutoScrollHandler
            r1 = 1
            r2 = r5
            long r2 = r2.intervalTime
            boolean r0 = r0.sendEmptyMessageDelayed(r1, r2)
            goto L_0x003a
        L_0x0032:
            r0 = r5
            android.os.Handler r0 = r0.mAutoScrollHandler
            r1 = 0
            r0.removeCallbacksAndMessages(r1)
        L_0x003a:
            r0 = r5
            r1 = r6
            boolean r0 = r0.dispatchTouchEvent(r1)     // Catch: Exception -> 0x005e
            r9 = r0
            r0 = r5
            com.taobao.weex.ui.view.gesture.WXGesture r0 = r0.wxGesture     // Catch: Exception -> 0x005e
            r10 = r0
            r0 = r9
            r8 = r0
            r0 = r10
            if (r0 == 0) goto L_0x005c
            r0 = r10
            r1 = r5
            r2 = r6
            boolean r0 = r0.onTouch(r1, r2)     // Catch: Exception -> 0x005e
            r8 = r0
            r0 = r9
            r1 = r8
            r0 = r0 | r1
            r8 = r0
        L_0x005c:
            r0 = r8
            return r0
        L_0x005e:
            r6 = move-exception
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.view.WXCircleViewPager.dispatchTouchEvent(android.view.MotionEvent):boolean");
    }

    public WXCirclePageAdapter getCirclePageAdapter() {
        return (WXCirclePageAdapter) getAdapter();
    }

    @Override // androidx.viewpager.widget.ViewPager
    public int getCurrentItem() {
        return getRealCurrentItem();
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.wxGesture;
    }

    public long getIntervalTime() {
        return this.intervalTime;
    }

    public int getRealCount() {
        return ((WXCirclePageAdapter) getAdapter()).getRealCount();
    }

    public int getRealCurrentItem() {
        return ((WXCirclePageAdapter) getAdapter()).getRealPosition(getCurrentItem());
    }

    public WXSmoothScroller getmScroller() {
        return this.mScroller;
    }

    public boolean isAutoScroll() {
        return this.isAutoScroll;
    }

    public boolean isScrollable() {
        return this.scrollable;
    }

    @Override // androidx.viewpager.widget.ViewPager, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2 = false;
        try {
            if (this.scrollable) {
                z2 = false;
                if (onInterceptTouchEvent(motionEvent)) {
                    z2 = true;
                }
            }
            return z2;
        } catch (ArrayIndexOutOfBoundsException e2) {
            e2.printStackTrace();
            return false;
        } catch (IllegalArgumentException e3) {
            e3.printStackTrace();
            return false;
        }
    }

    @Override // androidx.viewpager.widget.ViewPager, android.view.View
    public void onMeasure(int i2, int i3) {
        try {
            onMeasure(i2, i3);
        } catch (IllegalStateException e2) {
            WXLogUtils.e(e2.toString());
            if (getAdapter() != null) {
                getAdapter().notifyDataSetChanged();
                onMeasure(i2, i3);
            }
        }
    }

    @Override // androidx.viewpager.widget.ViewPager, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.scrollable) {
            return false;
        }
        return onTouchEvent(motionEvent);
    }

    public void pauseAutoScroll() {
        this.mAutoScrollHandler.removeCallbacksAndMessages(null);
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.wxGesture = wXGesture;
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        if (this.scrollable || this.mState != 1) {
            scrollTo(i2, i3);
        }
    }

    public void setCircle(boolean z2) {
        this.needLoop = z2;
    }

    public void setCirclePageAdapter(WXCirclePageAdapter wXCirclePageAdapter) {
        setAdapter(wXCirclePageAdapter);
    }

    @Override // androidx.viewpager.widget.ViewPager
    public void setCurrentItem(int i2) {
        setRealCurrentItem(i2, true);
    }

    @Override // androidx.viewpager.widget.ViewPager
    public void setCurrentItem(int i2, boolean z2) {
        setRealCurrentItem(i2, z2);
    }

    public void setIntervalTime(long j2) {
        this.intervalTime = j2;
    }

    public void setScrollable(boolean z2) {
        this.scrollable = z2;
    }

    public void startAutoScroll() {
        this.isAutoScroll = true;
        this.mAutoScrollHandler.removeCallbacksAndMessages(null);
        this.mAutoScrollHandler.sendEmptyMessageDelayed(1, this.intervalTime);
    }

    public void stopAutoScroll() {
        this.isAutoScroll = false;
        this.mAutoScrollHandler.removeCallbacksAndMessages(null);
    }

    public int superGetCurrentItem() {
        return getCurrentItem();
    }
}
