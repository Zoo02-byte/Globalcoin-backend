package com.taobao.weex.ui.view.gesture;

import android.content.Context;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.bridge.EventResult;
import com.taobao.weex.common.Constants;
import com.taobao.weex.dom.WXEvent;
import com.taobao.weex.ui.component.Scrollable;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.view.gesture.WXGestureType;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.common.constant.AbsoluteConst;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/gesture/WXGesture.class */
public class WXGesture extends GestureDetector.SimpleOnGestureListener implements View.OnTouchListener {
    private static final int CUR_EVENT;
    public static final String DOWN;
    public static final String END;
    public static final String LEFT;
    public static final String MOVE;
    public static final String RIGHT;
    public static final String START;
    private static final String TAG;
    public static final String UNKNOWN;
    public static final String UP;
    private WXComponent component;
    private GestureDetector mGestureDetector;
    private int mParentOrientation;
    private int shouldBubbleInterval;
    private boolean shouldBubbleResult;
    private long swipeDownTime = -1;
    private long panDownTime = -1;
    private WXGestureType mPendingPan = null;
    private boolean mIsPreventMoveEvent = false;
    private boolean mIsTouchEventConsumed = false;
    private boolean requestDisallowInterceptTouchEvent = false;
    private int shouldBubbleCallRemainTimes = 0;
    private final List<View.OnTouchListener> mTouchListeners = new LinkedList();
    private Rect globalRect = new Rect();
    private Point globalOffset = new Point();
    private Point globalEventOffset = new Point();
    private PointF locEventOffset = new PointF();
    private PointF locLeftTop = new PointF();

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/gesture/WXGesture$GestureHandler.class */
    public static class GestureHandler extends Handler {
        public GestureHandler() {
            super(Looper.getMainLooper());
        }
    }

    public WXGesture(WXComponent wXComponent, Context context) {
        this.mParentOrientation = -1;
        this.shouldBubbleResult = true;
        this.shouldBubbleInterval = 0;
        this.component = wXComponent;
        this.mGestureDetector = new GestureDetector(context, this, new GestureHandler());
        Scrollable parentScroller = wXComponent.getParentScroller();
        if (parentScroller != null) {
            this.mParentOrientation = parentScroller.getOrientation();
        }
        this.shouldBubbleResult = WXUtils.getBoolean(wXComponent.getAttrs().get(Constants.Name.SHOULD_STOP_PROPAGATION_INIT_RESULT), true).booleanValue();
        this.shouldBubbleInterval = WXUtils.getNumberInt(wXComponent.getAttrs().get(Constants.Name.SHOULD_STOP_PROPAGATION_INTERVAL), 0);
    }

    private boolean containsSimplePan() {
        return this.component.containsGesture(WXGestureType.HighLevelGesture.PAN_START) || this.component.containsGesture(WXGestureType.HighLevelGesture.PAN_MOVE) || this.component.containsGesture(WXGestureType.HighLevelGesture.PAN_END);
    }

    private Map<String, Object> createFireEventParam(MotionEvent motionEvent, int i2, String str) {
        JSONArray jSONArray = new JSONArray(motionEvent.getPointerCount());
        if (motionEvent.getActionMasked() == 2) {
            for (int i3 = 0; i3 < motionEvent.getPointerCount(); i3++) {
                jSONArray.add(createJSONObject(motionEvent, i2, i3));
            }
        } else if (isPointerNumChanged(motionEvent)) {
            jSONArray.add(createJSONObject(motionEvent, -1, motionEvent.getActionIndex()));
        }
        HashMap hashMap = new HashMap();
        hashMap.put(WXGestureType.GestureInfo.HISTORICAL_XY, jSONArray);
        if (str != null) {
            hashMap.put("state", str);
        }
        return hashMap;
    }

    private JSONObject createJSONObject(PointF pointF, PointF pointF2, float f2) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put(WXGestureType.GestureInfo.PAGE_X, (Object) Float.valueOf(pointF2.x));
        jSONObject.put(WXGestureType.GestureInfo.PAGE_Y, (Object) Float.valueOf(pointF2.y));
        jSONObject.put(WXGestureType.GestureInfo.SCREEN_X, (Object) Float.valueOf(pointF.x));
        jSONObject.put(WXGestureType.GestureInfo.SCREEN_Y, (Object) Float.valueOf(pointF.y));
        jSONObject.put(WXGestureType.GestureInfo.POINTER_ID, (Object) Float.valueOf(f2));
        return jSONObject;
    }

    private JSONObject createJSONObject(MotionEvent motionEvent, int i2, int i3) {
        PointF pointF;
        PointF pointF2;
        if (i2 == -1) {
            pointF = getEventLocInPageCoordinate(motionEvent, i3);
            pointF2 = getEventLocInScreenCoordinate(motionEvent, i3);
        } else {
            pointF = getEventLocInPageCoordinate(motionEvent, i3, i2);
            pointF2 = getEventLocInScreenCoordinate(motionEvent, i3, i2);
        }
        JSONObject createJSONObject = createJSONObject(pointF2, pointF, (float) motionEvent.getPointerId(i3));
        float pressure = motionEvent.getPressure();
        if (pressure > 0.0f && pressure < 1.0f) {
            createJSONObject.put(AbsoluteConst.INSTALL_OPTIONS_FORCE, (Object) Float.valueOf(motionEvent.getPressure()));
        }
        return createJSONObject;
    }

    private List<Map<String, Object>> createMultipleFireEventParam(MotionEvent motionEvent, String str) {
        ArrayList arrayList = new ArrayList(motionEvent.getHistorySize() + 1);
        arrayList.add(createFireEventParam(motionEvent, -1, str));
        return arrayList;
    }

    private void finishDisallowInterceptTouchEvent(View view) {
        if (view.getParent() != null) {
            view.getParent().requestDisallowInterceptTouchEvent(false);
        }
    }

    private PointF getEventLocInPageCoordinate(float f2, float f3) {
        this.locEventOffset.set(f2, f3);
        this.locLeftTop.set(0.0f, 0.0f);
        this.component.computeVisiblePointInViewCoordinate(this.locLeftTop);
        this.locEventOffset.offset(this.locLeftTop.x, this.locLeftTop.y);
        return new PointF(WXViewUtils.getWebPxByWidth(this.locEventOffset.x, this.component.getInstance().getInstanceViewPortWidthWithFloat()), WXViewUtils.getWebPxByWidth(this.locEventOffset.y, this.component.getInstance().getInstanceViewPortWidthWithFloat()));
    }

    private PointF getEventLocInPageCoordinate(MotionEvent motionEvent, int i2) {
        return getEventLocInPageCoordinate(motionEvent, i2, -1);
    }

    private PointF getEventLocInPageCoordinate(MotionEvent motionEvent, int i2, int i3) {
        float f2;
        float f3;
        if (i3 == -1) {
            f2 = motionEvent.getX(i2);
            f3 = motionEvent.getY(i2);
        } else {
            f2 = motionEvent.getHistoricalX(i2, i3);
            f3 = motionEvent.getHistoricalY(i2, i3);
        }
        return getEventLocInPageCoordinate(f2, f3);
    }

    private PointF getEventLocInScreenCoordinate(float f2, float f3) {
        this.globalRect.set(0, 0, 0, 0);
        this.globalOffset.set(0, 0);
        this.globalEventOffset.set((int) f2, (int) f3);
        this.component.getRealView().getGlobalVisibleRect(this.globalRect, this.globalOffset);
        this.globalEventOffset.offset(this.globalOffset.x, this.globalOffset.y);
        return new PointF(WXViewUtils.getWebPxByWidth((float) this.globalEventOffset.x, this.component.getInstance().getInstanceViewPortWidthWithFloat()), WXViewUtils.getWebPxByWidth((float) this.globalEventOffset.y, this.component.getInstance().getInstanceViewPortWidthWithFloat()));
    }

    private PointF getEventLocInScreenCoordinate(MotionEvent motionEvent, int i2) {
        return getEventLocInScreenCoordinate(motionEvent, i2, -1);
    }

    private PointF getEventLocInScreenCoordinate(MotionEvent motionEvent, int i2, int i3) {
        float f2;
        float f3;
        if (i3 == -1) {
            f3 = motionEvent.getX(i2);
            f2 = motionEvent.getY(i2);
        } else {
            f3 = motionEvent.getHistoricalX(i2, i3);
            f2 = motionEvent.getHistoricalY(i2, i3);
        }
        return getEventLocInScreenCoordinate(f3, f2);
    }

    private List<Map<String, Object>> getHistoricalEvents(MotionEvent motionEvent) {
        ArrayList arrayList = new ArrayList(motionEvent.getHistorySize());
        if (motionEvent.getActionMasked() == 2) {
            for (int i2 = 0; i2 < motionEvent.getHistorySize(); i2++) {
                arrayList.add(createFireEventParam(motionEvent, i2, null));
            }
        }
        return arrayList;
    }

    private String getPanEventAction(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        return action != 0 ? action != 1 ? action != 2 ? action != 3 ? "unknown" : "end" : MOVE : "end" : "start";
    }

    private boolean handleMotionEvent(WXGestureType wXGestureType, MotionEvent motionEvent) {
        if (this.component.getHover() != null) {
            this.component.getHover().handleMotionEvent(wXGestureType, motionEvent);
        }
        if (!this.component.containsGesture(wXGestureType)) {
            return false;
        }
        for (Map<String, Object> map : createMultipleFireEventParam(motionEvent, null)) {
            this.component.fireEvent(wXGestureType.toString(), map);
        }
        return true;
    }

    private boolean handlePanMotionEvent(MotionEvent motionEvent) {
        WXGestureType wXGestureType = this.mPendingPan;
        if (wXGestureType == null) {
            return false;
        }
        String panEventAction = (wXGestureType == WXGestureType.HighLevelGesture.HORIZONTALPAN || this.mPendingPan == WXGestureType.HighLevelGesture.VERTICALPAN) ? getPanEventAction(motionEvent) : null;
        if (!this.component.containsGesture(this.mPendingPan)) {
            return false;
        }
        if (this.mIsPreventMoveEvent && MOVE.equals(panEventAction)) {
            return true;
        }
        for (Map<String, Object> map : createMultipleFireEventParam(motionEvent, panEventAction)) {
            this.component.fireEvent(this.mPendingPan.toString(), map);
        }
        if (!(motionEvent.getAction() == 1 || motionEvent.getAction() == 3)) {
            return true;
        }
        this.mPendingPan = null;
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x0017, code lost:
        if (r3.component.containsGesture(com.taobao.weex.ui.view.gesture.WXGestureType.HighLevelGesture.HORIZONTALPAN) == false) goto L_0x001a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private boolean hasSameOrientationWithParent() {
        /*
            r3 = this;
            r0 = r3
            int r0 = r0.mParentOrientation
            r4 = r0
            r0 = 1
            r6 = r0
            r0 = r4
            if (r0 != 0) goto L_0x001a
            r0 = r6
            r5 = r0
            r0 = r3
            com.taobao.weex.ui.component.WXComponent r0 = r0.component
            com.taobao.weex.ui.view.gesture.WXGestureType$HighLevelGesture r1 = com.taobao.weex.ui.view.gesture.WXGestureType.HighLevelGesture.HORIZONTALPAN
            boolean r0 = r0.containsGesture(r1)
            if (r0 != 0) goto L_0x0036
        L_0x001a:
            r0 = r3
            int r0 = r0.mParentOrientation
            r1 = 1
            if (r0 != r1) goto L_0x0034
            r0 = r3
            com.taobao.weex.ui.component.WXComponent r0 = r0.component
            com.taobao.weex.ui.view.gesture.WXGestureType$HighLevelGesture r1 = com.taobao.weex.ui.view.gesture.WXGestureType.HighLevelGesture.VERTICALPAN
            boolean r0 = r0.containsGesture(r1)
            if (r0 == 0) goto L_0x0034
            r0 = r6
            r5 = r0
            goto L_0x0036
        L_0x0034:
            r0 = 0
            r5 = r0
        L_0x0036:
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.view.gesture.WXGesture.hasSameOrientationWithParent():boolean");
    }

    public static boolean hasStopPropagation(WXComponent wXComponent) {
        WXEvent events = wXComponent.getEvents();
        if (events == null) {
            return false;
        }
        int size = events.size();
        int i2 = 0;
        while (i2 < size && i2 < events.size()) {
            if (isStopPropagation((String) events.get(i2))) {
                return true;
            }
            i2++;
        }
        return false;
    }

    private boolean isParentScrollable() {
        WXComponent wXComponent = this.component;
        if (wXComponent == null) {
            return true;
        }
        Scrollable parentScroller = wXComponent.getParentScroller();
        boolean z2 = true;
        if (parentScroller != null) {
            z2 = parentScroller.isScrollable();
        }
        return z2;
    }

    private boolean isPointerNumChanged(MotionEvent motionEvent) {
        boolean z2 = true;
        if (motionEvent.getActionMasked() != 0) {
            z2 = true;
            if (motionEvent.getActionMasked() != 5) {
                z2 = true;
                if (motionEvent.getActionMasked() != 1) {
                    z2 = true;
                    if (motionEvent.getActionMasked() != 6) {
                        z2 = motionEvent.getActionMasked() == 3;
                    }
                }
            }
        }
        return z2;
    }

    public static boolean isStopPropagation(String str) {
        return Constants.Event.STOP_PROPAGATION.equals(str) || Constants.Event.STOP_PROPAGATION_RAX.equals(str);
    }

    private boolean shouldBubbleTouchEvent(MotionEvent motionEvent) {
        int i2;
        if (!hasStopPropagation(this.component)) {
            return true;
        }
        if (this.shouldBubbleInterval <= 0 || (i2 = this.shouldBubbleCallRemainTimes) <= 0) {
            Map<String, Object> createFireEventParam = createFireEventParam(motionEvent, -1, null);
            createFireEventParam.put("type", "touch");
            if (motionEvent.getAction() == 0) {
                createFireEventParam.put("action", "start");
            } else if (motionEvent.getAction() == 3 || motionEvent.getAction() == 1) {
                createFireEventParam.put("action", "end");
            } else {
                createFireEventParam.put("action", MOVE);
            }
            WXEvent events = this.component.getEvents();
            String str = Constants.Event.STOP_PROPAGATION;
            if (!events.contains(Constants.Event.STOP_PROPAGATION)) {
                str = Constants.Event.STOP_PROPAGATION_RAX;
            }
            EventResult fireEventWait = this.component.fireEventWait(str, createFireEventParam);
            if (fireEventWait.isSuccess() && fireEventWait.getResult() != null) {
                this.shouldBubbleResult = !WXUtils.getBoolean(fireEventWait.getResult(), Boolean.valueOf(!this.shouldBubbleResult)).booleanValue();
            }
            this.shouldBubbleCallRemainTimes = this.shouldBubbleInterval;
            return this.shouldBubbleResult;
        }
        this.shouldBubbleCallRemainTimes = i2 - 1;
        return this.shouldBubbleResult;
    }

    public void addOnTouchListener(View.OnTouchListener onTouchListener) {
        if (onTouchListener != null) {
            this.mTouchListeners.add(onTouchListener);
        }
    }

    public boolean isRequestDisallowInterceptTouchEvent() {
        return this.requestDisallowInterceptTouchEvent;
    }

    public boolean isTouchEventConsumedByAdvancedGesture() {
        return this.mIsTouchEventConsumed;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public void onLongPress(MotionEvent motionEvent) {
        if (this.component.containsGesture(WXGestureType.HighLevelGesture.LONG_PRESS)) {
            List<Map<String, Object>> createMultipleFireEventParam = createMultipleFireEventParam(motionEvent, null);
            this.component.getInstance().fireEvent(this.component.getRef(), WXGestureType.HighLevelGesture.LONG_PRESS.toString(), createMultipleFireEventParam.get(createMultipleFireEventParam.size() - 1));
            this.mIsTouchEventConsumed = true;
        }
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3) {
        boolean z2;
        boolean z3 = false;
        if (motionEvent == null || motionEvent2 == null) {
            return false;
        }
        WXGestureType.HighLevelGesture highLevelGesture = Math.abs(motionEvent2.getX() - motionEvent.getX()) > Math.abs(motionEvent2.getY() - motionEvent.getY()) ? WXGestureType.HighLevelGesture.HORIZONTALPAN : WXGestureType.HighLevelGesture.VERTICALPAN;
        if (this.mPendingPan == WXGestureType.HighLevelGesture.HORIZONTALPAN || this.mPendingPan == WXGestureType.HighLevelGesture.VERTICALPAN) {
            z2 = handlePanMotionEvent(motionEvent2);
        } else {
            if (this.component.containsGesture(highLevelGesture)) {
                ViewParent parent = this.component.getRealView().getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                WXGestureType wXGestureType = this.mPendingPan;
                if (wXGestureType != null) {
                    handleMotionEvent(wXGestureType, motionEvent2);
                }
                this.mPendingPan = highLevelGesture;
                this.component.fireEvent(highLevelGesture.toString(), createFireEventParam(motionEvent2, -1, "start"));
            } else if (containsSimplePan()) {
                if (this.panDownTime != motionEvent.getEventTime()) {
                    this.panDownTime = motionEvent.getEventTime();
                    this.mPendingPan = WXGestureType.HighLevelGesture.PAN_END;
                    this.component.fireEvent(WXGestureType.HighLevelGesture.PAN_START.toString(), createFireEventParam(motionEvent, -1, null));
                } else {
                    this.component.fireEvent(WXGestureType.HighLevelGesture.PAN_MOVE.toString(), createFireEventParam(motionEvent2, -1, null));
                }
            } else if (!this.component.containsGesture(WXGestureType.HighLevelGesture.SWIPE) || this.swipeDownTime == motionEvent.getEventTime()) {
                z2 = false;
            } else {
                this.swipeDownTime = motionEvent.getEventTime();
                List<Map<String, Object>> createMultipleFireEventParam = createMultipleFireEventParam(motionEvent2, null);
                Map<String, Object> map = createMultipleFireEventParam.get(createMultipleFireEventParam.size() - 1);
                if (Math.abs(f2) > Math.abs(f3)) {
                    map.put("direction", f2 > 0.0f ? "left" : "right");
                } else {
                    map.put("direction", f3 > 0.0f ? "up" : "down");
                }
                this.component.getInstance().fireEvent(this.component.getRef(), WXGestureType.HighLevelGesture.SWIPE.toString(), map);
            }
            z2 = true;
        }
        if (this.mIsTouchEventConsumed || z2) {
            z3 = true;
        }
        this.mIsTouchEventConsumed = z3;
        return z2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:29:0x0087, code lost:
        if (r0 != 6) goto L_0x018a;
     */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0194 A[Catch: Exception -> 0x01f4, TRY_LEAVE, TryCatch #0 {Exception -> 0x01f4, blocks: (B:6:0x000e, B:10:0x002b, B:12:0x0035, B:15:0x0044, B:17:0x004e, B:18:0x0067, B:30:0x008d, B:32:0x00a9, B:34:0x00b3, B:36:0x00d2, B:37:0x00e2, B:39:0x00fe, B:41:0x0108, B:43:0x0127, B:45:0x0133, B:47:0x013a, B:49:0x014b, B:51:0x0155, B:53:0x0164, B:55:0x016e, B:57:0x018a, B:59:0x0194, B:61:0x01a0, B:63:0x01b5, B:65:0x01bf, B:67:0x01cc, B:69:0x01d2, B:71:0x01ec), top: B:77:0x000e }] */
    @Override // android.view.View.OnTouchListener
    /* Code decompiled incorrectly, please refer to instructions dump */
    public boolean onTouch(android.view.View r6, android.view.MotionEvent r7) {
        /*
        // Method dump skipped, instructions count: 510
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.view.gesture.WXGesture.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    public boolean removeTouchListener(View.OnTouchListener onTouchListener) {
        if (onTouchListener != null) {
            return this.mTouchListeners.remove(onTouchListener);
        }
        return false;
    }

    public void setPreventMoveEvent(boolean z2) {
        this.mIsPreventMoveEvent = z2;
    }

    public void setRequestDisallowInterceptTouchEvent(boolean z2) {
        this.requestDisallowInterceptTouchEvent = z2;
    }
}
