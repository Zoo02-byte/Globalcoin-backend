package com.taobao.weex.ui.view.gesture;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/gesture/WXGestureObservable.class */
public interface WXGestureObservable {
    WXGesture getGestureListener();

    void registerGestureListener(WXGesture wXGesture);
}
