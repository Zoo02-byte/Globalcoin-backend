package com.taobao.weex.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.taobao.weex.ui.component.WXImage;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import com.taobao.weex.utils.ImageDrawable;
import com.taobao.weex.utils.WXLogUtils;
import java.lang.ref.WeakReference;
import java.util.Arrays;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXImageView.class */
public class WXImageView extends ImageView implements WXGestureObservable, IRenderStatus<WXImage>, IRenderResult<WXImage>, WXImage.Measurable {
    private float[] borderRadius;
    private boolean gif;
    private boolean mOutWindowVisibilityChangedReally;
    private WeakReference<WXImage> mWeakReference;
    private WXGesture wxGesture;
    private boolean isBitmapReleased = false;
    private boolean enableBitmapAutoManage = true;

    public WXImageView(Context context) {
        super(context);
    }

    public void autoRecoverImage() {
        if (this.enableBitmapAutoManage && this.isBitmapReleased) {
            WXImage component = getComponent();
            if (component != null) {
                component.autoRecoverImage();
            }
            this.isBitmapReleased = false;
        }
    }

    public void autoReleaseImage() {
        if (this.enableBitmapAutoManage && !this.isBitmapReleased) {
            this.isBitmapReleased = true;
            WXImage component = getComponent();
            if (component != null) {
                component.autoReleaseImage();
            }
        }
    }

    @Override // android.view.View
    public void dispatchWindowVisibilityChanged(int i2) {
        this.mOutWindowVisibilityChangedReally = true;
        dispatchWindowVisibilityChanged(i2);
        this.mOutWindowVisibilityChangedReally = false;
    }

    @Override // com.taobao.weex.ui.view.IRenderResult
    public WXImage getComponent() {
        WeakReference<WXImage> weakReference = this.mWeakReference;
        return weakReference != null ? weakReference.get() : null;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.wxGesture;
    }

    @Override // com.taobao.weex.ui.component.WXImage.Measurable
    public int getNaturalHeight() {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            return -1;
        }
        if (drawable instanceof ImageDrawable) {
            return ((ImageDrawable) drawable).getBitmapHeight();
        }
        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            if (bitmap != null) {
                return bitmap.getHeight();
            }
            WXLogUtils.w("WXImageView", "Bitmap on " + drawable.toString() + " is null");
            return -1;
        }
        WXLogUtils.w("WXImageView", "Not supported drawable type: " + drawable.getClass().getSimpleName());
        return -1;
    }

    @Override // com.taobao.weex.ui.component.WXImage.Measurable
    public int getNaturalWidth() {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            return -1;
        }
        if (drawable instanceof ImageDrawable) {
            return ((ImageDrawable) drawable).getBitmapWidth();
        }
        if (drawable instanceof BitmapDrawable) {
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            if (bitmap != null) {
                return bitmap.getWidth();
            }
            WXLogUtils.w("WXImageView", "Bitmap on " + drawable.toString() + " is null");
            return -1;
        }
        WXLogUtils.w("WXImageView", "Not supported drawable type: " + drawable.getClass().getSimpleName());
        return -1;
    }

    public void holdComponent(WXImage wXImage) {
        this.mWeakReference = new WeakReference<>(wXImage);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onAttachedToWindow() {
        onAttachedToWindow();
        autoRecoverImage();
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDetachedFromWindow() {
        onDetachedFromWindow();
        autoReleaseImage();
    }

    @Override // android.view.View
    public void onFinishTemporaryDetach() {
        onFinishTemporaryDetach();
        autoRecoverImage();
    }

    @Override // android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            setImageDrawable(getDrawable(), this.gif);
        }
    }

    @Override // android.view.View
    public void onStartTemporaryDetach() {
        onStartTemporaryDetach();
        autoReleaseImage();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = onTouchEvent(motionEvent);
        WXGesture wXGesture = this.wxGesture;
        boolean z2 = onTouchEvent;
        if (wXGesture != null) {
            z2 = onTouchEvent | wXGesture.onTouch(this, motionEvent);
        }
        return z2;
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i2) {
        onWindowVisibilityChanged(i2);
        if (!this.mOutWindowVisibilityChangedReally) {
            return;
        }
        if (i2 == 0) {
            autoRecoverImage();
        } else {
            autoReleaseImage();
        }
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.wxGesture = wXGesture;
    }

    public void setBorderRadius(float[] fArr) {
        this.borderRadius = fArr;
    }

    public void setEnableBitmapAutoManage(boolean z2) {
        this.enableBitmapAutoManage = z2;
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        setImageDrawable(bitmap == null ? null : new BitmapDrawable(getResources(), bitmap));
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        setImageDrawable(drawable, this.gif);
    }

    public void setImageDrawable(Drawable drawable, boolean z2) {
        WXImage wXImage;
        this.gif = z2;
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams != null) {
            Drawable createImageDrawable = ImageDrawable.createImageDrawable(drawable, getScaleType(), this.borderRadius, (layoutParams.width - getPaddingLeft()) - getPaddingRight(), (layoutParams.height - getPaddingTop()) - getPaddingBottom(), z2);
            if (createImageDrawable instanceof ImageDrawable) {
                ImageDrawable imageDrawable = (ImageDrawable) createImageDrawable;
                if (!Arrays.equals(imageDrawable.getCornerRadii(), this.borderRadius)) {
                    imageDrawable.setCornerRadii(this.borderRadius);
                }
            }
            setImageDrawable(createImageDrawable);
            WeakReference<WXImage> weakReference = this.mWeakReference;
            if (weakReference != null && (wXImage = weakReference.get()) != null) {
                wXImage.readyToRender();
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        setImageDrawable(getResources().getDrawable(i2));
    }
}
