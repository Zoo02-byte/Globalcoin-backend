package com.taobao.weex.ui.view.border;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.SparseIntArray;
import com.taobao.weex.dom.CSSShorthand;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXViewUtils;
import io.dcloud.feature.uniapp.ui.shadow.UniBoxShadowData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderDrawable.class */
public class BorderDrawable extends Drawable {
    public static final int BORDER_BOTTOM_LEFT_RADIUS;
    public static final int BORDER_BOTTOM_RIGHT_RADIUS;
    public static final int BORDER_RADIUS_ALL;
    public static final int BORDER_TOP_LEFT_RADIUS;
    public static final int BORDER_TOP_RIGHT_RADIUS;
    static final int DEFAULT_BORDER_COLOR;
    static final float DEFAULT_BORDER_WIDTH;
    private static final String TAG;
    private SparseIntArray mBorderColor;
    private CSSShorthand<CSSShorthand.CORNER> mBorderRadius;
    private SparseIntArray mBorderStyle;
    private CSSShorthand<CSSShorthand.EDGE> mBorderWidth;
    private BottomLeftCorner mBottomLeftCorner;
    private BottomRightCorner mBottomRightCorner;
    private CSSShorthand<CSSShorthand.CORNER> mOverlappingBorderRadius;
    private Path mPathForBorderOutline;
    private RectF mRectBounds;
    private TopLeftCorner mTopLeftCorner;
    private TopRightCorner mTopRightCorner;
    private static final BorderStyle DEFAULT_BORDER_STYLE = BorderStyle.SOLID;
    private static BorderStyle[] sBorderStyle = BorderStyle.values();
    private final Paint mPaint = new Paint(1);
    private boolean mNeedUpdatePath = false;
    private int mColor = 0;
    private Shader mShader = null;
    private int mAlpha = 255;
    private final BorderEdge mBorderEdge = new BorderEdge();
    UniBoxShadowData mBoxShadowData = null;

    private void drawBorders(Canvas canvas) {
        int i2;
        RectF rectF = this.mRectBounds;
        if (rectF == null) {
            this.mRectBounds = new RectF(getBounds());
        } else {
            rectF.set(getBounds());
        }
        UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
        r15 = 0;
        int i3 = 0;
        if (uniBoxShadowData != null) {
            i2 = uniBoxShadowData.getNormalTop() > 0 ? this.mBoxShadowData.getNormalTop() / 2 : 0;
            if (this.mBoxShadowData.getNormalLeft() > 0) {
                i3 = this.mBoxShadowData.getNormalLeft() / 2;
            }
            this.mRectBounds.inset((float) i3, (float) i2);
        } else {
            i2 = 0;
        }
        CSSShorthand<CSSShorthand.EDGE> cSSShorthand = this.mBorderWidth;
        if (cSSShorthand != null) {
            float f2 = cSSShorthand.get(CSSShorthand.EDGE.LEFT);
            float f3 = this.mBorderWidth.get(CSSShorthand.EDGE.TOP);
            float f4 = this.mBorderWidth.get(CSSShorthand.EDGE.BOTTOM);
            float f5 = this.mBorderWidth.get(CSSShorthand.EDGE.RIGHT);
            if (this.mTopLeftCorner == null) {
                this.mTopLeftCorner = new TopLeftCorner();
            }
            this.mTopLeftCorner.set(getBorderRadius(CSSShorthand.CORNER.BORDER_TOP_LEFT), f2, f3, this.mRectBounds);
            if (this.mTopRightCorner == null) {
                this.mTopRightCorner = new TopRightCorner();
            }
            this.mTopRightCorner.set(getBorderRadius(CSSShorthand.CORNER.BORDER_TOP_RIGHT), f3, f5, this.mRectBounds);
            if (this.mBottomRightCorner == null) {
                this.mBottomRightCorner = new BottomRightCorner();
            }
            this.mBottomRightCorner.set(getBorderRadius(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT), f5, f4, this.mRectBounds);
            if (this.mBottomLeftCorner == null) {
                this.mBottomLeftCorner = new BottomLeftCorner();
            }
            this.mBottomLeftCorner.set(getBorderRadius(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT), f4, f2, this.mRectBounds);
            if (!isDefAllDrawRoundRect(canvas, f2, f3, f4, f5)) {
                canvas.translate((float) i3, (float) i2);
                drawOneSide(canvas, this.mBorderEdge.set(this.mTopLeftCorner, this.mTopRightCorner, f3, CSSShorthand.EDGE.TOP));
                drawOneSide(canvas, this.mBorderEdge.set(this.mTopRightCorner, this.mBottomRightCorner, f5, CSSShorthand.EDGE.RIGHT));
                drawOneSide(canvas, this.mBorderEdge.set(this.mBottomRightCorner, this.mBottomLeftCorner, f4, CSSShorthand.EDGE.BOTTOM));
                drawOneSide(canvas, this.mBorderEdge.set(this.mBottomLeftCorner, this.mTopLeftCorner, f2, CSSShorthand.EDGE.LEFT));
            }
        }
    }

    private void drawOneSide(Canvas canvas, BorderEdge borderEdge) {
        if (0.0f != borderEdge.getBorderWidth()) {
            preparePaint(borderEdge.getEdge());
            borderEdge.drawEdge(canvas, this.mPaint);
        }
    }

    private float getBorderRadius(CSSShorthand.CORNER corner) {
        CSSShorthand<CSSShorthand.CORNER> cSSShorthand = this.mOverlappingBorderRadius;
        if (cSSShorthand != null) {
            return cSSShorthand.get(corner);
        }
        return 0.0f;
    }

    private float getScaleFactor(RectF rectF) {
        float f2 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT);
        float f3 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT);
        float f4 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT);
        float f5 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT);
        float f6 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT);
        float f7 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT);
        float f8 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT);
        float f9 = this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT);
        ArrayList arrayList = new ArrayList(4);
        updateFactor(arrayList, rectF.width(), f2 + f3);
        updateFactor(arrayList, rectF.height(), f4 + f5);
        updateFactor(arrayList, rectF.width(), f6 + f7);
        updateFactor(arrayList, rectF.height(), f8 + f9);
        return arrayList.isEmpty() ? Float.NaN : ((Float) Collections.min(arrayList)).floatValue();
    }

    private boolean isDefAllDrawRoundRect(Canvas canvas, float f2, float f3, float f4, float f5) {
        float outerCornerRadius = this.mTopLeftCorner.getOuterCornerRadius();
        if (outerCornerRadius <= 0.0f || outerCornerRadius != this.mTopRightCorner.getOuterCornerRadius() || outerCornerRadius != this.mBottomLeftCorner.getOuterCornerRadius() || outerCornerRadius != this.mBottomRightCorner.getOuterCornerRadius() || f2 <= 0.0f || f2 != f3 || f2 != f4 || f2 != f5) {
            return false;
        }
        int multiplyColorAlpha = WXViewUtils.multiplyColorAlpha(getBorderColor(CSSShorthand.EDGE.LEFT), this.mAlpha);
        int multiplyColorAlpha2 = WXViewUtils.multiplyColorAlpha(getBorderColor(CSSShorthand.EDGE.TOP), this.mAlpha);
        int multiplyColorAlpha3 = WXViewUtils.multiplyColorAlpha(getBorderColor(CSSShorthand.EDGE.BOTTOM), this.mAlpha);
        int multiplyColorAlpha4 = WXViewUtils.multiplyColorAlpha(getBorderColor(CSSShorthand.EDGE.RIGHT), this.mAlpha);
        if (multiplyColorAlpha != multiplyColorAlpha2 || multiplyColorAlpha != multiplyColorAlpha3 || multiplyColorAlpha != multiplyColorAlpha4) {
            return false;
        }
        preparePaint(this.mBorderEdge.set(this.mTopLeftCorner, this.mTopRightCorner, f3, CSSShorthand.EDGE.TOP).getEdge());
        this.mPaint.setStrokeWidth(f2);
        RectF rectF = new RectF();
        float f6 = f2 / 2.0f;
        rectF.top = this.mRectBounds.top + f6;
        rectF.bottom = this.mRectBounds.bottom - f6;
        rectF.left = this.mRectBounds.left + f6;
        rectF.right = this.mRectBounds.right - f6;
        canvas.drawRoundRect(rectF, outerCornerRadius, outerCornerRadius, this.mPaint);
        return true;
    }

    private void prepareBorderPath(int i2, int i3, int i4, int i5, RectF rectF, Path path) {
        UniBoxShadowData uniBoxShadowData = this.mBoxShadowData;
        if (uniBoxShadowData != null) {
            rectF.inset((float) (this.mBoxShadowData.getNormalLeft() > 0 ? this.mBoxShadowData.getNormalLeft() / 2 : 0), (float) (uniBoxShadowData.getNormalTop() > 0 ? this.mBoxShadowData.getNormalTop() / 2 : 0));
        }
        if (this.mBorderRadius != null) {
            prepareBorderRadius(rectF);
            if (this.mOverlappingBorderRadius == null) {
                this.mOverlappingBorderRadius = new CSSShorthand<>();
            }
            float f2 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT);
            float f3 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT);
            float f4 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT);
            float f5 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT);
            float f6 = (float) i5;
            float f7 = (float) i2;
            float f8 = (float) i3;
            float f9 = (float) i4;
            path.addRoundRect(rectF, new float[]{f2 - f6, f2 - f7, f3 - f8, f3 - f7, f4 - f8, f4 - f9, f5 - f6, f5 - f9}, Path.Direction.CW);
            return;
        }
        path.addRect(rectF, Path.Direction.CW);
    }

    private void prepareBorderRadius(RectF rectF) {
        if (this.mBorderRadius != null) {
            float scaleFactor = getScaleFactor(rectF);
            if (this.mOverlappingBorderRadius == null) {
                this.mOverlappingBorderRadius = new CSSShorthand<>();
            }
            if (Float.isNaN(scaleFactor) || scaleFactor >= 1.0f) {
                this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_TOP_LEFT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT));
                this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_TOP_RIGHT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT));
                this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT));
                this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT));
                return;
            }
            this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_TOP_LEFT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT) * scaleFactor);
            this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_TOP_RIGHT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT) * scaleFactor);
            this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT) * scaleFactor);
            this.mOverlappingBorderRadius.set(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT, this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT) * scaleFactor);
        }
    }

    private void preparePaint(CSSShorthand.EDGE edge) {
        float f2 = this.mBorderWidth.get(edge);
        int multiplyColorAlpha = WXViewUtils.multiplyColorAlpha(getBorderColor(edge), this.mAlpha);
        this.mPaint.setShader(sBorderStyle[getBorderStyle(edge)].getLineShader(f2, multiplyColorAlpha, edge));
        this.mPaint.setColor(multiplyColorAlpha);
        this.mPaint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void updateBorderOutline() {
        if (this.mNeedUpdatePath) {
            this.mNeedUpdatePath = false;
            if (this.mPathForBorderOutline == null) {
                this.mPathForBorderOutline = new Path();
            }
            this.mPathForBorderOutline.reset();
            prepareBorderPath(0, 0, 0, 0, new RectF(getBounds()), this.mPathForBorderOutline);
        }
    }

    private void updateFactor(List<Float> list, float f2, float f3) {
        if (f3 != 0.0f) {
            list.add(Float.valueOf(f2 / f3));
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        canvas.save();
        updateBorderOutline();
        this.mPaint.setAlpha(255);
        if (this.mPathForBorderOutline != null) {
            int multiplyColorAlpha = WXViewUtils.multiplyColorAlpha(this.mColor, this.mAlpha);
            Shader shader = this.mShader;
            if (shader != null) {
                this.mPaint.setShader(shader);
                this.mPaint.setStyle(Paint.Style.FILL);
                canvas.drawPath(this.mPathForBorderOutline, this.mPaint);
                this.mPaint.setShader(null);
            } else if ((multiplyColorAlpha >>> 24) != 0) {
                this.mPaint.setColor(multiplyColorAlpha);
                this.mPaint.setStyle(Paint.Style.FILL);
                canvas.drawPath(this.mPathForBorderOutline, this.mPaint);
                this.mPaint.setShader(null);
            }
        }
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setStrokeJoin(Paint.Join.ROUND);
        drawBorders(canvas);
        this.mPaint.setShader(null);
        canvas.restore();
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.mAlpha;
    }

    int getBorderColor(CSSShorthand.EDGE edge) {
        return BorderUtil.fetchFromSparseArray(this.mBorderColor, edge.ordinal(), -16777216);
    }

    public float[] getBorderInnerRadius(RectF rectF) {
        prepareBorderRadius(rectF);
        if (this.mOverlappingBorderRadius == null) {
            this.mOverlappingBorderRadius = new CSSShorthand<>();
        }
        float f2 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT);
        float f3 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT);
        float f4 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT);
        float f5 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT);
        CSSShorthand<CSSShorthand.EDGE> cSSShorthand = this.mBorderWidth;
        float f6 = f3;
        float f7 = f4;
        float f8 = f5;
        float f9 = f2;
        if (cSSShorthand != null) {
            f9 = Math.max(f2 - cSSShorthand.get(CSSShorthand.EDGE.TOP), 0.0f);
            f6 = Math.max(f3 - this.mBorderWidth.get(CSSShorthand.EDGE.TOP), 0.0f);
            f7 = Math.max(f4 - this.mBorderWidth.get(CSSShorthand.EDGE.BOTTOM), 0.0f);
            f8 = Math.max(f5 - this.mBorderWidth.get(CSSShorthand.EDGE.BOTTOM), 0.0f);
        }
        return new float[]{f9, f9, f6, f6, f7, f7, f8, f8};
    }

    public float[] getBorderRadius(RectF rectF) {
        prepareBorderRadius(rectF);
        if (this.mOverlappingBorderRadius == null) {
            this.mOverlappingBorderRadius = new CSSShorthand<>();
        }
        float f2 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT);
        float f3 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT);
        float f4 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT);
        float f5 = this.mOverlappingBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT);
        return new float[]{f2, f2, f3, f3, f4, f4, f5, f5};
    }

    int getBorderStyle(CSSShorthand.EDGE edge) {
        return BorderUtil.fetchFromSparseArray(this.mBorderStyle, edge.ordinal(), BorderStyle.SOLID.ordinal());
    }

    float getBorderWidth(CSSShorthand.EDGE edge) {
        return this.mBorderWidth.get(edge);
    }

    public int getColor() {
        return this.mColor;
    }

    public Path getContentPath(RectF rectF) {
        Path path = new Path();
        prepareBorderPath(0, 0, 0, 0, rectF, path);
        return path;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return this.mShader != null ? -1 : WXViewUtils.getOpacityFromColor(WXViewUtils.multiplyColorAlpha(this.mColor, this.mAlpha));
    }

    @Override // android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        if (this.mPathForBorderOutline == null) {
            this.mNeedUpdatePath = true;
        }
        updateBorderOutline();
        outline.setConvexPath(this.mPathForBorderOutline);
    }

    public boolean hasImage() {
        return this.mShader != null;
    }

    public boolean isRounded() {
        CSSShorthand<CSSShorthand.CORNER> cSSShorthand = this.mBorderRadius;
        return (cSSShorthand == null || (cSSShorthand.get(CSSShorthand.CORNER.BORDER_TOP_LEFT) == 0.0f && this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT) == 0.0f && this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT) == 0.0f && this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT) == 0.0f)) ? false : true;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        onBoundsChange(rect);
        this.mNeedUpdatePath = true;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        if (i2 != this.mAlpha) {
            this.mAlpha = i2;
            invalidateSelf();
        }
    }

    public void setBorderColor(CSSShorthand.EDGE edge, int i2) {
        if (this.mBorderColor == null) {
            SparseIntArray sparseIntArray = new SparseIntArray(5);
            this.mBorderColor = sparseIntArray;
            sparseIntArray.put(CSSShorthand.EDGE.ALL.ordinal(), -16777216);
        }
        if (getBorderColor(edge) != i2) {
            BorderUtil.updateSparseArray(this.mBorderColor, edge.ordinal(), i2);
            invalidateSelf();
        }
    }

    public void setBorderRadius(CSSShorthand.CORNER corner, float f2) {
        if (this.mBorderRadius == null) {
            this.mBorderRadius = new CSSShorthand<>();
        }
        if (this.mBorderRadius.get(corner) == f2) {
            if (corner != CSSShorthand.CORNER.ALL) {
                return;
            }
            if (f2 == this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_LEFT) && f2 == this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_TOP_RIGHT) && f2 == this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_RIGHT) && f2 == this.mBorderRadius.get(CSSShorthand.CORNER.BORDER_BOTTOM_LEFT)) {
                return;
            }
        }
        this.mBorderRadius.set(corner, f2);
        this.mNeedUpdatePath = true;
        invalidateSelf();
    }

    public void setBorderStyle(CSSShorthand.EDGE edge, String str) {
        if (this.mBorderStyle == null) {
            SparseIntArray sparseIntArray = new SparseIntArray(5);
            this.mBorderStyle = sparseIntArray;
            sparseIntArray.put(CSSShorthand.EDGE.ALL.ordinal(), DEFAULT_BORDER_STYLE.ordinal());
        }
        try {
            int ordinal = BorderStyle.valueOf(str.toUpperCase(Locale.US)).ordinal();
            if (getBorderStyle(edge) != ordinal) {
                BorderUtil.updateSparseArray(this.mBorderStyle, edge.ordinal(), ordinal);
                invalidateSelf();
            }
        } catch (IllegalArgumentException e2) {
            WXLogUtils.e(TAG, WXLogUtils.getStackTrace(e2));
        }
    }

    public void setBorderWidth(CSSShorthand.EDGE edge, float f2) {
        if (this.mBorderWidth == null) {
            this.mBorderWidth = new CSSShorthand<>();
        }
        if (this.mBorderWidth.get(edge) != f2) {
            this.mBorderWidth.set(edge, f2);
            this.mNeedUpdatePath = true;
            invalidateSelf();
        }
    }

    public void setColor(int i2) {
        this.mColor = i2;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
    }

    public void setImage(Shader shader) {
        this.mShader = shader;
        invalidateSelf();
    }

    public void updateBoxShadowData(UniBoxShadowData uniBoxShadowData) {
        this.mBoxShadowData = uniBoxShadowData;
        invalidateSelf();
    }
}
