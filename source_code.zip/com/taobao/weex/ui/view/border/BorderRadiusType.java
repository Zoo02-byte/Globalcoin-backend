package com.taobao.weex.ui.view.border;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.SOURCE)
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderRadiusType.class */
public @interface BorderRadiusType {
}
