package com.taobao.weex.ui.view.border;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.taobao.weex.base.FloatUtil;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderCorner.class */
public abstract class BorderCorner {
    static final float SWEEP_ANGLE;
    protected float mAngleBisector;
    private RectF mBorderBox;
    private float mOvalBottom;
    private float mOvalLeft;
    private float mOvalRight;
    private float mOvalTop;
    private float mRoundCornerEndX;
    private float mRoundCornerEndY;
    private float mRoundCornerStartX;
    private float mRoundCornerStartY;
    private float mCornerRadius = 0.0f;
    private float mPreBorderWidth = 0.0f;
    private float mPostBorderWidth = 0.0f;
    private boolean hasInnerCorner = false;
    private boolean hasOuterCorner = false;

    public final void drawRoundedCorner(Canvas canvas, Paint paint, float f2) {
        if (hasOuterCorner()) {
            Paint paint2 = new Paint(paint);
            float abs = Math.abs(this.mOvalLeft - this.mOvalRight);
            if (paint.getStrokeWidth() > abs) {
                paint2.setStrokeWidth(abs);
            }
            paint2.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawArc(this.mOvalLeft, this.mOvalTop, this.mOvalRight, this.mOvalBottom, f2, SWEEP_ANGLE, false, paint2);
        } else if (getRoundCornerStartX() != getRoundCornerEndX() || getRoundCornerStartY() != getRoundCornerEndY()) {
            canvas.drawLine(getRoundCornerStartX(), getRoundCornerStartY(), getRoundCornerEndX(), getRoundCornerEndY(), paint);
        }
    }

    public final float getAngleBisectorDegree() {
        return this.mAngleBisector;
    }

    protected final RectF getBorderBox() {
        return this.mBorderBox;
    }

    protected final float getOuterCornerRadius() {
        return this.mCornerRadius;
    }

    protected final float getPostBorderWidth() {
        return this.mPostBorderWidth;
    }

    protected final float getPreBorderWidth() {
        return this.mPreBorderWidth;
    }

    public final float getRoundCornerEndX() {
        return this.mRoundCornerEndX;
    }

    public final float getRoundCornerEndY() {
        return this.mRoundCornerEndY;
    }

    public final float getRoundCornerStartX() {
        return this.mRoundCornerStartX;
    }

    public final float getRoundCornerStartY() {
        return this.mRoundCornerStartY;
    }

    boolean hasInnerCorner() {
        return this.hasInnerCorner;
    }

    boolean hasOuterCorner() {
        return this.hasOuterCorner;
    }

    protected abstract void prepareOval();

    protected abstract void prepareRoundCorner();

    final void set(float f2, float f3, float f4, RectF rectF, float f5) {
        RectF rectF2;
        if (!FloatUtil.floatsEqual(this.mCornerRadius, f2) || !FloatUtil.floatsEqual(this.mPreBorderWidth, f3) || !FloatUtil.floatsEqual(this.mPostBorderWidth, f4) || !FloatUtil.floatsEqual(this.mAngleBisector, f5) || ((rectF2 = this.mBorderBox) != null && rectF2.equals(rectF))) {
            this.mCornerRadius = f2;
            this.mPreBorderWidth = f3;
            this.mPostBorderWidth = f4;
            this.mBorderBox = rectF;
            this.mAngleBisector = f5;
            boolean z2 = true;
            boolean z3 = f2 > 0.0f && !FloatUtil.floatsEqual(0.0f, f2);
            this.hasOuterCorner = z3;
            if (!z3 || getPreBorderWidth() < 0.0f || getPostBorderWidth() < 0.0f || getOuterCornerRadius() <= getPreBorderWidth() || getOuterCornerRadius() <= getPostBorderWidth()) {
                z2 = false;
            }
            this.hasInnerCorner = z2;
            if (this.hasOuterCorner) {
                prepareOval();
            }
            prepareRoundCorner();
        }
    }

    final void setOvalBottom(float f2) {
        this.mOvalBottom = f2;
    }

    final void setOvalLeft(float f2) {
        this.mOvalLeft = f2;
    }

    final void setOvalRight(float f2) {
        this.mOvalRight = f2;
    }

    final void setOvalTop(float f2) {
        this.mOvalTop = f2;
    }

    final void setRoundCornerEndX(float f2) {
        this.mRoundCornerEndX = f2;
    }

    final void setRoundCornerEndY(float f2) {
        this.mRoundCornerEndY = f2;
    }

    final void setRoundCornerStartX(float f2) {
        this.mRoundCornerStartX = f2;
    }

    final void setRoundCornerStartY(float f2) {
        this.mRoundCornerStartY = f2;
    }
}
