package com.taobao.weex.ui.view.border;

import android.graphics.LinearGradient;
import android.graphics.Shader;
import com.taobao.weex.dom.CSSShorthand;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderStyle.class */
public enum BorderStyle {
    SOLID,
    DASHED,
    DOTTED;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.taobao.weex.ui.view.border.BorderStyle$1  reason: invalid class name */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderStyle$1.class */
    public static /* synthetic */ class AnonymousClass1 {
        static final int[] $SwitchMap$com$taobao$weex$ui$view$border$BorderStyle;

        static {
            int[] iArr = new int[BorderStyle.values().length];
            $SwitchMap$com$taobao$weex$ui$view$border$BorderStyle = iArr;
            try {
                iArr[BorderStyle.DOTTED.ordinal()] = 1;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$taobao$weex$ui$view$border$BorderStyle[BorderStyle.DASHED.ordinal()] = 2;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Shader getLineShader(float f2, int i2, CSSShorthand.EDGE edge) {
        int i3 = AnonymousClass1.$SwitchMap$com$taobao$weex$ui$view$border$BorderStyle[ordinal()];
        if (i3 != 1) {
            if (i3 != 2) {
                return null;
            }
        } else if (edge == CSSShorthand.EDGE.LEFT || edge == CSSShorthand.EDGE.RIGHT) {
            return new LinearGradient(0.0f, 0.0f, 0.0f, f2 * 2.0f, new int[]{i2, 0}, new float[]{0.5f, 0.5f}, Shader.TileMode.REPEAT);
        } else {
            if (edge == CSSShorthand.EDGE.TOP || edge == CSSShorthand.EDGE.BOTTOM) {
                return new LinearGradient(0.0f, 0.0f, f2 * 2.0f, 0.0f, new int[]{i2, 0}, new float[]{0.5f, 0.5f}, Shader.TileMode.REPEAT);
            }
        }
        if (edge == CSSShorthand.EDGE.LEFT || edge == CSSShorthand.EDGE.RIGHT) {
            return new LinearGradient(0.0f, 0.0f, 0.0f, f2 * 6.0f, new int[]{i2, 0}, new float[]{0.5f, 0.5f}, Shader.TileMode.REPEAT);
        }
        if (edge == CSSShorthand.EDGE.TOP || edge == CSSShorthand.EDGE.BOTTOM) {
            return new LinearGradient(0.0f, 0.0f, f2 * 6.0f, 0.0f, new int[]{i2, 0}, new float[]{0.5f, 0.5f}, Shader.TileMode.REPEAT);
        }
        return null;
    }
}
