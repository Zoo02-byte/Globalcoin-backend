package com.taobao.weex.ui.view.border;

import android.util.SparseIntArray;
import com.taobao.weex.dom.CSSShorthand;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/border/BorderUtil.class */
public class BorderUtil {
    BorderUtil() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int fetchFromSparseArray(SparseIntArray sparseIntArray, int i2, int i3) {
        if (sparseIntArray != null) {
            i3 = sparseIntArray.get(i2, sparseIntArray.get(CSSShorthand.EDGE.ALL.ordinal()));
        }
        return i3;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void updateSparseArray(SparseIntArray sparseIntArray, int i2, int i3) {
        if (i2 == CSSShorthand.EDGE.ALL.ordinal()) {
            sparseIntArray.put(CSSShorthand.EDGE.ALL.ordinal(), i3);
            sparseIntArray.put(CSSShorthand.EDGE.TOP.ordinal(), i3);
            sparseIntArray.put(CSSShorthand.EDGE.LEFT.ordinal(), i3);
            sparseIntArray.put(CSSShorthand.EDGE.RIGHT.ordinal(), i3);
            sparseIntArray.put(CSSShorthand.EDGE.BOTTOM.ordinal(), i3);
            return;
        }
        sparseIntArray.put(i2, i3);
    }
}
