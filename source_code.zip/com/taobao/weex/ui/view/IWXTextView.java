package com.taobao.weex.ui.view;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWXTextView.class */
public interface IWXTextView {
    CharSequence getText();
}
