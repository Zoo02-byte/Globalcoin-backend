package com.taobao.weex.ui.view;

import android.content.Intent;
import android.view.View;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWebView.class */
public interface IWebView {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWebView$OnErrorListener.class */
    public interface OnErrorListener {
        void onError(String str, Object obj);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWebView$OnMessageListener.class */
    public interface OnMessageListener {
        void onMessage(Map<String, Object> map);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/IWebView$OnPageListener.class */
    public interface OnPageListener {
        void onPageFinish(String str, boolean z2, boolean z3);

        void onPageStart(String str);

        void onReceivedTitle(String str);
    }

    void destroy();

    View getView();

    void goBack();

    void goForward();

    void loadDataWithBaseURL(String str);

    void loadUrl(String str);

    void onActivityResult(int i2, int i3, Intent intent);

    void postMessage(Object obj);

    void reload();

    void setOnErrorListener(OnErrorListener onErrorListener);

    void setOnMessageListener(OnMessageListener onMessageListener);

    void setOnPageListener(OnPageListener onPageListener);

    void setShowLoading(boolean z2);
}
