package com.taobao.weex.ui.view;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.text.Layout;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.PopupMenu;
import com.taobao.weex.ui.component.WXText;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import java.lang.ref.WeakReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXTextView.class */
public class WXTextView extends View implements WXGestureObservable, IWXTextView, IRenderStatus<WXText>, IRenderResult<WXText> {
    private boolean mIsLabelSet = false;
    private WeakReference<WXText> mWeakReference;
    private Layout textLayout;
    private WXGesture wxGesture;

    public WXTextView(Context context) {
        super(context);
    }

    public void enableCopy(boolean z2) {
        if (z2) {
            setOnLongClickListener(new View.OnLongClickListener(this) { // from class: com.taobao.weex.ui.view.WXTextView.1
                final WXTextView this$0;

                {
                    this.this$0 = r4;
                }

                @Override // android.view.View.OnLongClickListener
                public boolean onLongClick(View view) {
                    String str;
                    PopupMenu popupMenu = new PopupMenu(this.this$0.getContext(), this.this$0);
                    try {
                        str = this.this$0.getContext().getResources().getString(17039361);
                    } catch (Throwable th) {
                        str = "Copy";
                    }
                    popupMenu.getMenu().add(str);
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(this, str) { // from class: com.taobao.weex.ui.view.WXTextView.1.1
                        final AnonymousClass1 this$1;
                        final String val$title;

                        {
                            this.this$1 = r4;
                            this.val$title = r5;
                        }

                        @Override // androidx.appcompat.widget.PopupMenu.OnMenuItemClickListener
                        public boolean onMenuItemClick(MenuItem menuItem) {
                            if (!this.val$title.equals(menuItem.getTitle())) {
                                return false;
                            }
                            String obj = this.this$1.this$0.getText().toString();
                            ClipboardManager clipboardManager = (ClipboardManager) this.this$1.this$0.getContext().getSystemService("clipboard");
                            if (clipboardManager == null) {
                                return true;
                            }
                            clipboardManager.setPrimaryClip(ClipData.newPlainText(obj, obj));
                            return true;
                        }
                    });
                    popupMenu.show();
                    return true;
                }
            });
        } else {
            setOnLongClickListener(null);
        }
    }

    @Override // com.taobao.weex.ui.view.IRenderResult
    public WXText getComponent() {
        WeakReference<WXText> weakReference = this.mWeakReference;
        return weakReference != null ? weakReference.get() : null;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.wxGesture;
    }

    @Override // com.taobao.weex.ui.view.IWXTextView
    public CharSequence getText() {
        Layout layout = this.textLayout;
        return layout != null ? layout.getText() : null;
    }

    public Layout getTextLayout() {
        return this.textLayout;
    }

    public void holdComponent(WXText wXText) {
        this.mWeakReference = new WeakReference<>(wXText);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        onDraw(canvas);
        canvas.save();
        Layout textLayout = getTextLayout();
        if (textLayout != null) {
            canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            textLayout.draw(canvas);
        }
        canvas.restore();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean onTouchEvent = onTouchEvent(motionEvent);
        WXGesture wXGesture = this.wxGesture;
        boolean z2 = onTouchEvent;
        if (wXGesture != null) {
            z2 = onTouchEvent | wXGesture.onTouch(this, motionEvent);
        }
        return z2;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.wxGesture = wXGesture;
    }

    public void setAriaLabel(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.mIsLabelSet = true;
            setContentDescription(str);
            return;
        }
        this.mIsLabelSet = false;
        Layout layout = this.textLayout;
        if (layout != null) {
            setContentDescription(layout.getText());
        }
    }

    public void setTextColor(int i2) {
        Layout textLayout = getTextLayout();
        if (textLayout != null) {
            textLayout.getPaint().setColor(i2);
        }
    }

    public void setTextLayout(Layout layout) {
        WXText wXText;
        this.textLayout = layout;
        if (layout != null && !this.mIsLabelSet) {
            setContentDescription(layout.getText());
        }
        WeakReference<WXText> weakReference = this.mWeakReference;
        if (weakReference != null && (wXText = weakReference.get()) != null) {
            wXText.readyToRender();
        }
    }
}
