package com.taobao.weex.ui.view;

import android.content.Context;
import android.view.animation.Interpolator;
import android.widget.Scroller;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXSmoothScroller.class */
public class WXSmoothScroller extends Scroller {
    private double mScrollFactor = 1.0d;

    public WXSmoothScroller(Context context) {
        super(context);
    }

    public WXSmoothScroller(Context context, Interpolator interpolator) {
        super(context, interpolator);
    }

    public WXSmoothScroller(Context context, Interpolator interpolator, boolean z2) {
        super(context, interpolator, z2);
    }

    public void setScrollDurationFactor(double d2) {
        this.mScrollFactor = d2;
    }

    @Override // android.widget.Scroller
    public void startScroll(int i2, int i3, int i4, int i5, int i6) {
        startScroll(i2, i3, i4, i5, (int) (((double) i6) * this.mScrollFactor));
    }
}
