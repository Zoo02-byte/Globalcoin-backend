package com.taobao.weex.ui.view.listview;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.utils.WXLogUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/ExtendedStaggeredGridLayoutManager.class */
public class ExtendedStaggeredGridLayoutManager extends StaggeredGridLayoutManager {
    public ExtendedStaggeredGridLayoutManager(int i2, int i3) {
        super(i2, i3);
    }

    @Override // androidx.recyclerview.widget.StaggeredGridLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    public void onItemsRemoved(RecyclerView recyclerView, int i2, int i3) {
        if (i2 == -1) {
            WXLogUtils.e("ExtendedStaggeredGridLayoutManager: onItemsRemoved  Error Invalid Index : positionStart :" + i2 + "  itemCount:" + i3);
            return;
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.e("ExtendedStaggeredGridLayoutManager: onItemsRemoved  positionStart :" + i2 + "  itemCount:" + i3);
        }
        onItemsRemoved(recyclerView, i2, i3);
    }
}
