package com.taobao.weex.ui.view.listview;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXVContainer;
import com.taobao.weex.ui.component.list.WXListComponent;
import com.taobao.weex.ui.view.gesture.WXGesture;
import com.taobao.weex.ui.view.gesture.WXGestureObservable;
import com.taobao.weex.ui.view.listview.ExtendedLinearLayoutManager;
import com.taobao.weex.ui.view.refresh.wrapper.BounceRecyclerView;
import io.dcloud.common.ui.blur.AppEventForBlurManager;
import io.dcloud.feature.weex.extend.DCWXSlider;
import io.dcloud.weex.FlingHelper;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/WXRecyclerView.class */
public class WXRecyclerView extends RecyclerView implements WXGestureObservable {
    public static final int TYPE_GRID_LAYOUT;
    public static final int TYPE_LINEAR_LAYOUT;
    public static final int TYPE_STAGGERED_GRID_LAYOUT;
    RecyclerView.OnScrollListener mChildScrollListener;
    private FlingHelper mFlingHelper;
    private WXGesture mGesture;
    private String mInstanceId;
    RecyclerView.OnScrollListener mParentScrollListener;
    private boolean scrollable = true;
    private boolean hasTouch = false;
    private JSONObject NestInfo = null;
    public boolean isNestParent = false;
    private int mCurrentDy = 0;
    private Float lastY = Float.valueOf(0.0f);
    private int totalDy = 0;
    private int velocityY = 0;
    private float headerHeight = 0.0f;
    boolean isStartFling = false;

    public WXRecyclerView(Context context) {
        super(context);
    }

    public WXRecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    static /* synthetic */ int access$212(WXRecyclerView wXRecyclerView, int i2) {
        int i3 = wXRecyclerView.totalDy + i2;
        wXRecyclerView.totalDy = i3;
        return i3;
    }

    public boolean canParentScrollVertically(int i2, boolean z2) {
        if (i2 == 1 && i2 == 1) {
            try {
                if (this.NestInfo != null && this.isNestParent) {
                    WXRecyclerView childRecylerView = getChildRecylerView();
                    if (childRecylerView == null) {
                        return true;
                    }
                    Rect rect = new Rect();
                    childRecylerView.getLocalVisibleRect(rect);
                    if (childRecylerView.getHeight() - rect.bottom == 0) {
                        return childRecylerView.isScrollTop();
                    }
                    return true;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return z2;
    }

    private void childFling(int i2) {
        WXRecyclerView childRecylerView = getChildRecylerView();
        if (childRecylerView != null) {
            childRecylerView.fling(0, i2);
        }
    }

    public void dispatchChildFling() {
        int i2;
        if (isScrollEnd() && (i2 = this.velocityY) != 0) {
            double splineFlingDistance = this.mFlingHelper.getSplineFlingDistance(i2);
            int i3 = this.totalDy;
            if (splineFlingDistance > ((double) i3)) {
                childFling(this.mFlingHelper.getVelocityByDistance(splineFlingDistance - ((double) i3)));
            }
        }
        this.totalDy = 0;
        this.velocityY = 0;
    }

    public void dispatchParentFling() {
        int i2;
        WXRecyclerView parentRecyclerView = getParentRecyclerView();
        if (parentRecyclerView != null && isScrollTop() && (i2 = this.velocityY) != 0) {
            double splineFlingDistance = this.mFlingHelper.getSplineFlingDistance(i2);
            if (splineFlingDistance > ((double) Math.abs(this.totalDy))) {
                parentRecyclerView.fling(0, -this.mFlingHelper.getVelocityByDistance(splineFlingDistance + ((double) this.totalDy)));
            }
            this.totalDy = 0;
            this.velocityY = 0;
        }
    }

    private WXRecyclerView getChildRecylerView() {
        WXComponent wXComponent;
        WXListComponent listComponent;
        JSONObject jSONObject = this.NestInfo;
        if (jSONObject == null || !this.isNestParent) {
            return null;
        }
        if (jSONObject.getBooleanValue("isSwipelist")) {
            WXComponent wXComponentById = WXSDKManager.getInstance().getWXRenderManager().getWXComponentById(this.mInstanceId, this.NestInfo.getString("swipeId"));
            wXComponent = wXComponentById;
            if (wXComponentById != null) {
                DCWXSlider dCWXSliderComponent = getDCWXSliderComponent(wXComponentById);
                wXComponent = dCWXSliderComponent;
                if (dCWXSliderComponent != null) {
                    wXComponent = dCWXSliderComponent;
                    if (dCWXSliderComponent instanceof DCWXSlider) {
                        wXComponent = dCWXSliderComponent.getChild(dCWXSliderComponent.getCurrentIndex());
                    }
                }
            }
        } else {
            wXComponent = WXSDKManager.getInstance().getWXRenderManager().getWXComponent(this.mInstanceId, this.NestInfo.getString("nestChildRef"));
        }
        if (wXComponent == null || (listComponent = getListComponent(wXComponent)) == null || listComponent.getHostView() == 0) {
            return null;
        }
        return (WXRecyclerView) ((BounceRecyclerView) listComponent.getHostView()).getInnerView();
    }

    private WXRecyclerView getParentRecyclerView() {
        WXComponent wXComponentById;
        WXListComponent listComponent;
        JSONObject jSONObject = this.NestInfo;
        if (jSONObject == null || this.isNestParent || (wXComponentById = WXSDKManager.getInstance().getWXRenderManager().getWXComponentById(this.mInstanceId, jSONObject.getString("listParentId"))) == null || (listComponent = getListComponent(wXComponentById)) == null || listComponent.getHostView() == 0) {
            return null;
        }
        return (WXRecyclerView) ((BounceRecyclerView) listComponent.getHostView()).getInnerView();
    }

    private boolean isScrollEnd() {
        return true ^ canScrollVertically(1);
    }

    public void callBackNestParent(String str, String str2, float f2) {
        WXRecyclerView parentRecyclerView = getParentRecyclerView();
        if (parentRecyclerView != null) {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("isNestParent", (Object) true);
            jSONObject.put("instanceId", (Object) str2);
            jSONObject.put("nestChildRef", (Object) str);
            jSONObject.put("headerHeight", (Object) Float.valueOf(f2));
            parentRecyclerView.setNestInfo(jSONObject);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        this.hasTouch = true;
        if (this.NestInfo != null) {
            if (this.isNestParent) {
                if (motionEvent != null && motionEvent.getAction() == 0) {
                    this.velocityY = 0;
                    stopScroll();
                }
                if (!(motionEvent == null || motionEvent.getAction() == 2)) {
                    this.lastY = Float.valueOf(0.0f);
                }
            } else if (motionEvent != null && motionEvent.getAction() == 0) {
                this.velocityY = 0;
            }
        }
        boolean dispatchTouchEvent = dispatchTouchEvent(motionEvent);
        WXGesture wXGesture = this.mGesture;
        boolean z2 = dispatchTouchEvent;
        if (wXGesture != null) {
            z2 = dispatchTouchEvent | wXGesture.onTouch(this, motionEvent);
        }
        return z2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView
    public boolean fling(int i2, int i3) {
        if (!isAttachedToWindow()) {
            return false;
        }
        boolean fling = fling(i2, i3);
        if (this.NestInfo != null) {
            if (this.isNestParent) {
                if (!fling || i3 <= 0) {
                    this.velocityY = 0;
                } else {
                    this.isStartFling = true;
                    this.velocityY = i3;
                }
            } else if (!fling || i3 >= 0) {
                this.velocityY = 0;
            } else {
                this.isStartFling = true;
                this.velocityY = i3;
            }
        }
        return fling;
    }

    public int getCurrentDy() {
        return this.mCurrentDy;
    }

    public DCWXSlider getDCWXSliderComponent(WXComponent wXComponent) {
        if (wXComponent instanceof DCWXSlider) {
            return (DCWXSlider) wXComponent;
        }
        if (!(wXComponent instanceof WXVContainer)) {
            return null;
        }
        WXVContainer wXVContainer = (WXVContainer) wXComponent;
        if (wXVContainer.getChildCount() <= 0) {
            return null;
        }
        for (int i2 = 0; i2 < wXVContainer.getChildCount(); i2++) {
            DCWXSlider dCWXSliderComponent = getDCWXSliderComponent(wXVContainer.getChild(i2));
            if (dCWXSliderComponent != null) {
                return dCWXSliderComponent;
            }
        }
        return null;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public WXGesture getGestureListener() {
        return this.mGesture;
    }

    public WXListComponent getListComponent(WXComponent wXComponent) {
        if (wXComponent instanceof WXListComponent) {
            return (WXListComponent) wXComponent;
        }
        if (!(wXComponent instanceof WXVContainer)) {
            return null;
        }
        WXVContainer wXVContainer = (WXVContainer) wXComponent;
        if (wXVContainer.getChildCount() <= 0) {
            return null;
        }
        for (int i2 = 0; i2 < wXVContainer.getChildCount(); i2++) {
            WXListComponent listComponent = getListComponent(wXVContainer.getChild(i2));
            if (listComponent != null) {
                return listComponent;
            }
        }
        return null;
    }

    public void initView(Context context, int i2, int i3) {
        initView(context, i2, 1, 32.0f, i3);
    }

    public void initView(Context context, int i2, int i3, float f2, int i4) {
        if (i2 == 2) {
            setLayoutManager(new GridLayoutManager(this, context, i3, i4, false, i4) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.3
                final WXRecyclerView this$0;
                final int val$orientation;

                {
                    this.this$0 = r7;
                    this.val$orientation = r12;
                }

                @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public boolean canScrollVertically() {
                    try {
                        return this.this$0.canParentScrollVertically(this.val$orientation, canScrollVertically());
                    } catch (Exception e2) {
                        return true;
                    }
                }

                @Override // androidx.recyclerview.widget.GridLayoutManager, androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                    try {
                        onLayoutChildren(recycler, state);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            });
        } else if (i2 == 3) {
            setLayoutManager(new ExtendedStaggeredGridLayoutManager(this, i3, i4, i4) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.4
                final WXRecyclerView this$0;
                final int val$orientation;

                {
                    this.this$0 = r5;
                    this.val$orientation = r8;
                }

                @Override // androidx.recyclerview.widget.StaggeredGridLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public boolean canScrollVertically() {
                    try {
                        return this.this$0.canParentScrollVertically(this.val$orientation, canScrollVertically());
                    } catch (Exception e2) {
                        return true;
                    }
                }

                @Override // androidx.recyclerview.widget.StaggeredGridLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                    try {
                        onLayoutChildren(recycler, state);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            });
        } else if (i2 == 1) {
            setLayoutManager(new LinearLayoutManager(this, context, i4, false, i4) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.5
                final WXRecyclerView this$0;
                final int val$orientation;

                {
                    this.this$0 = r6;
                    this.val$orientation = r10;
                }

                @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public boolean canScrollVertically() {
                    try {
                        return this.this$0.canParentScrollVertically(this.val$orientation, canScrollVertically());
                    } catch (Exception e2) {
                        return true;
                    }
                }

                @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
                public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                    try {
                        onLayoutChildren(recycler, state);
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                }
            });
        }
    }

    public boolean isNestScroll() {
        return this.NestInfo != null;
    }

    public boolean isScrollTop() {
        return !canScrollVertically(-1);
    }

    public boolean isScrollable() {
        return this.scrollable;
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return onInterceptTouchEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.isNestParent || this.NestInfo == null) {
            return onNestedFling(view, f2, f3, z2);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        if (!this.isNestParent || this.NestInfo == null) {
            return onNestedPreFling(view, f2, f3);
        }
        WXRecyclerView childRecylerView = getChildRecylerView();
        int i2 = (f3 > 0.0f ? 1 : (f3 == 0.0f ? 0 : -1));
        boolean z2 = i2 > 0 && !isScrollEnd();
        boolean z3 = i2 < 0 && childRecylerView != null && childRecylerView.isScrollTop();
        if (!z2 && !z3) {
            return false;
        }
        fling(0, (int) f3);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        if (this.isNestParent && this.NestInfo != null) {
            WXRecyclerView childRecylerView = getChildRecylerView();
            boolean z2 = i3 > 0 && !isScrollEnd();
            boolean z3 = i3 < 0 && childRecylerView != null && childRecylerView.isScrollTop();
            if (z2 || z3) {
                scrollBy(0, i3);
                iArr[1] = i3;
            }
        }
    }

    @Override // android.view.View
    protected void onScrollChanged(int i2, int i3, int i4, int i5) {
        onScrollChanged(i2, i3, i4, i5);
        AppEventForBlurManager.onScrollChanged(i2, i3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if (!this.isNestParent || this.NestInfo == null || view2 == null || !(view2 instanceof WXRecyclerView) || ((WXRecyclerView) view2).isNestParent) {
            return onStartNestedScroll(view, view2, i2);
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        View view;
        WXRecyclerView childRecylerView;
        int floatValue;
        if (!this.scrollable) {
            return true;
        }
        if (this.NestInfo != null && this.isNestParent) {
            if (this.lastY.floatValue() == 0.0f) {
                this.lastY = Float.valueOf(motionEvent.getY());
            }
            if (!(!isScrollEnd() || (childRecylerView = getChildRecylerView()) == null || (floatValue = (int) (this.lastY.floatValue() - motionEvent.getY())) == 0)) {
                childRecylerView.scrollBy(0, floatValue);
            }
            this.lastY = Float.valueOf(motionEvent.getY());
        }
        if (motionEvent.getAction() == 1 && (view = (View) getParent().getParent()) != null && view.hasOnClickListeners() && (view instanceof BounceRecyclerView) && pointInView(motionEvent.getX(), motionEvent.getY(), 0.0f) && getScrollState() == 0) {
            view.performClick();
        }
        return onTouchEvent(motionEvent);
    }

    public boolean pointInView(float f2, float f3, float f4) {
        float f5 = -f4;
        return f2 >= f5 && f3 >= f5 && f2 < ((float) (getRight() - getLeft())) + f4 && f3 < ((float) (getBottom() - getTop())) + f4;
    }

    @Override // com.taobao.weex.ui.view.gesture.WXGestureObservable
    public void registerGestureListener(WXGesture wXGesture) {
        this.mGesture = wXGesture;
    }

    public void scrollTo(int i2, int i3, int i4) {
        postDelayed(WXThread.secure(new Runnable(this, i4, i3, i2) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.7
            final WXRecyclerView this$0;
            final int val$orientation;
            final int val$x;
            final int val$y;

            {
                this.this$0 = r4;
                this.val$orientation = r5;
                this.val$y = r6;
                this.val$x = r7;
            }

            @Override // java.lang.Runnable
            public void run() {
                RecyclerView.LayoutManager layoutManager = this.this$0.getLayoutManager();
                int i5 = this.val$orientation == 1 ? this.val$y : this.val$x;
                if (layoutManager instanceof LinearLayoutManager) {
                    ((LinearLayoutManager) layoutManager).scrollToPositionWithOffset(0, -i5);
                } else if (layoutManager instanceof StaggeredGridLayoutManager) {
                    ((StaggeredGridLayoutManager) layoutManager).scrollToPositionWithOffset(0, -i5);
                }
            }
        }), 100);
    }

    public void scrollTo(boolean z2, int i2, int i3, int i4) {
        try {
            RecyclerView.LayoutManager layoutManager = getLayoutManager();
            stopScroll();
            if (z2) {
                if (i4 == 1) {
                    if (layoutManager instanceof LinearLayoutManager) {
                        int findFirstVisibleItemPosition = ((LinearLayoutManager) layoutManager).findFirstVisibleItemPosition();
                        int findLastVisibleItemPosition = ((LinearLayoutManager) layoutManager).findLastVisibleItemPosition();
                        if (i2 >= findFirstVisibleItemPosition && i2 <= findLastVisibleItemPosition) {
                            smoothScrollBy(0, getChildAt(i2 - findFirstVisibleItemPosition).getTop() + i3);
                            return;
                        }
                    } else if (layoutManager instanceof StaggeredGridLayoutManager) {
                        int[] findFirstVisibleItemPositions = ((StaggeredGridLayoutManager) layoutManager).findFirstVisibleItemPositions(null);
                        int[] findLastCompletelyVisibleItemPositions = ((StaggeredGridLayoutManager) layoutManager).findLastCompletelyVisibleItemPositions(null);
                        int i5 = findFirstVisibleItemPositions[0];
                        if (i2 >= i5 && i2 <= findLastCompletelyVisibleItemPositions[0]) {
                            smoothScrollBy(0, getChildAt(i2 - i5).getTop() + i3);
                            return;
                        }
                    }
                }
                smoothScrollToPosition(i2);
                if (i3 != 0) {
                    setOnSmoothScrollEndListener(new ExtendedLinearLayoutManager.OnSmoothScrollEndListener(this, i4, i3) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.6
                        final WXRecyclerView this$0;
                        final int val$offset;
                        final int val$orientation;

                        {
                            this.this$0 = r4;
                            this.val$orientation = r5;
                            this.val$offset = r6;
                        }

                        @Override // com.taobao.weex.ui.view.listview.ExtendedLinearLayoutManager.OnSmoothScrollEndListener
                        public void onStop() {
                            this.this$0.post(WXThread.secure(new Runnable(this) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.6.1
                                final AnonymousClass6 this$1;

                                {
                                    this.this$1 = r4;
                                }

                                @Override // java.lang.Runnable
                                public void run() {
                                    if (this.this$1.val$orientation == 1) {
                                        this.this$1.this$0.smoothScrollBy(0, this.this$1.val$offset);
                                    } else {
                                        this.this$1.this$0.smoothScrollBy(this.this$1.val$offset, 0);
                                    }
                                }
                            }));
                        }
                    });
                }
            } else if (layoutManager instanceof LinearLayoutManager) {
                ((LinearLayoutManager) layoutManager).scrollToPositionWithOffset(i2, -i3);
            } else if (layoutManager instanceof StaggeredGridLayoutManager) {
                ((StaggeredGridLayoutManager) layoutManager).scrollToPositionWithOffset(i2, -i3);
            }
        } catch (Exception e2) {
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView
    public void scrollToPosition(int i2) {
        if (!this.isNestParent || this.NestInfo == null) {
            scrollToPosition(i2);
            return;
        }
        WXRecyclerView childRecylerView = getChildRecylerView();
        if (childRecylerView != null) {
            childRecylerView.scrollToPosition(i2);
        }
        postDelayed(new Runnable(this, i2) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.9
            final WXRecyclerView this$0;
            final int val$position;

            {
                this.this$0 = r4;
                this.val$position = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.this$0.scrollToPosition(this.val$position);
            }
        }, 50);
    }

    public void setNestInfo(JSONObject jSONObject) {
        this.NestInfo = jSONObject;
        if (jSONObject != null) {
            this.isNestParent = jSONObject.getBooleanValue("isNestParent");
            this.mInstanceId = jSONObject.getString("instanceId");
            if (this.mFlingHelper == null) {
                this.mFlingHelper = new FlingHelper(getContext());
            }
            if (this.isNestParent) {
                setDescendantFocusability(131072);
                if (this.mParentScrollListener == null) {
                    this.headerHeight = jSONObject.getFloat("headerHeight").floatValue();
                    AnonymousClass1 r02 = new RecyclerView.OnScrollListener(this) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.1
                        final WXRecyclerView this$0;

                        {
                            this.this$0 = r4;
                        }

                        @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                        public void onScrollStateChanged(RecyclerView recyclerView, int i2) {
                            onScrollStateChanged(recyclerView, i2);
                            if (i2 == 0) {
                                this.this$0.mCurrentDy = 0;
                                this.this$0.dispatchChildFling();
                            }
                        }

                        @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                        public void onScrolled(RecyclerView recyclerView, int i2, int i3) {
                            onScrolled(recyclerView, i2, i3);
                            this.this$0.mCurrentDy = i3;
                            if (this.this$0.isStartFling) {
                                this.this$0.totalDy = 0;
                                this.this$0.isStartFling = false;
                            }
                            WXRecyclerView.access$212(this.this$0, i3);
                        }
                    };
                    this.mParentScrollListener = r02;
                    addOnScrollListener(r02);
                }
            } else if (this.mChildScrollListener == null) {
                AnonymousClass2 r03 = new RecyclerView.OnScrollListener(this) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.2
                    final WXRecyclerView this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                    public void onScrollStateChanged(RecyclerView recyclerView, int i2) {
                        if (i2 == 0) {
                            this.this$0.mCurrentDy = 0;
                            this.this$0.dispatchParentFling();
                        }
                        onScrollStateChanged(recyclerView, i2);
                    }

                    @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
                    public void onScrolled(RecyclerView recyclerView, int i2, int i3) {
                        onScrolled(recyclerView, i2, i3);
                        this.this$0.mCurrentDy = i3;
                        if (this.this$0.isStartFling) {
                            this.this$0.totalDy = 0;
                            this.this$0.isStartFling = false;
                        }
                        WXRecyclerView.access$212(this.this$0, i3);
                    }
                };
                this.mChildScrollListener = r03;
                addOnScrollListener(r03);
            }
        }
    }

    public void setOnSmoothScrollEndListener(ExtendedLinearLayoutManager.OnSmoothScrollEndListener onSmoothScrollEndListener) {
        addOnScrollListener(new RecyclerView.OnScrollListener(this, onSmoothScrollEndListener) { // from class: com.taobao.weex.ui.view.listview.WXRecyclerView.8
            final WXRecyclerView this$0;
            final ExtendedLinearLayoutManager.OnSmoothScrollEndListener val$onSmoothScrollEndListener;

            {
                this.this$0 = r4;
                this.val$onSmoothScrollEndListener = r5;
            }

            @Override // androidx.recyclerview.widget.RecyclerView.OnScrollListener
            public void onScrollStateChanged(RecyclerView recyclerView, int i2) {
                if (i2 == 0) {
                    recyclerView.removeOnScrollListener(this);
                    ExtendedLinearLayoutManager.OnSmoothScrollEndListener onSmoothScrollEndListener2 = this.val$onSmoothScrollEndListener;
                    if (onSmoothScrollEndListener2 != null) {
                        onSmoothScrollEndListener2.onStop();
                    }
                }
            }
        });
    }

    public void setScrollable(boolean z2) {
        this.scrollable = z2;
    }
}
