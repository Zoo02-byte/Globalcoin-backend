package com.taobao.weex.ui.view.listview;

import android.content.Context;
import android.graphics.PointF;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/ExtendedLinearLayoutManager.class */
public class ExtendedLinearLayoutManager extends LinearLayoutManager {
    private OnSmoothScrollEndListener onScrollEndListener;
    private RecyclerView.SmoothScroller smoothScroller;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/ExtendedLinearLayoutManager$OnSmoothScrollEndListener.class */
    public interface OnSmoothScrollEndListener {
        void onStop();
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/ExtendedLinearLayoutManager$TopSnappedSmoothScroller.class */
    private class TopSnappedSmoothScroller extends LinearSmoothScroller {
        final ExtendedLinearLayoutManager this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public TopSnappedSmoothScroller(ExtendedLinearLayoutManager extendedLinearLayoutManager, Context context) {
            super(context);
            this.this$0 = extendedLinearLayoutManager;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.SmoothScroller
        public PointF computeScrollVectorForPosition(int i2) {
            return this.this$0.computeScrollVectorForPosition(i2);
        }

        @Override // androidx.recyclerview.widget.LinearSmoothScroller
        protected int getVerticalSnapPreference() {
            return -1;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // androidx.recyclerview.widget.LinearSmoothScroller, androidx.recyclerview.widget.RecyclerView.SmoothScroller
        public void onStop() {
            onStop();
            if (this.this$0.onScrollEndListener != null) {
                this.this$0.onScrollEndListener.onStop();
                this.this$0.onScrollEndListener = null;
            }
        }
    }

    public ExtendedLinearLayoutManager(Context context) {
        super(context, 1, false);
    }

    public ExtendedLinearLayoutManager(Context context, int i2, boolean z2) {
        super(context, i2, z2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
        try {
            onLayoutChildren(recycler, state);
        } catch (IndexOutOfBoundsException e2) {
            e2.printStackTrace();
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    public int scrollVerticallyBy(int i2, RecyclerView.Recycler recycler, RecyclerView.State state) {
        try {
            return scrollVerticallyBy(i2, recycler, state);
        } catch (Exception e2) {
            e2.printStackTrace();
            return 0;
        }
    }

    public void setOnScrollEndListener(OnSmoothScrollEndListener onSmoothScrollEndListener) {
        this.onScrollEndListener = onSmoothScrollEndListener;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    public void smoothScrollToPosition(RecyclerView recyclerView, RecyclerView.State state, int i2) {
        if (this.smoothScroller == null) {
            this.smoothScroller = new TopSnappedSmoothScroller(this, recyclerView.getContext());
        }
        this.smoothScroller.setTargetPosition(i2);
        startSmoothScroll(this.smoothScroller);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.LayoutManager
    public boolean supportsPredictiveItemAnimations() {
        return false;
    }
}
