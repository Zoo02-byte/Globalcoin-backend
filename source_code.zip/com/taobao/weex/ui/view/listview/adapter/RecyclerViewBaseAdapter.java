package com.taobao.weex.ui.view.listview.adapter;

import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.taobao.weex.ui.view.listview.adapter.ListBaseViewHolder;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/adapter/RecyclerViewBaseAdapter.class */
public class RecyclerViewBaseAdapter<T extends ListBaseViewHolder> extends RecyclerView.Adapter<T> {
    private IRecyclerAdapterListener iRecyclerAdapterListener;

    public RecyclerViewBaseAdapter(IRecyclerAdapterListener iRecyclerAdapterListener) {
        this.iRecyclerAdapterListener = iRecyclerAdapterListener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        if (iRecyclerAdapterListener != null) {
            return iRecyclerAdapterListener.getItemCount();
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public long getItemId(int i2) {
        return this.iRecyclerAdapterListener.getItemId(i2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemViewType(int i2) {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        int i3 = i2;
        if (iRecyclerAdapterListener != null) {
            i3 = iRecyclerAdapterListener.getItemViewType(i2);
        }
        return i3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public /* bridge */ /* synthetic */ void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2) {
        onBindViewHolder((RecyclerViewBaseAdapter<T>) ((ListBaseViewHolder) viewHolder), i2);
    }

    public void onBindViewHolder(T t2, int i2) {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        if (iRecyclerAdapterListener != null) {
            iRecyclerAdapterListener.onBindViewHolder(t2, i2);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public T onCreateViewHolder(ViewGroup viewGroup, int i2) {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        if (iRecyclerAdapterListener != null) {
            return (T) ((ListBaseViewHolder) iRecyclerAdapterListener.onCreateViewHolder(viewGroup, i2));
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public /* bridge */ /* synthetic */ boolean onFailedToRecycleView(RecyclerView.ViewHolder viewHolder) {
        return onFailedToRecycleView((RecyclerViewBaseAdapter<T>) ((ListBaseViewHolder) viewHolder));
    }

    public boolean onFailedToRecycleView(T t2) {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        return iRecyclerAdapterListener != null ? iRecyclerAdapterListener.onFailedToRecycleView(t2) : onFailedToRecycleView((RecyclerViewBaseAdapter<T>) t2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public /* bridge */ /* synthetic */ void onViewAttachedToWindow(RecyclerView.ViewHolder viewHolder) {
        onViewAttachedToWindow((RecyclerViewBaseAdapter<T>) ((ListBaseViewHolder) viewHolder));
    }

    public void onViewAttachedToWindow(T t2) {
        ViewGroup.LayoutParams layoutParams;
        onViewAttachedToWindow((RecyclerViewBaseAdapter<T>) t2);
        if (t2 != null && t2.isFullSpan() && (layoutParams = ((ListBaseViewHolder) t2).itemView.getLayoutParams()) != null && (layoutParams instanceof StaggeredGridLayoutManager.LayoutParams)) {
            ((StaggeredGridLayoutManager.LayoutParams) layoutParams).setFullSpan(true);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public /* bridge */ /* synthetic */ void onViewDetachedFromWindow(RecyclerView.ViewHolder viewHolder) {
        onViewDetachedFromWindow((RecyclerViewBaseAdapter<T>) ((ListBaseViewHolder) viewHolder));
    }

    public void onViewDetachedFromWindow(T t2) {
        onViewDetachedFromWindow((RecyclerViewBaseAdapter<T>) t2);
        if (t2 != null) {
            t2.setComponentUsing(false);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public /* bridge */ /* synthetic */ void onViewRecycled(RecyclerView.ViewHolder viewHolder) {
        onViewRecycled((RecyclerViewBaseAdapter<T>) ((ListBaseViewHolder) viewHolder));
    }

    public void onViewRecycled(T t2) {
        IRecyclerAdapterListener iRecyclerAdapterListener = this.iRecyclerAdapterListener;
        if (iRecyclerAdapterListener != null) {
            iRecyclerAdapterListener.onViewRecycled(t2);
        }
        onViewRecycled((RecyclerViewBaseAdapter<T>) t2);
    }
}
