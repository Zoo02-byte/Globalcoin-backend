package com.taobao.weex.ui.view.listview.adapter;

import android.graphics.Canvas;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/adapter/TransformItemDecoration.class */
public class TransformItemDecoration extends RecyclerView.ItemDecoration {
    float mAlpha;
    boolean mIsVertical;
    int mRotation;
    float mScaleX;
    float mScaleY;
    int mXTranslate;
    int mYTranslate;

    public TransformItemDecoration(boolean z2, float f2, int i2, int i3, int i4, float f3, float f4) {
        this.mIsVertical = z2;
        this.mAlpha = f2;
        this.mXTranslate = i2;
        this.mYTranslate = i3;
        this.mRotation = i4;
        this.mScaleX = f3;
        this.mScaleY = f4;
    }

    private void updateItem(View view, int i2, int i3) {
        int i4;
        int i5;
        if (this.mIsVertical) {
            int height = view.getHeight();
            i4 = view.getTop() + (height / 2);
            i5 = height;
        } else {
            i5 = view.getWidth();
            i4 = view.getLeft() + (i5 / 2);
            i3 = i2;
        }
        float min = Math.min(1.0f, Math.max(-1.0f, (1.0f / ((float) ((i5 + i3) / 2))) * ((float) (i4 - (i3 / 2)))));
        float f2 = this.mAlpha;
        if (f2 > 0.0f) {
            view.setAlpha(1.0f - (f2 * Math.abs(min)));
        }
        float f3 = this.mScaleX;
        if (f3 > 0.0f || this.mScaleY > 0.0f) {
            view.setScaleX(1.0f - (f3 * Math.abs(min)));
            view.setScaleY(1.0f - (this.mScaleY * Math.abs(min)));
        }
        int i6 = this.mRotation;
        if (i6 != 0) {
            view.setRotation(((float) i6) * min);
        }
        int i7 = this.mXTranslate;
        if (i7 != 0) {
            view.setTranslationX(((float) i7) * Math.abs(min));
        }
        int i8 = this.mYTranslate;
        if (i8 != 0) {
            view.setTranslationY(((float) i8) * Math.abs(min));
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.ItemDecoration
    public void onDrawOver(Canvas canvas, RecyclerView recyclerView, RecyclerView.State state) {
        onDrawOver(canvas, recyclerView, state);
        int width = recyclerView.getWidth();
        int height = recyclerView.getHeight();
        int childCount = recyclerView.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            updateItem(recyclerView.getChildAt(i2), width, height);
        }
    }
}
