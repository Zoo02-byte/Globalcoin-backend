package com.taobao.weex.ui.view.listview.adapter;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXHeader;
import java.lang.ref.WeakReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/adapter/ListBaseViewHolder.class */
public class ListBaseViewHolder extends RecyclerView.ViewHolder {
    private boolean isRecycled;
    private WeakReference<WXComponent> mComponent;
    private int mViewType;

    public ListBaseViewHolder(View view, int i2) {
        super(view);
        this.mViewType = i2;
    }

    public ListBaseViewHolder(WXComponent wXComponent, int i2) {
        super(wXComponent.getHostView());
        this.mViewType = i2;
        this.mComponent = new WeakReference<>(wXComponent);
        this.isRecycled = wXComponent.canRecycled();
    }

    public ListBaseViewHolder(WXComponent wXComponent, int i2, boolean z2) {
        this(wXComponent, i2);
        this.isRecycled = this.isRecycled || z2;
    }

    public void bindData(WXComponent wXComponent) {
        WeakReference<WXComponent> weakReference = this.mComponent;
        if (weakReference != null && weakReference.get() != null) {
            this.mComponent.get().bindData(wXComponent);
            this.isRecycled = false;
        }
    }

    public boolean canRecycled() {
        WeakReference<WXComponent> weakReference = this.mComponent;
        if (weakReference == null || weakReference.get() == null) {
            return true;
        }
        return this.mComponent.get().canRecycled();
    }

    public WXComponent getComponent() {
        WeakReference<WXComponent> weakReference = this.mComponent;
        return weakReference != null ? weakReference.get() : null;
    }

    public View getView() {
        return this.itemView;
    }

    public int getViewType() {
        return this.mViewType;
    }

    public boolean isFullSpan() {
        WeakReference<WXComponent> weakReference = this.mComponent;
        return weakReference != null && (weakReference.get() instanceof WXHeader);
    }

    public boolean isRecycled() {
        return this.isRecycled;
    }

    public void recycled() {
        WeakReference<WXComponent> weakReference = this.mComponent;
        if (weakReference != null && weakReference.get() != null) {
            this.mComponent.get().recycled();
            this.isRecycled = true;
        }
    }

    public void setComponentUsing(boolean z2) {
        WeakReference<WXComponent> weakReference = this.mComponent;
        if (weakReference != null && weakReference.get() != null) {
            this.mComponent.get().setUsing(z2);
        }
    }
}
