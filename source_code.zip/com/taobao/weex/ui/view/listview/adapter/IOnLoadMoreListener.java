package com.taobao.weex.ui.view.listview.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/adapter/IOnLoadMoreListener.class */
public interface IOnLoadMoreListener {
    void notifyAppearStateChange(int i2, int i3, int i4, int i5);

    void onBeforeScroll(int i2, int i3);

    void onLoadMore(int i2);
}
