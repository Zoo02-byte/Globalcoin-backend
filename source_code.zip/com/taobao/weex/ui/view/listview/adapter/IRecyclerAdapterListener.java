package com.taobao.weex.ui.view.listview.adapter;

import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/listview/adapter/IRecyclerAdapterListener.class */
public interface IRecyclerAdapterListener<T extends RecyclerView.ViewHolder> {
    int getItemCount();

    long getItemId(int i2);

    int getItemViewType(int i2);

    void onBindViewHolder(T t2, int i2);

    T onCreateViewHolder(ViewGroup viewGroup, int i2);

    boolean onFailedToRecycleView(T t2);

    void onViewRecycled(T t2);
}
