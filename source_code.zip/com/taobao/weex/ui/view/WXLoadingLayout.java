package com.taobao.weex.ui.view;

import android.content.Context;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/view/WXLoadingLayout.class */
public class WXLoadingLayout extends WXBaseRefreshLayout {
    public WXLoadingLayout(Context context) {
        super(context);
    }
}
