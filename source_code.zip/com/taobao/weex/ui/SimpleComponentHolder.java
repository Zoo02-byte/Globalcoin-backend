package com.taobao.weex.ui;

import android.util.Pair;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.annotation.Component;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.Invoker;
import com.taobao.weex.bridge.MethodInvoker;
import com.taobao.weex.common.WXRuntimeException;
import com.taobao.weex.ui.action.BasicComponentData;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXComponentProp;
import com.taobao.weex.ui.component.WXVContainer;
import com.taobao.weex.utils.WXLogUtils;
import io.dcloud.feature.uniapp.UniSDKInstance;
import io.dcloud.feature.uniapp.annotation.UniJSMethod;
import io.dcloud.feature.uniapp.ui.action.AbsComponentData;
import io.dcloud.feature.uniapp.ui.component.AbsVContainer;
import io.dcloud.feature.uniapp.ui.component.UniComponent;
import io.dcloud.feature.uniapp.ui.component.UniComponentProp;
import io.dcloud.feature.uniapp.ui.component.UniVContainer;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/SimpleComponentHolder.class */
public class SimpleComponentHolder implements IFComponentHolder {
    public static final String TAG;
    private final Class<? extends WXComponent> mClz;
    private ComponentCreator mCreator;
    private Map<String, Invoker> mMethodInvokers;
    private Map<String, Invoker> mPropertyInvokers;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/ui/SimpleComponentHolder$ClazzComponentCreator.class */
    public static class ClazzComponentCreator implements ComponentCreator {
        private Constructor<? extends WXComponent> mAbsConstructor;
        private final Class<? extends WXComponent> mCompClz;
        private Constructor<? extends WXComponent> mConstructor;

        public ClazzComponentCreator(Class<? extends WXComponent> cls) {
            this.mCompClz = cls;
        }

        private Constructor<? extends WXComponent> getComponentConstructor(Boolean bool) {
            Class<?> cls;
            Class<?> cls2;
            Class<?> cls3;
            Constructor<? extends WXComponent> constructor;
            Class<? extends WXComponent> cls4 = this.mCompClz;
            if (bool.booleanValue()) {
                cls2 = UniSDKInstance.class;
                cls3 = AbsVContainer.class;
                cls = AbsComponentData.class;
            } else {
                cls2 = WXSDKInstance.class;
                cls3 = WXVContainer.class;
                cls = BasicComponentData.class;
            }
            try {
                constructor = cls4.getConstructor(cls2, cls3, cls);
            } catch (NoSuchMethodException e2) {
                WXLogUtils.d("ClazzComponentCreator", "Use deprecated component constructor");
                try {
                    constructor = cls4.getConstructor(cls2, cls3, Boolean.TYPE, cls);
                } catch (NoSuchMethodException e3) {
                    try {
                        constructor = cls4.getConstructor(cls2, cls3, String.class, Boolean.TYPE, cls);
                    } catch (NoSuchMethodException e4) {
                        throw new WXRuntimeException("Can't find constructor of component.");
                    }
                }
            }
            return constructor;
        }

        @Override // com.taobao.weex.ui.ComponentCreator
        public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
            Constructor<? extends WXComponent> constructor;
            boolean z2 = UniVContainer.class.isAssignableFrom(this.mCompClz) || UniComponent.class.isAssignableFrom(this.mCompClz);
            if (z2) {
                if (this.mAbsConstructor == null) {
                    this.mAbsConstructor = getComponentConstructor(Boolean.valueOf(z2));
                }
                constructor = this.mAbsConstructor;
            } else {
                if (this.mConstructor == null) {
                    this.mConstructor = getComponentConstructor(Boolean.valueOf(z2));
                }
                constructor = this.mConstructor;
            }
            int length = constructor.getParameterTypes().length;
            return length == 3 ? (WXComponent) constructor.newInstance(wXSDKInstance, wXVContainer, basicComponentData) : length == 4 ? (WXComponent) constructor.newInstance(wXSDKInstance, wXVContainer, false, basicComponentData) : (WXComponent) constructor.newInstance(wXSDKInstance, wXVContainer, wXSDKInstance.getInstanceId(), Boolean.valueOf(wXVContainer.isLazy()));
        }
    }

    public SimpleComponentHolder(Class<? extends WXComponent> cls) {
        this(cls, new ClazzComponentCreator(cls));
    }

    public SimpleComponentHolder(Class<? extends WXComponent> cls, ComponentCreator componentCreator) {
        this.mClz = cls;
        this.mCreator = componentCreator;
    }

    private void generate() {
        synchronized (this) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("SimpleComponentHolder", "Generate Component:" + this.mClz.getSimpleName());
            }
            Pair<Map<String, Invoker>, Map<String, Invoker>> methods = getMethods(this.mClz);
            this.mPropertyInvokers = (Map) methods.first;
            this.mMethodInvokers = (Map) methods.second;
        }
    }

    public static Pair<Map<String, Invoker>, Map<String, Invoker>> getMethods(Class cls) {
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        try {
            Method[] methods = cls.getMethods();
            for (Method method : methods) {
                try {
                    Annotation[] declaredAnnotations = method.getDeclaredAnnotations();
                    int length = declaredAnnotations.length;
                    int i2 = 0;
                    while (true) {
                        if (i2 >= length) {
                            break;
                        }
                        Annotation annotation = declaredAnnotations[i2];
                        if (annotation != null) {
                            if (annotation instanceof WXComponentProp) {
                                hashMap.put(((WXComponentProp) annotation).name(), new MethodInvoker(method, true));
                                break;
                            } else if (annotation instanceof JSMethod) {
                                JSMethod jSMethod = (JSMethod) annotation;
                                String alias = jSMethod.alias();
                                String str = alias;
                                if ("_".equals(alias)) {
                                    str = method.getName();
                                }
                                hashMap2.put(str, new MethodInvoker(method, jSMethod.uiThread()));
                            } else if (annotation instanceof UniComponentProp) {
                                hashMap.put(((UniComponentProp) annotation).name(), new MethodInvoker(method, true));
                                break;
                            } else if (annotation instanceof UniJSMethod) {
                                UniJSMethod uniJSMethod = (UniJSMethod) annotation;
                                String alias2 = uniJSMethod.alias();
                                String str2 = alias2;
                                if ("_".equals(alias2)) {
                                    str2 = method.getName();
                                }
                                hashMap2.put(str2, new MethodInvoker(method, uniJSMethod.uiThread()));
                            }
                        }
                        i2++;
                    }
                } catch (ArrayIndexOutOfBoundsException | IncompatibleClassChangeError e2) {
                }
            }
        } catch (IndexOutOfBoundsException e3) {
            e3.printStackTrace();
        } catch (Exception e4) {
            WXLogUtils.e("SimpleComponentHolder", e4);
        }
        return new Pair<>(hashMap, hashMap2);
    }

    @Override // com.taobao.weex.ui.ComponentCreator
    public WXComponent createInstance(WXSDKInstance wXSDKInstance, WXVContainer wXVContainer, BasicComponentData basicComponentData) throws IllegalAccessException, InvocationTargetException, InstantiationException {
        WXComponent createInstance;
        synchronized (this) {
            createInstance = this.mCreator.createInstance(wXSDKInstance, wXVContainer, basicComponentData);
            createInstance.bindHolder(this);
        }
        return createInstance;
    }

    @Override // com.taobao.weex.bridge.JavascriptInvokable
    public Invoker getMethodInvoker(String str) {
        if (this.mMethodInvokers == null) {
            generate();
        }
        return this.mMethodInvokers.get(str);
    }

    @Override // com.taobao.weex.bridge.JavascriptInvokable
    public String[] getMethods() {
        String[] strArr;
        synchronized (this) {
            if (this.mMethodInvokers == null) {
                generate();
            }
            Set<String> keySet = this.mMethodInvokers.keySet();
            strArr = (String[]) keySet.toArray(new String[keySet.size()]);
        }
        return strArr;
    }

    @Override // io.dcloud.feature.uniapp.ui.AbsIComponentHolder
    public Invoker getPropertyInvoker(String str) {
        Invoker invoker;
        synchronized (this) {
            if (this.mPropertyInvokers == null) {
                generate();
            }
            invoker = this.mPropertyInvokers.get(str);
        }
        return invoker;
    }

    @Override // io.dcloud.feature.uniapp.ui.AbsIComponentHolder
    public void loadIfNonLazy() {
        Annotation[] declaredAnnotations = this.mClz.getDeclaredAnnotations();
        for (Annotation annotation : declaredAnnotations) {
            if (annotation instanceof Component) {
                if (!((Component) annotation).lazyload() && this.mMethodInvokers == null) {
                    generate();
                    return;
                } else {
                    return;
                }
            }
        }
    }
}
