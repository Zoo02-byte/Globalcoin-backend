package com.taobao.weex.ui.module;

import android.app.Application;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.LocaleList;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.WXModule;
import com.taobao.weex.el.parse.Operators;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/module/WXLocaleModule.class */
public class WXLocaleModule extends WXModule {
    private String getLanguageImpl() {
        Locale locale = LocaleList.getDefault().get(0);
        return locale.getLanguage() + Operators.SUB + locale.getCountry();
    }

    private String getLanguageTags() {
        Resources resources;
        Configuration configuration;
        Application application = WXEnvironment.getApplication();
        return (application == null || (resources = application.getResources()) == null || (configuration = resources.getConfiguration()) == null) ? "" : configuration.getLocales().toLanguageTags();
    }

    private String toLanguageTag(Locale locale) {
        return locale.toLanguageTag();
    }

    @JSMethod(uiThread = false)
    public void getLanguage(JSCallback jSCallback) {
        jSCallback.invoke(getLanguageImpl());
    }

    @JSMethod(uiThread = false)
    public String getLanguageSync() {
        return getLanguageImpl();
    }

    @JSMethod(uiThread = false)
    public List<String> getLanguages() {
        return Arrays.asList(getLanguageTags().split(","));
    }

    @JSMethod(uiThread = false)
    public void getLanguages(JSCallback jSCallback) {
        jSCallback.invoke(getLanguageTags().split(","));
    }
}
