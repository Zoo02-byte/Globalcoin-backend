package com.taobao.weex.ui.module;

import android.text.TextUtils;
import androidx.collection.ArrayMap;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.WXModule;
import com.taobao.weex.ui.component.WXImage;
import com.taobao.weex.utils.LogLevel;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.feature.uniapp.utils.AbsLogLevel;
import kotlinx.coroutines.DebugKt;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/module/ConsoleLogModule.class */
public class ConsoleLogModule extends WXModule {
    private AbsLogLevel getLogLevel(String str) {
        LogLevel logLevel;
        if (!TextUtils.isEmpty(str)) {
            str.hashCode();
            char c2 = 65535;
            switch (str.hashCode()) {
                case 109935:
                    if (str.equals(DebugKt.DEBUG_PROPERTY_VALUE_OFF)) {
                        c2 = 0;
                        break;
                    }
                    break;
                case 3237038:
                    if (str.equals("info")) {
                        c2 = 1;
                        break;
                    }
                    break;
                case 95458899:
                    if (str.equals("debug")) {
                        c2 = 2;
                        break;
                    }
                    break;
                case 96784904:
                    if (str.equals("error")) {
                        c2 = 3;
                        break;
                    }
                    break;
                case 1124446108:
                    if (str.equals("warning")) {
                        c2 = 4;
                        break;
                    }
                    break;
            }
            switch (c2) {
                case 0:
                    logLevel = LogLevel.OFF;
                    break;
                case 1:
                    logLevel = LogLevel.INFO;
                    break;
                case 2:
                    logLevel = LogLevel.DEBUG;
                    break;
                case 3:
                    logLevel = LogLevel.ERROR;
                    break;
                case 4:
                    logLevel = LogLevel.WARN;
                    break;
            }
            return logLevel;
        }
        logLevel = null;
        return logLevel;
    }

    @JSMethod(uiThread = false)
    public void setPerfMode(String str) {
        WXEnvironment.isPerf = AbsoluteConst.TRUE.equals(str);
        WXBridgeManager.getInstance().setLogLevel(WXEnvironment.sLogLevel.getValue(), WXEnvironment.isPerf());
    }

    @JSMethod(uiThread = false)
    public void switchLogLevel(String str, JSCallback jSCallback) {
        AbsLogLevel logLevel = getLogLevel(str);
        ArrayMap arrayMap = new ArrayMap();
        if (logLevel != null) {
            WXEnvironment.sLogLevel = logLevel;
            WXBridgeManager.getInstance().setLogLevel(WXEnvironment.sLogLevel.getValue(), WXEnvironment.isPerf());
            arrayMap.put("status", WXImage.SUCCEED);
        } else {
            arrayMap.put("status", "failure");
        }
        if (jSCallback != null) {
            jSCallback.invoke(arrayMap);
        }
    }
}
