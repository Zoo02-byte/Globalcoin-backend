package com.taobao.weex.ui.module;

import android.app.Dialog;
import android.content.DialogInterface;
import android.widget.Toast;
import com.taobao.weex.WXSDKEngine;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/module/WXModalUIModule.class */
public class WXModalUIModule extends WXSDKEngine.DestroyableModule {
    public static final String CANCEL = "Cancel";
    public static final String CANCEL_TITLE = "cancelTitle";
    public static final String DATA = "data";
    public static final String DEFAULT = "default";
    public static final String DURATION = "duration";
    public static final String GRAVITY = "gravity";
    public static final String MESSAGE = "message";
    public static final String OK = "OK";
    public static final String OK_TITLE = "okTitle";
    public static final String RESULT = "result";
    private Dialog activeDialog;
    private Toast toast;

    private void tracking(Dialog dialog) {
        this.activeDialog = dialog;
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener(this) { // from class: com.taobao.weex.ui.module.WXModalUIModule.6
            final WXModalUIModule this$0;

            {
                this.this$0 = r4;
            }

            @Override // android.content.DialogInterface.OnDismissListener
            public void onDismiss(DialogInterface dialogInterface) {
                this.this$0.activeDialog = null;
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x006f  */
    @com.taobao.weex.annotation.JSMethod(uiThread = true)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void alert(com.alibaba.fastjson.JSONObject r9, com.taobao.weex.bridge.JSCallback r10) {
        /*
            r8 = this;
            r0 = r8
            com.taobao.weex.WXSDKInstance r0 = r0.mWXSDKInstance
            android.content.Context r0 = r0.getContext()
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L_0x009d
            java.lang.String r0 = "OK"
            r12 = r0
            java.lang.String r0 = ""
            r13 = r0
            r0 = r9
            if (r0 == 0) goto L_0x003e
            r0 = r9
            java.lang.String r1 = "message"
            java.lang.String r0 = r0.getString(r1)     // Catch: Exception -> 0x002e
            r11 = r0
            r0 = r9
            java.lang.String r1 = "okTitle"
            java.lang.String r0 = r0.getString(r1)     // Catch: Exception -> 0x002a
            r9 = r0
            goto L_0x0044
        L_0x002a:
            r9 = move-exception
            goto L_0x0032
        L_0x002e:
            r9 = move-exception
            java.lang.String r0 = ""
            r11 = r0
        L_0x0032:
            java.lang.String r0 = "[WXModalUIModule] alert param parse error "
            r1 = r9
            com.taobao.weex.utils.WXLogUtils.e(r0, r1)
            java.lang.String r0 = "OK"
            r9 = r0
            goto L_0x0044
        L_0x003e:
            java.lang.String r0 = "OK"
            r9 = r0
            java.lang.String r0 = ""
            r11 = r0
        L_0x0044:
            r0 = r11
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto L_0x0051
            r0 = r13
            r11 = r0
            goto L_0x0051
        L_0x0051:
            android.app.AlertDialog$Builder r0 = new android.app.AlertDialog$Builder
            r1 = r0
            r2 = r8
            com.taobao.weex.WXSDKInstance r2 = r2.mWXSDKInstance
            android.content.Context r2 = r2.getContext()
            r1.<init>(r2)
            r13 = r0
            r0 = r13
            r1 = r11
            android.app.AlertDialog$Builder r0 = r0.setMessage(r1)
            r0 = r9
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 == 0) goto L_0x0075
            r0 = r12
            r9 = r0
            goto L_0x0075
        L_0x0075:
            r0 = r13
            r1 = r9
            com.taobao.weex.ui.module.WXModalUIModule$1 r2 = new com.taobao.weex.ui.module.WXModalUIModule$1
            r3 = r2
            r4 = r8
            r5 = r10
            r6 = r9
            r3.<init>(r4, r5, r6)
            android.app.AlertDialog$Builder r0 = r0.setPositiveButton(r1, r2)
            r0 = r13
            android.app.AlertDialog r0 = r0.create()
            r9 = r0
            r0 = r9
            r1 = 0
            r0.setCanceledOnTouchOutside(r1)
            r0 = r9
            r0.show()
            r0 = r8
            r1 = r9
            r0.tracking(r1)
            goto L_0x00a2
        L_0x009d:
            java.lang.String r0 = "[WXModalUIModule] when call alert mWXSDKInstance.getContext() must instanceof Activity"
            com.taobao.weex.utils.WXLogUtils.e(r0)
        L_0x00a2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.module.WXModalUIModule.alert(com.alibaba.fastjson.JSONObject, com.taobao.weex.bridge.JSCallback):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0067  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x008d  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x009a  */
    @com.taobao.weex.annotation.JSMethod(uiThread = true)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void confirm(com.alibaba.fastjson.JSONObject r9, com.taobao.weex.bridge.JSCallback r10) {
        /*
        // Method dump skipped, instructions count: 223
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.module.WXModalUIModule.confirm(com.alibaba.fastjson.JSONObject, com.taobao.weex.bridge.JSCallback):void");
    }

    @Override // com.taobao.weex.common.Destroyable
    public void destroy() {
        Dialog dialog = this.activeDialog;
        if (dialog != null && dialog.isShowing()) {
            this.activeDialog.dismiss();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00f2  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ff  */
    @com.taobao.weex.annotation.JSMethod(uiThread = true)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void prompt(com.alibaba.fastjson.JSONObject r10, com.taobao.weex.bridge.JSCallback r11) {
        /*
        // Method dump skipped, instructions count: 325
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.module.WXModalUIModule.prompt(com.alibaba.fastjson.JSONObject, com.taobao.weex.bridge.JSCallback):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00b5  */
    @com.taobao.weex.annotation.JSMethod(uiThread = true)
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void toast(com.alibaba.fastjson.JSONObject r6) {
        /*
        // Method dump skipped, instructions count: 260
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.ui.module.WXModalUIModule.toast(com.alibaba.fastjson.JSONObject):void");
    }
}
