package com.taobao.weex.ui.module;

import android.os.Handler;
import android.os.Message;
import android.util.SparseArray;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.bridge.WXHashMap;
import com.taobao.weex.bridge.WXJSObject;
import com.taobao.weex.common.Destroyable;
import com.taobao.weex.common.WXModule;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.utils.WXJsonUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import java.util.ArrayList;
import java.util.HashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/module/WXTimerModule.class */
public class WXTimerModule extends WXModule implements Destroyable, Handler.Callback {
    private static final String TAG = "timer";
    private Handler handler = new Handler(WXBridgeManager.getInstance().getJSLooper(), this);
    private SparseArray<Integer> antiIntAutoBoxing = new SparseArray<>();

    private void checkIfTimerInBack(int i2) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(String.valueOf(i2));
        if (sDKInstance != null && sDKInstance.isViewDisAppear()) {
            sDKInstance.getApmForInstance().updateDiffStats(WXInstanceApm.KEY_PAGE_TIMER_BACK_NUM, 1.0d);
        }
    }

    private WXJSObject[] createTimerArgs(int i2, int i3, boolean z2) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(Integer.valueOf(i3));
        arrayList.add(new HashMap());
        arrayList.add(Boolean.valueOf(z2));
        WXHashMap wXHashMap = new WXHashMap();
        wXHashMap.put("method", WXBridgeManager.METHOD_CALLBACK);
        wXHashMap.put("args", arrayList);
        return new WXJSObject[]{new WXJSObject(2, String.valueOf(i2)), new WXJSObject(3, WXJsonUtils.fromObjectToJSONString(new Object[]{wXHashMap}))};
    }

    private void postMessage(int i2, int i3, int i4, int i5) {
        if (i4 < 0 || i3 <= 0) {
            WXLogUtils.e(TAG, "interval < 0 or funcId <=0");
            return;
        }
        if (this.antiIntAutoBoxing.get(i3) == null) {
            this.antiIntAutoBoxing.put(i3, Integer.valueOf(i3));
        }
        this.handler.sendMessageDelayed(this.handler.obtainMessage(i2, i5, i4, this.antiIntAutoBoxing.get(i3)), (long) i4);
    }

    private void postOrHoldMessage(int i2, int i3, int i4, int i5) {
        if (this.mWXSDKInstance.isPreRenderMode()) {
            postMessage(i2, i3, i4, i5);
        } else {
            postMessage(i2, i3, i4, i5);
        }
    }

    private void removeOrHoldMessage(int i2, int i3) {
        if (this.mWXSDKInstance.isPreRenderMode()) {
            this.handler.removeMessages(i2, this.antiIntAutoBoxing.get(i3, Integer.valueOf(i3)));
        } else {
            this.handler.removeMessages(i2, this.antiIntAutoBoxing.get(i3, Integer.valueOf(i3)));
        }
    }

    @JSMethod(uiThread = false)
    public void clearInterval(int i2) {
        if (i2 > 0) {
            removeOrHoldMessage(12, i2);
        }
    }

    @JSMethod(uiThread = false)
    public void clearTimeout(int i2) {
        if (i2 > 0) {
            removeOrHoldMessage(11, i2);
        }
    }

    @Override // com.taobao.weex.common.Destroyable
    public void destroy() {
        if (this.handler != null) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d(TAG, "Timer Module removeAllMessages: ");
            }
            this.handler.removeCallbacksAndMessages(null);
            this.antiIntAutoBoxing.clear();
        }
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message message) {
        boolean z2 = false;
        if (message != null) {
            int i2 = message.what;
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d(TAG, "Timer Module handleMessage : " + message.what);
            }
            if (i2 != 11) {
                if (i2 != 12) {
                    z2 = false;
                } else if (message.obj == null) {
                    z2 = false;
                } else {
                    checkIfTimerInBack(message.arg1);
                    postMessage(12, ((Integer) message.obj).intValue(), message.arg2, message.arg1);
                    WXBridgeManager.getInstance().invokeExecJS(String.valueOf(message.arg1), null, WXBridgeManager.METHOD_CALL_JS, createTimerArgs(message.arg1, ((Integer) message.obj).intValue(), true), true);
                    z2 = true;
                }
            } else if (message.obj == null) {
                z2 = false;
            } else {
                checkIfTimerInBack(message.arg1);
                WXBridgeManager.getInstance().invokeExecJS(String.valueOf(message.arg1), null, WXBridgeManager.METHOD_CALL_JS, createTimerArgs(message.arg1, ((Integer) message.obj).intValue(), false), true);
                z2 = true;
            }
        }
        return z2;
    }

    void setHandler(Handler handler) {
        this.handler = handler;
    }

    @JSMethod(uiThread = false)
    public void setInterval(int i2, float f2) {
        if (this.mWXSDKInstance != null) {
            postOrHoldMessage(12, i2, (int) f2, WXUtils.parseInt(this.mWXSDKInstance.getInstanceId()));
            if (this.mWXSDKInstance.getWXPerformance() != null) {
                this.mWXSDKInstance.getWXPerformance().timerInvokeCount++;
            }
            this.mWXSDKInstance.getApmForInstance().updateFSDiffStats(WXInstanceApm.KEY_PAGE_STATS_FS_TIMER_NUM, 1.0d);
        }
    }

    @JSMethod(uiThread = false)
    public void setTimeout(int i2, float f2) {
        if (this.mWXSDKInstance != null) {
            postOrHoldMessage(11, i2, (int) f2, WXUtils.parseInt(this.mWXSDKInstance.getInstanceId()));
            if (this.mWXSDKInstance.getWXPerformance() != null) {
                this.mWXSDKInstance.getWXPerformance().timerInvokeCount++;
            }
            this.mWXSDKInstance.getApmForInstance().updateFSDiffStats(WXInstanceApm.KEY_PAGE_STATS_FS_TIMER_NUM, 1.0d);
        }
    }
}
