package com.taobao.weex.ui.animation;

import android.animation.PropertyValuesHolder;
import android.text.TextUtils;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import androidx.collection.ArrayMap;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.utils.FunctionParser;
import com.taobao.weex.utils.WXDataStructureUtil;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/animation/TransformParser.class */
public class TransformParser {
    public static final String BACKGROUND_COLOR;
    public static final String BOTTOM;
    public static final String CENTER;
    private static final String DEG;
    private static final String FULL;
    private static final String HALF;
    public static final String HEIGHT;
    public static final String LEFT;
    private static final String PX;
    public static final String RIGHT;
    public static final String TOP;
    public static final String WIDTH;
    public static final String WX_ROTATE;
    public static final String WX_ROTATE_X;
    public static final String WX_ROTATE_Y;
    public static final String WX_ROTATE_Z;
    public static final String WX_SCALE;
    public static final String WX_SCALE_X;
    public static final String WX_SCALE_Y;
    public static final String WX_TRANSLATE;
    public static final String WX_TRANSLATE_X;
    public static final String WX_TRANSLATE_Y;
    private static final String ZERO;
    public static Map<String, List<Property<View, Float>>> wxToAndroidMap;

    static {
        ArrayMap arrayMap = new ArrayMap();
        wxToAndroidMap = arrayMap;
        arrayMap.put("translate", Arrays.asList(View.TRANSLATION_X, View.TRANSLATION_Y));
        wxToAndroidMap.put("translateX", Collections.singletonList(View.TRANSLATION_X));
        wxToAndroidMap.put("translateY", Collections.singletonList(View.TRANSLATION_Y));
        wxToAndroidMap.put("rotate", Collections.singletonList(View.ROTATION));
        wxToAndroidMap.put(WX_ROTATE_Z, Collections.singletonList(View.ROTATION));
        wxToAndroidMap.put("rotateX", Collections.singletonList(View.ROTATION_X));
        wxToAndroidMap.put("rotateY", Collections.singletonList(View.ROTATION_Y));
        wxToAndroidMap.put("scale", Arrays.asList(View.SCALE_X, View.SCALE_Y));
        wxToAndroidMap.put("scaleX", Collections.singletonList(View.SCALE_X));
        wxToAndroidMap.put("scaleY", Collections.singletonList(View.SCALE_Y));
        wxToAndroidMap.put(Constants.Name.PERSPECTIVE, Collections.singletonList(CameraDistanceProperty.getInstance()));
        wxToAndroidMap = Collections.unmodifiableMap(wxToAndroidMap);
    }

    private static float parsePercent(String str, int i2, int i3) {
        return (WXUtils.fastGetFloat(str, (float) i3) / 100.0f) * ((float) i2);
    }

    public static float parsePercentOrPx(String str, int i2, float f2) {
        int lastIndexOf = str.lastIndexOf(37);
        if (lastIndexOf != -1) {
            return parsePercent(str.substring(0, lastIndexOf), i2, 1);
        }
        int lastIndexOf2 = str.lastIndexOf(PX);
        return lastIndexOf2 != -1 ? WXViewUtils.getRealPxByWidth(WXUtils.fastGetFloat(str.substring(0, lastIndexOf2), 1.0f), f2) : WXViewUtils.getRealPxByWidth(WXUtils.fastGetFloat(str, 1.0f), f2);
    }

    private static Pair<Float, Float> parsePivot(String str, int i2, int i3, float f2) {
        int indexOf;
        if (TextUtils.isEmpty(str) || (indexOf = str.indexOf(32)) == -1) {
            return null;
        }
        int i4 = indexOf;
        while (i4 < str.length() && str.charAt(i4) == ' ') {
            i4++;
        }
        if (i4 >= str.length() || str.charAt(i4) == ' ') {
            return null;
        }
        ArrayList arrayList = new ArrayList(2);
        arrayList.add(str.substring(0, indexOf).trim());
        arrayList.add(str.substring(i4, str.length()).trim());
        return parsePivot(arrayList, i2, i3, f2);
    }

    private static Pair<Float, Float> parsePivot(List<String> list, int i2, int i3, float f2) {
        return new Pair<>(Float.valueOf(parsePivotX(list.get(0), i2, f2)), Float.valueOf(parsePivotY(list.get(1), i3, f2)));
    }

    private static float parsePivotX(String str, int i2, float f2) {
        String str2;
        if ("left".equals(str)) {
            str2 = ZERO;
        } else if ("right".equals(str)) {
            str2 = FULL;
        } else {
            str2 = str;
            if ("center".equals(str)) {
                str2 = HALF;
            }
        }
        return parsePercentOrPx(str2, i2, f2);
    }

    private static float parsePivotY(String str, int i2, float f2) {
        String str2;
        if ("top".equals(str)) {
            str2 = ZERO;
        } else if ("bottom".equals(str)) {
            str2 = FULL;
        } else {
            str2 = str;
            if ("center".equals(str)) {
                str2 = HALF;
            }
        }
        return parsePercentOrPx(str2, i2, f2);
    }

    public static Map<Property<View, Float>, Float> parseTransForm(String str, String str2, int i2, int i3, float f2) {
        try {
            if (!TextUtils.isEmpty(str2)) {
                return new FunctionParser(str2, new FunctionParser.Mapper<Property<View, Float>, Float>(i2, i3, f2) { // from class: com.taobao.weex.ui.animation.TransformParser.1
                    final int val$height;
                    final float val$viewportW;
                    final int val$width;

                    {
                        this.val$width = r4;
                        this.val$height = r5;
                        this.val$viewportW = r6;
                    }

                    private Map<Property<View, Float>, Float> convertParam(int i4, int i5, float f3, List<Property<View, Float>> list, List<String> list2) {
                        HashMap newHashMapWithExpectedSize = WXDataStructureUtil.newHashMapWithExpectedSize(list.size());
                        ArrayList arrayList = new ArrayList(list.size());
                        if (list.contains(View.ROTATION) || list.contains(View.ROTATION_X) || list.contains(View.ROTATION_Y)) {
                            arrayList.addAll(parseRotationZ(list2));
                        } else if (list.contains(View.TRANSLATION_X) || list.contains(View.TRANSLATION_Y)) {
                            arrayList.addAll(parseTranslation(list, i4, i5, list2, f3));
                        } else if (list.contains(View.SCALE_X) || list.contains(View.SCALE_Y)) {
                            arrayList.addAll(parseScale(list.size(), list2));
                        } else if (list.contains(CameraDistanceProperty.getInstance())) {
                            arrayList.add(parseCameraDistance(list2));
                        }
                        if (list.size() == arrayList.size()) {
                            for (int i6 = 0; i6 < list.size(); i6++) {
                                newHashMapWithExpectedSize.put(list.get(i6), (Float) arrayList.get(i6));
                            }
                        }
                        return newHashMapWithExpectedSize;
                    }

                    private Float parseCameraDistance(List<String> list) {
                        float f3;
                        if (list.size() == 1) {
                            float realPxByWidth = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(list.get(0)), this.val$viewportW);
                            float f4 = WXEnvironment.getApplication().getResources().getDisplayMetrics().density;
                            if (!Float.isNaN(realPxByWidth) && realPxByWidth > 0.0f) {
                                f3 = realPxByWidth * f4;
                                return Float.valueOf(f3);
                            }
                        }
                        f3 = Float.MAX_VALUE;
                        return Float.valueOf(f3);
                    }

                    private void parseDoubleTranslation(int i4, int i5, List<String> list, List<Float> list2, String str3, float f3) {
                        String str4 = list.size() == 1 ? str3 : list.get(1);
                        list2.add(Float.valueOf(TransformParser.parsePercentOrPx(str3, i4, f3)));
                        list2.add(Float.valueOf(TransformParser.parsePercentOrPx(str4, i5, f3)));
                    }

                    private List<Float> parseRotationZ(List<String> list) {
                        ArrayList arrayList = new ArrayList(1);
                        for (String str3 : list) {
                            int lastIndexOf = str3.lastIndexOf(TransformParser.DEG);
                            if (lastIndexOf != -1) {
                                arrayList.add(Float.valueOf(WXUtils.fastGetFloat(str3.substring(0, lastIndexOf))));
                            } else {
                                arrayList.add(Float.valueOf((float) Math.toDegrees((double) WXUtils.fastGetFloat(str3))));
                            }
                        }
                        return arrayList;
                    }

                    private List<Float> parseScale(int i4, List<String> list) {
                        ArrayList arrayList = new ArrayList(list.size() * 2);
                        ArrayList arrayList2 = new ArrayList(list.size());
                        for (String str3 : list) {
                            arrayList2.add(Float.valueOf(WXUtils.fastGetFloat(str3)));
                        }
                        arrayList.addAll(arrayList2);
                        if (i4 != 1 && list.size() == 1) {
                            arrayList.addAll(arrayList2);
                        }
                        return arrayList;
                    }

                    private void parseSingleTranslation(List<Property<View, Float>> list, int i4, int i5, List<Float> list2, String str3, float f3) {
                        if (list.contains(View.TRANSLATION_X)) {
                            list2.add(Float.valueOf(TransformParser.parsePercentOrPx(str3, i4, f3)));
                        } else if (list.contains(View.TRANSLATION_Y)) {
                            list2.add(Float.valueOf(TransformParser.parsePercentOrPx(str3, i5, f3)));
                        }
                    }

                    private List<Float> parseTranslation(List<Property<View, Float>> list, int i4, int i5, List<String> list2, float f3) {
                        ArrayList arrayList = new ArrayList(2);
                        String str3 = list2.get(0);
                        if (list.size() == 1) {
                            parseSingleTranslation(list, i4, i5, arrayList, str3, f3);
                        } else {
                            parseDoubleTranslation(i4, i5, list2, arrayList, str3, f3);
                        }
                        return arrayList;
                    }

                    @Override // com.taobao.weex.utils.FunctionParser.Mapper
                    public Map<Property<View, Float>, Float> map(String str3, List<String> list) {
                        return (list == null || list.isEmpty() || !TransformParser.wxToAndroidMap.containsKey(str3)) ? new HashMap() : convertParam(this.val$width, this.val$height, this.val$viewportW, TransformParser.wxToAndroidMap.get(str3), list);
                    }
                }).parse();
            }
        } catch (Exception e2) {
            WXLogUtils.e("TransformParser", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_TRANSITION, "parse animation transition", WXErrorCode.WX_RENDER_ERR_TRANSITION.getErrorMsg() + "parse transition error: " + e2.getMessage(), null);
        }
        return new LinkedHashMap();
    }

    public static PropertyValuesHolder[] toHolders(Map<Property<View, Float>, Float> map) {
        PropertyValuesHolder[] propertyValuesHolderArr = new PropertyValuesHolder[map.size()];
        int i2 = 0;
        for (Map.Entry<Property<View, Float>, Float> entry : map.entrySet()) {
            propertyValuesHolderArr[i2] = PropertyValuesHolder.ofFloat(entry.getKey(), entry.getValue().floatValue());
            i2++;
        }
        return propertyValuesHolderArr;
    }
}
