package com.taobao.weex.ui.animation;

import android.view.View;
import android.view.ViewGroup;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/animation/WidthProperty.class */
public class WidthProperty extends LayoutParamsProperty {
    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    public /* bridge */ /* synthetic */ Integer get(View view) {
        return get(view);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    protected Integer getProperty(ViewGroup.LayoutParams layoutParams) {
        return Integer.valueOf(layoutParams.width);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    public /* bridge */ /* synthetic */ void set(View view, Integer num) {
        set(view, num);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    protected void setProperty(ViewGroup.LayoutParams layoutParams, Integer num) {
        layoutParams.width = num.intValue();
    }
}
