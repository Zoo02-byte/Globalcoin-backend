package com.taobao.weex.ui.animation;

import android.util.Property;
import android.view.View;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/animation/CameraDistanceProperty.class */
class CameraDistanceProperty extends Property<View, Float> {
    private static final String TAG = "CameraDistance";
    private static CameraDistanceProperty instance;

    private CameraDistanceProperty() {
        super(Float.class, TAG);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Property<View, Float> getInstance() {
        return instance;
    }

    public Float get(View view) {
        return Float.valueOf(view.getCameraDistance());
    }

    public void set(View view, Float f2) {
        view.setCameraDistance(f2.floatValue());
    }
}
