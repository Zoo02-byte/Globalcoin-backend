package com.taobao.weex.ui.animation;

import android.view.View;
import android.view.ViewGroup;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/animation/HeightProperty.class */
public class HeightProperty extends LayoutParamsProperty {
    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    public /* bridge */ /* synthetic */ Integer get(View view) {
        return get(view);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    protected Integer getProperty(ViewGroup.LayoutParams layoutParams) {
        return Integer.valueOf(layoutParams.height);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    public /* bridge */ /* synthetic */ void set(View view, Integer num) {
        set(view, num);
    }

    @Override // com.taobao.weex.ui.animation.LayoutParamsProperty
    protected void setProperty(ViewGroup.LayoutParams layoutParams, Integer num) {
        layoutParams.height = num.intValue();
    }
}
