package com.taobao.weex.ui;

import io.dcloud.feature.uniapp.ui.AbsIComponentHolder;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ui/IFComponentHolder.class */
public interface IFComponentHolder extends AbsIComponentHolder {
}
