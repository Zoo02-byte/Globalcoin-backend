package com.taobao.weex;
/* loaded from: Coinglobal1.jar:com/taobao/weex/IWXStatisticsListener.class */
public interface IWXStatisticsListener {
    void onException(String str, String str2, String str3);

    void onFirstScreen();

    void onFirstView();

    void onHeadersReceived();

    void onHttpFinish();

    void onHttpStart();

    void onJsFrameworkReady();

    void onJsFrameworkStart();

    void onSDKEngineInitialize();
}
