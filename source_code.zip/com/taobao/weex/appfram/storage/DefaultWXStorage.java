package com.taobao.weex.appfram.storage;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteFullException;
import android.database.sqlite.SQLiteStatement;
import com.taobao.weex.appfram.storage.IWXStorageAdapter;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.ui.component.WXImage;
import com.taobao.weex.utils.WXLogUtils;
import io.dcloud.common.DHInterface.IApp;
import io.dcloud.common.constant.AbsoluteConst;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/storage/DefaultWXStorage.class */
public class DefaultWXStorage implements IWXStorageAdapter {
    private WXSQLiteOpenHelper mDatabaseSupplier;
    private ExecutorService mExecutorService;

    public DefaultWXStorage(Context context) {
        this.mDatabaseSupplier = new WXSQLiteOpenHelper(context);
    }

    private void execute(Runnable runnable) {
        if (this.mExecutorService == null) {
            this.mExecutorService = Executors.newSingleThreadExecutor();
        }
        if (runnable != null && !this.mExecutorService.isShutdown() && !this.mExecutorService.isTerminated()) {
            this.mExecutorService.execute(WXThread.secure(runnable));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public List<String> performGetAllKeys() {
        SQLiteDatabase database = this.mDatabaseSupplier.getDatabase();
        if (database == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        Cursor query = database.query("default_wx_storage", new String[]{IApp.ConfigProperty.CONFIG_KEY}, null, null, null, null, null);
        while (query.moveToNext()) {
            try {
                arrayList.add(query.getString(query.getColumnIndex(IApp.ConfigProperty.CONFIG_KEY)));
            } catch (Exception e2) {
                WXLogUtils.e("weex_storage", "DefaultWXStorage occurred an exception when execute getAllKeys:" + e2.getMessage());
                return arrayList;
            } finally {
                query.close();
            }
        }
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String performGetItem(String str) {
        SQLiteDatabase database = this.mDatabaseSupplier.getDatabase();
        if (database == null) {
            return null;
        }
        Cursor query = database.query("default_wx_storage", new String[]{"value"}, "key=?", new String[]{str}, null, null, null);
        try {
            try {
                if (query.moveToNext()) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("timestamp", WXSQLiteOpenHelper.sDateFormatter.format(new Date()));
                    WXLogUtils.d("weex_storage", "update timestamp " + (this.mDatabaseSupplier.getDatabase().update("default_wx_storage", contentValues, "key= ?", new String[]{str}) == 1 ? WXImage.SUCCEED : AbsoluteConst.EVENTS_FAILED) + " for operation [getItem(key = " + str + ")]");
                    return query.getString(query.getColumnIndex("value"));
                }
            } catch (Exception e2) {
                WXLogUtils.e("weex_storage", "DefaultWXStorage occurred an exception when execute getItem:" + e2.getMessage());
            }
            query.close();
            return null;
        } finally {
            query.close();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public long performGetLength() {
        SQLiteDatabase database = this.mDatabaseSupplier.getDatabase();
        if (database == null) {
            return 0;
        }
        SQLiteStatement sQLiteStatement = null;
        SQLiteStatement sQLiteStatement2 = null;
        try {
            try {
                SQLiteStatement compileStatement = database.compileStatement("SELECT count(key) FROM default_wx_storage");
                sQLiteStatement2 = compileStatement;
                sQLiteStatement = compileStatement;
                long simpleQueryForLong = compileStatement.simpleQueryForLong();
                if (compileStatement != null) {
                    compileStatement.close();
                }
                return simpleQueryForLong;
            } catch (Exception e2) {
                sQLiteStatement2 = sQLiteStatement;
                WXLogUtils.e("weex_storage", "DefaultWXStorage occurred an exception when execute getLength:" + e2.getMessage());
                if (sQLiteStatement == null) {
                    return 0;
                }
                sQLiteStatement.close();
                return 0;
            }
        } catch (Throwable th) {
            if (sQLiteStatement2 != null) {
                sQLiteStatement2.close();
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean performRemoveItem(String str) {
        SQLiteDatabase database = this.mDatabaseSupplier.getDatabase();
        boolean z2 = false;
        if (database == null) {
            return false;
        }
        try {
            if (database.delete("default_wx_storage", "key=?", new String[]{str}) == 1) {
                z2 = true;
            }
            return z2;
        } catch (Exception e2) {
            WXLogUtils.e("weex_storage", "DefaultWXStorage occurred an exception when execute removeItem:" + e2.getMessage());
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean performSetItem(String str, String str2, boolean z2, boolean z3) {
        SQLiteStatement sQLiteStatement;
        SQLiteDatabase database = this.mDatabaseSupplier.getDatabase();
        if (database == null) {
            return false;
        }
        try {
            WXLogUtils.d("weex_storage", "set k-v to storage(key:" + str + ",value:" + str2 + ",isPersistent:" + z2 + ",allowRetry:" + z3 + Operators.BRACKET_END_STR);
            String format = WXSQLiteOpenHelper.sDateFormatter.format(new Date());
            SQLiteStatement sQLiteStatement2 = null;
            sQLiteStatement = null;
            try {
                SQLiteStatement compileStatement = database.compileStatement("INSERT OR REPLACE INTO default_wx_storage VALUES (?,?,?,?);");
                compileStatement.clearBindings();
                compileStatement.bindString(1, str);
                compileStatement.bindString(2, str2);
                compileStatement.bindString(3, format);
                compileStatement.bindLong(4, z2 ? 1 : 0);
                sQLiteStatement = compileStatement;
                sQLiteStatement2 = compileStatement;
                compileStatement.execute();
                if (compileStatement == null) {
                    return true;
                }
                compileStatement.close();
                return true;
            } catch (Exception e2) {
                WXLogUtils.e("weex_storage", "DefaultWXStorage occurred an exception when execute setItem :" + e2.getMessage());
                if ((e2 instanceof SQLiteFullException) && z3 && trimToSize()) {
                    WXLogUtils.d("weex_storage", "retry set k-v to storage(key:" + str + ",value:" + str2 + Operators.BRACKET_END_STR);
                    boolean performSetItem = performSetItem(str, str2, z2, false);
                    if (sQLiteStatement2 != null) {
                        sQLiteStatement2.close();
                    }
                    return performSetItem;
                } else if (sQLiteStatement2 == null) {
                    return false;
                } else {
                    sQLiteStatement2.close();
                    return false;
                }
            }
        } catch (Throwable th) {
            if (sQLiteStatement != null) {
                sQLiteStatement.close();
            }
            throw th;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00e2 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00e4  */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private boolean trimToSize() {
        /*
        // Method dump skipped, instructions count: 305
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.appfram.storage.DefaultWXStorage.trimToSize():boolean");
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void close() {
        execute(new Runnable(this, this.mExecutorService) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.7
            final DefaultWXStorage this$0;
            final ExecutorService val$needCloseService;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$needCloseService = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    this.this$0.mDatabaseSupplier.closeDatabase();
                    ExecutorService executorService = this.val$needCloseService;
                    if (executorService != null) {
                        executorService.shutdown();
                    }
                } catch (Exception e2) {
                    WXLogUtils.e("weex_storage", e2.getMessage());
                }
            }
        });
        this.mExecutorService = null;
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void getAllKeys(IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.5
            final DefaultWXStorage this$0;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$listener = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> allkeysResult = StorageResultHandler.getAllkeysResult(this.this$0.performGetAllKeys());
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(allkeysResult);
                }
            }
        });
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void getItem(String str, IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, str, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.2
            final DefaultWXStorage this$0;
            final String val$key;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$key = r5;
                this.val$listener = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> itemResult = StorageResultHandler.getItemResult(this.this$0.performGetItem(this.val$key));
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(itemResult);
                }
            }
        });
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void length(IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.4
            final DefaultWXStorage this$0;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$listener = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> lengthResult = StorageResultHandler.getLengthResult(this.this$0.performGetLength());
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(lengthResult);
                }
            }
        });
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void removeItem(String str, IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, str, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.3
            final DefaultWXStorage this$0;
            final String val$key;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$key = r5;
                this.val$listener = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> removeItemResult = StorageResultHandler.removeItemResult(this.this$0.performRemoveItem(this.val$key));
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(removeItemResult);
                }
            }
        });
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void setItem(String str, String str2, IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, str, str2, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.1
            final DefaultWXStorage this$0;
            final String val$key;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;
            final String val$value;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$key = r5;
                this.val$value = r6;
                this.val$listener = r7;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> itemResult = StorageResultHandler.setItemResult(this.this$0.performSetItem(this.val$key, this.val$value, false, true));
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(itemResult);
                }
            }
        });
    }

    @Override // com.taobao.weex.appfram.storage.IWXStorageAdapter
    public void setItemPersistent(String str, String str2, IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener) {
        execute(new Runnable(this, str, str2, onResultReceivedListener) { // from class: com.taobao.weex.appfram.storage.DefaultWXStorage.6
            final DefaultWXStorage this$0;
            final String val$key;
            final IWXStorageAdapter.OnResultReceivedListener val$listener;
            final String val$value;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$key = r5;
                this.val$value = r6;
                this.val$listener = r7;
            }

            @Override // java.lang.Runnable
            public void run() {
                Map<String, Object> itemResult = StorageResultHandler.setItemResult(this.this$0.performSetItem(this.val$key, this.val$value, true, true));
                IWXStorageAdapter.OnResultReceivedListener onResultReceivedListener2 = this.val$listener;
                if (onResultReceivedListener2 != null) {
                    onResultReceivedListener2.onReceived(itemResult);
                }
            }
        });
    }
}
