package com.taobao.weex.appfram.navigator;

import android.app.Activity;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/navigator/INavigator.class */
public interface INavigator {
    boolean pop(Activity activity, String str);

    boolean push(Activity activity, String str);
}
