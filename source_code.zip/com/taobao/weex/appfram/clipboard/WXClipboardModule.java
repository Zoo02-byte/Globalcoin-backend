package com.taobao.weex.appfram.clipboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.WXModule;
import java.util.HashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/clipboard/WXClipboardModule.class */
public class WXClipboardModule extends WXModule implements IWXClipboard {
    private static final String DATA = "data";
    private static final String RESULT = "result";
    private static final String RESULT_FAILED = "failed";
    private static final String RESULT_OK = "success";
    private final String CLIP_KEY = "WEEX_CLIP_KEY_MAIN";

    /* JADX WARN: Code restructure failed: missing block: B:46:0x00d7, code lost:
        if (r6 == null) goto L_0x0112;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x00da, code lost:
        r6.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x010c, code lost:
        if (r6 == null) goto L_0x0112;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private java.lang.CharSequence coerceToText(android.content.Context r6, android.content.ClipData.Item r7) {
        /*
        // Method dump skipped, instructions count: 333
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.appfram.clipboard.WXClipboardModule.coerceToText(android.content.Context, android.content.ClipData$Item):java.lang.CharSequence");
    }

    @Override // com.taobao.weex.appfram.clipboard.IWXClipboard
    @JSMethod
    public void getString(JSCallback jSCallback) {
        Context context = this.mWXSDKInstance.getContext();
        ClipboardManager clipboardManager = (ClipboardManager) context.getSystemService("clipboard");
        HashMap hashMap = new HashMap(2);
        ClipData primaryClip = clipboardManager.getPrimaryClip();
        CharSequence charSequence = "";
        String str = "failed";
        if (primaryClip == null || primaryClip.getItemCount() <= 0) {
            hashMap.put("result", "failed");
            hashMap.put("data", "");
        } else {
            CharSequence coerceToText = coerceToText(context, primaryClip.getItemAt(0));
            if (coerceToText != null) {
                str = "success";
            }
            hashMap.put("result", str);
            if (coerceToText != null) {
                charSequence = coerceToText;
            }
            hashMap.put("data", charSequence);
        }
        if (jSCallback != null) {
            jSCallback.invoke(hashMap);
        }
    }

    @Override // com.taobao.weex.appfram.clipboard.IWXClipboard
    @JSMethod
    public void setString(String str) {
        if (str != null) {
            ((ClipboardManager) this.mWXSDKInstance.getContext().getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("WEEX_CLIP_KEY_MAIN", str));
        }
    }
}
