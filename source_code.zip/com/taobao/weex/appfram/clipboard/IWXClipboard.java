package com.taobao.weex.appfram.clipboard;

import com.taobao.weex.bridge.JSCallback;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/clipboard/IWXClipboard.class */
interface IWXClipboard {
    void getString(JSCallback jSCallback);

    void setString(String str);
}
