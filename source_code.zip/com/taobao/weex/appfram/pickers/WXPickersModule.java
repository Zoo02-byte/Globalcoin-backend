package com.taobao.weex.appfram.pickers;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.TextView;
import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.appfram.pickers.DatePickerImpl;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.WXModule;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.utils.WXResourceUtils;
import com.taobao.weex.utils.WXViewUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/pickers/WXPickersModule.class */
public class WXPickersModule extends WXModule {
    private static final String CANCEL = "cancel";
    private static final String DATA = "data";
    private static final String ERROR = "error";
    private static final String KEY_CANCEL_TITLE = "cancelTitle";
    private static final String KEY_CANCEL_TITLE_COLOR = "cancelTitleColor";
    private static final String KEY_CONFIRM_TITLE = "confirmTitle";
    private static final String KEY_CONFIRM_TITLE_COLOR = "confirmTitleColor";
    private static final String KEY_INDEX = "index";
    private static final String KEY_ITEMS = "items";
    private static final String KEY_MAX = "max";
    private static final String KEY_MIN = "min";
    private static final String KEY_SELECTION_COLOR = "selectionColor";
    private static final String KEY_TEXT_COLOR = "textColor";
    private static final String KEY_TITLE = "title";
    private static final String KEY_TITLE_BACKGROUND_COLOR = "titleBackgroundColor";
    private static final String KEY_TITLE_COLOR = "titleColor";
    private static final String KEY_VALUE = "value";
    private static final String RESULT = "result";
    private static final String SUCCESS = "success";
    private int selected;

    /* JADX INFO: Access modifiers changed from: private */
    public int getColor(Map<String, Object> map, String str, int i2) {
        Object option = getOption(map, str, null);
        return option == null ? i2 : WXResourceUtils.getColor(option.toString(), i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public <T> T getOption(Map<String, Object> map, String str, T t2) {
        T t3 = (T) map.get(str);
        return t3 == null ? t2 : t3;
    }

    private TextView makeTitleView(Context context, Map<String, Object> map) {
        String str = (String) getOption(map, "title", null);
        if (str == null) {
            return null;
        }
        TextView textView = new TextView(context);
        textView.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
        textView.setTextSize(2, 20.0f);
        int dip2px = WXViewUtils.dip2px(12.0f);
        textView.setPadding(dip2px, dip2px, dip2px, dip2px);
        textView.getPaint().setFakeBoldText(true);
        textView.setBackgroundColor(getColor(map, KEY_TITLE_BACKGROUND_COLOR, 0));
        textView.setTextColor(getColor(map, KEY_TITLE_COLOR, -16777216));
        textView.setText(str);
        return textView;
    }

    private void performPickDate(Map<String, Object> map, JSCallback jSCallback) {
        DatePickerImpl.pickDate(this.mWXSDKInstance.getContext(), (String) getOption(map, "value", ""), (String) getOption(map, "max", ""), (String) getOption(map, "min", ""), new DatePickerImpl.OnPickListener(this, jSCallback) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.2
            final WXPickersModule this$0;
            final JSCallback val$callback;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$callback = r5;
            }

            @Override // com.taobao.weex.appfram.pickers.DatePickerImpl.OnPickListener
            public void onPick(boolean z2, String str) {
                if (z2) {
                    HashMap hashMap = new HashMap(2);
                    hashMap.put("result", "success");
                    hashMap.put("data", str);
                    this.val$callback.invoke(hashMap);
                    return;
                }
                HashMap hashMap2 = new HashMap(2);
                hashMap2.put("result", "cancel");
                hashMap2.put("data", null);
                this.val$callback.invoke(hashMap2);
            }
        }, map);
    }

    private void performPickTime(Map<String, Object> map, JSCallback jSCallback) {
        DatePickerImpl.pickTime(this.mWXSDKInstance.getContext(), (String) getOption(map, "value", ""), new DatePickerImpl.OnPickListener(this, jSCallback) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.1
            final WXPickersModule this$0;
            final JSCallback val$callback;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$callback = r5;
            }

            @Override // com.taobao.weex.appfram.pickers.DatePickerImpl.OnPickListener
            public void onPick(boolean z2, String str) {
                if (z2) {
                    HashMap hashMap = new HashMap(2);
                    hashMap.put("result", "success");
                    hashMap.put("data", str);
                    this.val$callback.invoke(hashMap);
                    return;
                }
                HashMap hashMap2 = new HashMap(2);
                hashMap2.put("result", "cancel");
                hashMap2.put("data", null);
                this.val$callback.invoke(hashMap2);
            }
        }, map);
    }

    private void performSinglePick(List<String> list, Map<String, Object> map, JSCallback jSCallback) {
        this.selected = ((Integer) getOption(map, "index", 0)).intValue();
        int color = getColor(map, KEY_TEXT_COLOR, 0);
        AnonymousClass3 r02 = new ArrayAdapter<String>(this, this.mWXSDKInstance.getContext(), 17367055, list, getColor(map, KEY_SELECTION_COLOR, 0), color) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.3
            final WXPickersModule this$0;
            final int val$selectionColor;
            final int val$textColor;

            {
                this.this$0 = r6;
                this.val$selectionColor = r10;
                this.val$textColor = r11;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                int i3;
                View view2 = getView(i2, view, viewGroup);
                if (view2 != null && (view2 instanceof Checkable)) {
                    boolean z2 = i2 == this.this$0.selected;
                    ((Checkable) view2).setChecked(z2);
                    if (z2) {
                        view2.setBackgroundColor(this.val$selectionColor);
                    } else {
                        view2.setBackgroundColor(0);
                    }
                }
                if ((view2 instanceof TextView) && (i3 = this.val$textColor) != 0) {
                    ((TextView) view2).setTextColor(i3);
                }
                return view2;
            }
        };
        AlertDialog create = new AlertDialog.Builder(this.mWXSDKInstance.getContext()).setAdapter(r02, null).setPositiveButton(17039370, new DialogInterface.OnClickListener(this, jSCallback) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.5
            final WXPickersModule this$0;
            final JSCallback val$callback;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$callback = r5;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                HashMap hashMap = new HashMap(2);
                hashMap.put("result", "success");
                hashMap.put("data", Integer.valueOf(this.this$0.selected));
                this.val$callback.invoke(hashMap);
            }
        }).setNegativeButton(17039360, new DialogInterface.OnClickListener(this, jSCallback) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.4
            final WXPickersModule this$0;
            final JSCallback val$callback;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$callback = r5;
            }

            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i2) {
                HashMap hashMap = new HashMap(2);
                hashMap.put("result", "cancel");
                hashMap.put("data", -1);
                this.val$callback.invoke(hashMap);
            }
        }).setCustomTitle(makeTitleView(this.mWXSDKInstance.getContext(), map)).create();
        create.create();
        create.getListView().setOnItemClickListener(new AdapterView.OnItemClickListener(this, r02) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.6
            final WXPickersModule this$0;
            final ArrayAdapter val$adapter;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$adapter = r5;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
                this.this$0.selected = i2;
                this.val$adapter.notifyDataSetChanged();
            }
        });
        create.getWindow().getDecorView().post(WXThread.secure(new Runnable(this, create, map) { // from class: com.taobao.weex.appfram.pickers.WXPickersModule.7
            final WXPickersModule this$0;
            final AlertDialog val$dialog;
            final Map val$options;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$dialog = r5;
                this.val$options = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                Button button = this.val$dialog.getButton(-1);
                Button button2 = this.val$dialog.getButton(-2);
                if (button != null) {
                    String str = (String) this.this$0.getOption(this.val$options, WXPickersModule.KEY_CONFIRM_TITLE, null);
                    int color2 = this.this$0.getColor(this.val$options, WXPickersModule.KEY_CONFIRM_TITLE_COLOR, 0);
                    if (str != null) {
                        button.setText(str);
                        button.setAllCaps(false);
                    }
                    if (color2 != 0) {
                        button.setTextColor(color2);
                        button.setAllCaps(false);
                    }
                }
                if (button2 != null) {
                    String str2 = (String) this.this$0.getOption(this.val$options, "cancelTitle", null);
                    int color3 = this.this$0.getColor(this.val$options, WXPickersModule.KEY_CANCEL_TITLE_COLOR, 0);
                    if (str2 != null) {
                        button2.setText(str2);
                    }
                    if (color3 != 0) {
                        button2.setTextColor(color3);
                    }
                }
            }
        }));
        create.show();
    }

    private List<String> safeConvert(List list) {
        ArrayList arrayList = new ArrayList(list.size());
        for (Object obj : list) {
            arrayList.add(String.valueOf(obj));
        }
        return arrayList;
    }

    @JSMethod
    public void pick(Map<String, Object> map, JSCallback jSCallback) {
        try {
            performSinglePick(safeConvert((List) getOption(map, KEY_ITEMS, new ArrayList())), map, jSCallback);
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    @JSMethod
    public void pickDate(Map<String, Object> map, JSCallback jSCallback) {
        performPickDate(map, jSCallback);
    }

    @JSMethod
    public void pickTime(Map<String, Object> map, JSCallback jSCallback) {
        performPickTime(map, jSCallback);
    }
}
