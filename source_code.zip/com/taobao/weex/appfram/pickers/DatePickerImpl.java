package com.taobao.weex.appfram.pickers;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.ui.module.WXModalUIModule;
import com.taobao.weex.utils.WXLogUtils;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/pickers/DatePickerImpl.class */
public class DatePickerImpl {
    private static final int DEFAULT_END_YEAR = 2100;
    private static final int DEFAULT_START_YEAR = 1900;
    private static SimpleDateFormat dateFormatter;
    private static SimpleDateFormat timeFormatter;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/pickers/DatePickerImpl$OnPickListener.class */
    public interface OnPickListener {
        void onPick(boolean z2, String str);
    }

    private static Date parseDate(String str) {
        if (dateFormatter == null) {
            dateFormatter = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        }
        try {
            return dateFormatter.parse(str);
        } catch (ParseException e2) {
            WXLogUtils.w("[DatePickerImpl] " + e2.toString());
            return new Date();
        }
    }

    private static Date parseTime(String str) {
        if (timeFormatter == null) {
            timeFormatter = new SimpleDateFormat("HH:mm", Locale.getDefault());
        }
        try {
            return timeFormatter.parse(str);
        } catch (ParseException e2) {
            WXLogUtils.w("[DatePickerImpl] " + e2.toString());
            return new Date();
        }
    }

    public static void pickDate(Context context, String str, String str2, String str3, OnPickListener onPickListener, Map<String, Object> map) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(parseDate(str));
        DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener(onPickListener) { // from class: com.taobao.weex.appfram.pickers.DatePickerImpl.1
            final OnPickListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$listener = r4;
            }

            @Override // android.app.DatePickerDialog.OnDateSetListener
            public void onDateSet(DatePicker datePicker, int i2, int i3, int i4) {
                int i5 = i3 + 1;
                this.val$listener.onPick(true, i2 + Operators.SUB + (i5 < 10 ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT + i5 : String.valueOf(i5)) + Operators.SUB + (i4 < 10 ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT + i4 : String.valueOf(i4)));
            }
        }, instance.get(1), instance.get(2), instance.get(5));
        DatePicker datePicker = datePickerDialog.getDatePicker();
        Calendar instance2 = Calendar.getInstance(Locale.getDefault());
        Calendar instance3 = Calendar.getInstance(Locale.getDefault());
        instance2.set(DEFAULT_START_YEAR, 0, 1);
        instance3.set(DEFAULT_END_YEAR, 11, 31);
        if (!TextUtils.isEmpty(str3)) {
            if (datePicker.getMaxDate() >= parseDate(str3).getTime()) {
                datePicker.setMinDate(parseDate(str3).getTime());
            } else {
                datePicker.setMinDate(instance2.getTimeInMillis());
                datePicker.setMaxDate(instance3.getTimeInMillis());
            }
        }
        if (!TextUtils.isEmpty(str2)) {
            if (datePicker.getMinDate() <= parseDate(str2).getTime()) {
                datePicker.setMaxDate(parseDate(str2).getTime());
            } else {
                datePicker.setMinDate(instance2.getTimeInMillis());
                datePicker.setMaxDate(instance3.getTimeInMillis());
            }
        }
        datePickerDialog.setOnCancelListener(new DialogInterface.OnCancelListener(onPickListener) { // from class: com.taobao.weex.appfram.pickers.DatePickerImpl.2
            final OnPickListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$listener = r4;
            }

            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialogInterface) {
                this.val$listener.onPick(false, null);
            }
        });
        Object obj = null;
        setButtonText(datePickerDialog, -2, String.valueOf(map != null ? map.get(WXModalUIModule.CANCEL_TITLE) : null));
        if (map != null) {
            obj = map.get("confirmTitle");
        }
        setButtonText(datePickerDialog, -1, String.valueOf(obj));
        datePickerDialog.show();
    }

    public static void pickTime(Context context, String str, OnPickListener onPickListener, Map<String, Object> map) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(parseTime(str));
        TimePickerDialog timePickerDialog = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener(onPickListener) { // from class: com.taobao.weex.appfram.pickers.DatePickerImpl.3
            final OnPickListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$listener = r4;
            }

            @Override // android.app.TimePickerDialog.OnTimeSetListener
            public void onTimeSet(TimePicker timePicker, int i2, int i3) {
                this.val$listener.onPick(true, (i2 < 10 ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT + i2 : String.valueOf(i2)) + ":" + (i3 < 10 ? WXInstanceApm.VALUE_ERROR_CODE_DEFAULT + i3 : String.valueOf(i3)));
            }
        }, instance.get(11), instance.get(12), false);
        timePickerDialog.setOnCancelListener(new DialogInterface.OnCancelListener(onPickListener) { // from class: com.taobao.weex.appfram.pickers.DatePickerImpl.4
            final OnPickListener val$listener;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$listener = r4;
            }

            @Override // android.content.DialogInterface.OnCancelListener
            public void onCancel(DialogInterface dialogInterface) {
                this.val$listener.onPick(false, null);
            }
        });
        Object obj = null;
        setButtonText(timePickerDialog, -2, String.valueOf(map != null ? map.get(WXModalUIModule.CANCEL_TITLE) : null));
        if (map != null) {
            obj = map.get("confirmTitle");
        }
        setButtonText(timePickerDialog, -1, String.valueOf(obj));
        timePickerDialog.show();
    }

    private static void setButtonText(AlertDialog alertDialog, int i2, CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && !"null".equals(charSequence)) {
            try {
                alertDialog.getWindow().getDecorView().post(WXThread.secure(new Runnable(alertDialog, i2, charSequence) { // from class: com.taobao.weex.appfram.pickers.DatePickerImpl.5
                    final AlertDialog val$dialog;
                    final CharSequence val$text;
                    final int val$which;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.val$dialog = r4;
                        this.val$which = r5;
                        this.val$text = r6;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        Button button = this.val$dialog.getButton(this.val$which);
                        if (button != null) {
                            button.setAllCaps(false);
                            button.setText(this.val$text);
                        }
                    }
                }));
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }
}
