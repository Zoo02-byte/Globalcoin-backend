package com.taobao.weex.appfram.websocket;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/websocket/IWebSocketAdapterFactory.class */
public interface IWebSocketAdapterFactory {
    IWebSocketAdapter createWebSocketAdapter();
}
