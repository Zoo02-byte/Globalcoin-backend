package com.taobao.weex.appfram.websocket;
/* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/websocket/IWebSocketAdapter.class */
public interface IWebSocketAdapter {
    public static final String HEADER_SEC_WEBSOCKET_PROTOCOL = "Sec-WebSocket-Protocol";

    /* loaded from: Coinglobal1.jar:com/taobao/weex/appfram/websocket/IWebSocketAdapter$EventListener.class */
    public interface EventListener {
        void onClose(int i2, String str, boolean z2);

        void onError(String str);

        void onMessage(String str);

        void onOpen();
    }

    void close(int i2, String str);

    void connect(String str, String str2, EventListener eventListener);

    void connect(String str, String str2, String str3, EventListener eventListener);

    void destroy();

    void send(String str);
}
