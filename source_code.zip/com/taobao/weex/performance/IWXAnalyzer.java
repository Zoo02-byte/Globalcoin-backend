package com.taobao.weex.performance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/performance/IWXAnalyzer.class */
public interface IWXAnalyzer {
    void transfer(String str, String str2, String str3, String str4);
}
