package com.taobao.weex.performance;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXConfigAdapter;
import com.taobao.weex.common.Constants;
import org.json.JSONObject;
/* loaded from: Coinglobal1.jar:com/taobao/weex/performance/WhiteScreenUtils.class */
public class WhiteScreenUtils {
    public static boolean doWhiteScreenCheck() {
        IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
        boolean z2 = false;
        if (wxConfigAdapter == null) {
            return false;
        }
        double random = Math.random();
        double d2 = 100.0d;
        try {
            d2 = Double.valueOf(wxConfigAdapter.getConfig("wxapm", "new_ws_sampling", "100")).doubleValue();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (random * 100.0d < d2) {
            z2 = true;
        }
        return z2;
    }

    private static JSONObject geViewDetailTreeMsg(View view) {
        if (view == null) {
            return null;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("width", view.getWidth());
            jSONObject.put("height", view.getHeight());
            int[] iArr = new int[2];
            iArr[0] = -1;
            iArr[1] = -1;
            view.getLocationOnScreen(iArr);
            jSONObject.put(Constants.Name.X, iArr[0]);
            jSONObject.put(Constants.Name.Y, iArr[1]);
            if (view instanceof ViewGroup) {
                jSONObject.put("type", view.getClass().getSimpleName());
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    jSONObject.put("child_" + i2, geViewDetailTreeMsg(viewGroup.getChildAt(i2)));
                }
            } else {
                jSONObject.put("type", view.getClass().getSimpleName());
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return jSONObject;
    }

    private static boolean hasLeafViewOrSizeIgnore(View view, int i2) {
        if (!(view instanceof ViewGroup)) {
            return true;
        }
        int i3 = i2;
        if (i2 > 0) {
            if (view.getHeight() < 10 || view.getWidth() < 10) {
                return true;
            }
            i3 = i2 - 1;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        for (int i4 = 0; i4 < viewGroup.getChildCount(); i4++) {
            if (hasLeafViewOrSizeIgnore(viewGroup.getChildAt(i4), i3)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isInWhiteList(WXSDKInstance wXSDKInstance) {
        IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
        if (wxConfigAdapter == null) {
            return false;
        }
        String config = wxConfigAdapter.getConfig("wxapm", "ws_white_list", null);
        if (TextUtils.isEmpty(config)) {
            return false;
        }
        try {
            String[] split = config.split(";");
            for (String str : split) {
                if (wXSDKInstance.getBundleUrl() != null && wXSDKInstance.getBundleUrl().contains(str)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e2) {
            e2.printStackTrace();
            return false;
        }
    }

    public static boolean isWhiteScreen(WXSDKInstance wXSDKInstance) {
        if (wXSDKInstance == null) {
            return false;
        }
        View containerView = wXSDKInstance.getContainerView();
        if ((containerView instanceof ViewGroup) && !isInWhiteList(wXSDKInstance)) {
            return !hasLeafViewOrSizeIgnore(containerView, 3);
        }
        return false;
    }

    public static String takeViewTreeSnapShot(WXSDKInstance wXSDKInstance) {
        if (wXSDKInstance == null) {
            return "nullInstance";
        }
        JSONObject geViewDetailTreeMsg = geViewDetailTreeMsg(wXSDKInstance.getContainerView());
        return geViewDetailTreeMsg != null ? geViewDetailTreeMsg.toString() : "";
    }
}
