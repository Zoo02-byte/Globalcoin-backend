package com.taobao.weex.performance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/performance/IApmGenerator.class */
public interface IApmGenerator {
    IWXApmMonitorAdapter generateApmInstance(String str);
}
