package com.taobao.weex.performance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/performance/IWXApmMonitorAdapter.class */
public interface IWXApmMonitorAdapter {
    void addProperty(String str, Object obj);

    void addStats(String str, double d2);

    void onAppear();

    void onDisappear();

    void onEnd();

    void onEvent(String str, Object obj);

    void onStage(String str, long j2);

    void onStart(String str);

    void onSubProcedureEvent(String str, String str2);

    void onSubProcedureStage(String str, String str2);

    String parseReportUrl(String str);

    void setSubProcedureProperties(String str, String str2, Object obj);

    void setSubProcedureStats(String str, String str2, double d2);
}
