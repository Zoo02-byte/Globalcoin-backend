package com.taobao.weex.performance;

import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.common.WXPerformance;
import com.taobao.weex.common.WXRenderStrategy;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
/* loaded from: Coinglobal1.jar:com/taobao/weex/performance/WXInstanceApm.class */
public class WXInstanceApm {
    public static final String KEY_PAGE_ANIM_BACK_NUM;
    public static final String KEY_PAGE_PROPERTIES_BIZ_ID;
    public static final String KEY_PAGE_PROPERTIES_BUBDLE_URL;
    public static final String KEY_PAGE_PROPERTIES_BUNDLE_TYPE;
    public static final String KEY_PAGE_PROPERTIES_CACHE_INFO;
    public static final String KEY_PAGE_PROPERTIES_CACHE_TYPE;
    public static final String KEY_PAGE_PROPERTIES_CONTAINER_NAME;
    public static final String KEY_PAGE_PROPERTIES_INSTANCE_TYPE;
    public static final String KEY_PAGE_PROPERTIES_JSLIB_VERSION;
    public static final String KEY_PAGE_PROPERTIES_JS_FM_INI;
    public static final String KEY_PAGE_PROPERTIES_PARENT_PAGE;
    public static final String KEY_PAGE_PROPERTIES_RENDER_TYPE;
    public static final String KEY_PAGE_PROPERTIES_REQUEST_TYPE;
    public static final String KEY_PAGE_PROPERTIES_UIKIT_TYPE;
    public static final String KEY_PAGE_PROPERTIES_WEEX_VERSION;
    public static final String KEY_PAGE_STAGES_CONTAINER_READY;
    public static final String KEY_PAGE_STAGES_CREATE_FINISH;
    public static final String KEY_PAGE_STAGES_CUSTOM_PREPROCESS_END;
    public static final String KEY_PAGE_STAGES_CUSTOM_PREPROCESS_START;
    public static final String KEY_PAGE_STAGES_DESTROY;
    public static final String KEY_PAGE_STAGES_DOWN_BUNDLE_END;
    public static final String KEY_PAGE_STAGES_DOWN_BUNDLE_START;
    public static final String KEY_PAGE_STAGES_END_EXCUTE_BUNDLE;
    public static final String KEY_PAGE_STAGES_FIRST_INTERACTION_VIEW;
    public static final String KEY_PAGE_STAGES_FSRENDER;
    public static final String KEY_PAGE_STAGES_INTERACTION;
    public static final String KEY_PAGE_STAGES_LOAD_BUNDLE_END;
    public static final String KEY_PAGE_STAGES_LOAD_BUNDLE_START;
    public static final String KEY_PAGE_STAGES_NEW_FSRENDER;
    public static final String KEY_PAGE_STAGES_RENDER_ORGIGIN;
    public static final String KEY_PAGE_STATS_ACTUAL_DOWNLOAD_TIME;
    public static final String KEY_PAGE_STATS_BODY_RATIO;
    public static final String KEY_PAGE_STATS_BUNDLE_SIZE;
    public static final String KEY_PAGE_STATS_CELL_DATA_UN_RECYCLE_NUM;
    public static final String KEY_PAGE_STATS_CELL_EXCEED_NUM;
    public static final String KEY_PAGE_STATS_CELL_UN_RE_USE_NUM;
    public static final String KEY_PAGE_STATS_COMPONENT_CREATE_COST;
    public static final String KEY_PAGE_STATS_EMBED_COUNT;
    public static final String KEY_PAGE_STATS_EXECUTE_JS_CALLBACK_COST;
    public static final String KEY_PAGE_STATS_FS_CALL_EVENT_NUM;
    public static final String KEY_PAGE_STATS_FS_CALL_JS_NUM;
    public static final String KEY_PAGE_STATS_FS_CALL_JS_TIME;
    public static final String KEY_PAGE_STATS_FS_CALL_NATIVE_NUM;
    public static final String KEY_PAGE_STATS_FS_CALL_NATIVE_TIME;
    public static final String KEY_PAGE_STATS_FS_REQUEST_NUM;
    public static final String KEY_PAGE_STATS_FS_TIMER_NUM;
    public static final String KEY_PAGE_STATS_IMG_LOAD_FAIL_NUM;
    public static final String KEY_PAGE_STATS_IMG_LOAD_NUM;
    public static final String KEY_PAGE_STATS_IMG_LOAD_SUCCESS_NUM;
    public static final String KEY_PAGE_STATS_IMG_UN_RECYCLE_NUM;
    public static final String KEY_PAGE_STATS_I_ALL_VIEW_COUNT;
    public static final String KEY_PAGE_STATS_I_COMPONENT_CREATE_COUNT;
    public static final String KEY_PAGE_STATS_I_SCREEN_VIEW_COUNT;
    public static final String KEY_PAGE_STATS_JSLIB_INIT_TIME;
    public static final String KEY_PAGE_STATS_LARGE_IMG_COUNT;
    public static final String KEY_PAGE_STATS_LAYOUT_TIME;
    public static final String KEY_PAGE_STATS_MAX_COMPONENT_NUM;
    public static final String KEY_PAGE_STATS_MAX_DEEP_DOM;
    public static final String KEY_PAGE_STATS_MAX_DEEP_VIEW;
    public static final String KEY_PAGE_STATS_NET_FAIL_NUM;
    public static final String KEY_PAGE_STATS_NET_NUM;
    public static final String KEY_PAGE_STATS_NET_SUCCESS_NUM;
    public static final String KEY_PAGE_STATS_SCROLLER_NUM;
    public static final String KEY_PAGE_STATS_VIEW_CREATE_COST;
    public static final String KEY_PAGE_STATS_WRONG_IMG_SIZE_COUNT;
    public static final String KEY_PAGE_TIMER_BACK_NUM;
    public static final String KEY_PROPERTIES_ERROR_CODE;
    public static final String VALUE_BUNDLE_LOAD_LENGTH;
    public static final String VALUE_ERROR_CODE_DEFAULT;
    public static final String WEEX_PAGE_TOPIC;
    private IWXApmMonitorAdapter apmInstance;
    public long componentCreateTime;
    public boolean hasAddView;
    public Rect instanceRect;
    private long interactionComponentCreateTime;
    private long interactionJsCallBackTime;
    private double interactionLayoutTime;
    private long interactionViewCreateTime;
    private boolean isFSEnd;
    private String mInstanceId;
    public String reportPageName;
    public long viewCreateTime;
    private long wxExecJsCallBackTime;
    private boolean mHasInit = false;
    private boolean mEnd = false;
    private boolean hasRecordFistInteractionView = false;
    public boolean forceStopRecordInteraction = false;
    public boolean hasReportLayerOverDraw = false;
    public Set<String> exceptionRecord = new CopyOnWriteArraySet();
    private boolean mHasRecordDetailData = false;
    private boolean hasSendInteractionToJS = false;
    public volatile boolean isReady = true;
    private Runnable jsPerformanceCallBack = new Runnable(this) { // from class: com.taobao.weex.performance.WXInstanceApm.1
        final WXInstanceApm this$0;

        {
            this.this$0 = r4;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.this$0.sendPerformanceToJS();
        }
    };
    private Runnable delayCollectDataTask = new Runnable(this) { // from class: com.taobao.weex.performance.WXInstanceApm.2
        final WXInstanceApm this$0;

        {
            this.this$0 = r4;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.this$0.recordPerformanceDetailData();
        }
    };
    private long preUpdateTime = 0;
    public final Map<String, Object> extInfo = new ConcurrentHashMap();
    public final Map<String, Long> stageMap = new ConcurrentHashMap();
    private Handler mUIHandler = new Handler(Looper.getMainLooper());
    private Map<String, Double> recordStatsMap = new ConcurrentHashMap();
    private Map<String, Object> mPropertiesMap = new ConcurrentHashMap();

    public WXInstanceApm(String str) {
        this.mInstanceId = str;
        IApmGenerator apmGenerater = WXSDKManager.getInstance().getApmGenerater();
        if (apmGenerater != null) {
            this.apmInstance = apmGenerater.generateApmInstance(WEEX_PAGE_TOPIC);
        }
    }

    private void addPropeyFromExtParms(String str, String str2, Map<String, Object> map) {
        Object obj = map.get(str);
        if (obj instanceof String) {
            addProperty(str2, obj);
        }
    }

    private void printLog() {
        Long l2 = this.stageMap.get(KEY_PAGE_STAGES_DOWN_BUNDLE_START);
        Long l3 = this.stageMap.get(KEY_PAGE_STAGES_DOWN_BUNDLE_END);
        Long l4 = this.stageMap.get(KEY_PAGE_STAGES_INTERACTION);
        Long l5 = this.stageMap.get(KEY_PAGE_STAGES_CONTAINER_READY);
        if (!(l3 == null || l2 == null)) {
            WXLogUtils.d("test->", "downLoadTime: " + (l3.longValue() - l2.longValue()));
        }
        if (!(l3 == null || l4 == null)) {
            WXLogUtils.d("test->", "renderTime: " + (l4.longValue() - l3.longValue()));
        }
        if (l5 != null && l4 != null) {
            WXLogUtils.d("test->", "showTime: " + (l4.longValue() - l5.longValue()));
        }
    }

    private void sendProperty(String str, Object obj) {
        if (WXAnalyzerDataTransfer.isOpenPerformance) {
            WXAnalyzerDataTransfer.transferPerformance(this.mInstanceId, "properties", str, obj);
        }
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.addProperty(str, obj);
        }
    }

    private void sendStageInfo(String str, long j2) {
        if (WXAnalyzerDataTransfer.isOpenPerformance) {
            WXAnalyzerDataTransfer.transferPerformance(this.mInstanceId, "stage", str, Long.valueOf(j2));
        }
        if (KEY_PAGE_STAGES_RENDER_ORGIGIN.equalsIgnoreCase(str)) {
            this.mUIHandler.postDelayed(this.jsPerformanceCallBack, 8000);
        }
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.onStage(str, j2);
        }
    }

    private void sendStats(String str, double d2) {
        if (WXAnalyzerDataTransfer.isOpenPerformance) {
            WXAnalyzerDataTransfer.transferPerformance(this.mInstanceId, "stats", str, Double.valueOf(d2));
        }
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.addStats(str, d2);
        }
    }

    public void actionLoadImg() {
        updateDiffStats(KEY_PAGE_STATS_IMG_LOAD_NUM, 1.0d);
    }

    public void actionLoadImgResult(boolean z2, String str) {
        if (z2) {
            updateDiffStats(KEY_PAGE_STATS_IMG_LOAD_SUCCESS_NUM, 1.0d);
        } else {
            updateDiffStats(KEY_PAGE_STATS_IMG_LOAD_FAIL_NUM, 1.0d);
        }
    }

    public void actionNetRequest() {
        if (!this.isFSEnd) {
            updateFSDiffStats(KEY_PAGE_STATS_FS_REQUEST_NUM, 1.0d);
        }
        updateDiffStats(KEY_PAGE_STATS_NET_NUM, 1.0d);
    }

    public void actionNetResult(boolean z2, String str) {
        if (z2) {
            updateDiffStats(KEY_PAGE_STATS_NET_SUCCESS_NUM, 1.0d);
        } else {
            updateDiffStats(KEY_PAGE_STATS_NET_FAIL_NUM, 1.0d);
        }
    }

    public void addProperty(String str, Object obj) {
        if (!this.mEnd && str != null && obj != null) {
            this.mPropertiesMap.put(str, obj);
            if (this.isReady) {
                sendProperty(str, obj);
            }
        }
    }

    public void addStats(String str, double d2) {
        if (!this.mEnd && str != null) {
            this.recordStatsMap.put(str, Double.valueOf(d2));
            if (this.isReady) {
                sendStats(str, d2);
            }
        }
    }

    public void arriveFSRenderTime() {
        if (this.apmInstance != null) {
            this.isFSEnd = true;
            onStage(KEY_PAGE_STAGES_FSRENDER);
        }
    }

    public void arriveInteraction(WXComponent wXComponent) {
        WXPerformance wXPerformance;
        if (this.apmInstance != null && wXComponent != null && wXComponent.getInstance() != null) {
            if (WXAnalyzerDataTransfer.isOpenPerformance) {
                WXAnalyzerDataTransfer.transferInteractionInfo(wXComponent);
            }
            if (this.apmInstance != null && (wXPerformance = wXComponent.getInstance().getWXPerformance()) != null) {
                long fixUnixTime = WXUtils.getFixUnixTime();
                if (WXAnalyzerDataTransfer.isInteractionLogOpen()) {
                    Log.d(WXAnalyzerDataTransfer.INTERACTION_TAG, "[client][wxinteraction]" + wXComponent.getInstance().getInstanceId() + "," + wXComponent.getComponentType() + "," + wXComponent.getRef() + "," + wXComponent.getStyles() + "," + wXComponent.getAttrs());
                }
                if (!this.hasRecordFistInteractionView) {
                    onStage(KEY_PAGE_STAGES_FIRST_INTERACTION_VIEW);
                    this.hasRecordFistInteractionView = true;
                }
                if (!this.forceStopRecordInteraction) {
                    long fixUnixTime2 = WXUtils.getFixUnixTime();
                    if (fixUnixTime2 - this.preUpdateTime > 50) {
                        WXBridgeManager.getInstance().onInteractionTimeUpdate(this.mInstanceId);
                        this.preUpdateTime = fixUnixTime2;
                    }
                    this.interactionComponentCreateTime = this.componentCreateTime;
                    this.interactionViewCreateTime = this.viewCreateTime;
                    Double d2 = this.recordStatsMap.get(KEY_PAGE_STATS_LAYOUT_TIME);
                    this.interactionLayoutTime = d2 == null ? 0.0d : d2.doubleValue();
                    wXPerformance.interactionTime = fixUnixTime - wXPerformance.renderUnixTimeOrigin;
                    wXPerformance.interactionRealUnixTime = System.currentTimeMillis();
                    onStageWithTime(KEY_PAGE_STAGES_INTERACTION, fixUnixTime);
                    updateDiffStats(KEY_PAGE_STATS_I_SCREEN_VIEW_COUNT, 1.0d);
                    updateMaxStats(KEY_PAGE_STATS_I_ALL_VIEW_COUNT, (double) wXPerformance.localInteractionViewAddCount);
                    WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(this.mInstanceId);
                    if (sDKInstance != null) {
                        updateMaxStats(KEY_PAGE_STATS_I_COMPONENT_CREATE_COUNT, (double) sDKInstance.getWXPerformance().componentCount);
                    }
                }
            }
        }
    }

    public void arriveNewFsRenderTime() {
        if (this.apmInstance != null) {
            onStage(KEY_PAGE_STAGES_NEW_FSRENDER);
        }
    }

    public void doDelayCollectData() {
        new Handler(Looper.getMainLooper()).postDelayed(this.delayCollectDataTask, 8000);
    }

    public void doInit() {
        if (this.isReady && !this.mHasInit) {
            this.mHasInit = true;
            IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
            if (iWXApmMonitorAdapter != null) {
                iWXApmMonitorAdapter.onStart(this.mInstanceId);
                WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(this.mInstanceId);
                addProperty(KEY_PAGE_PROPERTIES_BUBDLE_URL, wXSDKInstance == null ? "unKnowUrl" : wXSDKInstance.getBundleUrl());
                addProperty(KEY_PROPERTIES_ERROR_CODE, VALUE_ERROR_CODE_DEFAULT);
                addProperty(KEY_PAGE_PROPERTIES_JSLIB_VERSION, WXEnvironment.JS_LIB_SDK_VERSION);
                addProperty(KEY_PAGE_PROPERTIES_WEEX_VERSION, WXEnvironment.WXSDK_VERSION);
                addProperty(KEY_PAGE_PROPERTIES_WEEX_VERSION, WXEnvironment.WXSDK_VERSION);
                addStats("wxReInitCount", (double) WXBridgeManager.reInitCount);
                if (wXSDKInstance != null) {
                    addProperty(KEY_PAGE_PROPERTIES_UIKIT_TYPE, wXSDKInstance.getRenderType());
                }
                addProperty("wxUseRuntimeApi", Boolean.valueOf(WXEnvironment.sUseRunTimeApi));
                if (wXSDKInstance != null && (wXSDKInstance.getRenderStrategy() == WXRenderStrategy.DATA_RENDER || wXSDKInstance.getRenderStrategy() == WXRenderStrategy.DATA_RENDER_BINARY)) {
                    addProperty(KEY_PAGE_PROPERTIES_RENDER_TYPE, WXEnvironment.EAGLE);
                }
                if (wXSDKInstance != null) {
                    for (Map.Entry<String, String> entry : wXSDKInstance.getContainerInfo().entrySet()) {
                        addProperty(entry.getKey(), entry.getValue());
                    }
                }
            }
        }
    }

    public boolean hasInit() {
        return this.mHasInit;
    }

    public void onAppear() {
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.onAppear();
        }
    }

    public void onDisAppear() {
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.onDisappear();
        }
    }

    public void onEnd() {
        if (this.apmInstance != null && !this.mEnd) {
            new Handler(Looper.getMainLooper()).removeCallbacks(this.delayCollectDataTask);
            recordPerformanceDetailData();
            this.exceptionRecord.clear();
            this.mUIHandler.removeCallbacks(this.jsPerformanceCallBack);
            onStage(KEY_PAGE_STAGES_DESTROY);
            if (!this.mHasInit) {
                this.apmInstance.onEnd();
            }
            this.mEnd = true;
            if (WXEnvironment.isApkDebugable()) {
                printLog();
            }
        }
    }

    public void onEvent(String str, Object obj) {
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            iWXApmMonitorAdapter.onEvent(str, obj);
        }
    }

    public void onInstanceReady(boolean z2) {
        this.isReady = true;
        if (z2) {
            onStage(KEY_PAGE_STAGES_DOWN_BUNDLE_START);
        }
        doInit();
        for (Map.Entry<String, Long> entry : this.stageMap.entrySet()) {
            sendStageInfo(entry.getKey(), entry.getValue().longValue());
        }
        for (Map.Entry<String, Double> entry2 : this.recordStatsMap.entrySet()) {
            sendStats(entry2.getKey(), entry2.getValue().doubleValue());
        }
        for (Map.Entry<String, Object> entry3 : this.mPropertiesMap.entrySet()) {
            sendProperty(entry3.getKey(), entry3.getValue());
        }
    }

    public void onStage(String str) {
        onStageWithTime(str, WXUtils.getFixUnixTime());
    }

    public void onStageWithTime(String str, long j2) {
        if (!this.mEnd && str != null) {
            this.stageMap.put(str, Long.valueOf(j2));
            if (this.isReady) {
                sendStageInfo(str, j2);
            }
        }
    }

    public void recordPerformanceDetailData() {
        if (!this.mHasRecordDetailData) {
            this.mHasRecordDetailData = true;
            addStats(KEY_PAGE_STATS_VIEW_CREATE_COST, (double) this.interactionViewCreateTime);
            addStats(KEY_PAGE_STATS_COMPONENT_CREATE_COST, (double) this.interactionComponentCreateTime);
            addStats(KEY_PAGE_STATS_EXECUTE_JS_CALLBACK_COST, (double) this.interactionJsCallBackTime);
            addStats(KEY_PAGE_STATS_LAYOUT_TIME, this.interactionLayoutTime);
        }
    }

    public void sendPerformanceToJS() {
        if (!this.hasSendInteractionToJS) {
            this.hasSendInteractionToJS = true;
            WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(this.mInstanceId);
            if (wXSDKInstance != null) {
                HashMap hashMap = new HashMap(2);
                hashMap.put(KEY_PAGE_PROPERTIES_BIZ_ID, this.reportPageName);
                hashMap.put(KEY_PAGE_PROPERTIES_BUBDLE_URL, wXSDKInstance.getBundleUrl());
                HashMap hashMap2 = new HashMap(1);
                hashMap2.put(KEY_PAGE_STAGES_INTERACTION, Long.valueOf(wXSDKInstance.getWXPerformance().interactionRealUnixTime));
                HashMap hashMap3 = new HashMap(2);
                hashMap3.put("stage", hashMap2);
                hashMap3.put("properties", hashMap);
                wXSDKInstance.fireGlobalEventCallback("wx_apm", hashMap3);
            }
        }
    }

    public void setPageName(String str) {
        String str2 = str;
        if (TextUtils.isEmpty(str)) {
            WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(this.mInstanceId);
            str2 = str;
            if (wXSDKInstance != null) {
                str2 = wXSDKInstance.getContainerInfo().get(KEY_PAGE_PROPERTIES_CONTAINER_NAME);
            }
        }
        IWXApmMonitorAdapter iWXApmMonitorAdapter = this.apmInstance;
        if (iWXApmMonitorAdapter != null) {
            str2 = iWXApmMonitorAdapter.parseReportUrl(str2);
        }
        this.reportPageName = str2;
        String str3 = TextUtils.isEmpty(str2) ? "emptyPageName" : this.reportPageName;
        this.reportPageName = str3;
        addProperty(KEY_PAGE_PROPERTIES_BIZ_ID, str3);
    }

    public String toPerfString() {
        Long l2 = this.stageMap.get(KEY_PAGE_STAGES_RENDER_ORGIGIN);
        Long l3 = this.stageMap.get(KEY_PAGE_STAGES_INTERACTION);
        Long l4 = this.stageMap.get(KEY_PAGE_STAGES_NEW_FSRENDER);
        StringBuilder sb = new StringBuilder();
        if (!(l2 == null || l3 == null)) {
            sb.append("interactiveTime " + (l3.longValue() - l2.longValue()) + "ms");
        }
        if (l4 != null) {
            sb.append(" wxNewFsRender " + l4 + "ms");
        }
        return sb.toString();
    }

    public void updateDiffStats(String str, double d2) {
        if (this.apmInstance != null) {
            Double valueOf = Double.valueOf(this.recordStatsMap.containsKey(str) ? this.recordStatsMap.get(str).doubleValue() : 0.0d);
            if (valueOf == null) {
                WXExceptionUtils.commitCriticalExceptionRT("", WXErrorCode.WX_ERR_HASH_MAP_TMP, "updateDiffStats", "key : " + str, null);
            } else {
                addStats(str, valueOf.doubleValue() + d2);
            }
        }
    }

    public void updateFSDiffStats(String str, double d2) {
        if (this.apmInstance != null && !this.isFSEnd) {
            updateDiffStats(str, d2);
        }
    }

    public void updateMaxStats(String str, double d2) {
        if (this.apmInstance != null) {
            Double valueOf = Double.valueOf(this.recordStatsMap.containsKey(str) ? this.recordStatsMap.get(str).doubleValue() : 0.0d);
            if (valueOf == null) {
                WXExceptionUtils.commitCriticalExceptionRT("", WXErrorCode.WX_ERR_HASH_MAP_TMP, "updateMaxStats", "key : " + str, null);
            } else if (valueOf.doubleValue() < d2) {
                addStats(str, Double.valueOf(d2).doubleValue());
            }
        }
    }

    public void updateNativePerformanceData(Map<String, String> map) {
        double d2;
        if (map != null) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                try {
                    d2 = Double.valueOf(entry.getValue()).doubleValue();
                } catch (Exception e2) {
                    e2.printStackTrace();
                    d2 = -1.0d;
                }
                if (d2 != -1.0d) {
                    this.recordStatsMap.put(entry.getKey(), Double.valueOf(d2));
                }
            }
        }
    }

    public void updateRecordInfo(Map<String, Object> map) {
        if (this.apmInstance != null && map != null) {
            addPropeyFromExtParms(KEY_PAGE_PROPERTIES_REQUEST_TYPE, KEY_PAGE_PROPERTIES_REQUEST_TYPE, map);
            addPropeyFromExtParms(WXPerformance.CACHE_TYPE, KEY_PAGE_PROPERTIES_CACHE_TYPE, map);
            addPropeyFromExtParms("zCacheInfo", KEY_PAGE_PROPERTIES_CACHE_INFO, map);
            addStats(KEY_PAGE_STATS_JSLIB_INIT_TIME, (double) WXEnvironment.sJSLibInitTime);
            addProperty(KEY_PAGE_PROPERTIES_JS_FM_INI, Boolean.valueOf(WXEnvironment.JsFrameworkInit));
            Object obj = map.get("actualNetworkTime");
            if (obj instanceof Long) {
                updateDiffStats(KEY_PAGE_STATS_ACTUAL_DOWNLOAD_TIME, ((Long) obj).doubleValue());
            }
        }
    }
}
