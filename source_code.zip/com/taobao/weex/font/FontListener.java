package com.taobao.weex.font;
/* loaded from: Coinglobal1.jar:com/taobao/weex/font/FontListener.class */
public interface FontListener {
    void onAddFontRule(String str, String str2, String str3);

    void onFontLoad(String str, String str2, String str3);
}
