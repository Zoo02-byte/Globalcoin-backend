package com.taobao.weex.layout;

import com.taobao.weex.common.Destroyable;
import com.taobao.weex.ui.component.WXComponent;
import java.io.Serializable;
/* loaded from: Coinglobal1.jar:com/taobao/weex/layout/ContentBoxMeasurement.class */
public abstract class ContentBoxMeasurement implements Serializable, Destroyable {
    protected WXComponent mComponent;
    protected boolean mMeasureExactly;
    protected float mMeasureHeight;
    protected float mMeasureWidth;

    public ContentBoxMeasurement() {
        this.mMeasureExactly = false;
        this.mComponent = null;
    }

    public ContentBoxMeasurement(WXComponent wXComponent) {
        this.mMeasureExactly = false;
        this.mComponent = wXComponent;
    }

    @Override // com.taobao.weex.common.Destroyable
    public void destroy() {
        this.mComponent = null;
    }

    public float getHeight() {
        return this.mMeasureHeight;
    }

    public boolean getMeasureExactly() {
        return this.mMeasureExactly;
    }

    public float getWidth() {
        return this.mMeasureWidth;
    }

    public abstract void layoutAfter(float f2, float f3);

    public abstract void layoutBefore();

    public final void measure(float f2, float f3, int i2, int i3) {
        measureInternal(f2, f3, i2, i3);
    }

    public abstract void measureInternal(float f2, float f3, int i2, int i3);
}
