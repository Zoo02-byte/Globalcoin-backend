package com.taobao.weex.layout.measurefunc;

import android.graphics.Canvas;
import android.os.Looper;
import android.text.Editable;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AlignmentSpan;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.dom.TextDecorationSpan;
import com.taobao.weex.dom.WXAttr;
import com.taobao.weex.dom.WXCustomStyleSpan;
import com.taobao.weex.dom.WXLineHeightSpan;
import com.taobao.weex.dom.WXStyle;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.layout.MeasureMode;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXTextDecoration;
import com.taobao.weex.utils.WXDomUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXResourceUtils;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/layout/measurefunc/TextContentBoxMeasurement.class */
public class TextContentBoxMeasurement extends ContentBoxMeasurement {
    private static final Canvas DUMMY_CANVAS = new Canvas();
    private static final String ELLIPSIS = "…";
    private Layout layout;
    protected Layout.Alignment mAlignment;
    protected int mColor;
    protected TextPaint mTextPaint;
    private Spanned spanned;
    private TextUtils.TruncateAt textOverflow;
    protected boolean mIsColorSet = false;
    private boolean hasBeenMeasured = false;
    protected int mFontStyle = -1;
    protected int mFontWeight = -1;
    private int mNumberOfLines = -1;
    protected int mFontSize = -1;
    protected int mLineHeight = -1;
    private float previousWidth = Float.NaN;
    protected String mFontFamily = null;
    private String mText = null;
    protected WXTextDecoration mTextDecoration = WXTextDecoration.NONE;
    private AtomicReference<Layout> atomicReference = new AtomicReference<>();

    /* loaded from: Coinglobal1.jar:com/taobao/weex/layout/measurefunc/TextContentBoxMeasurement$SetSpanOperation.class */
    class SetSpanOperation {
        protected final int end;
        protected final int flag;
        protected final int start;
        final TextContentBoxMeasurement this$0;
        protected final Object what;

        SetSpanOperation(TextContentBoxMeasurement textContentBoxMeasurement, int i2, int i3, Object obj) {
            this(textContentBoxMeasurement, i2, i3, obj, 17);
        }

        SetSpanOperation(TextContentBoxMeasurement textContentBoxMeasurement, int i2, int i3, Object obj, int i4) {
            this.this$0 = textContentBoxMeasurement;
            this.start = i2;
            this.end = i3;
            this.what = obj;
            this.flag = i4;
        }

        public void execute(Spannable spannable) {
            spannable.setSpan(this.what, this.start, this.end, this.flag);
        }
    }

    public TextContentBoxMeasurement(WXComponent wXComponent) {
        super(wXComponent);
    }

    private void adjustSpansRange(Spanned spanned, Spannable spannable) {
        Object[] spans = spanned.getSpans(0, spanned.length(), Object.class);
        for (Object obj : spans) {
            int spanStart = spanned.getSpanStart(obj);
            int spanEnd = spanned.getSpanEnd(obj);
            if (spanStart == 0 && spanEnd == spanned.length()) {
                spannable.removeSpan(obj);
                spannable.setSpan(obj, 0, spannable.length(), spanned.getSpanFlags(obj));
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x000d, code lost:
        if (r12 == null) goto L_0x0010;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private android.text.Layout createLayout(float r11, android.text.Layout r12) {
        /*
        // Method dump skipped, instructions count: 297
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.layout.measurefunc.TextContentBoxMeasurement.createLayout(float, android.text.Layout):android.text.Layout");
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0031, code lost:
        if (r0 < r5) goto L_0x0034;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private float getTextWidth(android.text.TextPaint r4, float r5, boolean r6) {
        /*
            r3 = this;
            r0 = r3
            java.lang.String r0 = r0.mText
            if (r0 != 0) goto L_0x000f
            r0 = r6
            if (r0 == 0) goto L_0x000d
            r0 = r5
            return r0
        L_0x000d:
            r0 = 0
            return r0
        L_0x000f:
            r0 = r6
            if (r0 == 0) goto L_0x0019
            r0 = r5
            r7 = r0
            goto L_0x0038
        L_0x0019:
            r0 = r3
            android.text.Spanned r0 = r0.spanned
            r1 = r4
            float r0 = android.text.Layout.getDesiredWidth(r0, r1)
            r8 = r0
            r0 = r5
            boolean r0 = com.taobao.weex.utils.WXUtils.isUndefined(r0)
            if (r0 != 0) goto L_0x0034
            r0 = r5
            r7 = r0
            r0 = r8
            r1 = r5
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0038
        L_0x0034:
            r0 = r8
            r7 = r0
        L_0x0038:
            r0 = r7
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.layout.measurefunc.TextContentBoxMeasurement.getTextWidth(android.text.TextPaint, float, boolean):float");
    }

    private void recalculateLayout(float f2) {
        float contentWidth = WXDomUtils.getContentWidth(this.mComponent.getPadding(), this.mComponent.getBorder(), f2);
        if (contentWidth > 0.0f) {
            Spanned createSpanned = createSpanned(this.mText);
            this.spanned = createSpanned;
            if (createSpanned != null) {
                Layout createLayout = createLayout(contentWidth, this.layout);
                this.layout = createLayout;
                this.previousWidth = (float) createLayout.getWidth();
                return;
            }
            this.previousWidth = 0.0f;
        }
    }

    private void swap() {
        Layout layout = this.layout;
        if (layout != null) {
            this.atomicReference.set(layout);
            this.layout = null;
        }
        this.hasBeenMeasured = false;
    }

    private Spanned truncate(Editable editable, TextPaint textPaint, int i2, TextUtils.TruncateAt truncateAt) {
        Spanned spanned = new SpannedString("");
        if (!TextUtils.isEmpty(editable) && editable.length() > 0) {
            if (truncateAt != null) {
                editable.append(ELLIPSIS);
                Object[] spans = editable.getSpans(0, editable.length(), Object.class);
                for (Object obj : spans) {
                    int spanStart = editable.getSpanStart(obj);
                    int spanEnd = editable.getSpanEnd(obj);
                    if (spanStart == 0 && spanEnd == editable.length() - 1) {
                        editable.removeSpan(obj);
                        editable.setSpan(obj, 0, editable.length(), editable.getSpanFlags(obj));
                    }
                }
            }
            while (editable.length() > 1) {
                int length = editable.length();
                int i3 = length - 1;
                if (truncateAt != null) {
                    i3 = length - 2;
                }
                editable.delete(i3, i3 + 1);
                if (new StaticLayout(editable, textPaint, i2, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false).getLineCount() <= 1) {
                    spanned = editable;
                    break;
                }
            }
        }
        return spanned;
    }

    private void updateStyleAndText() {
        updateStyleImp(this.mComponent.getStyles());
        this.mText = WXAttr.getValue(this.mComponent.getAttrs());
    }

    private void updateStyleImp(Map<String, Object> map) {
        if (map != null) {
            if (map.containsKey(Constants.Name.LINES)) {
                int lines = WXStyle.getLines(map);
                if (lines <= 0) {
                    lines = -1;
                }
                this.mNumberOfLines = lines;
            }
            if (map.containsKey(Constants.Name.FONT_SIZE)) {
                this.mFontSize = WXStyle.getFontSize(map, this.mComponent.getInstance().getDefaultFontSize(), this.mComponent.getViewPortWidthForFloat());
            }
            if (map.containsKey(Constants.Name.FONT_WEIGHT)) {
                this.mFontWeight = WXStyle.getFontWeight(map);
            }
            if (map.containsKey(Constants.Name.FONT_STYLE)) {
                this.mFontStyle = WXStyle.getFontStyle(map);
            }
            if (map.containsKey("color")) {
                int color = WXResourceUtils.getColor(WXStyle.getTextColor(map));
                this.mColor = color;
                this.mIsColorSet = color != Integer.MIN_VALUE;
            }
            if (map.containsKey(Constants.Name.TEXT_DECORATION)) {
                this.mTextDecoration = WXStyle.getTextDecoration(map);
            }
            if (map.containsKey(Constants.Name.FONT_FAMILY)) {
                this.mFontFamily = WXStyle.getFontFamily(map);
            }
            this.mAlignment = WXStyle.getTextAlignment(map, this.mComponent.isLayoutRTL());
            this.textOverflow = WXStyle.getTextOverflow(map);
            int lineHeight = WXStyle.getLineHeight(map, this.mComponent.getViewPortWidthForFloat());
            if (lineHeight != -1) {
                this.mLineHeight = lineHeight;
            }
        }
    }

    private boolean warmUpTextLayoutCache(Layout layout) {
        boolean z2;
        try {
            layout.draw(DUMMY_CANVAS);
            z2 = true;
        } catch (Exception e2) {
            WXLogUtils.eTag("TextWarmUp", e2);
            z2 = false;
        }
        return z2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public Spanned createSpanned(String str) {
        if (TextUtils.isEmpty(str)) {
            return new SpannableString("");
        }
        SpannableString spannableString = new SpannableString(str);
        updateSpannable(spannableString, 17);
        return spannableString;
    }

    public void forceRelayout() {
        layoutBefore();
        measure(this.previousWidth, Float.NaN, MeasureMode.EXACTLY, MeasureMode.UNSPECIFIED);
        layoutAfter(this.previousWidth, Float.NaN);
    }

    @Override // com.taobao.weex.layout.ContentBoxMeasurement
    public void layoutAfter(float f2, float f3) {
        if (this.mComponent != null) {
            if (!this.hasBeenMeasured) {
                updateStyleAndText();
                recalculateLayout(f2);
            } else if (!(this.layout == null || WXDomUtils.getContentWidth(this.mComponent.getPadding(), this.mComponent.getBorder(), f2) == this.previousWidth)) {
                recalculateLayout(f2);
            }
            this.hasBeenMeasured = false;
            Layout layout = this.layout;
            if (!(layout == null || layout.equals(this.atomicReference.get()) || Thread.currentThread() == Looper.getMainLooper().getThread())) {
                warmUpTextLayoutCache(this.layout);
            }
            swap();
            WXSDKManager.getInstance().getWXRenderManager().postOnUiThread(new Runnable(this) { // from class: com.taobao.weex.layout.measurefunc.TextContentBoxMeasurement.1
                final TextContentBoxMeasurement this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (this.this$0.mComponent != null) {
                        this.this$0.mComponent.updateExtra(this.this$0.atomicReference.get());
                    }
                }
            }, this.mComponent.getInstanceId());
        }
    }

    @Override // com.taobao.weex.layout.ContentBoxMeasurement
    public void layoutBefore() {
        this.mTextPaint = new TextPaint(1);
        this.hasBeenMeasured = false;
        updateStyleAndText();
        this.spanned = createSpanned(this.mText);
    }

    @Override // com.taobao.weex.layout.ContentBoxMeasurement
    public void measureInternal(float f2, float f3, int i2, int i3) {
        float f4;
        float f5;
        boolean z2 = true;
        this.hasBeenMeasured = true;
        TextPaint textPaint = this.mTextPaint;
        if (i2 != MeasureMode.EXACTLY) {
            z2 = false;
        }
        float textWidth = getTextWidth(textPaint, f2, z2);
        if (textWidth <= 0.0f || this.spanned == null) {
            if (i2 == MeasureMode.UNSPECIFIED) {
                f2 = 0.0f;
            }
            f4 = f2;
            f5 = f3;
            if (i3 == MeasureMode.UNSPECIFIED) {
                f5 = 0.0f;
                f4 = f2;
            }
        } else {
            Layout createLayout = createLayout(textWidth, null);
            this.layout = createLayout;
            this.previousWidth = (float) createLayout.getWidth();
            float width = Float.isNaN(f2) ? (float) this.layout.getWidth() : Math.min((float) this.layout.getWidth(), f2);
            f4 = width;
            f5 = f3;
            if (Float.isNaN(f3)) {
                f5 = (float) this.layout.getHeight();
                f4 = width;
            }
        }
        this.mMeasureWidth = f4;
        this.mMeasureHeight = f5;
    }

    protected void setSpan(Spannable spannable, Object obj, int i2, int i3, int i4) {
        spannable.setSpan(obj, i2, i3, i4);
    }

    protected void updateSpannable(Spannable spannable, int i2) {
        int length = spannable.length();
        int i3 = this.mFontSize;
        if (i3 == -1) {
            this.mTextPaint.setTextSize((float) this.mComponent.getInstance().getDefaultFontSize());
        } else {
            this.mTextPaint.setTextSize((float) i3);
        }
        if (this.mLineHeight != -1) {
            setSpan(spannable, new WXLineHeightSpan(this.mLineHeight), 0, length, i2);
        }
        setSpan(spannable, new AlignmentSpan.Standard(this.mAlignment), 0, length, i2);
        if (!(this.mFontStyle == -1 && this.mFontWeight == -1 && this.mFontFamily == null)) {
            setSpan(spannable, new WXCustomStyleSpan(this.mFontStyle, this.mFontWeight, this.mFontFamily), 0, length, i2);
        }
        if (this.mIsColorSet) {
            this.mTextPaint.setColor(this.mColor);
        }
        if (this.mTextDecoration == WXTextDecoration.UNDERLINE || this.mTextDecoration == WXTextDecoration.LINETHROUGH) {
            setSpan(spannable, new TextDecorationSpan(this.mTextDecoration), 0, length, i2);
        }
    }
}
