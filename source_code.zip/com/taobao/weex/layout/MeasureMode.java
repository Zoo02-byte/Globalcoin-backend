package com.taobao.weex.layout;

import java.io.Serializable;
/* loaded from: Coinglobal1.jar:com/taobao/weex/layout/MeasureMode.class */
public class MeasureMode implements Serializable {
    public static int EXACTLY = 1;
    public static int UNSPECIFIED;
}
