package com.taobao.weex.layout;

import java.io.Serializable;
/* loaded from: Coinglobal1.jar:com/taobao/weex/layout/MeasureSize.class */
public class MeasureSize implements Serializable {
    private float height;
    private float width;

    public float getHeight() {
        return this.height;
    }

    public float getWidth() {
        return this.width;
    }

    public void setHeight(float f2) {
        this.height = f2;
    }

    public void setWidth(float f2) {
        this.width = f2;
    }
}
