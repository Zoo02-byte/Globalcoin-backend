package com.taobao.weex;

import android.view.View;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/ComponentObserver.class */
public interface ComponentObserver {
    void onCreate(WXComponent wXComponent);

    void onPreDestory(WXComponent wXComponent);

    void onViewCreated(WXComponent wXComponent, View view);
}
