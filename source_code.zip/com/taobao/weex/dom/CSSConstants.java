package com.taobao.weex.dom;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/CSSConstants.class */
public class CSSConstants {
    public static final float UNDEFINED = Float.NaN;

    public static boolean isUndefined(float f2) {
        return Float.compare(f2, Float.NaN) == 0;
    }
}
