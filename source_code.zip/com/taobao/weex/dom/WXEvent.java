package com.taobao.weex.dom;

import io.dcloud.feature.uniapp.dom.AbsEvent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/WXEvent.class */
public class WXEvent extends AbsEvent {
    @Override // io.dcloud.feature.uniapp.dom.AbsEvent, java.util.ArrayList, java.lang.Object
    public WXEvent clone() {
        WXEvent wXEvent = new WXEvent();
        wXEvent.addAll(this);
        if (getEventBindingArgs() != null) {
            wXEvent.setEventBindingArgs(getEventBindingArgs());
        }
        wXEvent.setEventBindingArgsValues(null);
        return wXEvent;
    }
}
