package com.taobao.weex.dom;

import android.graphics.Paint;
import android.text.style.LineHeightSpan;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.utils.WXLogUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/WXLineHeightSpan.class */
public class WXLineHeightSpan implements LineHeightSpan {
    private int lineHeight;

    public WXLineHeightSpan(int i2) {
        this.lineHeight = i2;
    }

    @Override // android.text.style.LineHeightSpan
    public void chooseHeight(CharSequence charSequence, int i2, int i3, int i4, int i5, Paint.FontMetricsInt fontMetricsInt) {
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("LineHeight", ((Object) charSequence) + " ; start " + i2 + "; end " + i3 + "; spanstartv " + i4 + "; v " + i5 + "; fm " + fontMetricsInt);
        }
        int i6 = this.lineHeight - (fontMetricsInt.descent - fontMetricsInt.ascent);
        int i7 = i6 / 2;
        int i8 = i6 - i7;
        fontMetricsInt.top -= i8;
        fontMetricsInt.bottom += i7;
        fontMetricsInt.ascent -= i8;
        fontMetricsInt.descent += i7;
    }
}
