package com.taobao.weex.dom;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/WXImageQuality.class */
public enum WXImageQuality {
    ORIGINAL,
    LOW,
    NORMAL,
    HIGH,
    AUTO
}
