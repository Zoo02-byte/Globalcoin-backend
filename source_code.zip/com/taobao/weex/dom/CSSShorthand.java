package com.taobao.weex.dom;

import io.dcloud.feature.uniapp.dom.AbsCSSShorthand;
import java.lang.Enum;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/CSSShorthand.class */
public class CSSShorthand<T extends Enum<? extends WXCSSProperty>> extends AbsCSSShorthand {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/dom/CSSShorthand$CORNER.class */
    public enum CORNER implements WXCSSProperty {
        BORDER_TOP_LEFT,
        BORDER_TOP_RIGHT,
        BORDER_BOTTOM_RIGHT,
        BORDER_BOTTOM_LEFT,
        ALL
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/dom/CSSShorthand$EDGE.class */
    public enum EDGE implements WXCSSProperty {
        TOP,
        BOTTOM,
        LEFT,
        RIGHT,
        ALL
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/dom/CSSShorthand$WXCSSProperty.class */
    interface WXCSSProperty extends AbsCSSShorthand.CSSProperty {
    }

    public CSSShorthand() {
    }

    public CSSShorthand(float[] fArr) {
        super(fArr);
    }

    @Override // io.dcloud.feature.uniapp.dom.AbsCSSShorthand, java.lang.Object
    public CSSShorthand clone() throws CloneNotSupportedException {
        return (CSSShorthand) clone();
    }
}
