package com.taobao.weex.dom;

import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;
import com.taobao.weex.utils.TypefaceUtil;
/* loaded from: Coinglobal1.jar:com/taobao/weex/dom/WXCustomStyleSpan.class */
public class WXCustomStyleSpan extends MetricAffectingSpan {
    private final String mFontFamily;
    private final int mStyle;
    private final int mWeight;

    public WXCustomStyleSpan(int i2, int i3, String str) {
        this.mStyle = i2;
        this.mWeight = i3;
        this.mFontFamily = str;
    }

    public String getFontFamily() {
        return this.mFontFamily;
    }

    public int getStyle() {
        int i2 = this.mStyle;
        int i3 = i2;
        if (i2 == -1) {
            i3 = 0;
        }
        return i3;
    }

    public int getWeight() {
        int i2 = this.mWeight;
        int i3 = i2;
        if (i2 == -1) {
            i3 = 0;
        }
        return i3;
    }

    @Override // android.text.style.CharacterStyle
    public void updateDrawState(TextPaint textPaint) {
        TypefaceUtil.applyFontStyle(textPaint, this.mStyle, this.mWeight, this.mFontFamily);
    }

    @Override // android.text.style.MetricAffectingSpan
    public void updateMeasureState(TextPaint textPaint) {
        TypefaceUtil.applyFontStyle(textPaint, this.mStyle, this.mWeight, this.mFontFamily);
    }
}
