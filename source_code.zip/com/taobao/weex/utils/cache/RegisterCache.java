package com.taobao.weex.utils.cache;

import com.taobao.weex.bridge.ModuleFactory;
import com.taobao.weex.bridge.WXModuleManager;
import com.taobao.weex.ui.IFComponentHolder;
import com.taobao.weex.ui.WXComponentRegistry;
import com.taobao.weex.ui.config.AutoScanConfigRegister;
import com.taobao.weex.utils.WXLogUtils;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/cache/RegisterCache.class */
public class RegisterCache {
    private static RegisterCache registerCache;
    private static Map<String, ModuleCache> moduleCacheMap = new ConcurrentHashMap();
    private static Map<String, ComponentCache> componentCacheMap = new ConcurrentHashMap();
    private boolean enable = false;
    private boolean enableAutoScan = true;
    private volatile boolean finished = false;
    private volatile int doNotCacheSize = Integer.MAX_VALUE;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/cache/RegisterCache$ComponentCache.class */
    public class ComponentCache {
        public final Map<String, Object> componentInfo;
        public final IFComponentHolder holder;
        final RegisterCache this$0;
        public final String type;

        ComponentCache(RegisterCache registerCache, String str, IFComponentHolder iFComponentHolder, Map<String, Object> map) {
            this.this$0 = registerCache;
            this.type = str;
            this.componentInfo = map;
            this.holder = iFComponentHolder;
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/cache/RegisterCache$ModuleCache.class */
    public class ModuleCache {
        public final ModuleFactory factory;
        public final boolean global;
        public final String name;
        final RegisterCache this$0;

        ModuleCache(RegisterCache registerCache, String str, ModuleFactory moduleFactory, boolean z2) {
            this.this$0 = registerCache;
            this.name = str;
            this.factory = moduleFactory;
            this.global = z2;
        }
    }

    private RegisterCache() {
    }

    private void CacheComponentRegister() {
        if (!componentCacheMap.isEmpty()) {
            WXComponentRegistry.registerComponent(componentCacheMap);
        }
    }

    private void CacheModuleRegister() {
        if (!moduleCacheMap.isEmpty()) {
            WXModuleManager.registerModule(moduleCacheMap);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0017, code lost:
        if (getDoNotCacheSize() < 1) goto L_0x001f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private boolean canCache() {
        /*
            r3 = this;
            r0 = r3
            boolean r0 = r0.enableCache()
            if (r0 == 0) goto L_0x001d
            r0 = r3
            boolean r0 = r0.finished
            if (r0 != 0) goto L_0x001d
            r0 = r3
            int r0 = r0.getDoNotCacheSize()
            r4 = r0
            r0 = 1
            r5 = r0
            r0 = r4
            r1 = 1
            if (r0 >= r1) goto L_0x001d
            goto L_0x001f
        L_0x001d:
            r0 = 0
            r5 = r0
        L_0x001f:
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.cache.RegisterCache.canCache():boolean");
    }

    private boolean enableCache() {
        return this.enable;
    }

    private int getDoNotCacheSize() {
        int i2 = this.doNotCacheSize;
        this.doNotCacheSize = i2 - 1;
        return i2;
    }

    public static RegisterCache getInstance() {
        if (registerCache == null) {
            synchronized (RegisterCache.class) {
                try {
                    if (registerCache == null) {
                        registerCache = new RegisterCache();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return registerCache;
    }

    public boolean cacheComponent(String str, IFComponentHolder iFComponentHolder, Map<String, Object> map) {
        if (!canCache()) {
            return false;
        }
        try {
            componentCacheMap.put(str, new ComponentCache(this, str, iFComponentHolder, map));
            return true;
        } catch (Exception e2) {
            return false;
        }
    }

    public boolean cacheModule(String str, ModuleFactory moduleFactory, boolean z2) {
        if (!canCache()) {
            return false;
        }
        try {
            moduleCacheMap.put(str, new ModuleCache(this, str, moduleFactory, z2));
            return true;
        } catch (Exception e2) {
            return false;
        }
    }

    public boolean enableAutoScan() {
        return this.enableAutoScan;
    }

    public boolean idle(boolean z2) {
        if (this.finished) {
            return true;
        }
        WXLogUtils.e((z2 ? "idle from create instance" : "idle from external") + " cache size is " + (moduleCacheMap.size() + componentCacheMap.size()));
        this.finished = true;
        CacheComponentRegister();
        CacheModuleRegister();
        return true;
    }

    public void setDoNotCacheSize(int i2) {
        this.doNotCacheSize = i2;
    }

    public void setEnable(boolean z2) {
        this.enable = z2;
    }

    public void setEnableAutoScan(boolean z2) {
        if (this.enableAutoScan != z2) {
            if (z2) {
                AutoScanConfigRegister.doScanConfig();
            }
            this.enableAutoScan = z2;
        }
    }
}
