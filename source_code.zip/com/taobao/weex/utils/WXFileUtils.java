package com.taobao.weex.utils;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;
import com.taobao.weex.el.parse.Operators;
import io.dcloud.common.util.Md5Utils;
import io.dcloud.common.util.PdrUtil;
import io.dcloud.weex.DCFileUtils;
import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXFileUtils.class */
public class WXFileUtils {
    public static String base64Md5(String str) {
        if (str == null) {
            return "";
        }
        try {
            return base64Md5(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e2) {
            return "";
        }
    }

    public static String base64Md5(byte[] bArr) {
        try {
            MessageDigest instance = MessageDigest.getInstance(Md5Utils.ALGORITHM);
            instance.update(bArr);
            return Base64.encodeToString(instance.digest(), 2);
        } catch (NoSuchAlgorithmException e2) {
            return "";
        }
    }

    public static void closeIo(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    public static void copyFile(File file, File file2) {
        FileInputStream fileInputStream;
        Exception e2;
        FileOutputStream fileOutputStream;
        try {
            fileInputStream = new FileInputStream(file);
            try {
                byte[] bArr = new byte[1024];
                fileOutputStream = new FileOutputStream(file2);
                while (fileInputStream.read(bArr) != -1) {
                    try {
                        fileOutputStream.write(bArr);
                    } catch (Exception e3) {
                        e2 = e3;
                        WXLogUtils.e("copyFile " + e2.getMessage() + ": " + file.getAbsolutePath() + ": " + file2.getAbsolutePath());
                        if (fileInputStream != null) {
                            try {
                                fileInputStream.close();
                            } catch (IOException e4) {
                                e4.printStackTrace();
                            }
                        }
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                                return;
                            } catch (IOException e5) {
                                e5.printStackTrace();
                                return;
                            }
                        } else {
                            return;
                        }
                    }
                }
                fileInputStream.close();
                fileOutputStream.close();
            } catch (Exception e6) {
                e2 = e6;
                fileOutputStream = null;
            }
        } catch (Exception e7) {
            e2 = e7;
            fileOutputStream = null;
            fileInputStream = null;
        }
    }

    public static void copyFileWithException(File file, File file2) throws Exception {
        Throwable th;
        FileOutputStream fileOutputStream;
        Exception e2;
        r4 = null;
        FileInputStream fileInputStream = null;
        try {
            FileInputStream fileInputStream2 = new FileInputStream(file);
            try {
                byte[] bArr = new byte[1024];
                fileOutputStream = new FileOutputStream(file2);
                while (fileInputStream2.read(bArr) != -1) {
                    try {
                        fileOutputStream.write(bArr);
                    } catch (Exception e3) {
                        e2 = e3;
                        fileOutputStream = fileOutputStream;
                        fileInputStream = fileInputStream2;
                        try {
                            throw e2;
                        } catch (Throwable th2) {
                            th = th2;
                            closeIo(fileInputStream);
                            closeIo(fileOutputStream);
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        fileInputStream = fileInputStream2;
                        closeIo(fileInputStream);
                        closeIo(fileOutputStream);
                        throw th;
                    }
                }
                closeIo(fileInputStream2);
                closeIo(fileOutputStream);
            } catch (Exception e4) {
                e2 = e4;
                fileOutputStream = null;
            } catch (Throwable th4) {
                th = th4;
                fileOutputStream = null;
            }
        } catch (Exception e5) {
            e2 = e5;
            fileOutputStream = null;
        } catch (Throwable th5) {
            th = th5;
            fileOutputStream = null;
        }
    }

    public static boolean extractSo(String str, String str2) throws IOException {
        r10 = false;
        boolean z2 = false;
        if (PdrUtil.isSafeEntryName(str)) {
            if (!PdrUtil.isSafeEntryName(str2)) {
                z2 = false;
            } else {
                HashMap hashMap = new HashMap();
                ZipFile zipFile = new ZipFile(str);
                ZipInputStream zipInputStream = new ZipInputStream(new BufferedInputStream(new FileInputStream(str)));
                Enumeration<? extends ZipEntry> entries = zipFile.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry zipEntry = (ZipEntry) entries.nextElement();
                    if (!zipEntry.getName().contains("../") && !zipEntry.isDirectory() && validLibPath(zipEntry.getName()) && (zipEntry.getName().contains("weex") || zipEntry.getName().equals("libjsc.so") || zipEntry.getName().equals("libJavaScriptCore.so"))) {
                        String[] split = zipEntry.getName().split(Operators.DIV);
                        String str3 = split[split.length - 1];
                        File file = new File(str2 + Operators.DIV + str3);
                        if (replaceLib(zipEntry.getName(), (String) hashMap.get(str3))) {
                            hashMap.put(str3, zipEntry.getName());
                            if (file.exists()) {
                                file.delete();
                            }
                            InputStream inputStream = zipFile.getInputStream(zipEntry);
                            byte[] bArr = new byte[1024];
                            file.createNewFile();
                            FileOutputStream fileOutputStream = new FileOutputStream(file);
                            while (inputStream.read(bArr) != -1) {
                                fileOutputStream.write(bArr);
                            }
                            fileOutputStream.close();
                        }
                        z2 = true;
                    }
                }
                zipInputStream.closeEntry();
            }
        }
        return z2;
    }

    public static String loadAsset(String str, Context context) {
        if (context == null || TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            String assetPath = DCFileUtils.getAssetPath(str);
            InputStream loadWeexAsset = DCFileUtils.loadWeexAsset(assetPath, context);
            InputStream inputStream = loadWeexAsset;
            if (loadWeexAsset == null) {
                inputStream = context.getAssets().open(assetPath);
            }
            return readStreamToString(inputStream);
        } catch (IOException e2) {
            return "";
        }
    }

    public static String loadFileOrAsset(String str, Context context) {
        if (TextUtils.isEmpty(str)) {
            return "";
        }
        File file = new File(str);
        if (!file.exists()) {
            return loadAsset(str, context);
        }
        try {
            return readStreamToString(new FileInputStream(file));
        } catch (FileNotFoundException e2) {
            e2.printStackTrace();
            return "";
        }
    }

    public static String md5(String str) {
        if (str == null) {
            return "";
        }
        try {
            return md5(str.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e2) {
            return "";
        }
    }

    public static String md5(byte[] bArr) {
        try {
            MessageDigest instance = MessageDigest.getInstance(Md5Utils.ALGORITHM);
            instance.update(bArr);
            return new BigInteger(1, instance.digest()).toString(16);
        } catch (NoSuchAlgorithmException e2) {
            return "";
        }
    }

    public static byte[] readBytesFromAssets(String str, Context context) {
        if (context == null || TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            byte[] bArr = new byte[4096];
            int read = context.getAssets().open(str).read(bArr);
            byte[] bArr2 = new byte[read];
            System.arraycopy(bArr, 0, bArr2, 0, read);
            return bArr2;
        } catch (IOException e2) {
            WXLogUtils.e("", e2);
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x00d7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00c3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private static java.lang.String readStreamToString(java.io.InputStream r5) {
        /*
        // Method dump skipped, instructions count: 232
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXFileUtils.readStreamToString(java.io.InputStream):java.lang.String");
    }

    private static boolean replaceLib(String str, String str2) {
        if (str == null || str2 == null) {
            return true;
        }
        String[] validCPUABIS = validCPUABIS();
        boolean z2 = false;
        for (String str3 : validCPUABIS) {
            if (str2.contains(str3) && z2) {
                return true;
            }
            if (str.contains(str3)) {
                z2 = true;
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.io.FileOutputStream] */
    /* JADX WARN: Type inference failed for: r5v7 */
    public static boolean saveFile(String str, byte[] bArr, Context context) {
        Throwable th;
        Exception e2;
        FileOutputStream fileOutputStream;
        FileOutputStream fileOutputStream2;
        if (TextUtils.isEmpty(str) || bArr == null || context == 0) {
            return false;
        }
        try {
            fileOutputStream = null;
            try {
                fileOutputStream2 = new FileOutputStream(str);
            } catch (Exception e3) {
                e2 = e3;
            }
        } catch (Throwable th2) {
            th = th2;
        }
        try {
            fileOutputStream2.write(bArr);
            try {
                fileOutputStream2.close();
                return true;
            } catch (IOException e4) {
                e4.printStackTrace();
                return true;
            }
        } catch (Exception e5) {
            e2 = e5;
            fileOutputStream = fileOutputStream2;
            WXLogUtils.e("WXFileUtils saveFile: " + WXLogUtils.getStackTrace(e2));
            if (fileOutputStream == null) {
                return false;
            }
            try {
                fileOutputStream.close();
                return false;
            } catch (IOException e6) {
                e6.printStackTrace();
                return false;
            }
        } catch (Throwable th3) {
            th = th3;
            context = fileOutputStream2;
            if (context != 0) {
                try {
                    context.close();
                } catch (IOException e7) {
                    e7.printStackTrace();
                }
            }
            throw th;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x000c, code lost:
        if (r0.length == 0) goto L_0x000f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private static java.lang.String[] validCPUABIS() {
        /*
            java.lang.String[] r0 = android.os.Build.SUPPORTED_ABIS
            r5 = r0
            r0 = r5
            if (r0 == 0) goto L_0x000f
            r0 = r5
            r4 = r0
            r0 = r5
            int r0 = r0.length
            if (r0 != 0) goto L_0x001a
        L_0x000f:
            r0 = 1
            java.lang.String[] r0 = new java.lang.String[r0]
            r4 = r0
            r0 = r4
            r1 = 0
            java.lang.String r2 = android.os.Build.CPU_ABI
            r0[r1] = r2
        L_0x001a:
            r0 = r4
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXFileUtils.validCPUABIS():java.lang.String[]");
    }

    private static boolean validLibPath(String str) {
        for (String str2 : validCPUABIS()) {
            if (str.contains(str2)) {
                return true;
            }
        }
        return false;
    }
}
