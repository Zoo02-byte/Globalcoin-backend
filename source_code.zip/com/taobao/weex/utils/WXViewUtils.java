package com.taobao.weex.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.common.WXRuntimeException;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.component.WXDiv;
import com.taobao.weex.ui.flat.widget.Widget;
import com.taobao.weex.ui.flat.widget.WidgetGroup;
import com.taobao.weex.ui.view.WXFrameLayout;
import com.taobao.weex.ui.view.border.BorderDrawable;
import io.dcloud.common.constant.AbsoluteConst;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.concurrent.atomic.AtomicInteger;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXViewUtils.class */
public class WXViewUtils {
    public static final int DIMENSION_UNSET;
    @Deprecated
    public static final int OPAQUE;
    @Deprecated
    public static final int TRANSLUCENT;
    @Deprecated
    public static final int TRANSPARENT;
    private static int mScreenHeight;
    private static int mScreenWidth;
    private static final boolean mUseWebPx;
    private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);

    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXViewUtils$Opacity.class */
    public @interface Opacity {
    }

    private static boolean clipCanvasDueToAndroidVersion(Canvas canvas) {
        return true;
    }

    private static boolean clipCanvasIfAnimationExist(View view) {
        return false;
    }

    private static boolean clipCanvasIfBackgroundImageExist(View view, BorderDrawable borderDrawable) {
        if (!(view instanceof ViewGroup)) {
            return true;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            BorderDrawable borderDrawable2 = getBorderDrawable(viewGroup.getChildAt(i2));
            if (borderDrawable2 != null) {
                borderDrawable2.hasImage();
            }
        }
        return true;
    }

    private static boolean clipCanvasIfBackgroundImageExist(Widget widget, BorderDrawable borderDrawable) {
        if (!(widget instanceof WidgetGroup)) {
            return true;
        }
        for (Widget widget2 : ((WidgetGroup) widget).getChildren()) {
            widget2.getBackgroundAndBorder().hasImage();
        }
        return true;
    }

    public static void clipCanvasWithinBorderBox(View view, Canvas canvas) {
        if (clipCanvasDueToAndroidVersion(canvas) && clipCanvasIfAnimationExist(view)) {
            BorderDrawable borderDrawable = getBorderDrawable(view);
            if ((borderDrawable instanceof BorderDrawable) && borderDrawable.isRounded() && clipCanvasIfBackgroundImageExist(view, borderDrawable)) {
                RectF rectF = new RectF(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
                Path contentPath = borderDrawable.getContentPath(rectF);
                if (view instanceof WXFrameLayout) {
                    WXDiv component = ((WXFrameLayout) view).getComponent();
                    if (component != null) {
                        Object obj = component.getAttrs().get(Constants.Name.ROTATE_FIX);
                        if (obj != null && obj.toString().equals(AbsoluteConst.TRUE)) {
                            canvas.clipRect(rectF);
                        } else if (component.getStyles() != null && "hidden".equals(component.getStyles().getOverflow())) {
                            canvas.clipPath(contentPath);
                        }
                    }
                } else {
                    canvas.clipPath(contentPath);
                }
            }
        }
    }

    public static void clipCanvasWithinBorderBox(Widget widget, Canvas canvas) {
        BorderDrawable backgroundAndBorder;
        if (clipCanvasDueToAndroidVersion(canvas) && clipCanvasIfAnimationExist(null) && (backgroundAndBorder = widget.getBackgroundAndBorder()) != null) {
            if (!backgroundAndBorder.isRounded() || !clipCanvasIfBackgroundImageExist(widget, backgroundAndBorder)) {
                canvas.clipRect(widget.getBorderBox());
            } else {
                canvas.clipPath(backgroundAndBorder.getContentPath(new RectF(0.0f, 0.0f, (float) widget.getBorderBox().width(), (float) widget.getBorderBox().height())));
            }
        }
    }

    public static int dip2px(float f2) {
        float f3;
        try {
            f3 = WXEnvironment.getApplication().getResources().getDisplayMetrics().density;
        } catch (Exception e2) {
            WXLogUtils.e("[WXViewUtils] dip2px:", e2);
            f3 = 2.0f;
        }
        float f4 = (f2 * f3) + 0.5f;
        return (f4 <= 0.0f || f4 >= 1.0f) ? (int) f4 : 1;
    }

    public static int generateViewId() {
        return View.generateViewId();
    }

    public static BorderDrawable getBorderDrawable(View view) {
        Drawable background = view.getBackground();
        if (background instanceof BorderDrawable) {
            return (BorderDrawable) background;
        }
        if (!(background instanceof LayerDrawable)) {
            return null;
        }
        LayerDrawable layerDrawable = (LayerDrawable) background;
        if (layerDrawable.getNumberOfLayers() <= 1) {
            return null;
        }
        for (int i2 = 0; i2 < layerDrawable.getNumberOfLayers(); i2++) {
            Drawable drawable = layerDrawable.getDrawable(i2);
            if (drawable instanceof BorderDrawable) {
                return (BorderDrawable) drawable;
            }
        }
        return null;
    }

    public static int getFullScreenHeight(Context context) {
        if (context != null) {
            Resources resources = context.getResources();
            WindowManager windowManager = (WindowManager) context.getSystemService("window");
            if (windowManager == null || windowManager.getDefaultDisplay() == null) {
                mScreenHeight = context.getResources().getDisplayMetrics().heightPixels;
            } else {
                Point point = new Point();
                windowManager.getDefaultDisplay().getRealSize(point);
                mScreenHeight = point.y;
            }
            if (WXEnvironment.SETTING_FORCE_VERTICAL_SCREEN) {
                int i2 = resources.getDisplayMetrics().widthPixels;
                mScreenWidth = i2;
                int i3 = mScreenHeight;
                int i4 = i2;
                if (i3 > i2) {
                    i4 = i3;
                }
                mScreenHeight = i4;
            }
        } else if (WXEnvironment.isApkDebugable()) {
            throw new WXRuntimeException("Error Context is null When getScreenHeight");
        }
        return mScreenHeight;
    }

    public static int getOpacityFromColor(int i2) {
        int i3 = i2 >>> 24;
        if (i3 == 255) {
            return -1;
        }
        return i3 == 0 ? -2 : -3;
    }

    @Deprecated
    public static float getRealPxByWidth(float f2) {
        return realPxByWidth(f2, 750.0f);
    }

    public static float getRealPxByWidth(float f2, float f3) {
        return realPxByWidth(f2, f3);
    }

    public static float getRealPxByWidth(float f2, int i2) {
        return realPxByWidth(f2, (float) i2);
    }

    @Deprecated
    public static float getRealPxByWidth2(float f2) {
        return (float) realPxByWidth2(f2, 750.0f);
    }

    public static int getRealPxByWidth2(float f2, float f3) {
        return realPxByWidth2(f2, f3);
    }

    public static int getRealPxByWidth2(float f2, int i2) {
        return realPxByWidth2(f2, (float) i2);
    }

    @Deprecated
    public static float getRealSubPxByWidth(float f2) {
        return realSubPxByWidth(f2, 750.0f);
    }

    public static float getRealSubPxByWidth(float f2, float f3) {
        return realSubPxByWidth(f2, f3);
    }

    public static float getRealSubPxByWidth(float f2, int i2) {
        return realSubPxByWidth(f2, (float) i2);
    }

    public static float getScreenDensity(Context context) {
        if (context == null) {
            return 3.0f;
        }
        try {
            return context.getResources().getDisplayMetrics().density;
        } catch (Exception e2) {
            WXLogUtils.e("getScreenDensityDpi exception:" + e2.getMessage());
            return 3.0f;
        }
    }

    @Deprecated
    public static int getScreenHeight() {
        return getScreenHeight(WXEnvironment.sApplication);
    }

    public static int getScreenHeight(Context context) {
        if (context != null) {
            Resources resources = context.getResources();
            mScreenHeight = resources.getDisplayMetrics().heightPixels;
            if (WXEnvironment.SETTING_FORCE_VERTICAL_SCREEN) {
                int i2 = resources.getDisplayMetrics().widthPixels;
                mScreenWidth = i2;
                int i3 = mScreenHeight;
                int i4 = i2;
                if (i3 > i2) {
                    i4 = i3;
                }
                mScreenHeight = i4;
            }
        } else if (WXEnvironment.isApkDebugable()) {
            throw new WXRuntimeException("Error Context is null When getScreenHeight");
        }
        return mScreenHeight;
    }

    public static int getScreenHeight(String str) {
        return WXSDKManager.getInstance().getSDKInstance(str).isFullScreenHeightEnabled() ? getFullScreenHeight(WXEnvironment.sApplication) : getScreenHeight(WXEnvironment.sApplication);
    }

    @Deprecated
    public static int getScreenWidth() {
        return getScreenWidth(WXEnvironment.sApplication);
    }

    public static int getScreenWidth(Context context) {
        if (context != null) {
            Resources resources = context.getResources();
            mScreenWidth = resources.getDisplayMetrics().widthPixels;
            if (WXEnvironment.SETTING_FORCE_VERTICAL_SCREEN) {
                int i2 = resources.getDisplayMetrics().heightPixels;
                mScreenHeight = i2;
                int i3 = mScreenWidth;
                int i4 = i2;
                if (i2 > i3) {
                    i4 = i3;
                }
                mScreenWidth = i4;
            }
        } else if (WXEnvironment.isApkDebugable()) {
            throw new WXRuntimeException("Error Context is null When getScreenHeight");
        }
        return mScreenWidth;
    }

    public static int getStatusBarHeight(Context context) {
        Resources resources = context.getResources();
        int identifier = resources.getIdentifier("status_bar_height", "dimen", WXEnvironment.OS);
        if (identifier > 0) {
            return resources.getDimensionPixelSize(identifier);
        }
        return -1;
    }

    @Deprecated
    public static float getWebPxByWidth(float f2) {
        return webPxByWidth(f2, 750.0f);
    }

    public static float getWebPxByWidth(float f2, float f3) {
        return webPxByWidth(f2, f3);
    }

    public static float getWebPxByWidth(float f2, int i2) {
        return webPxByWidth(f2, (float) i2);
    }

    public static int getWeexHeight(String str) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        if (sDKInstance == null) {
            return -3;
        }
        int weexHeight = sDKInstance.getWeexHeight();
        int i2 = weexHeight;
        if (weexHeight < 0) {
            i2 = weexHeight == -2 ? weexHeight : getScreenHeight(WXEnvironment.sApplication);
        }
        return i2;
    }

    @Deprecated
    public static float getWeexPxByReal(float f2) {
        return weexPxByReal(f2, 750.0f);
    }

    public static float getWeexPxByReal(float f2, float f3) {
        return weexPxByReal(f2, f3);
    }

    public static float getWeexPxByReal(float f2, int i2) {
        return weexPxByReal(f2, (float) i2);
    }

    public static int getWeexWidth(String str) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        if (sDKInstance == null) {
            return -3;
        }
        int weexWidth = sDKInstance.getWeexWidth();
        int i2 = weexWidth;
        if (weexWidth < 0) {
            i2 = weexWidth == -2 ? weexWidth : getScreenWidth(WXEnvironment.sApplication);
        }
        return i2;
    }

    public static int multiplyColorAlpha(int i2, int i3) {
        return i3 == 255 ? i2 : i3 == 0 ? i2 & 16777215 : (i2 & 16777215) | ((((i2 >>> 24) * (i3 + (i3 >> 7))) >> 8) << 24);
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0061, code lost:
        if (r0 <= 0) goto L_0x0064;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public static boolean onScreenArea(android.view.View r3) {
        /*
            r0 = 0
            r7 = r0
            r0 = r7
            r6 = r0
            r0 = r3
            if (r0 == 0) goto L_0x0066
            r0 = r3
            int r0 = r0.getVisibility()
            if (r0 == 0) goto L_0x0017
            r0 = r7
            r6 = r0
            goto L_0x0066
        L_0x0017:
            r0 = 2
            int[] r0 = new int[r0]
            r8 = r0
            r0 = r3
            r1 = r8
            r0.getLocationOnScreen(r1)
            r0 = r3
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            r9 = r0
            r0 = r9
            if (r0 == 0) goto L_0x0036
            r0 = r9
            int r0 = r0.height
            r4 = r0
            goto L_0x003b
        L_0x0036:
            r0 = r3
            int r0 = r0.getHeight()
            r4 = r0
        L_0x003b:
            r0 = r8
            r1 = 1
            r0 = r0[r1]
            r5 = r0
            r0 = r5
            if (r0 <= 0) goto L_0x004f
            r0 = r5
            android.app.Application r1 = com.taobao.weex.WXEnvironment.sApplication
            int r1 = getScreenHeight(r1)
            int r0 = r0 - r1
            if (r0 < 0) goto L_0x0064
        L_0x004f:
            r0 = r8
            r1 = 1
            r0 = r0[r1]
            r5 = r0
            r0 = r7
            r6 = r0
            r0 = r4
            r1 = r5
            int r0 = r0 + r1
            if (r0 <= 0) goto L_0x0066
            r0 = r7
            r6 = r0
            r0 = r5
            if (r0 > 0) goto L_0x0066
        L_0x0064:
            r0 = 1
            r6 = r0
        L_0x0066:
            r0 = r6
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXViewUtils.onScreenArea(android.view.View):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0022, code lost:
        if (r0 < 1.0f) goto L_0x002e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private static float realPxByWidth(float r5, float r6) {
        /*
            r0 = r5
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 == 0) goto L_0x0009
            r0 = r5
            return r0
        L_0x0009:
            r0 = r5
            int r1 = getScreenWidth()
            float r1 = (float) r1
            float r0 = r0 * r1
            r1 = r6
            float r0 = r0 / r1
            r6 = r0
            r0 = r6
            double r0 = (double) r0
            r7 = r0
            r0 = r7
            r1 = 4572414629676717179(0x3f747ae147ae147b, double:0.005)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0028
            r0 = 1065353216(0x3f800000, float:1.0)
            r5 = r0
            r0 = r6
            r1 = 1065353216(0x3f800000, float:1.0)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 >= 0) goto L_0x0028
            goto L_0x002e
        L_0x0028:
            r0 = r7
            double r0 = java.lang.Math.rint(r0)
            float r0 = (float) r0
            r5 = r0
        L_0x002e:
            r0 = r5
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXViewUtils.realPxByWidth(float, float):float");
    }

    private static int realPxByWidth2(float f2, float f3) {
        float screenWidth = (f2 * ((float) getScreenWidth())) / f3;
        int i2 = 1;
        if (((double) screenWidth) <= 0.005d || screenWidth >= 1.0f) {
            i2 = ((int) screenWidth) - 1;
        }
        return i2;
    }

    private static float realSubPxByWidth(float f2, float f3) {
        if (Float.isNaN(f2)) {
            return f2;
        }
        float screenWidth = (f2 * ((float) getScreenWidth())) / f3;
        float f4 = screenWidth;
        if (((double) screenWidth) > 0.005d) {
            f4 = screenWidth;
            if (screenWidth < 1.0f) {
                f4 = 1.0f;
            }
        }
        return f4;
    }

    public static void setBackGround(View view, Drawable drawable, WXComponent wXComponent) {
        try {
            view.setBackground(drawable);
        } catch (Exception e2) {
            if (wXComponent != null) {
                WXExceptionUtils.commitCriticalExceptionRT(wXComponent.getInstanceId(), WXErrorCode.WX_RENDER_ERR_TEXTURE_SETBACKGROUND, wXComponent.getComponentType() + " setBackGround for android view", WXErrorCode.WX_RENDER_ERR_TEXTURE_SETBACKGROUND.getErrorMsg() + ": TextureView doesn't support displaying a background drawable!", null);
            }
        }
    }

    @Deprecated
    public static int setScreenWidth(int i2) {
        mScreenWidth = i2;
        return i2;
    }

    public static void updateApplicationScreen(Context context) {
        if (context != null && WXEnvironment.sApplication != null) {
            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            DisplayMetrics displayMetrics2 = WXEnvironment.sApplication.getResources().getDisplayMetrics();
            displayMetrics2.heightPixels = displayMetrics.heightPixels;
            displayMetrics2.widthPixels = displayMetrics.widthPixels;
            displayMetrics2.density = displayMetrics.density;
            displayMetrics2.densityDpi = displayMetrics.densityDpi;
            displayMetrics2.scaledDensity = displayMetrics.scaledDensity;
            displayMetrics2.xdpi = displayMetrics.xdpi;
        }
    }

    private static float webPxByWidth(float f2, float f3) {
        double d2 = (double) f2;
        if (d2 < -1.9999d && d2 > -2.005d) {
            return Float.NaN;
        }
        float screenWidth = (f2 * f3) / ((float) getScreenWidth());
        float f4 = screenWidth;
        if (((double) screenWidth) > 0.005d) {
            f4 = screenWidth;
            if (screenWidth < 1.0f) {
                f4 = 1.0f;
            }
        }
        return f4;
    }

    private static float weexPxByReal(float f2, float f3) {
        return Float.isNaN(f2) ? f2 : (f2 * f3) / ((float) getScreenWidth());
    }
}
