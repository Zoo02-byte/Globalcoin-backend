package com.taobao.weex.utils;

import com.taobao.weex.dom.CSSConstants;
import com.taobao.weex.dom.CSSShorthand;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXDomUtils.class */
public class WXDomUtils {
    public static float getContentHeight(WXComponent wXComponent) {
        float layoutHeight = wXComponent.getLayoutHeight();
        CSSShorthand padding = wXComponent.getPadding();
        CSSShorthand border = wXComponent.getBorder();
        float f2 = padding.get(CSSShorthand.EDGE.TOP);
        float f3 = layoutHeight;
        if (!CSSConstants.isUndefined(f2)) {
            f3 = layoutHeight - f2;
        }
        float f4 = padding.get(CSSShorthand.EDGE.BOTTOM);
        float f5 = f3;
        if (!CSSConstants.isUndefined(f4)) {
            f5 = f3 - f4;
        }
        float f6 = border.get(CSSShorthand.EDGE.TOP);
        float f7 = f5;
        if (!CSSConstants.isUndefined(f6)) {
            f7 = f5 - f6;
        }
        float f8 = border.get(CSSShorthand.EDGE.BOTTOM);
        float f9 = f7;
        if (!CSSConstants.isUndefined(f8)) {
            f9 = f7 - f8;
        }
        return f9;
    }

    public static float getContentWidth(CSSShorthand cSSShorthand, CSSShorthand cSSShorthand2, float f2) {
        float f3 = cSSShorthand.get(CSSShorthand.EDGE.LEFT);
        float f4 = f2;
        if (!CSSConstants.isUndefined(f3)) {
            f4 = f2 - f3;
        }
        float f5 = cSSShorthand.get(CSSShorthand.EDGE.RIGHT);
        float f6 = f4;
        if (!CSSConstants.isUndefined(f5)) {
            f6 = f4 - f5;
        }
        float f7 = cSSShorthand2.get(CSSShorthand.EDGE.LEFT);
        float f8 = f6;
        if (!CSSConstants.isUndefined(f7)) {
            f8 = f6 - f7;
        }
        float f9 = cSSShorthand2.get(CSSShorthand.EDGE.RIGHT);
        float f10 = f8;
        if (!CSSConstants.isUndefined(f9)) {
            f10 = f8 - f9;
        }
        return f10;
    }

    public static float getContentWidth(WXComponent wXComponent) {
        float layoutWidth = wXComponent.getLayoutWidth();
        CSSShorthand padding = wXComponent.getPadding();
        CSSShorthand border = wXComponent.getBorder();
        float f2 = padding.get(CSSShorthand.EDGE.LEFT);
        float f3 = layoutWidth;
        if (!CSSConstants.isUndefined(f2)) {
            f3 = layoutWidth - f2;
        }
        float f4 = padding.get(CSSShorthand.EDGE.RIGHT);
        float f5 = f3;
        if (!CSSConstants.isUndefined(f4)) {
            f5 = f3 - f4;
        }
        float f6 = border.get(CSSShorthand.EDGE.LEFT);
        float f7 = f5;
        if (!CSSConstants.isUndefined(f6)) {
            f7 = f5 - f6;
        }
        float f8 = border.get(CSSShorthand.EDGE.RIGHT);
        float f9 = f7;
        if (!CSSConstants.isUndefined(f8)) {
            f9 = f7 - f8;
        }
        return f9;
    }
}
