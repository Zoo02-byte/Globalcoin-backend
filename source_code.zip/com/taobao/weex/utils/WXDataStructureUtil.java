package com.taobao.weex.utils;

import java.util.HashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXDataStructureUtil.class */
public class WXDataStructureUtil {
    private static final int MAX_POWER_OF_TWO = 1073741824;

    private static int capacity(int i2) {
        if (i2 < 3) {
            checkNonnegative(i2, "expectedSize");
            return i2 + 1;
        } else if (i2 < MAX_POWER_OF_TWO) {
            return (int) ((((float) i2) / 0.75f) + 1.0f);
        } else {
            return Integer.MAX_VALUE;
        }
    }

    private static int checkNonnegative(int i2, String str) {
        if (i2 >= 0) {
            return i2;
        }
        throw new IllegalArgumentException(str + " cannot be negative but was: " + i2);
    }

    public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int i2) {
        return new HashMap<>(capacity(i2));
    }
}
