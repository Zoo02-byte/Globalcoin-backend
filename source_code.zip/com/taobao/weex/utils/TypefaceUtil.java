package com.taobao.weex.utils;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.TextUtils;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXHttpAdapter;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXRequest;
import com.taobao.weex.font.FontAdapter;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/TypefaceUtil.class */
public class TypefaceUtil {
    public static final String ACTION_TYPE_FACE_AVAILABLE;
    public static final String FONT_CACHE_DIR_NAME;
    private static final String TAG;
    private static final Map<String, FontDO> sCacheMap = new HashMap();

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0051, code lost:
        if (r5 == -1) goto L_0x0054;
     */
    /* JADX WARN: Removed duplicated region for block: B:23:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0077  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:39:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public static void applyFontStyle(android.graphics.Paint r4, int r5, int r6, java.lang.String r7) {
        /*
            r0 = r4
            android.graphics.Typeface r0 = r0.getTypeface()
            r13 = r0
            r0 = 0
            r11 = r0
            r0 = r13
            if (r0 != 0) goto L_0x0014
            r0 = 0
            r10 = r0
            goto L_0x001b
        L_0x0014:
            r0 = r13
            int r0 = r0.getStyle()
            r10 = r0
        L_0x001b:
            r0 = 1
            r12 = r0
            r0 = r12
            r9 = r0
            r0 = r6
            r1 = 1
            if (r0 == r1) goto L_0x003d
            r0 = r10
            r1 = 1
            r0 = r0 & r1
            if (r0 == 0) goto L_0x003a
            r0 = r6
            r1 = -1
            if (r0 != r1) goto L_0x003a
            r0 = r12
            r9 = r0
            goto L_0x003d
        L_0x003a:
            r0 = 0
            r9 = r0
        L_0x003d:
            r0 = r5
            r1 = 2
            if (r0 == r1) goto L_0x0054
            r0 = r9
            r6 = r0
            r0 = r10
            r1 = 2
            r0 = r0 & r1
            if (r0 == 0) goto L_0x0059
            r0 = r9
            r6 = r0
            r0 = r5
            r1 = -1
            if (r0 != r1) goto L_0x0059
        L_0x0054:
            r0 = r9
            r1 = 2
            r0 = r0 | r1
            r6 = r0
        L_0x0059:
            r0 = r7
            if (r0 == 0) goto L_0x0064
            r0 = r7
            r1 = r6
            android.graphics.Typeface r0 = getOrCreateTypeface(r0, r1)
            r13 = r0
        L_0x0064:
            r0 = r13
            if (r0 == 0) goto L_0x0077
            r0 = r4
            r1 = r13
            r2 = r6
            android.graphics.Typeface r1 = android.graphics.Typeface.create(r1, r2)
            android.graphics.Typeface r0 = r0.setTypeface(r1)
            goto L_0x0080
        L_0x0077:
            r0 = r4
            r1 = r6
            android.graphics.Typeface r1 = android.graphics.Typeface.defaultFromStyle(r1)
            android.graphics.Typeface r0 = r0.setTypeface(r1)
        L_0x0080:
            r0 = r5
            if (r0 < 0) goto L_0x00b0
            r0 = r11
            r6 = r0
            r0 = r4
            android.graphics.Typeface r0 = r0.getTypeface()
            if (r0 == 0) goto L_0x0096
            r0 = r4
            android.graphics.Typeface r0 = r0.getTypeface()
            int r0 = r0.getStyle()
            r6 = r0
        L_0x0096:
            r0 = r5
            r1 = r6
            r2 = -1
            r1 = r1 ^ r2
            r0 = r0 & r1
            r1 = 2
            r0 = r0 & r1
            if (r0 == 0) goto L_0x00a7
            r0 = -1102263091(0xffffffffbe4ccccd, float:-0.2)
            r8 = r0
            goto L_0x00aa
        L_0x00a7:
            r0 = 0
            r8 = r0
        L_0x00aa:
            r0 = r4
            r1 = r8
            r0.setTextSkewX(r1)
        L_0x00b0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.TypefaceUtil.applyFontStyle(android.graphics.Paint, int, int, java.lang.String):void");
    }

    private static void downloadFontByNetwork(String str, String str2, String str3) {
        IWXHttpAdapter iWXHttpAdapter = WXSDKManager.getInstance().getIWXHttpAdapter();
        if (iWXHttpAdapter == null) {
            WXLogUtils.e(TAG, "downloadFontByNetwork() IWXHttpAdapter == null");
            return;
        }
        WXRequest wXRequest = new WXRequest();
        wXRequest.url = str;
        wXRequest.method = "GET";
        iWXHttpAdapter.sendRequest(wXRequest, new IWXHttpAdapter.OnHttpListener(str, str2, str3) { // from class: com.taobao.weex.utils.TypefaceUtil.1
            final String val$fontFamily;
            final String val$fullPath;
            final String val$url;

            {
                this.val$url = r4;
                this.val$fullPath = r5;
                this.val$fontFamily = r6;
            }

            @Override // com.taobao.weex.adapter.IWXHttpAdapter.OnHttpListener
            public void onHeadersReceived(int i2, Map<String, List<String>> map) {
            }

            /* JADX WARN: Removed duplicated region for block: B:10:0x0040  */
            @Override // com.taobao.weex.adapter.IWXHttpAdapter.OnHttpListener
            /* Code decompiled incorrectly, please refer to instructions dump */
            public void onHttpFinish(com.taobao.weex.common.WXResponse r6) {
                /*
                    r5 = this;
                    r0 = r6
                    java.lang.String r0 = r0.statusCode
                    boolean r0 = android.text.TextUtils.isEmpty(r0)
                    r8 = r0
                    r0 = 0
                    r9 = r0
                    r0 = r8
                    if (r0 != 0) goto L_0x0034
                    r0 = r6
                    java.lang.String r0 = r0.statusCode     // Catch: NumberFormatException -> 0x001a
                    int r0 = java.lang.Integer.parseInt(r0)     // Catch: NumberFormatException -> 0x001a
                    r7 = r0
                    goto L_0x0036
                L_0x001a:
                    r10 = move-exception
                    java.lang.String r0 = "TypefaceUtil"
                    java.lang.StringBuilder r1 = new java.lang.StringBuilder
                    r2 = r1
                    java.lang.String r3 = "IWXHttpAdapter onHttpFinish statusCode:"
                    r2.<init>(r3)
                    r2 = r6
                    java.lang.String r2 = r2.statusCode
                    java.lang.StringBuilder r1 = r1.append(r2)
                    java.lang.String r1 = r1.toString()
                    com.taobao.weex.utils.WXLogUtils.e(r0, r1)
                L_0x0034:
                    r0 = 0
                    r7 = r0
                L_0x0036:
                    r0 = r9
                    r8 = r0
                    r0 = r7
                    r1 = 200(0xc8, float:2.8E-43)
                    if (r0 < r1) goto L_0x008c
                    r0 = r9
                    r8 = r0
                    r0 = r7
                    r1 = 299(0x12b, float:4.19E-43)
                    if (r0 > r1) goto L_0x008c
                    r0 = r9
                    r8 = r0
                    r0 = r6
                    byte[] r0 = r0.originalData
                    if (r0 == 0) goto L_0x008c
                    r0 = r5
                    java.lang.String r0 = r0.val$fullPath
                    r1 = r6
                    byte[] r1 = r1.originalData
                    android.app.Application r2 = com.taobao.weex.WXEnvironment.getApplication()
                    boolean r0 = com.taobao.weex.utils.WXFileUtils.saveFile(r0, r1, r2)
                    r9 = r0
                    r0 = r9
                    if (r0 == 0) goto L_0x0079
                    r0 = r5
                    java.lang.String r0 = r0.val$fullPath
                    r1 = r5
                    java.lang.String r1 = r1.val$fontFamily
                    r2 = 1
                    boolean r0 = com.taobao.weex.utils.TypefaceUtil.access$000(r0, r1, r2)
                    r8 = r0
                    goto L_0x008c
                L_0x0079:
                    r0 = r9
                    r8 = r0
                    boolean r0 = com.taobao.weex.WXEnvironment.isApkDebugable()
                    if (r0 == 0) goto L_0x008c
                    java.lang.String r0 = "TypefaceUtil"
                    java.lang.String r1 = "downloadFontByNetwork() onHttpFinish success, but save file failed."
                    com.taobao.weex.utils.WXLogUtils.d(r0, r1)
                    r0 = r9
                    r8 = r0
                L_0x008c:
                    r0 = r8
                    if (r0 != 0) goto L_0x00a9
                    java.util.Map r0 = com.taobao.weex.utils.TypefaceUtil.access$100()
                    r1 = r5
                    java.lang.String r1 = r1.val$fontFamily
                    java.lang.Object r0 = r0.get(r1)
                    com.taobao.weex.utils.FontDO r0 = (com.taobao.weex.utils.FontDO) r0
                    r6 = r0
                    r0 = r6
                    if (r0 == 0) goto L_0x00a9
                    r0 = r6
                    r1 = 3
                    r0.setState(r1)
                L_0x00a9:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.TypefaceUtil.AnonymousClass1.onHttpFinish(com.taobao.weex.common.WXResponse):void");
            }

            @Override // com.taobao.weex.adapter.IWXHttpAdapter.OnHttpListener
            public void onHttpResponseProgress(int i2) {
            }

            @Override // com.taobao.weex.adapter.IWXHttpAdapter.OnHttpListener
            public void onHttpStart() {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d(TypefaceUtil.TAG, "downloadFontByNetwork begin url:" + this.val$url);
                }
            }

            @Override // com.taobao.weex.adapter.IWXHttpAdapter.OnHttpListener
            public void onHttpUploadProgress(int i2) {
            }
        });
    }

    private static String getFontCacheDir() {
        return WXEnvironment.getApplication().getCacheDir() + "/font-family";
    }

    public static FontDO getFontDO(String str) {
        return sCacheMap.get(str);
    }

    public static Typeface getOrCreateTypeface(String str, int i2) {
        FontDO fontDO = sCacheMap.get(str);
        return (fontDO == null || fontDO.getTypeface() == null) ? Typeface.create(str, i2) : fontDO.getTypeface();
    }

    private static void loadFromAsset(FontDO fontDO, String str) {
        try {
            Typeface createFromAsset = Typeface.createFromAsset(WXEnvironment.getApplication().getAssets(), str);
            if (createFromAsset != null) {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d(TAG, "load asset file success");
                }
                fontDO.setState(2);
                fontDO.setTypeface(createFromAsset);
                return;
            }
            WXLogUtils.e(TAG, "Font asset file not found " + fontDO.getUrl());
        } catch (Exception e2) {
            WXLogUtils.e(TAG, e2.toString());
        }
    }

    public static boolean loadLocalFontFile(String str, String str2, boolean z2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            return false;
        }
        try {
            if (!new File(str).exists()) {
                return false;
            }
            Typeface createFromFile = Typeface.createFromFile(str);
            if (createFromFile != null) {
                FontDO fontDO = sCacheMap.get(str2);
                if (fontDO == null) {
                    return false;
                }
                fontDO.setState(2);
                fontDO.setTypeface(createFromFile);
                fontDO.setFilePath(str);
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d(TAG, "load local font file success");
                }
                if (z2) {
                    WXSDKManager.getInstance().getWXRenderManager().postOnUiThread(new Runnable(fontDO) { // from class: com.taobao.weex.utils.TypefaceUtil.2
                        final FontDO val$fontDo;

                        {
                            this.val$fontDo = r4;
                        }

                        @Override // java.lang.Runnable
                        public void run() {
                            TypefaceUtil.notifyFontAvailable(true, this.val$fontDo);
                        }
                    }, 100);
                    return true;
                }
                notifyFontAvailable(true, fontDO);
                return true;
            }
            WXLogUtils.e(TAG, "load local font file failed, can't create font.");
            return false;
        } catch (Exception e2) {
            WXLogUtils.e(TAG, e2.toString());
            return false;
        }
    }

    public static void loadTypeface(FontDO fontDO, boolean z2) {
        if (fontDO != null && fontDO.getTypeface() == null && (fontDO.getState() == 3 || fontDO.getState() == 0)) {
            fontDO.setState(1);
            if (fontDO.getType() == 3) {
                loadFromAsset(fontDO, Uri.parse(fontDO.getUrl()).getPath().substring(1));
            } else if (fontDO.getType() == 1) {
                String url = fontDO.getUrl();
                String fontFamilyName = fontDO.getFontFamilyName();
                String md5 = WXFileUtils.md5(url);
                File file = new File(getFontCacheDir());
                if (!file.exists()) {
                    file.mkdirs();
                }
                String str = file.getAbsolutePath() + File.separator + md5;
                if (!loadLocalFontFile(str, fontFamilyName, false)) {
                    downloadFontByNetwork(url, str, fontFamilyName);
                }
            } else if ((fontDO.getType() == 2 || fontDO.getType() == 5) && !loadLocalFontFile(fontDO.getUrl(), fontDO.getFontFamilyName(), false)) {
                fontDO.setState(3);
            }
        } else if (z2) {
            notifyFontAvailable(false, fontDO);
        }
    }

    public static void notifyFontAvailable(boolean z2, FontDO fontDO) {
        if (z2) {
            Intent intent = new Intent(ACTION_TYPE_FACE_AVAILABLE);
            intent.putExtra(Constants.Name.FONT_FAMILY, fontDO.getFontFamilyName());
            intent.putExtra("filePath", fontDO.getFilePath());
            intent.putExtra("fontUrl", fontDO.getUrl());
            LocalBroadcastManager.getInstance(WXEnvironment.getApplication()).sendBroadcast(intent);
        }
        FontAdapter fontAdapter = WXSDKManager.getInstance().getFontAdapter();
        if (fontAdapter != null) {
            fontAdapter.onFontLoad(fontDO.getFontFamilyName(), fontDO.getUrl(), fontDO.getFilePath());
        }
    }

    public static void putFontDO(FontDO fontDO) {
        if (fontDO != null && !TextUtils.isEmpty(fontDO.getFontFamilyName())) {
            sCacheMap.put(fontDO.getFontFamilyName(), fontDO);
        }
    }

    public static void registerNativeFont(Map<String, Typeface> map) {
        if (map != null && map.size() > 0) {
            for (Map.Entry<String, Typeface> entry : map.entrySet()) {
                putFontDO(new FontDO(entry.getKey(), entry.getValue()));
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d(TAG, "register new typeface: " + entry.getKey());
                }
            }
        }
    }

    public static void removeFontDO(String str) {
        sCacheMap.remove(str);
    }
}
