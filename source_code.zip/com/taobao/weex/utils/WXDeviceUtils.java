package com.taobao.weex.utils;

import android.content.Context;
import android.os.Build;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXDeviceUtils.class */
public class WXDeviceUtils {
    public static boolean isAutoResize(Context context) {
        boolean z2 = false;
        if (context == null) {
            return false;
        }
        if (isMateX(context) || isGalaxyFold(context)) {
            z2 = true;
        }
        return z2;
    }

    public static boolean isGalaxyFold(Context context) {
        return "samsung".equalsIgnoreCase(Build.BRAND) && "SM-F9000".equalsIgnoreCase(Build.MODEL);
    }

    public static boolean isMateX(Context context) {
        return "HUAWEI".equalsIgnoreCase(Build.BRAND) && ("unknownRLI".equalsIgnoreCase(Build.DEVICE) || "HWTAH".equalsIgnoreCase(Build.DEVICE));
    }
}
