package com.taobao.weex.utils;

import android.graphics.Typeface;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.common.Constants;
import io.dcloud.feature.uniapp.adapter.AbsURIAdapter;
import java.io.File;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FontDO.class */
public class FontDO {
    public static final int STATE_FAILED;
    public static final int STATE_INIT;
    public static final int STATE_INVALID;
    public static final int STATE_LOADING;
    public static final int STATE_SUCCESS;
    public static final int TYPE_BASE64;
    public static final int TYPE_FILE;
    public static final int TYPE_LOCAL;
    public static final int TYPE_NATIVE;
    public static final int TYPE_NETWORK;
    public static final int TYPE_UNKNOWN;
    private String mFilePath;
    private final String mFontFamilyName;
    private Typeface mTypeface;
    private String mUrl = "";
    private int mType = 4;
    private int mState = 2;

    public FontDO(String str, Typeface typeface) {
        this.mFontFamilyName = str;
        this.mTypeface = typeface;
    }

    public FontDO(String str, String str2, WXSDKInstance wXSDKInstance) {
        this.mFontFamilyName = str;
        parseSrc(str2, wXSDKInstance);
    }

    private void parseSrc(String str, WXSDKInstance wXSDKInstance) {
        String trim = str != null ? str.trim() : "";
        String str2 = trim;
        if (wXSDKInstance != null) {
            str2 = trim;
            if (wXSDKInstance.getCustomFontNetworkHandler() != null) {
                String fetchLocal = wXSDKInstance.getCustomFontNetworkHandler().fetchLocal(trim);
                str2 = trim;
                if (!TextUtils.isEmpty(fetchLocal)) {
                    str2 = fetchLocal;
                }
            }
        }
        if (str2.isEmpty()) {
            this.mState = -1;
            WXLogUtils.e("TypefaceUtil", "font src is empty.");
            return;
        }
        if (str2.matches("^url\\((('.*')|(\".*\"))\\)$")) {
            Uri parse = Uri.parse(str2.substring(5, str2.length() - 2));
            Uri uri = parse;
            if (wXSDKInstance != null) {
                uri = wXSDKInstance.rewriteUri(parse, AbsURIAdapter.FONT);
            }
            this.mUrl = uri.toString();
            try {
                String scheme = uri.getScheme();
                if (!"http".equals(scheme) && !"https".equals(scheme)) {
                    if ("file".equals(scheme)) {
                        this.mType = 2;
                        this.mUrl = uri.getEncodedSchemeSpecificPart();
                    } else if (Constants.Scheme.LOCAL.equals(scheme)) {
                        this.mType = 3;
                    } else if ("data".equals(scheme)) {
                        long currentTimeMillis = System.currentTimeMillis();
                        String[] split = this.mUrl.split(",");
                        if (split != null && split.length == 2) {
                            String str3 = split[0];
                            if (!TextUtils.isEmpty(str3) && str3.endsWith("base64")) {
                                String str4 = split[1];
                                if (!TextUtils.isEmpty(str4)) {
                                    String md5 = WXFileUtils.md5(str4);
                                    File file = new File(WXEnvironment.getApplication().getCacheDir(), TypefaceUtil.FONT_CACHE_DIR_NAME);
                                    if (!file.exists()) {
                                        file.mkdirs();
                                    }
                                    File file2 = new File(file, md5);
                                    if (!file2.exists()) {
                                        file2.createNewFile();
                                        WXFileUtils.saveFile(file2.getPath(), Base64.decode(str4, 0), WXEnvironment.getApplication());
                                    }
                                    this.mUrl = file2.getPath();
                                    this.mType = 5;
                                    WXLogUtils.d("TypefaceUtil", "Parse base64 font cost " + (System.currentTimeMillis() - currentTimeMillis) + " ms");
                                }
                            }
                        }
                    } else {
                        WXLogUtils.e("TypefaceUtil", "Unknown scheme for font url: " + this.mUrl);
                        this.mType = 0;
                    }
                    this.mState = 0;
                }
                this.mType = 1;
                this.mState = 0;
            } catch (Exception e2) {
                this.mType = -1;
                WXLogUtils.e("TypefaceUtil", "URI.create(mUrl) failed mUrl: " + this.mUrl + "\n" + WXLogUtils.getStackTrace(e2));
            }
        } else {
            this.mUrl = str2;
            this.mState = -1;
        }
        if (WXEnvironment.isApkDebugable()) {
            WXLogUtils.d("TypefaceUtil", "src:" + str2 + ", mUrl:" + this.mUrl + ", mType:" + this.mType);
        }
    }

    public String getFilePath() {
        return this.mFilePath;
    }

    public String getFontFamilyName() {
        return this.mFontFamilyName;
    }

    public int getState() {
        return this.mState;
    }

    public int getType() {
        return this.mType;
    }

    public Typeface getTypeface() {
        return this.mTypeface;
    }

    public String getUrl() {
        return this.mUrl;
    }

    public void setFilePath(String str) {
        this.mFilePath = str;
    }

    public void setState(int i2) {
        this.mState = i2;
    }

    public void setTypeface(Typeface typeface) {
        this.mTypeface = typeface;
    }
}
