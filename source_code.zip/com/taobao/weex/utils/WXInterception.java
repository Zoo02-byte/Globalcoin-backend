package com.taobao.weex.utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXInterception.class */
public class WXInterception {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXInterception$Intercepted.class */
    private interface Intercepted {
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXInterception$InterceptionHandler.class */
    public static abstract class InterceptionHandler<T> implements InvocationHandler {
        private T mDelegate;

        protected T delegate() {
            return this.mDelegate;
        }

        @Override // java.lang.reflect.InvocationHandler
        public Object invoke(Object obj, Method method, Object[] objArr) throws Throwable {
            try {
                return method.invoke(delegate(), objArr);
            } catch (IllegalAccessException e2) {
                WXLogUtils.e("", e2);
                return null;
            } catch (IllegalArgumentException e3) {
                WXLogUtils.e("", e3);
                return null;
            } catch (InvocationTargetException e4) {
                throw e4.getTargetException();
            }
        }

        void setDelegate(T t2) {
            this.mDelegate = t2;
        }
    }

    private WXInterception() {
    }

    public static <T> T proxy(Object obj, InterceptionHandler<T> interceptionHandler, Class<?>... clsArr) throws IllegalArgumentException {
        interceptionHandler.setDelegate(obj);
        return (T) Proxy.newProxyInstance(WXInterception.class.getClassLoader(), clsArr, interceptionHandler);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static <T> T proxy(Object obj, Class<T> cls, InterceptionHandler<T> interceptionHandler) throws IllegalArgumentException {
        if (obj instanceof Intercepted) {
            return obj;
        }
        interceptionHandler.setDelegate(obj);
        return (T) Proxy.newProxyInstance(WXInterception.class.getClassLoader(), new Class[]{cls, Intercepted.class}, interceptionHandler);
    }
}
