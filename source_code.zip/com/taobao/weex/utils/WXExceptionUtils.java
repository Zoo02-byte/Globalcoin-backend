package com.taobao.weex.utils;

import android.text.TextUtils;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXConfigAdapter;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.performance.WXStateRecord;
import io.dcloud.common.constant.AbsoluteConst;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXExceptionUtils.class */
public class WXExceptionUtils {
    private static Set<String> sGlobalExceptionRecord = new CopyOnWriteArraySet();
    public static String degradeUrl = "BundleUrlDefaultDegradeUrl";

    private static boolean checkNeedReportCauseRepeat(String str, WXErrorCode wXErrorCode, String str2) {
        if (TextUtils.isEmpty(str2)) {
            return true;
        }
        if (wXErrorCode != null && wXErrorCode.getErrorGroup() != WXErrorCode.ErrorGroup.JS) {
            return true;
        }
        String str3 = str;
        if (TextUtils.isEmpty(str)) {
            str3 = "instanceIdNull";
        }
        String str4 = str2;
        if (str2.length() > 200) {
            str4 = str2.substring(0, 200);
        }
        WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(str3);
        Set<String> set = wXSDKInstance == null ? sGlobalExceptionRecord : wXSDKInstance.getApmForInstance().exceptionRecord;
        if (set == null) {
            return true;
        }
        if (set.contains(str4)) {
            return false;
        }
        set.add(str4);
        return true;
    }

    public static void commitCriticalExceptionRT(String str, WXErrorCode wXErrorCode, String str2, String str3, Map<String, String> map) {
        try {
            WXLogUtils.e("weex", "commitCriticalExceptionRT :" + wXErrorCode + "exception" + str3);
            WXStateRecord.getInstance().recordException(str, str3);
            IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
            boolean z2 = true;
            if (wxConfigAdapter != null ? AbsoluteConst.TRUE.equalsIgnoreCase(wxConfigAdapter.getConfig("wxapm", "check_repeat_report", AbsoluteConst.TRUE)) : true) {
                z2 = checkNeedReportCauseRepeat(str, wXErrorCode, str3);
            }
            if (!z2) {
                return;
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
        commitCriticalExceptionWithDefaultUrl("BundleUrlDefault", str, wXErrorCode, str2, str3, map);
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x00dd, code lost:
        if (r0.equals("default") != false) goto L_0x00e0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public static void commitCriticalExceptionWithDefaultUrl(java.lang.String r9, java.lang.String r10, com.taobao.weex.common.WXErrorCode r11, java.lang.String r12, java.lang.String r13, java.util.Map<java.lang.String, java.lang.String> r14) {
        /*
        // Method dump skipped, instructions count: 626
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXExceptionUtils.commitCriticalExceptionWithDefaultUrl(java.lang.String, java.lang.String, com.taobao.weex.common.WXErrorCode, java.lang.String, java.lang.String, java.util.Map):void");
    }

    private static String convertStageToStr(WXSDKInstance wXSDKInstance) {
        if (wXSDKInstance == null || wXSDKInstance.getApmForInstance() == null || wXSDKInstance.getApmForInstance().stageMap.isEmpty()) {
            return "noStageRecord";
        }
        ArrayList<Map.Entry> arrayList = new ArrayList(wXSDKInstance.getApmForInstance().stageMap.entrySet());
        Collections.sort(arrayList, new Comparator<Map.Entry<String, Long>>() { // from class: com.taobao.weex.utils.WXExceptionUtils.1
            public int compare(Map.Entry<String, Long> entry, Map.Entry<String, Long> entry2) {
                return (int) (entry.getValue().longValue() - entry2.getValue().longValue());
            }
        });
        StringBuilder sb = new StringBuilder();
        for (Map.Entry entry : arrayList) {
            sb.append((String) entry.getKey()).append(':').append(entry.getValue()).append("->");
        }
        return sb.toString();
    }
}
