package com.taobao.weex.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.shapes.Shape;
import android.widget.ImageView;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/ImageDrawable.class */
public class ImageDrawable extends PaintDrawable {
    private int bitmapHeight;
    private int bitmapWidth;
    private float[] radii;

    private ImageDrawable() {
    }

    public static Drawable createImageDrawable(Drawable drawable, ImageView.ScaleType scaleType, float[] fArr, int i2, int i3, boolean z2) {
        Bitmap bitmap;
        if (!z2 && i2 > 0 && i3 > 0) {
            if ((drawable instanceof BitmapDrawable) && (bitmap = ((BitmapDrawable) drawable).getBitmap()) != null) {
                ImageDrawable imageDrawable = new ImageDrawable();
                imageDrawable.getPaint().setFilterBitmap(true);
                imageDrawable.bitmapWidth = bitmap.getWidth();
                imageDrawable.bitmapHeight = bitmap.getHeight();
                BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                updateShaderAndSize(scaleType, i2, i3, imageDrawable, bitmapShader);
                imageDrawable.getPaint().setShader(bitmapShader);
                return imageDrawable;
            } else if (drawable instanceof ImageDrawable) {
                ImageDrawable imageDrawable2 = (ImageDrawable) drawable;
                if (imageDrawable2.getPaint() != null && (imageDrawable2.getPaint().getShader() instanceof BitmapShader)) {
                    updateShaderAndSize(scaleType, i2, i3, imageDrawable2, (BitmapShader) imageDrawable2.getPaint().getShader());
                    return imageDrawable2;
                }
            }
        }
        return drawable;
    }

    private static Matrix createShaderMatrix(ImageView.ScaleType scaleType, int i2, int i3, int i4, int i5) {
        float f2;
        float f3;
        float f4;
        if (i4 * i3 > i5 * i2) {
            f4 = ((float) i3) / ((float) i5);
            f2 = (((float) i2) - (((float) i4) * f4)) * 0.5f;
            f3 = 0.0f;
        } else {
            f4 = ((float) i2) / ((float) i4);
            f3 = (((float) i3) - (((float) i5) * f4)) * 0.5f;
            f2 = 0.0f;
        }
        Matrix matrix = new Matrix();
        if (scaleType == ImageView.ScaleType.FIT_XY) {
            matrix.setScale(((float) i2) / ((float) i4), ((float) i3) / ((float) i5));
        } else if (scaleType == ImageView.ScaleType.FIT_CENTER) {
            matrix.setRectToRect(new RectF(0.0f, 0.0f, (float) i4, (float) i5), new RectF(0.0f, 0.0f, (float) i2, (float) i3), Matrix.ScaleToFit.CENTER);
        } else if (scaleType == ImageView.ScaleType.CENTER_CROP) {
            matrix.setScale(f4, f4);
            matrix.postTranslate(f2 + 0.5f, f3 + 0.5f);
        }
        return matrix;
    }

    private static void updateShaderAndSize(ImageView.ScaleType scaleType, int i2, int i3, ImageDrawable imageDrawable, BitmapShader bitmapShader) {
        Matrix createShaderMatrix = createShaderMatrix(scaleType, i2, i3, imageDrawable.bitmapWidth, imageDrawable.bitmapHeight);
        Matrix matrix = createShaderMatrix;
        if (scaleType == ImageView.ScaleType.FIT_CENTER) {
            RectF rectF = new RectF(0.0f, 0.0f, (float) imageDrawable.bitmapWidth, (float) imageDrawable.bitmapHeight);
            RectF rectF2 = new RectF();
            createShaderMatrix.mapRect(rectF2, rectF);
            i2 = (int) rectF2.width();
            i3 = (int) rectF2.height();
            matrix = createShaderMatrix(scaleType, i2, i3, imageDrawable.bitmapWidth, imageDrawable.bitmapHeight);
        }
        imageDrawable.setIntrinsicWidth(i2);
        imageDrawable.setIntrinsicHeight(i3);
        bitmapShader.setLocalMatrix(matrix);
    }

    public int getBitmapHeight() {
        return this.bitmapHeight;
    }

    public int getBitmapWidth() {
        return this.bitmapWidth;
    }

    public float[] getCornerRadii() {
        return this.radii;
    }

    @Override // android.graphics.drawable.ShapeDrawable
    protected void onDraw(Shape shape, Canvas canvas, Paint paint) {
        onDraw(shape, canvas, paint);
    }

    @Override // android.graphics.drawable.PaintDrawable
    public void setCornerRadii(float[] fArr) {
        this.radii = fArr;
        setCornerRadii(fArr);
    }
}
