package com.taobao.weex.utils;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FunctionParser.class */
public class FunctionParser<K, V> {
    public static final char SPACE = ' ';
    private Lexer lexer;
    private Mapper<K, V> mapper;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FunctionParser$Lexer.class */
    public static class Lexer {
        private static final char A_LOWER = 'a';
        private static final char A_UPPER = 'A';
        private static final String COMMA = ",";
        private static final char DOT = '.';
        private static final String LEFT_PARENT = "(";
        private static final char MINUS = '-';
        private static final char NINE = '9';
        private static final char PLUS = '+';
        private static final String RIGHT_PARENT = ")";
        private static final char ZERO = '0';
        private static final char Z_LOWER = 'z';
        private static final char Z_UPPER = 'Z';
        private Token current;
        private int pointer;
        private String source;
        private String value;

        private Lexer(String str) {
            this.pointer = 0;
            this.source = str;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public Token getCurrentToken() {
            return this.current;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public String getCurrentTokenValue() {
            return this.value;
        }

        private boolean isCharacterOrDigit(char c2) {
            return ('0' <= c2 && c2 <= '9') || ('a' <= c2 && c2 <= 'z') || ('A' <= c2 && c2 <= 'Z');
        }

        private boolean isFuncName(CharSequence charSequence) {
            for (int i2 = 0; i2 < charSequence.length(); i2++) {
                char charAt = charSequence.charAt(i2);
                if (('a' > charAt || charAt > 'z') && (('A' > charAt || charAt > 'Z') && charAt != '-')) {
                    return false;
                }
            }
            return true;
        }

        private void moveOn(String str) {
            if ("(".equals(str)) {
                this.current = Token.LEFT_PARENT;
                this.value = "(";
            } else if (")".equals(str)) {
                this.current = Token.RIGHT_PARENT;
                this.value = ")";
            } else if (",".equals(str)) {
                this.current = Token.COMMA;
                this.value = ",";
            } else if (isFuncName(str)) {
                this.current = Token.FUNC_NAME;
                this.value = str;
            } else {
                this.current = Token.PARAM_VALUE;
                this.value = str;
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean moveOn() {
            int i2 = this.pointer;
            while (true) {
                if (this.pointer >= this.source.length()) {
                    break;
                }
                char charAt = this.source.charAt(this.pointer);
                if (charAt == ' ') {
                    int i3 = this.pointer;
                    this.pointer = i3 + 1;
                    if (i2 != i3) {
                        break;
                    }
                    i2++;
                } else if (isCharacterOrDigit(charAt) || charAt == '.' || charAt == '%' || charAt == '-' || charAt == '+') {
                    this.pointer++;
                } else {
                    int i4 = this.pointer;
                    if (i2 == i4) {
                        this.pointer = i4 + 1;
                    }
                }
            }
            int i5 = this.pointer;
            if (i2 != i5) {
                moveOn(this.source.substring(i2, i5));
                return true;
            }
            this.current = null;
            this.value = null;
            return false;
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FunctionParser$Mapper.class */
    public interface Mapper<K, V> {
        Map<K, V> map(String str, List<String> list);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FunctionParser$Token.class */
    public enum Token {
        FUNC_NAME,
        PARAM_VALUE,
        LEFT_PARENT,
        RIGHT_PARENT,
        COMMA
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/FunctionParser$WXInterpretationException.class */
    private static class WXInterpretationException extends RuntimeException {
        private WXInterpretationException(String str) {
            super(str);
        }
    }

    public FunctionParser(String str, Mapper<K, V> mapper) {
        this.lexer = new Lexer(str);
        this.mapper = mapper;
    }

    private LinkedHashMap<K, V> definition() {
        LinkedHashMap<K, V> linkedHashMap = new LinkedHashMap<>();
        do {
            linkedHashMap.putAll(function());
        } while (this.lexer.getCurrentToken() == Token.FUNC_NAME);
        return linkedHashMap;
    }

    private Map<K, V> function() {
        LinkedList linkedList = new LinkedList();
        String match = match(Token.FUNC_NAME);
        match(Token.LEFT_PARENT);
        linkedList.add(match(Token.PARAM_VALUE));
        while (this.lexer.getCurrentToken() == Token.COMMA) {
            match(Token.COMMA);
            linkedList.add(match(Token.PARAM_VALUE));
        }
        match(Token.RIGHT_PARENT);
        return this.mapper.map(match, linkedList);
    }

    private String match(Token token) {
        try {
            if (token != this.lexer.getCurrentToken()) {
                return "";
            }
            String currentTokenValue = this.lexer.getCurrentTokenValue();
            this.lexer.moveOn();
            return currentTokenValue;
        } catch (Exception e2) {
            WXLogUtils.e(token + "Token doesn't match" + this.lexer.source);
            return "";
        }
    }

    public LinkedHashMap<K, V> parse() {
        this.lexer.moveOn();
        return definition();
    }
}
