package com.taobao.weex.utils;

import com.taobao.weex.utils.FunctionParser;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/SingleFunctionParser.class */
public class SingleFunctionParser<V> extends FunctionParser<String, List<V>> {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/SingleFunctionParser$FlatMapper.class */
    public interface FlatMapper<V> {
        V map(String str);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/SingleFunctionParser$NonUniformMapper.class */
    public interface NonUniformMapper<V> {
        List<V> map(List<String> list);
    }

    public SingleFunctionParser(String str, FlatMapper<V> flatMapper) {
        super(str, new FunctionParser.Mapper<String, List<V>>(flatMapper) { // from class: com.taobao.weex.utils.SingleFunctionParser.1
            final FlatMapper val$mapper;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$mapper = r4;
            }

            @Override // com.taobao.weex.utils.FunctionParser.Mapper
            public Map<String, List<V>> map(String str2, List<String> list) {
                HashMap hashMap = new HashMap();
                LinkedList linkedList = new LinkedList();
                for (String str3 : list) {
                    linkedList.add(this.val$mapper.map(str3));
                }
                hashMap.put(str2, linkedList);
                return hashMap;
            }
        });
    }

    public SingleFunctionParser(String str, NonUniformMapper<V> nonUniformMapper) {
        super(str, new FunctionParser.Mapper<String, List<V>>(nonUniformMapper) { // from class: com.taobao.weex.utils.SingleFunctionParser.2
            final NonUniformMapper val$mapper;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$mapper = r4;
            }

            @Override // com.taobao.weex.utils.FunctionParser.Mapper
            public Map<String, List<V>> map(String str2, List<String> list) {
                HashMap hashMap = new HashMap();
                hashMap.put(str2, this.val$mapper.map(list));
                return hashMap;
            }
        });
    }

    public List<V> parse(String str) {
        LinkedHashMap<String, V> parse = parse();
        if (parse.containsKey(str)) {
            return (List) parse.get(str);
        }
        return null;
    }
}
