package com.taobao.weex.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import androidx.collection.LruCache;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXConfigAdapter;
import com.taobao.weex.common.Constants;
import com.taobao.weex.el.parse.Operators;
import io.dcloud.common.constant.AbsoluteConst;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXUtils.class */
public class WXUtils {
    private static final int HUNDRED;
    public static final char PERCENT;
    static final LruCache<String, Integer> sCache = new LruCache<>(64);
    private static final long sInterval = System.currentTimeMillis() - SystemClock.uptimeMillis();

    public static boolean checkGreyConfig(String str, String str2, String str3) {
        IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
        boolean z2 = false;
        if (wxConfigAdapter == null) {
            return false;
        }
        double random = Math.random();
        double d2 = 100.0d;
        try {
            d2 = Double.valueOf(wxConfigAdapter.getConfig(str, str2, str3)).doubleValue();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (random * 100.0d < d2) {
            z2 = true;
        }
        return z2;
    }

    public static float fastGetFloat(String str) {
        return fastGetFloat(str, 2.1474836E9f);
    }

    public static float fastGetFloat(String str, float f2) {
        boolean z2;
        int i2;
        float f3;
        char charAt;
        float f4 = 0.0f;
        if (!TextUtils.isEmpty(str)) {
            int i3 = 0;
            if (str.charAt(0) == '-') {
                z2 = false;
                i2 = 1;
                f3 = 0.0f;
            } else if (str.charAt(0) == '+') {
                i2 = 1;
                z2 = true;
                f3 = 0.0f;
            } else {
                i2 = 0;
                z2 = true;
                f3 = 0.0f;
            }
            while (i2 < str.length() && (charAt = str.charAt(i2)) >= '0' && charAt <= '9') {
                f3 = ((f3 * 10.0f) + ((float) charAt)) - 48.0f;
                i2++;
            }
            float f5 = f3;
            if (i2 < str.length()) {
                f5 = f3;
                if (str.charAt(i2) == '.') {
                    int i4 = i2 + 1;
                    int i5 = 10;
                    while (true) {
                        f5 = f3;
                        if (i4 >= str.length()) {
                            break;
                        }
                        f5 = f3;
                        if (((float) i3) >= f2) {
                            break;
                        }
                        char charAt2 = str.charAt(i4);
                        f5 = f3;
                        if (charAt2 < '0') {
                            break;
                        }
                        f5 = f3;
                        if (charAt2 > '9') {
                            break;
                        }
                        f3 += ((float) (charAt2 - '0')) / ((float) i5);
                        i5 *= 10;
                        i4++;
                        i3++;
                    }
                }
            }
            f4 = f5;
            if (!z2) {
                f4 = f5 * -1.0f;
            }
        }
        return f4;
    }

    private static float floatByViewport(Object obj, float f2) {
        if (obj == null) {
            return Float.NaN;
        }
        String trim = obj.toString().trim();
        if ("auto".equals(trim) || Constants.Name.UNDEFINED.equals(trim) || TextUtils.isEmpty(trim)) {
            WXLogUtils.e("Argument Warning ! value is " + trim + "And default Value:NaN");
            return Float.NaN;
        } else if (trim.endsWith("wx")) {
            try {
                return transferWx(trim, f2);
            } catch (NumberFormatException e2) {
                WXLogUtils.e("Argument format error! value is " + obj, e2);
                return Float.NaN;
            } catch (Exception e3) {
                WXLogUtils.e("Argument error! value is " + obj, e3);
                return Float.NaN;
            }
        } else if (!trim.endsWith("px")) {
            try {
                return Float.parseFloat(trim);
            } catch (NumberFormatException e4) {
                WXLogUtils.e("Argument format error! value is " + obj, e4);
                return Float.NaN;
            } catch (Exception e5) {
                WXLogUtils.e("Argument error! value is " + obj, e5);
                return Float.NaN;
            }
        } else if (trim.length() <= 3 || (!trim.endsWith("rpx") && !trim.endsWith("upx"))) {
            try {
                return Float.parseFloat(trim.substring(0, trim.indexOf("px")));
            } catch (NumberFormatException e6) {
                WXLogUtils.e("Argument format error! value is " + obj, e6);
                return Float.NaN;
            } catch (Exception e7) {
                WXLogUtils.e("Argument error! value is " + obj, e7);
                return Float.NaN;
            }
        } else {
            try {
                return transferRpxAndUpx(trim.substring(0, trim.length() - 3), 750.0f);
            } catch (NumberFormatException e8) {
                WXLogUtils.e("Argument format error! value is " + obj, e8);
                return Float.NaN;
            } catch (Exception e9) {
                WXLogUtils.e("Argument error! value is " + obj, e9);
                return Float.NaN;
            }
        }
    }

    public static long getAvailMemory(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        WXLogUtils.w("app AvailMemory ---->>>" + (memoryInfo.availMem / 1048576));
        return memoryInfo.availMem / 1048576;
    }

    public static Boolean getBoolean(Object obj, Boolean bool) {
        if (obj == null) {
            return bool;
        }
        if (TextUtils.equals(AbsoluteConst.FALSE, obj.toString())) {
            return false;
        }
        if (TextUtils.equals(AbsoluteConst.TRUE, obj.toString())) {
            return true;
        }
        return bool;
    }

    public static String getBundleBanner(String str) {
        int i2;
        String substring;
        int lastIndexOf;
        int indexOf = str.indexOf("/*!");
        if (indexOf == -1) {
            return null;
        }
        int length = indexOf + "/*!".length();
        int indexLineBreak = indexLineBreak(str, length);
        if (indexLineBreak == -1 || (lastIndexOf = (substring = str.substring((i2 = indexLineBreak + 1), Integer.parseInt(str.substring(length, indexLineBreak)) + i2)).lastIndexOf("!*/")) == -1) {
            return null;
        }
        String substring2 = substring.substring(0, lastIndexOf);
        StringBuilder sb = new StringBuilder();
        for (String str2 : splitLineBreak(substring2)) {
            sb.append(str2.replaceFirst("\\*", ""));
        }
        return sb.toString();
    }

    public static LruCache getCache() {
        return sCache;
    }

    @Deprecated
    public static double getDouble(Object obj) {
        if (obj == null) {
            return 0.0d;
        }
        String trim = obj.toString().trim();
        if (trim.endsWith("wx")) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.w("the value of " + obj + " use wx unit, which will be not supported soon after.");
            }
            try {
                return (double) transferWx(trim, 750.0f);
            } catch (NumberFormatException e2) {
                WXLogUtils.e("Argument format error! value is " + obj, e2);
                return 0.0d;
            } catch (Exception e3) {
                WXLogUtils.e("Argument error! value is " + obj, e3);
                return 0.0d;
            }
        } else if (!trim.endsWith("px")) {
            try {
                return Double.parseDouble(trim);
            } catch (NumberFormatException e4) {
                WXLogUtils.e("Argument format error! value is " + obj, e4);
                return 0.0d;
            } catch (Exception e5) {
                WXLogUtils.e("Argument error! value is " + obj, e5);
                return 0.0d;
            }
        } else if (trim.length() <= 3 || (!trim.endsWith("rpx") && !trim.endsWith("upx"))) {
            try {
                return Double.parseDouble(trim.substring(0, trim.indexOf("px")));
            } catch (NumberFormatException e6) {
                WXLogUtils.e("Argument format error! value is " + obj, e6);
                return 0.0d;
            } catch (Exception e7) {
                WXLogUtils.e("Argument error! value is " + obj, e7);
                return 0.0d;
            }
        } else {
            try {
                return (double) transferRpxAndUpx(trim.substring(0, trim.length() - 3), 750.0f);
            } catch (NumberFormatException e8) {
                WXLogUtils.e("Argument format error! value is " + obj, e8);
                return 0.0d;
            } catch (Exception e9) {
                WXLogUtils.e("Argument error! value is " + obj, e9);
                return 0.0d;
            }
        }
    }

    public static long getFixUnixTime() {
        return sInterval + SystemClock.uptimeMillis();
    }

    public static float getFloat(Object obj) {
        return getFloat(obj, Float.valueOf(Float.NaN)).floatValue();
    }

    public static Float getFloat(Object obj, Float f2) {
        if (obj == null) {
            return f2;
        }
        String trim = obj.toString().trim();
        if ("auto".equals(trim) || Constants.Name.UNDEFINED.equals(trim) || TextUtils.isEmpty(trim)) {
            WXLogUtils.e("Argument Warning ! value is " + trim + "And default Value:NaN");
            return f2;
        }
        if (trim.endsWith("wx")) {
            try {
                return Float.valueOf(transferWx(trim, 750.0f));
            } catch (NumberFormatException e2) {
                WXLogUtils.e("Argument format error! value is " + obj, e2);
            } catch (Exception e3) {
                WXLogUtils.e("Argument error! value is " + obj, e3);
            }
        } else if (!trim.endsWith("px")) {
            try {
                return Float.valueOf(Float.parseFloat(trim));
            } catch (NumberFormatException e4) {
                WXLogUtils.e("Argument format error! value is " + obj, e4);
            } catch (Exception e5) {
                WXLogUtils.e("Argument error! value is " + obj, e5);
            }
        } else if (trim.length() <= 3 || (!trim.endsWith("rpx") && !trim.endsWith("upx"))) {
            try {
                return Float.valueOf(Float.parseFloat(trim.substring(0, trim.indexOf("px"))));
            } catch (NumberFormatException e6) {
                WXLogUtils.e("Argument format error! value is " + obj, e6);
            } catch (Exception e7) {
                WXLogUtils.e("Argument error! value is " + obj, e7);
            }
        } else {
            try {
                return Float.valueOf(transferRpxAndUpx(trim.substring(0, trim.length() - 3), 750.0f));
            } catch (NumberFormatException e8) {
                WXLogUtils.e("Argument format error! value is " + obj, e8);
            } catch (Exception e9) {
                WXLogUtils.e("Argument error! value is " + obj, e9);
            }
        }
        return f2;
    }

    public static float getFloatByViewport(Object obj, float f2) {
        return floatByViewport(obj, f2);
    }

    public static float getFloatByViewport(Object obj, int i2) {
        return floatByViewport(obj, (float) i2);
    }

    public static int getInt(Object obj) {
        return getInteger(obj, 0).intValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Object, java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v16 */
    /* JADX WARN: Type inference failed for: r5v2 */
    public static Integer getInteger(Object obj, Integer num) {
        if (obj == 0) {
            return num;
        }
        String trim = obj.toString().trim();
        Integer num2 = sCache.get(trim);
        if (num2 != null) {
            return num2;
        }
        String substring = trim.length() >= 2 ? trim.substring(trim.length() - 2, trim.length()) : "";
        if (TextUtils.equals("wx", substring)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.w("the value of " + obj + " use wx unit, which will be not supported soon after.");
            }
            try {
                obj = Integer.valueOf((int) transferWx(trim, 750.0f));
            } catch (NumberFormatException e2) {
                WXLogUtils.e("Argument format error! value is " + obj, e2);
            } catch (Exception e3) {
                WXLogUtils.e("Argument error! value is " + obj, e3);
            }
        } else if (!TextUtils.equals("px", substring)) {
            try {
            } catch (NumberFormatException e4) {
                WXLogUtils.e("Argument format error! value is " + obj, e4);
            } catch (Exception e5) {
                WXLogUtils.e("Argument error! value is " + obj, e5);
            }
            if (!TextUtils.isEmpty(trim)) {
                obj = trim.contains(Operators.DOT_STR) ? Integer.valueOf((int) parseFloat(trim)) : Integer.valueOf(Integer.parseInt(trim));
            } else {
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.e("Argument value is null, df is" + num);
                }
                obj = num;
            }
        } else if (trim.length() <= 3 || (!trim.endsWith("rpx") && !trim.endsWith("upx"))) {
            try {
                String substring2 = trim.substring(0, trim.length() - 2);
                obj = (TextUtils.isEmpty(substring2) || !substring2.contains(Operators.DOT_STR)) ? Integer.valueOf(Integer.parseInt(substring2)) : Integer.valueOf((int) parseFloat(substring2));
            } catch (NumberFormatException e6) {
                WXLogUtils.e("Argument format error! value is " + obj, e6);
            } catch (Exception e7) {
                WXLogUtils.e("Argument error! value is " + obj, e7);
            }
        } else {
            try {
                obj = Integer.valueOf((int) transferRpxAndUpx(trim.substring(0, trim.length() - 3), 750.0f));
            } catch (NumberFormatException e8) {
                WXLogUtils.e("Argument format error! value is " + obj, e8);
            } catch (Exception e9) {
                WXLogUtils.e("Argument error! value is " + obj, e9);
            }
        }
        if (obj != 0 && !obj.equals(num)) {
            sCache.put(trim, obj);
        }
        return obj;
    }

    @Deprecated
    public static long getLong(Object obj) {
        if (obj == null) {
            return 0;
        }
        String trim = obj.toString().trim();
        if (trim.endsWith("wx")) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.w("the value of " + obj + " use wx unit, which will be not supported soon after.");
            }
            try {
                return (long) transferWx(trim, 750.0f);
            } catch (NumberFormatException e2) {
                WXLogUtils.e("Argument format error! value is " + obj, e2);
                return 0;
            } catch (Exception e3) {
                WXLogUtils.e("Argument error! value is " + obj, e3);
                return 0;
            }
        } else if (!trim.endsWith("px")) {
            try {
                return Long.parseLong(trim);
            } catch (NumberFormatException e4) {
                WXLogUtils.e("Argument format error! value is " + obj, e4);
                return 0;
            } catch (Exception e5) {
                WXLogUtils.e("Argument error! value is " + obj, e5);
                return 0;
            }
        } else if (trim.length() <= 3 || (!trim.endsWith("rpx") && !trim.endsWith("upx"))) {
            try {
                return Long.parseLong(trim.substring(0, trim.indexOf("px")));
            } catch (NumberFormatException e6) {
                WXLogUtils.e("Argument format error! value is " + obj, e6);
                return 0;
            } catch (Exception e7) {
                WXLogUtils.e("Argument error! value is " + obj, e7);
                return 0;
            }
        } else {
            try {
                return (long) transferRpxAndUpx(trim.substring(0, trim.length() - 3), 750.0f);
            } catch (NumberFormatException e8) {
                WXLogUtils.e("Argument format error! value is " + obj, e8);
                return 0;
            } catch (Exception e9) {
                WXLogUtils.e("Argument error! value is " + obj, e9);
                return 0;
            }
        }
    }

    public static int getNumberInt(Object obj, int i2) {
        if (obj == null) {
            return i2;
        }
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        try {
            String obj2 = obj.toString();
            return obj2.indexOf(46) >= 0 ? (int) Float.parseFloat(obj.toString()) : Integer.parseInt(obj2);
        } catch (Exception e2) {
            return i2;
        }
    }

    public static String getString(Object obj, String str) {
        if (obj == null) {
            return str;
        }
        return obj instanceof String ? (String) obj : obj.toString();
    }

    private static int indexLineBreak(String str, int i2) {
        int indexOf = str.indexOf("\r", i2);
        int i3 = indexOf;
        if (indexOf == -1) {
            i3 = str.indexOf("\n", i2);
        }
        int i4 = i3;
        if (i3 == -1) {
            i4 = str.indexOf("\r\n", i2);
        }
        return i4;
    }

    @Deprecated
    public static boolean isTabletDevice() {
        boolean z2 = false;
        try {
            if ((WXEnvironment.getApplication().getResources().getConfiguration().screenLayout & 15) >= 3) {
                z2 = true;
            }
        } catch (Exception e2) {
        }
        return z2;
    }

    public static boolean isUiThread() {
        return Thread.currentThread().getId() == Looper.getMainLooper().getThread().getId();
    }

    public static boolean isUndefined(float f2) {
        return Float.isNaN(f2);
    }

    public static float parseFloat(Object obj) {
        return parseFloat(String.valueOf(obj));
    }

    public static float parseFloat(String str) {
        try {
            if (!TextUtils.isEmpty(str) && !TextUtils.equals(str, "null")) {
                return Float.parseFloat(str);
            }
            if (!WXEnvironment.isApkDebugable()) {
                return 0.0f;
            }
            WXLogUtils.e("WXUtils parseFloat illegal value is " + str);
            return 0.0f;
        } catch (NumberFormatException e2) {
            if (!WXEnvironment.isApkDebugable()) {
                return 0.0f;
            }
            WXLogUtils.e(WXLogUtils.getStackTrace(e2));
            return 0.0f;
        }
    }

    public static int parseInt(Object obj) {
        return parseInt(String.valueOf(obj));
    }

    public static int parseInt(String str) {
        try {
            if (TextUtils.isEmpty(str) || str.contains(Operators.DOT_STR)) {
                return 0;
            }
            return Integer.parseInt(str);
        } catch (NumberFormatException e2) {
            if (!WXEnvironment.isApkDebugable()) {
                return 0;
            }
            WXLogUtils.e(WXLogUtils.getStackTrace(e2));
            return 0;
        }
    }

    private static int parsePercent(String str, int i2) {
        return (int) ((Float.parseFloat(str) / 100.0f) * ((float) i2));
    }

    public static int parseUnitOrPercent(String str, int i2) {
        int lastIndexOf = str.lastIndexOf(37);
        return lastIndexOf != -1 ? parsePercent(str.substring(0, lastIndexOf), i2) : parseInt(str);
    }

    private static String[] splitLineBreak(String str) {
        String[] split = str.split("\r");
        String[] strArr = split;
        if (split.length == 1) {
            strArr = str.split("\n");
        }
        String[] strArr2 = strArr;
        if (strArr.length == 1) {
            strArr2 = str.split("\r\n");
        }
        return strArr2;
    }

    private static float transferRpxAndUpx(String str, float f2) {
        String str2;
        if (str == null) {
            return 0.0f;
        }
        if (str.endsWith("rpx")) {
            str2 = str.substring(0, str.indexOf("rpx"));
        } else {
            str2 = str;
            if (str.endsWith("upx")) {
                str2 = str.substring(0, str.indexOf("upx"));
            }
        }
        return (WXEnvironment.getViewProt() / f2) * Float.valueOf(Float.parseFloat(str2)).floatValue();
    }

    private static float transferWx(String str, float f2) {
        if (str == null) {
            return 0.0f;
        }
        String str2 = str;
        if (str.endsWith("wx")) {
            str2 = str.substring(0, str.indexOf("wx"));
        }
        return ((WXEnvironment.sApplication.getResources().getDisplayMetrics().density * Float.valueOf(Float.parseFloat(str2)).floatValue()) * f2) / ((float) WXViewUtils.getScreenWidth());
    }
}
