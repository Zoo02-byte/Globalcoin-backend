package com.taobao.weex.utils;

import java.io.Serializable;
import java.util.HashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXMap.class */
public class WXMap extends HashMap<String, String> implements Serializable {
    public String put(String str, byte[] bArr) {
        return put((WXMap) str, new String(bArr));
    }
}
