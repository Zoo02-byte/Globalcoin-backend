package com.taobao.weex.utils;

import android.util.Log;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/Trace.class */
public class Trace {
    private static final String TAG = "Weex_Trace";
    private static final boolean sEnabled = false;
    private static final AbstractTrace sTrace = new TraceDummy();

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/Trace$AbstractTrace.class */
    private static abstract class AbstractTrace {
        private AbstractTrace() {
        }

        abstract void beginSection(String str);

        abstract void endSection();
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/Trace$TraceDummy.class */
    private static final class TraceDummy extends AbstractTrace {
        private TraceDummy() {
            super();
        }

        @Override // com.taobao.weex.utils.Trace.AbstractTrace
        void beginSection(String str) {
        }

        @Override // com.taobao.weex.utils.Trace.AbstractTrace
        void endSection() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/Trace$TraceJBMR2.class */
    private static final class TraceJBMR2 extends AbstractTrace {
        private TraceJBMR2() {
            super();
        }

        @Override // com.taobao.weex.utils.Trace.AbstractTrace
        void beginSection(String str) {
            android.os.Trace.beginSection(str);
        }

        @Override // com.taobao.weex.utils.Trace.AbstractTrace
        void endSection() {
            android.os.Trace.endSection();
        }
    }

    public static void beginSection(String str) {
        Log.i(TAG, "beginSection() " + str);
        sTrace.beginSection(str);
    }

    public static void endSection() {
        sTrace.endSection();
        Log.i(TAG, "endSection()");
    }

    public static final boolean getTraceEnabled() {
        return sEnabled;
    }
}
