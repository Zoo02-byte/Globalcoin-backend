package com.taobao.weex.utils;

import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import java.lang.reflect.Constructor;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/StaticLayoutProxy.class */
public class StaticLayoutProxy {
    private static Constructor<StaticLayout> layoutConstructor;

    public static StaticLayout create(CharSequence charSequence, TextPaint textPaint, int i2, Layout.Alignment alignment, float f2, float f3, boolean z2, boolean z3) {
        StaticLayout createInternal;
        if (z3 && (createInternal = createInternal(charSequence, textPaint, i2, alignment, TextDirectionHeuristics.RTL, f2, f3, z2)) != null) {
            return createInternal;
        }
        return new StaticLayout(charSequence, textPaint, i2, alignment, f2, f3, z2);
    }

    private static StaticLayout createInternal(CharSequence charSequence, TextPaint textPaint, int i2, Layout.Alignment alignment, TextDirectionHeuristic textDirectionHeuristic, float f2, float f3, boolean z2) {
        try {
            if (layoutConstructor == null) {
                layoutConstructor = StaticLayout.class.getConstructor(CharSequence.class, TextPaint.class, Integer.TYPE, Layout.Alignment.class, TextDirectionHeuristic.class, Float.TYPE, Float.TYPE, Boolean.TYPE);
            }
            Constructor<StaticLayout> constructor = layoutConstructor;
            if (constructor != null) {
                return constructor.newInstance(charSequence, textPaint, Integer.valueOf(i2), alignment, textDirectionHeuristic, Float.valueOf(f2), Float.valueOf(f3), Boolean.valueOf(z2));
            }
            return null;
        } catch (Throwable th) {
            th.printStackTrace();
            return null;
        }
    }
}
