package com.taobao.weex.utils;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.performance.WXInstanceApm;
import io.dcloud.common.util.StringUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/BoxShadowUtil.class */
public class BoxShadowUtil {
    private static final String TAG = "BoxShadowUtil";
    private static boolean sBoxShadowEnabled = true;
    private static Pattern sColorPattern;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/BoxShadowUtil$BoxShadowOptions.class */
    public static class BoxShadowOptions {
        public float blur;
        public int color;
        public float hShadow;
        public boolean isInset;
        private List<IParser> optionParamParsers;
        public float[] radii;
        public float spread;
        public PointF topLeft;
        public float vShadow;
        public int viewHeight;
        public int viewWidth;
        private float viewport;

        /* JADX INFO: Access modifiers changed from: private */
        /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/BoxShadowUtil$BoxShadowOptions$IParser.class */
        public interface IParser {
            void parse(String str);
        }

        private BoxShadowOptions(float f2) {
            this.viewport = 750.0f;
            this.blur = 0.0f;
            this.spread = 0.0f;
            this.radii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
            this.color = -16777216;
            this.isInset = false;
            this.viewWidth = 0;
            this.viewHeight = 0;
            this.topLeft = null;
            if (750.0f != 0.0f) {
                this.viewport = f2;
            }
            this.optionParamParsers = new ArrayList();
            AnonymousClass1 r02 = new IParser(this) { // from class: com.taobao.weex.utils.BoxShadowUtil.BoxShadowOptions.1
                final BoxShadowOptions this$0;

                {
                    this.this$0 = r4;
                }

                @Override // com.taobao.weex.utils.BoxShadowUtil.BoxShadowOptions.IParser
                public void parse(String str) {
                    if (!TextUtils.isEmpty(str)) {
                        float floatValue = WXUtils.getFloat(str, Float.valueOf(0.0f)).floatValue();
                        BoxShadowOptions boxShadowOptions = this.this$0;
                        boxShadowOptions.spread = WXViewUtils.getRealSubPxByWidth(floatValue, boxShadowOptions.viewport);
                        WXLogUtils.w(BoxShadowUtil.TAG, "Experimental box-shadow attribute: spread");
                    }
                }
            };
            this.optionParamParsers.add(new IParser(this) { // from class: com.taobao.weex.utils.BoxShadowUtil.BoxShadowOptions.2
                final BoxShadowOptions this$0;

                {
                    this.this$0 = r4;
                }

                @Override // com.taobao.weex.utils.BoxShadowUtil.BoxShadowOptions.IParser
                public void parse(String str) {
                    if (!TextUtils.isEmpty(str)) {
                        float floatValue = WXUtils.getFloat(str, Float.valueOf(0.0f)).floatValue();
                        BoxShadowOptions boxShadowOptions = this.this$0;
                        boxShadowOptions.blur = WXViewUtils.getRealSubPxByWidth(floatValue, boxShadowOptions.viewport);
                    }
                }
            });
            this.optionParamParsers.add(r02);
        }

        public Rect getTargetCanvasRect() {
            return new Rect(0, 0, this.viewWidth + (((int) (this.blur + this.spread + Math.abs(this.hShadow))) * 2), this.viewHeight + (((int) (this.blur + this.spread + Math.abs(this.vShadow))) * 2));
        }

        public BoxShadowOptions scale(float f2) {
            if (f2 <= 0.0f || f2 > 1.0f) {
                return null;
            }
            BoxShadowOptions boxShadowOptions = new BoxShadowOptions(this.viewport);
            boxShadowOptions.hShadow = this.hShadow * f2;
            boxShadowOptions.vShadow = this.vShadow * f2;
            boxShadowOptions.blur = this.blur * f2;
            boxShadowOptions.spread = this.spread * f2;
            int i2 = 0;
            while (true) {
                float[] fArr = this.radii;
                if (i2 >= fArr.length) {
                    break;
                }
                boxShadowOptions.radii[i2] = fArr[i2] * f2;
                i2++;
            }
            boxShadowOptions.viewHeight = (int) (((float) this.viewHeight) * f2);
            boxShadowOptions.viewWidth = (int) (((float) this.viewWidth) * f2);
            if (this.topLeft != null) {
                PointF pointF = new PointF();
                boxShadowOptions.topLeft = pointF;
                pointF.x = this.topLeft.x * f2;
                boxShadowOptions.topLeft.y = this.topLeft.y * f2;
            }
            boxShadowOptions.color = this.color;
            boxShadowOptions.isInset = this.isInset;
            WXLogUtils.d(BoxShadowUtil.TAG, "Scaled BoxShadowOptions: [" + f2 + "] " + boxShadowOptions);
            return boxShadowOptions;
        }

        public String toString() {
            StringBuffer stringBuffer = new StringBuffer("BoxShadowOptions{h-shadow=");
            stringBuffer.append(this.hShadow);
            stringBuffer.append(", v-shadow=").append(this.vShadow);
            stringBuffer.append(", blur=").append(this.blur);
            stringBuffer.append(", spread=").append(this.spread);
            stringBuffer.append(", corner-radius=").append(Operators.ARRAY_START_STR + this.radii[0] + "," + this.radii[2] + "," + this.radii[4] + "," + this.radii[6] + Operators.ARRAY_END_STR);
            stringBuffer.append(", color=#").append(Integer.toHexString(this.color));
            stringBuffer.append(", inset=").append(this.isInset);
            stringBuffer.append('}');
            return stringBuffer.toString();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/BoxShadowUtil$InsetShadowDrawable.class */
    public static class InsetShadowDrawable extends Drawable {
        private static final int BOTTOM_TO_TOP = 3;
        private static final int LEFT_TO_RIGHT = 0;
        private static final int RIGHT_TO_LEFT = 2;
        private static final int TOP_TO_BOTTOM = 1;
        private float blurRadius;
        private float height;
        private Paint paint;
        private Path[] paths;
        private float[] radii;
        private Shader[] shades;
        private int shadowColor;
        private float shadowXSize;
        private float shadowYSize;
        private float width;

        private InsetShadowDrawable(int i2, int i3, float f2, float f3, float f4, float f5, int i4, float[] fArr) {
            this.shades = new Shader[4];
            this.paths = new Path[4];
            this.blurRadius = f4;
            this.shadowColor = i4;
            this.width = ((float) i2) + (f2 * 2.0f);
            this.height = ((float) i3) + (2.0f * f3);
            this.shadowXSize = f2 + f5;
            this.shadowYSize = f3 + f5;
            this.radii = fArr;
            setBounds(0, 0, i2, i3);
            prepare();
        }

        private void prepare() {
            PointF pointF = new PointF(0.0f, 0.0f);
            PointF pointF2 = new PointF(this.width, 0.0f);
            PointF pointF3 = new PointF(pointF2.x, this.height);
            PointF pointF4 = new PointF(pointF.x, pointF3.y);
            PointF pointF5 = new PointF(this.shadowXSize, this.shadowYSize);
            PointF pointF6 = new PointF(pointF2.x - this.shadowXSize, pointF5.y);
            PointF pointF7 = new PointF(pointF6.x, pointF3.y - this.shadowYSize);
            PointF pointF8 = new PointF(pointF5.x, pointF7.y);
            LinearGradient linearGradient = new LinearGradient(pointF5.x - this.blurRadius, pointF5.y, pointF5.x, pointF5.y, this.shadowColor, 0, Shader.TileMode.CLAMP);
            LinearGradient linearGradient2 = new LinearGradient(pointF5.x, pointF5.y - this.blurRadius, pointF5.x, pointF5.y, this.shadowColor, 0, Shader.TileMode.CLAMP);
            LinearGradient linearGradient3 = new LinearGradient(pointF7.x + this.blurRadius, pointF7.y, pointF7.x, pointF7.y, this.shadowColor, 0, Shader.TileMode.CLAMP);
            LinearGradient linearGradient4 = new LinearGradient(pointF7.x, pointF7.y + this.blurRadius, pointF7.x, pointF7.y, this.shadowColor, 0, Shader.TileMode.CLAMP);
            Shader[] shaderArr = this.shades;
            shaderArr[0] = linearGradient;
            shaderArr[1] = linearGradient2;
            shaderArr[2] = linearGradient3;
            shaderArr[3] = linearGradient4;
            Path path = new Path();
            path.moveTo(pointF.x, pointF.y);
            path.lineTo(pointF5.x, pointF5.y);
            path.lineTo(pointF8.x, pointF8.y);
            path.lineTo(pointF4.x, pointF4.y);
            path.close();
            Path path2 = new Path();
            path2.moveTo(pointF.x, pointF.y);
            path2.lineTo(pointF2.x, pointF2.y);
            path2.lineTo(pointF6.x, pointF6.y);
            path2.lineTo(pointF5.x, pointF5.y);
            path2.close();
            Path path3 = new Path();
            path3.moveTo(pointF2.x, pointF2.y);
            path3.lineTo(pointF3.x, pointF3.y);
            path3.lineTo(pointF7.x, pointF7.y);
            path3.lineTo(pointF6.x, pointF6.y);
            path3.close();
            Path path4 = new Path();
            path4.moveTo(pointF4.x, pointF4.y);
            path4.lineTo(pointF3.x, pointF3.y);
            path4.lineTo(pointF7.x, pointF7.y);
            path4.lineTo(pointF8.x, pointF8.y);
            path4.close();
            Path[] pathArr = this.paths;
            pathArr[0] = path;
            pathArr[1] = path2;
            pathArr[2] = path3;
            pathArr[3] = path4;
            Paint paint = new Paint();
            this.paint = paint;
            paint.setAntiAlias(true);
            this.paint.setStyle(Paint.Style.FILL);
            this.paint.setColor(this.shadowColor);
        }

        @Override // android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            Rect clipBounds = canvas.getClipBounds();
            Path path = new Path();
            path.addRoundRect(new RectF(clipBounds), this.radii, Path.Direction.CCW);
            canvas.clipPath(path);
            canvas.translate((float) clipBounds.left, (float) clipBounds.top);
            for (int i2 = 0; i2 < 4; i2++) {
                Shader shader = this.shades[i2];
                Path path2 = this.paths[i2];
                this.paint.setShader(shader);
                canvas.drawPath(path2, this.paint);
            }
        }

        @Override // android.graphics.drawable.Drawable
        public int getOpacity() {
            return -1;
        }

        @Override // android.graphics.drawable.Drawable
        public void setAlpha(int i2) {
        }

        @Override // android.graphics.drawable.Drawable
        public void setColorFilter(ColorFilter colorFilter) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/BoxShadowUtil$OverflowBitmapDrawable.class */
    public static class OverflowBitmapDrawable extends BitmapDrawable {
        private int paddingX;
        private int paddingY;
        private float[] radii;
        private Rect viewRect;

        private OverflowBitmapDrawable(Resources resources, Bitmap bitmap, Point point, Rect rect, float[] fArr) {
            super(resources, bitmap);
            this.paddingX = point.x;
            int i2 = point.y;
            this.paddingY = i2;
            this.viewRect = rect;
            this.radii = fArr;
            setBounds(-this.paddingX, -i2, rect.width() + this.paddingX, rect.height() + this.paddingY);
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r8v0, types: [android.graphics.Rect] */
        /* JADX WARN: Type inference failed for: r8v1, types: [android.graphics.Path] */
        @Override // android.graphics.drawable.BitmapDrawable, android.graphics.drawable.Drawable
        public void draw(Canvas canvas) {
            Rect clipBounds = canvas.getClipBounds();
            Rect rect = new Rect(clipBounds);
            rect.inset((-this.paddingX) * 2, (-this.paddingY) * 2);
            try {
                if (WXEnvironment.sApplication.getApplicationInfo().targetSdkVersion > 26) {
                    canvas.clipRect((Rect) rect);
                } else {
                    canvas.clipRect((Rect) rect, Region.Op.REPLACE);
                }
            } catch (NullPointerException e2) {
                canvas.clipRect(rect);
            }
            rect = new Path();
            rect.addRoundRect(new RectF(clipBounds), this.radii, Path.Direction.CCW);
            canvas.clipPath(rect, Region.Op.DIFFERENCE);
            canvas.translate((float) clipBounds.left, (float) clipBounds.top);
            draw(canvas);
        }
    }

    private static void drawShadow(Canvas canvas, BoxShadowOptions boxShadowOptions) {
        RectF rectF = new RectF(0.0f, 0.0f, ((float) boxShadowOptions.viewWidth) + (boxShadowOptions.spread * 2.0f), ((float) boxShadowOptions.viewHeight) + (boxShadowOptions.spread * 2.0f));
        if (boxShadowOptions.topLeft != null) {
            rectF.offset(boxShadowOptions.topLeft.x, boxShadowOptions.topLeft.y);
        }
        float f2 = boxShadowOptions.blur;
        float f3 = boxShadowOptions.blur;
        float f4 = f2;
        if (boxShadowOptions.hShadow > 0.0f) {
            f4 = f2 + (boxShadowOptions.hShadow * 2.0f);
        }
        float f5 = f3;
        if (boxShadowOptions.vShadow > 0.0f) {
            f5 = f3 + (boxShadowOptions.vShadow * 2.0f);
        }
        rectF.offset(f4, f5);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(boxShadowOptions.color);
        paint.setStyle(Paint.Style.FILL);
        if (boxShadowOptions.blur > 0.0f) {
            paint.setMaskFilter(new BlurMaskFilter(boxShadowOptions.blur, BlurMaskFilter.Blur.NORMAL));
        }
        Path path = new Path();
        float[] fArr = new float[8];
        for (int i2 = 0; i2 < boxShadowOptions.radii.length; i2++) {
            if (boxShadowOptions.radii[i2] == 0.0f) {
                fArr[i2] = 0.0f;
            } else {
                fArr[i2] = boxShadowOptions.radii[i2] + boxShadowOptions.spread;
            }
        }
        path.addRoundRect(rectF, fArr, Path.Direction.CCW);
        canvas.drawPath(path, paint);
    }

    public static boolean isBoxShadowEnabled() {
        return sBoxShadowEnabled;
    }

    private static BoxShadowOptions parseBoxShadow(String str, float f2) {
        BoxShadowOptions boxShadowOptions = new BoxShadowOptions(f2);
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        String replaceAll = str.replaceAll("\\s*,\\s+", ",");
        String str2 = replaceAll;
        if (replaceAll.contains("inset")) {
            boxShadowOptions.isInset = true;
            str2 = replaceAll.replace("inset", "");
        }
        ArrayList arrayList = new ArrayList(Arrays.asList(str2.trim().split("\\s+")));
        String str3 = (String) arrayList.get(arrayList.size() - 1);
        if (!TextUtils.isEmpty(str3) && (str3.startsWith("#") || str3.startsWith("rgb") || WXResourceUtils.isNamedColor(str3))) {
            boxShadowOptions.color = WXResourceUtils.getColor(str3, -16777216);
            arrayList.remove(arrayList.size() - 1);
        }
        try {
        } catch (Throwable th) {
            th.printStackTrace();
        }
        if (arrayList.size() < 2) {
            return null;
        }
        if (!TextUtils.isEmpty((CharSequence) arrayList.get(0))) {
            boxShadowOptions.hShadow = WXViewUtils.getRealSubPxByWidth(WXUtils.getFloat(((String) arrayList.get(0)).trim(), Float.valueOf(0.0f)).floatValue(), f2);
        }
        int i2 = 2;
        if (!TextUtils.isEmpty((CharSequence) arrayList.get(1))) {
            boxShadowOptions.vShadow = WXViewUtils.getRealPxByWidth(WXUtils.getFloat(((String) arrayList.get(1)).trim(), Float.valueOf(0.0f)).floatValue(), f2);
            i2 = 2;
        }
        while (i2 < arrayList.size()) {
            ((BoxShadowOptions.IParser) boxShadowOptions.optionParamParsers.get(i2 - 2)).parse((String) arrayList.get(i2));
            i2++;
        }
        return boxShadowOptions;
    }

    public static BoxShadowOptions[] parseBoxShadows(String str, float f2) {
        if (sColorPattern == null) {
            sColorPattern = Pattern.compile("([rR][gG][bB][aA]?)\\((\\d+\\s*),\\s*(\\d+\\s*),\\s*(\\d+\\s*)(?:,\\s*(\\d+(?:\\.\\d+)?))?\\)");
        }
        Matcher matcher = sColorPattern.matcher(str);
        while (matcher.find()) {
            String group = matcher.group();
            str = str.replace(group, "#" + StringUtil.format("%8s", Integer.toHexString(WXResourceUtils.getColor(group, -16777216))).replaceAll("\\s", WXInstanceApm.VALUE_ERROR_CODE_DEFAULT));
        }
        String[] split = str.split(",");
        if (split == null || split.length <= 0) {
            return null;
        }
        BoxShadowOptions[] boxShadowOptionsArr = new BoxShadowOptions[split.length];
        for (int i2 = 0; i2 < split.length; i2++) {
            boxShadowOptionsArr[i2] = parseBoxShadow(split[i2], f2);
        }
        return boxShadowOptionsArr;
    }

    public static void setBoxShadow(View view, String str, float[] fArr, float f2, float f3) {
        if (!sBoxShadowEnabled) {
            WXLogUtils.w(TAG, "box-shadow was disabled by config");
        } else if (view == null) {
            WXLogUtils.w(TAG, "Target view is null!");
        } else if (TextUtils.isEmpty(str)) {
            view.getOverlay().clear();
            WXLogUtils.d(TAG, "Remove all box-shadow");
        } else {
            BoxShadowOptions[] parseBoxShadows = parseBoxShadows(str, f2);
            if (parseBoxShadows == null || parseBoxShadows.length == 0) {
                WXLogUtils.w(TAG, "Failed to parse box-shadow: " + str);
                return;
            }
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (BoxShadowOptions boxShadowOptions : parseBoxShadows) {
                if (boxShadowOptions != null) {
                    if (boxShadowOptions.isInset) {
                        arrayList2.add(0, boxShadowOptions);
                    } else {
                        arrayList.add(0, boxShadowOptions);
                    }
                }
            }
            if (fArr != null) {
                if (fArr.length != 8) {
                    WXLogUtils.w(TAG, "Length of radii must be 8");
                } else {
                    for (int i2 = 0; i2 < fArr.length; i2++) {
                        fArr[i2] = WXViewUtils.getRealSubPxByWidth(fArr[i2], f2);
                    }
                }
            }
            view.post(WXThread.secure(new Runnable(view, arrayList, f3, fArr, arrayList2) { // from class: com.taobao.weex.utils.BoxShadowUtil.1
                final List val$insetShadows;
                final List val$normalShadows;
                final float val$quality;
                final float[] val$radii;
                final View val$target;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.val$target = r4;
                    this.val$normalShadows = r5;
                    this.val$quality = r6;
                    this.val$radii = r7;
                    this.val$insetShadows = r8;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.val$target.getOverlay().clear();
                    if (this.val$normalShadows.size() > 0) {
                        BoxShadowUtil.setNormalBoxShadow(this.val$target, this.val$normalShadows, this.val$quality, this.val$radii);
                    }
                    if (this.val$insetShadows.size() > 0) {
                        BoxShadowUtil.setInsetBoxShadow(this.val$target, this.val$insetShadows, this.val$quality, this.val$radii);
                    }
                }
            }));
        }
    }

    public static void setBoxShadowEnabled(boolean z2) {
        sBoxShadowEnabled = z2;
        WXLogUtils.w(TAG, "Switch box-shadow status: " + z2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void setInsetBoxShadow(View view, List<BoxShadowOptions> list, float f2, float[] fArr) {
        if (view == null || list == null) {
            WXLogUtils.w(TAG, "Illegal arguments");
        } else if (view.getWidth() == 0 || view.getHeight() == 0) {
            WXLogUtils.w(TAG, "Target view is invisible, ignore set shadow.");
        } else {
            Drawable[] drawableArr = new Drawable[list.size()];
            for (int i2 = 0; i2 < list.size(); i2++) {
                BoxShadowOptions boxShadowOptions = list.get(i2);
                drawableArr[i2] = new InsetShadowDrawable(view.getWidth(), view.getHeight(), boxShadowOptions.hShadow, boxShadowOptions.vShadow, boxShadowOptions.blur, boxShadowOptions.spread, boxShadowOptions.color, fArr);
            }
            view.getOverlay().add(new LayerDrawable(drawableArr));
            view.invalidate();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void setNormalBoxShadow(View view, List<BoxShadowOptions> list, float f2, float[] fArr) {
        int height = view.getHeight();
        int width = view.getWidth();
        view.getLayoutParams();
        if (height == 0 || width == 0) {
            Log.w(TAG, "Target view is invisible, ignore set shadow.");
            return;
        }
        int i2 = 0;
        int i3 = 0;
        for (BoxShadowOptions boxShadowOptions : list) {
            boxShadowOptions.viewWidth = width;
            boxShadowOptions.viewHeight = height;
            boxShadowOptions.radii = fArr;
            Rect targetCanvasRect = boxShadowOptions.getTargetCanvasRect();
            int i4 = i2;
            if (i2 < targetCanvasRect.width()) {
                i4 = targetCanvasRect.width();
            }
            i2 = i4;
            if (i3 < targetCanvasRect.height()) {
                i3 = targetCanvasRect.height();
                i2 = i4;
            }
        }
        Bitmap createBitmap = Bitmap.createBitmap((int) (((float) i2) * f2), (int) (((float) i3) * f2), Bitmap.Config.ARGB_4444);
        WXLogUtils.d(TAG, "Allocation memory for box-shadow: " + (createBitmap.getAllocationByteCount() / 1024) + " KB");
        Canvas canvas = new Canvas(createBitmap);
        for (BoxShadowOptions boxShadowOptions2 : list) {
            Rect targetCanvasRect2 = boxShadowOptions2.getTargetCanvasRect();
            boxShadowOptions2.topLeft = new PointF(((float) (i2 - targetCanvasRect2.width())) / 2.0f, ((float) (i3 - targetCanvasRect2.height())) / 2.0f);
            drawShadow(canvas, boxShadowOptions2.scale(f2));
        }
        OverflowBitmapDrawable overflowBitmapDrawable = new OverflowBitmapDrawable(view.getResources(), createBitmap, new Point((i2 - width) / 2, (i3 - height) / 2), new Rect(0, 0, width, height), fArr);
        view.getOverlay().add(overflowBitmapDrawable);
        ViewParent parent = view.getParent();
        if (parent != null) {
            parent.requestLayout();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).invalidate(overflowBitmapDrawable.getBounds());
            }
        }
    }
}
