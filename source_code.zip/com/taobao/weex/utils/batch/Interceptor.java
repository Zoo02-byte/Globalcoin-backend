package com.taobao.weex.utils.batch;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/batch/Interceptor.class */
public interface Interceptor {
    boolean take(Runnable runnable);
}
