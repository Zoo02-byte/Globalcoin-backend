package com.taobao.weex.utils.batch;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/batch/BactchExecutor.class */
public interface BactchExecutor {
    void post(Runnable runnable);

    void setInterceptor(Interceptor interceptor);
}
