package com.taobao.weex.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.common.WXRuntimeException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXJsonUtils.class */
public class WXJsonUtils {
    public static String fromObjectToJSONString(Object obj) {
        return fromObjectToJSONString(obj, false);
    }

    public static String fromObjectToJSONString(Object obj, boolean z2) {
        try {
            return z2 ? JSON.toJSONString(obj, SerializerFeature.WriteNonStringKeyAsString) : JSON.toJSONString(obj);
        } catch (Exception e2) {
            if (!WXEnvironment.isApkDebugable()) {
                WXLogUtils.e("fromObjectToJSONString error:", e2);
                return "{}";
            }
            throw new WXRuntimeException("fromObjectToJSONString parse error!");
        }
    }

    public static <T> List<T> getList(String str, Class<T> cls) {
        List<T> list;
        try {
            list = JSONObject.parseArray(str, cls);
        } catch (Exception e2) {
            e2.printStackTrace();
            list = new ArrayList<>();
        }
        return list;
    }

    public static void putAll(Map<String, Object> map, JSONObject jSONObject) {
        for (Map.Entry<String, Object> entry : jSONObject.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (!(key == null || value == null)) {
                map.put(key, value);
            }
        }
    }
}
