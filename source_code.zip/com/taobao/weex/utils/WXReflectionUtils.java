package com.taobao.weex.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXReflectionUtils.class */
public class WXReflectionUtils {
    public static Field getDeclaredField(Object obj, String str) {
        for (Class<?> cls = obj.getClass(); cls != Object.class; cls = cls.getSuperclass()) {
            try {
                return cls.getDeclaredField(str);
            } catch (Exception e2) {
            }
        }
        return null;
    }

    public static Object parseArgument(Type type, Object obj) {
        if (obj != null) {
            if (obj.getClass() == type) {
                return obj;
            }
            if ((type instanceof Class) && ((Class) type).isAssignableFrom(obj.getClass())) {
                return obj;
            }
        }
        if (type == String.class) {
            if (!(obj instanceof String)) {
                obj = JSON.toJSONString(obj);
            }
            return obj;
        } else if (type == Integer.TYPE) {
            if (!obj.getClass().isAssignableFrom(Integer.TYPE)) {
                obj = Integer.valueOf(WXUtils.getInt(obj));
            }
            return obj;
        } else if (type == Long.TYPE) {
            if (!obj.getClass().isAssignableFrom(Long.TYPE)) {
                obj = Long.valueOf(WXUtils.getLong(obj));
            }
            return obj;
        } else if (type == Double.TYPE) {
            if (!obj.getClass().isAssignableFrom(Double.TYPE)) {
                obj = Double.valueOf(WXUtils.getDouble(obj));
            }
            return obj;
        } else if (type == Float.TYPE) {
            if (!obj.getClass().isAssignableFrom(Float.TYPE)) {
                obj = Float.valueOf(WXUtils.getFloat(obj));
            }
            return obj;
        } else if (type == JSONArray.class && obj != null && obj.getClass() == JSONArray.class) {
            return obj;
        } else {
            if (type == JSONObject.class && obj != null && obj.getClass() == JSONObject.class) {
                return obj;
            }
            return JSON.parseObject(obj instanceof String ? (String) obj : JSON.toJSONString(obj), type, new Feature[0]);
        }
    }

    public static void setProperty(Object obj, Field field, Object obj2) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        if (obj != null && field != null) {
            try {
                field.setAccessible(true);
                field.set(obj, obj2);
            } catch (Exception e2) {
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:44:0x00d6, code lost:
        if (r0.getType() == java.lang.Boolean.class) goto L_0x00d9;
     */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00df A[Catch: Exception -> 0x00ef, TRY_ENTER, TryCatch #0 {Exception -> 0x00ef, blocks: (B:6:0x000e, B:8:0x001c, B:10:0x0023, B:13:0x002c, B:15:0x0034, B:18:0x0042, B:20:0x004c, B:23:0x005a, B:25:0x0064, B:28:0x0072, B:30:0x007c, B:34:0x008f, B:35:0x009a, B:36:0x00a9, B:37:0x00b7, B:39:0x00c4, B:43:0x00cf, B:48:0x00df, B:50:0x00e8), top: B:53:0x000e }] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public static void setValue(java.lang.Object r4, java.lang.String r5, java.lang.Object r6) {
        /*
        // Method dump skipped, instructions count: 243
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.utils.WXReflectionUtils.setValue(java.lang.Object, java.lang.String, java.lang.Object):void");
    }
}
