package com.taobao.weex.utils;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.el.parse.Operators;
import io.dcloud.common.adapter.util.DeviceInfo;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
/* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXViewToImageUtil.class */
public class WXViewToImageUtil {
    public static int mBackgroundColor;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/utils/WXViewToImageUtil$OnImageSavedCallback.class */
    public interface OnImageSavedCallback {
        void onSaveFailed(String str);

        void onSaveSucceed(String str);
    }

    public static void generateImage(View view, int i2, int i3, OnImageSavedCallback onImageSavedCallback) {
        mBackgroundColor = i3;
        WXSDKManager.getInstance().getWXWorkThreadManager().post(new Thread(new Runnable(view, i2, onImageSavedCallback) { // from class: com.taobao.weex.utils.WXViewToImageUtil.1
            final View val$imageView;
            final OnImageSavedCallback val$mOnImageSavedCallback;
            final int val$width;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.val$imageView = r4;
                this.val$width = r5;
                this.val$mOnImageSavedCallback = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                Bitmap bitmapFromImageView = WXViewToImageUtil.getBitmapFromImageView(this.val$imageView, this.val$width);
                if (bitmapFromImageView == null) {
                    OnImageSavedCallback onImageSavedCallback2 = this.val$mOnImageSavedCallback;
                    if (onImageSavedCallback2 != null) {
                        onImageSavedCallback2.onSaveFailed("Image is empty");
                        return;
                    }
                    return;
                }
                new Handler(Looper.getMainLooper()).post(new Runnable(this, WXViewToImageUtil.saveBitmapToGallery(this.val$imageView.getContext(), bitmapFromImageView, this.val$mOnImageSavedCallback)) { // from class: com.taobao.weex.utils.WXViewToImageUtil.1.1
                    final AnonymousClass1 this$0;
                    final String val$destPath;

                    /* JADX WARN: Incorrect args count in method signature: ()V */
                    {
                        this.this$0 = r4;
                        this.val$destPath = r5;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        if (this.this$0.val$mOnImageSavedCallback != null) {
                            this.this$0.val$mOnImageSavedCallback.onSaveSucceed(this.val$destPath);
                            this.this$0.val$imageView.getContext().sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse(this.val$destPath)));
                        }
                    }
                });
            }
        }));
    }

    public static Bitmap getBitmapFromImageView(View view, int i2) {
        if (view.getWidth() <= 0 || view.getHeight() <= 0) {
            view.measure(View.MeasureSpec.makeMeasureSpec(i2, 1073741824), View.MeasureSpec.makeMeasureSpec(0, 0));
            view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        }
        view.setDrawingCacheEnabled(true);
        return view.getDrawingCache();
    }

    public static String saveBitmapToGallery(Context context, Bitmap bitmap, OnImageSavedCallback onImageSavedCallback) {
        File file = new File(Environment.getExternalStorageDirectory(), "Weex");
        if (!file.exists()) {
            file.mkdir();
        }
        String str = System.currentTimeMillis() + ".jpg";
        File file2 = new File(file, str);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e2) {
            if (onImageSavedCallback != null) {
                onImageSavedCallback.onSaveFailed("Image creation failed due to system reason");
            }
            e2.printStackTrace();
        } catch (IOException e3) {
            if (onImageSavedCallback != null) {
                onImageSavedCallback.onSaveFailed("Android IOException");
            }
            e3.printStackTrace();
        }
        try {
            MediaStore.Images.Media.insertImage(context.getContentResolver(), file2.getAbsolutePath(), str, (String) null);
        } catch (FileNotFoundException e4) {
            e4.printStackTrace();
        }
        context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.parse(DeviceInfo.FILE_PROTOCOL + file.getAbsolutePath() + Operators.DIV + str)));
        return file2.getAbsolutePath();
    }
}
