package com.taobao.weex.http;

import com.taobao.weex.common.Constants;
import com.taobao.weex.ui.component.WXImage;
import io.dcloud.common.DHInterface.IReflectAble;
/* loaded from: Coinglobal1.jar:com/taobao/weex/http/CertJSResponse.class */
public class CertJSResponse implements IReflectAble {
    public int code;
    public String message;
    public String type;

    public static CertJSResponse obtainFail(int i2, String str) {
        CertJSResponse certJSResponse = new CertJSResponse();
        certJSResponse.type = Constants.Event.FAIL;
        certJSResponse.code = i2;
        certJSResponse.message = str;
        return certJSResponse;
    }

    public static CertJSResponse obtainSuccess() {
        CertJSResponse certJSResponse = new CertJSResponse();
        certJSResponse.type = WXImage.SUCCEED;
        certJSResponse.code = 0;
        certJSResponse.message = "";
        return certJSResponse;
    }
}
