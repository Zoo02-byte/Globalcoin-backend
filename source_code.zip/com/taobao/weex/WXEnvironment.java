package com.taobao.weex;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.WXConfig;
import com.taobao.weex.utils.FontDO;
import com.taobao.weex.utils.LogLevel;
import com.taobao.weex.utils.TypefaceUtil;
import com.taobao.weex.utils.WXFileUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXSoInstallMgrSdk;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import dalvik.system.PathClassLoader;
import io.dcloud.common.DHInterface.IApp;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.common.util.BaseInfo;
import io.dcloud.feature.uniapp.utils.AbsLogLevel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
/* loaded from: Coinglobal1.jar:com/taobao/weex/WXEnvironment.class */
public class WXEnvironment {
    public static boolean AUTO_ADJUST_ENV_DEVICE_WIDTH;
    public static boolean AUTO_UPDATE_APPLICATION_SCREEN_SIZE;
    private static String COPY_SO_DES_DIR;
    public static final String CORE_JSB_SO_NAME;
    public static String CORE_JSB_SO_PATH;
    public static final String CORE_JSC_SO_NAME;
    private static String CORE_JSC_SO_PATH;
    private static String CORE_JSS_ICU_PATH;
    public static String CORE_JSS_RUNTIME_SO_PATH;
    public static final String CORE_JSS_SO_NAME;
    private static String CORE_JSS_SO_PATH;
    public static final String CORE_JST_SO_NAME;
    public static final String CORE_SO_NAME;
    public static final String DEV_Id;
    public static final String EAGLE;
    public static final String ENVIRONMENT;
    public static String JS_LIB_SDK_VERSION;
    public static volatile boolean JsFrameworkInit;
    private static String LIB_LD_PATH;
    public static final String OS;
    public static final String SETTING_EXCLUDE_X86SUPPORT;
    public static boolean SETTING_FORCE_VERTICAL_SCREEN;
    public static final String SYS_MODEL;
    public static String SYS_VERSION;
    public static final String WEEX_CURRENT_KEY;
    public static String WXSDK_VERSION;
    private static boolean isApkDebug;
    public static boolean isPerf;
    public static volatile boolean isWsFixMode;
    private static float mViewProt;
    private static WXDefaultSettings mWXDefaultSettings;
    private static boolean openDebugLog;
    private static Map<String, String> options;
    public static Application sApplication;
    public static long sComponentsAndModulesReadyTime;
    private static boolean sDebugFlagInit;
    public static boolean sDebugMode;
    public static boolean sDebugNetworkEventReporterEnable;
    public static boolean sDebugServerConnectable;
    public static String sDebugWsUrl;
    @Deprecated
    public static int sDefaultWidth;
    public static boolean sDynamicMode;
    public static String sDynamicUrl;
    public static final boolean sForceEnableDevTool;
    private static String sGlobalFontFamily;
    public static boolean sInAliWeex;
    public static long sJSFMStartListenerTime;
    public static long sJSLibInitTime;
    public static AbsLogLevel sLogLevel;
    public static boolean sRemoteDebugMode;
    public static String sRemoteDebugProxyUrl;
    public static long sSDKInitExecuteTime;
    public static long sSDKInitInvokeTime;
    public static long sSDKInitStart;
    public static long sSDKInitTime;
    public static volatile boolean sUseRunTimeApi;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/WXEnvironment$WXDefaultSettings.class */
    public static class WXDefaultSettings {
        private String configName = "weex_default_settings";
        private SharedPreferences sharedPreferences;

        public WXDefaultSettings(Application application) {
            this.sharedPreferences = null;
            if (application != null) {
                this.sharedPreferences = application.getSharedPreferences("weex_default_settings", 0);
            }
        }

        public String getValue(String str, String str2) {
            synchronized (this) {
                if (this.sharedPreferences != null && !TextUtils.isEmpty(str)) {
                    String string = this.sharedPreferences.getString(str, str2);
                    WXLogUtils.i("get default settings " + str + " : " + string);
                    return string;
                }
                WXLogUtils.i("get default settings " + str + " return default value :" + str2);
                return str2;
            }
        }

        public void saveValue(String str, String str2) {
            synchronized (this) {
                if (this.sharedPreferences != null && !TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2)) {
                    WXLogUtils.i("save default settings " + str + ":" + str2);
                    SharedPreferences.Editor edit = this.sharedPreferences.edit();
                    edit.putString(str, str2);
                    edit.apply();
                }
            }
        }
    }

    static {
        String str = Build.VERSION.RELEASE;
        SYS_VERSION = str;
        if (str != null && str.toUpperCase(Locale.ROOT).equals("P")) {
            SYS_VERSION = "9.0.0";
        }
        String str2 = SYS_VERSION;
        if (str2 != null && str2.toUpperCase(Locale.ROOT).equals("Q")) {
            SYS_VERSION = "10.0.0";
        }
        SYS_MODEL = Build.MODEL;
        JS_LIB_SDK_VERSION = BuildConfig.buildJavascriptFrameworkVersion;
        WXSDK_VERSION = BuildConfig.buildVersion;
        DEV_Id = getDevId();
        sDefaultWidth = 750;
        JsFrameworkInit = false;
        SETTING_FORCE_VERTICAL_SCREEN = false;
        AUTO_ADJUST_ENV_DEVICE_WIDTH = true;
        AUTO_UPDATE_APPLICATION_SCREEN_SIZE = true;
        sUseRunTimeApi = false;
        sDebugMode = false;
        sDebugWsUrl = "";
        sDebugServerConnectable = false;
        sRemoteDebugMode = false;
        sRemoteDebugProxyUrl = "";
        sDebugNetworkEventReporterEnable = false;
        sJSLibInitTime = 0;
        sSDKInitStart = 0;
        sSDKInitInvokeTime = 0;
        sSDKInitExecuteTime = 0;
        sSDKInitTime = 0;
        sJSFMStartListenerTime = 0;
        isWsFixMode = true;
        sComponentsAndModulesReadyTime = 0;
        sInAliWeex = false;
        sLogLevel = LogLevel.DEBUG;
        isApkDebug = true;
        isPerf = false;
        sDebugFlagInit = false;
        openDebugLog = true;
        CORE_JSS_SO_PATH = null;
        CORE_JSS_RUNTIME_SO_PATH = null;
        CORE_JSS_ICU_PATH = null;
        CORE_JSC_SO_PATH = null;
        CORE_JSB_SO_PATH = null;
        COPY_SO_DES_DIR = null;
        LIB_LD_PATH = null;
        mViewProt = 750.0f;
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        options = concurrentHashMap;
        concurrentHashMap.put(WXConfig.os, OS);
        options.put(WXConfig.osName, OS);
        sDynamicMode = false;
        sDynamicUrl = "";
    }

    public static void addCustomOptions(String str, String str2) {
        options.put(str, str2);
    }

    public static String copySoDesDir() {
        File file;
        try {
            if (TextUtils.isEmpty(COPY_SO_DES_DIR)) {
                if (sApplication == null) {
                    WXLogUtils.e("sApplication is null, so copy path will be null");
                    return null;
                }
                String path = getApplication().getApplicationContext().getCacheDir().getPath();
                if (!TextUtils.isEmpty(path)) {
                    file = new File(path, "/cache/weex/libs");
                } else {
                    file = new File("/data/data/" + sApplication.getPackageName() + "/cache/weex/libs");
                }
                if (!file.exists()) {
                    file.mkdirs();
                }
                COPY_SO_DES_DIR = file.getAbsolutePath();
            }
        } catch (Throwable th) {
            WXLogUtils.e(WXLogUtils.getStackTrace(th));
        }
        return COPY_SO_DES_DIR;
    }

    public static boolean extractSo() {
        ArrayList arrayList = new ArrayList();
        String[] strArr = getApplication().getApplicationContext().getApplicationInfo().splitSourceDirs;
        if (strArr != null) {
            for (String str : strArr) {
                if (str.contains(Build.CPU_ABI)) {
                    arrayList.add(0, str);
                } else {
                    arrayList.add(str);
                }
            }
        }
        File file = new File(getApplication().getApplicationContext().getApplicationInfo().sourceDir);
        if (file.exists()) {
            arrayList.add(file.getAbsolutePath());
        }
        String copySoDesDir = copySoDesDir();
        if (arrayList.size() <= 0 || TextUtils.isEmpty(copySoDesDir)) {
            return false;
        }
        try {
            Iterator it = arrayList.iterator();
            do {
                if (!it.hasNext()) {
                    return true;
                }
            } while (!WXFileUtils.extractSo((String) it.next(), copySoDesDir));
            return true;
        } catch (IOException e2) {
            WXLogUtils.e("extractSo error " + e2.getMessage());
            return false;
        }
    }

    private static String findIcuPath() {
        Throwable th;
        IOException e2;
        BufferedReader bufferedReader;
        String readLine;
        BufferedReader bufferedReader2 = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(new File("/proc/self/maps")));
        } catch (IOException e3) {
            e2 = e3;
            bufferedReader = null;
        } catch (Throwable th2) {
            th = th2;
        }
        do {
            bufferedReader2 = bufferedReader;
            try {
                try {
                    readLine = bufferedReader.readLine();
                } catch (IOException e4) {
                    e2 = e4;
                    e2.printStackTrace();
                    if (bufferedReader == null) {
                        return null;
                    }
                    try {
                        bufferedReader.close();
                        return null;
                    } catch (IOException e5) {
                        return null;
                    }
                }
                if (readLine == null) {
                    bufferedReader.close();
                    bufferedReader.close();
                    return null;
                }
            } catch (Throwable th3) {
                th = th3;
                if (bufferedReader2 != null) {
                    try {
                        bufferedReader2.close();
                    } catch (IOException e6) {
                    }
                }
                throw th;
            }
        } while (!readLine.contains("icudt"));
        String trim = readLine.substring(readLine.indexOf(47)).trim();
        try {
            bufferedReader.close();
        } catch (IOException e7) {
        }
        return trim;
    }

    public static String findSoPath(String str) {
        String findLibrary = ((PathClassLoader) WXEnvironment.class.getClassLoader()).findLibrary(str);
        if (!TextUtils.isEmpty(findLibrary)) {
            File file = new File(findLibrary);
            if (file.exists()) {
                WXLogUtils.e(str + "'s Path is" + findLibrary);
                return file.getAbsolutePath();
            }
            WXLogUtils.e(str + "'s Path is " + findLibrary + " but file does not exist");
        }
        String str2 = "lib" + str + ".so";
        String cacheDir = getCacheDir();
        if (TextUtils.isEmpty(cacheDir)) {
            WXLogUtils.e("cache dir is null");
            return "";
        }
        if (cacheDir.indexOf("/cache") > 0) {
            findLibrary = new File(cacheDir.replace("/cache", "/lib"), str2).getAbsolutePath();
        }
        if (new File(findLibrary).exists()) {
            WXLogUtils.e(str + "use lib so");
            return findLibrary;
        }
        File file2 = new File(copySoDesDir(), str2);
        return file2.exists() ? file2.getAbsolutePath() : extractSo() ? new File(getCacheDir(), str2).getAbsolutePath() : findLibrary;
    }

    private static String getAppCacheFile() {
        String str;
        try {
            str = sApplication.getApplicationContext().getCacheDir().getPath();
        } catch (Exception e2) {
            WXLogUtils.e("WXEnvironment getAppCacheFile Exception: ", e2);
            str = "";
        }
        return str;
    }

    public static String getAppVersionName() {
        String str;
        try {
            str = sApplication.getPackageManager().getPackageInfo(sApplication.getPackageName(), 0).versionName;
        } catch (Exception e2) {
            WXLogUtils.e("WXEnvironment getAppVersionName Exception: ", e2);
            str = "";
        }
        return str;
    }

    public static Application getApplication() {
        return sApplication;
    }

    public static String getCacheDir() {
        Application application = getApplication();
        if (application == null || application.getApplicationContext() == null) {
            return null;
        }
        return application.getApplicationContext().getCacheDir().getPath();
    }

    public static Map<String, String> getConfig() {
        Application application;
        HashMap hashMap = new HashMap();
        hashMap.put(WXConfig.os, OS);
        hashMap.put(WXConfig.appVersion, getAppVersionName());
        hashMap.put(WXConfig.cacheDir, getAppCacheFile());
        hashMap.put(WXConfig.devId, DEV_Id);
        hashMap.put(WXConfig.sysVersion, SYS_VERSION);
        hashMap.put(WXConfig.sysModel, SYS_MODEL);
        hashMap.put(WXConfig.weexVersion, String.valueOf(WXSDK_VERSION));
        if (sRemoteDebugMode) {
            hashMap.put(WXConfig.logLevel, "log");
        } else {
            hashMap.put(WXConfig.logLevel, sLogLevel.getName());
        }
        try {
            hashMap.put(WXConfig.layoutDirection, isLayoutDirectionRTL() ? Constants.Name.RTL : "ltr");
        } catch (Exception e2) {
            hashMap.put(WXConfig.layoutDirection, "ltr");
        }
        try {
            if (isApkDebugable()) {
                addCustomOptions(WXConfig.debugMode, AbsoluteConst.TRUE);
            }
            addCustomOptions("scale", Float.toString(sApplication.getResources().getDisplayMetrics().density));
            addCustomOptions(WXConfig.androidStatusBarHeight, Float.toString((float) WXViewUtils.getStatusBarHeight(sApplication)));
        } catch (NullPointerException e3) {
            WXLogUtils.e("WXEnvironment scale Exception: ", e3);
        }
        hashMap.putAll(getCustomOptions());
        if (hashMap.get(WXConfig.appName) == null && (application = sApplication) != null) {
            hashMap.put(WXConfig.appName, application.getPackageName());
        }
        return hashMap;
    }

    public static String getCrashFilePath(Context context) {
        File dir;
        return (context == null || (dir = context.getDir(IApp.ConfigProperty.CONFIG_CRASH, 0)) == null) ? "" : dir.getAbsolutePath();
    }

    public static String getCustomOptions(String str) {
        return options.get(str);
    }

    @Deprecated
    public static Map<String, String> getCustomOptions() {
        return options;
    }

    public static String getDefaultSettingValue(String str, String str2) {
        synchronized (WXEnvironment.class) {
            try {
                WXDefaultSettings wXDefaultSettings = getWXDefaultSettings();
                if (wXDefaultSettings != null && !TextUtils.isEmpty(str)) {
                    return wXDefaultSettings.getValue(str, str2);
                }
                return str2;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private static String getDevId() {
        return "";
    }

    public static String getDiskCacheDir(Context context) {
        String str = null;
        if (context == null) {
            return null;
        }
        try {
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        if (!"mounted".equals(Environment.getExternalStorageState()) && Environment.isExternalStorageRemovable()) {
            str = context.getCacheDir().getPath();
            return str;
        }
        str = context.getExternalCacheDir().getPath();
        return str;
    }

    public static String getFilesDir(Context context) {
        String str;
        if (context == null) {
            return "";
        }
        File filesDir = context.getFilesDir();
        if (filesDir != null) {
            str = filesDir.getPath();
        } else {
            str = (getApplication().getApplicationInfo().dataDir + File.separator) + "files";
        }
        return str;
    }

    public static String getGlobalFontFamilyName() {
        return sGlobalFontFamily;
    }

    public static String getLibJScRealPath() {
        return "";
    }

    public static String getLibJssIcuPath() {
        if (TextUtils.isEmpty(CORE_JSS_ICU_PATH)) {
            CORE_JSS_ICU_PATH = findIcuPath();
        }
        return CORE_JSS_ICU_PATH;
    }

    public static String getLibJssRealPath() {
        if (!sUseRunTimeApi || TextUtils.isEmpty(CORE_JSS_RUNTIME_SO_PATH)) {
            if (TextUtils.isEmpty(CORE_JSS_SO_PATH)) {
                CORE_JSS_SO_PATH = findSoPath(CORE_JSS_SO_NAME);
                WXLogUtils.d("test-> findLibJssRealPath " + CORE_JSS_SO_PATH);
            }
            return CORE_JSS_SO_PATH;
        }
        WXLogUtils.d("test-> findLibJssRuntimeRealPath " + CORE_JSS_RUNTIME_SO_PATH);
        return CORE_JSS_RUNTIME_SO_PATH;
    }

    public static String getLibLdPath() {
        if (TextUtils.isEmpty(LIB_LD_PATH)) {
            ClassLoader classLoader = WXEnvironment.class.getClassLoader();
            try {
                LIB_LD_PATH = (String) classLoader.getClass().getMethod("getLdLibraryPath", new Class[0]).invoke(classLoader, new Object[0]);
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
            } catch (NoSuchMethodException e3) {
                e3.printStackTrace();
            } catch (InvocationTargetException e4) {
                e4.printStackTrace();
            }
        }
        if (TextUtils.isEmpty(LIB_LD_PATH)) {
            try {
                String property = System.getProperty("java.library.path");
                String libJScRealPath = getLibJScRealPath();
                if (!TextUtils.isEmpty(libJScRealPath)) {
                    LIB_LD_PATH = new File(libJScRealPath).getParent() + ":" + property;
                }
            } catch (Exception e5) {
                e5.printStackTrace();
            }
        }
        WXLogUtils.d("getLibLdPath is " + LIB_LD_PATH);
        return LIB_LD_PATH;
    }

    public static float getViewProt() {
        return mViewProt;
    }

    public static WXDefaultSettings getWXDefaultSettings() {
        WXDefaultSettings wXDefaultSettings;
        synchronized (WXEnvironment.class) {
            try {
                if (mWXDefaultSettings == null && getApplication() != null) {
                    mWXDefaultSettings = new WXDefaultSettings(getApplication());
                }
                wXDefaultSettings = mWXDefaultSettings;
            } catch (Throwable th) {
                throw th;
            }
        }
        return wXDefaultSettings;
    }

    public static boolean isApkDebugable() {
        return isApkDebugable(sApplication);
    }

    public static boolean isApkDebugable(Application application) {
        if (application == null || isPerf) {
            return false;
        }
        if (sDebugFlagInit) {
            return isApkDebug;
        }
        if (!isApkDebug && BaseInfo.SyncDebug) {
            isApkDebug = true;
        } else if (isApkDebug && !BaseInfo.SyncDebug) {
            isApkDebug = false;
        }
        sDebugFlagInit = true;
        return isApkDebug;
    }

    public static boolean isCPUSupport() {
        boolean z2 = true;
        boolean z3 = WXSoInstallMgrSdk.isX86() && AbsoluteConst.TRUE.equals(getCustomOptions().get(SETTING_EXCLUDE_X86SUPPORT));
        if (!WXSoInstallMgrSdk.isCPUSupport() || z3) {
            z2 = false;
        }
        if (isApkDebugable()) {
            WXLogUtils.d("WXEnvironment.sSupport:" + z2 + "isX86AndExclueded: " + z3);
        }
        return z2;
    }

    @Deprecated
    public static boolean isHardwareSupport() {
        if (isApkDebugable()) {
            WXLogUtils.d("isTableDevice:" + WXUtils.isTabletDevice());
        }
        return isCPUSupport();
    }

    public static boolean isLayoutDirectionRTL() {
        return sApplication.getApplicationContext().getResources().getBoolean(R.bool.weex_is_right_to_left);
    }

    public static boolean isOpenDebugLog() {
        return openDebugLog;
    }

    public static boolean isPerf() {
        return isPerf;
    }

    @Deprecated
    public static boolean isSupport() {
        boolean isInitialized = WXSDKEngine.isInitialized();
        if (!isInitialized) {
            WXLogUtils.e("WXSDKEngine.isInitialized():" + isInitialized);
        }
        return isHardwareSupport() && isInitialized;
    }

    public static void setApkDebugable(boolean z2) {
        isApkDebug = z2;
        if (!z2) {
            openDebugLog = false;
        }
    }

    public static void setGlobalFontFamily(String str, Typeface typeface) {
        WXLogUtils.d("GlobalFontFamily", "Set global font family: " + str);
        sGlobalFontFamily = str;
        if (TextUtils.isEmpty(str)) {
            return;
        }
        if (typeface == null) {
            TypefaceUtil.removeFontDO(str);
            return;
        }
        TypefaceUtil.putFontDO(new FontDO(str, typeface));
        WXLogUtils.d("TypefaceUtil", "Add new font: " + str);
    }

    public static void setOpenDebugLog(boolean z2) {
        openDebugLog = z2;
    }

    public static void setViewProt(float f2) {
        mViewProt = f2;
    }

    public static void writeDefaultSettingsValue(String str, String str2) {
        synchronized (WXEnvironment.class) {
            try {
                WXDefaultSettings wXDefaultSettings = getWXDefaultSettings();
                if (wXDefaultSettings != null && !TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2)) {
                    wXDefaultSettings.saveValue(str, str2);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void initMetrics() {
    }
}
