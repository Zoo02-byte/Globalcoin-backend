package com.taobao.weex;
/* loaded from: Coinglobal1.jar:com/taobao/weex/R.class */
public final class R {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$attr.class */
    public static final class attr {
        public static int sb_background = 0x7f020108;
        public static int sb_border_width = 0x7f020109;
        public static int sb_button_color = 0x7f02010a;
        public static int sb_checked = 0x7f02010b;
        public static int sb_checked_color = 0x7f02010c;
        public static int sb_checkline_color = 0x7f02010d;
        public static int sb_checkline_width = 0x7f02010e;
        public static int sb_effect_duration = 0x7f02010f;
        public static int sb_enable_effect = 0x7f020110;
        public static int sb_shadow_color = 0x7f020111;
        public static int sb_shadow_effect = 0x7f020112;
        public static int sb_shadow_offset = 0x7f020113;
        public static int sb_shadow_radius = 0x7f020114;
        public static int sb_show_indicator = 0x7f020115;
        public static int sb_uncheck_color = 0x7f020116;
        public static int sb_uncheckcircle_color = 0x7f020117;
        public static int sb_uncheckcircle_radius = 0x7f020118;
        public static int sb_uncheckcircle_width = 0x7f020119;

        private attr() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$bool.class */
    public static final class bool {
        public static int weex_is_right_to_left = 0x7f030003;

        private bool() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$drawable.class */
    public static final class drawable {
        public static int weex_error = 0x7f060101;

        private drawable() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$layout.class */
    public static final class layout {
        public static int weex_recycler_layout = 0x7f0a005d;

        private layout() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$string.class */
    public static final class string {
        public static int dcloud_feature_weex_jsfk_not_found_tips = 0x7f0d008f;
        public static int dcloud_feature_weex_msg_cannot_find_file_by_path = 0x7f0d0090;
        public static int dcloud_feature_weex_msg_page_destroyed = 0x7f0d0091;
        public static int dcloud_feature_weex_msg_param_empty = 0x7f0d0092;
        public static int dcloud_feature_weex_msg_param_invalid = 0x7f0d0093;

        private string() {
        }
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/R$styleable.class */
    public static final class styleable {
        public static int[] SwitchButton = {2130837768, 2130837769, 2130837770, 2130837771, 2130837772, 2130837773, 2130837774, 2130837775, 2130837776, 2130837777, 2130837778, 2130837779, 2130837780, 2130837781, 2130837782, 2130837783, 2130837784, 2130837785};
        public static int SwitchButton_sb_background = 0x00000000;
        public static int SwitchButton_sb_border_width = 0x00000001;
        public static int SwitchButton_sb_button_color = 0x00000002;
        public static int SwitchButton_sb_checked = 0x00000003;
        public static int SwitchButton_sb_checked_color = 0x00000004;
        public static int SwitchButton_sb_checkline_color = 0x00000005;
        public static int SwitchButton_sb_checkline_width = 0x00000006;
        public static int SwitchButton_sb_effect_duration = 0x00000007;
        public static int SwitchButton_sb_enable_effect = 0x00000008;
        public static int SwitchButton_sb_shadow_color = 0x00000009;
        public static int SwitchButton_sb_shadow_effect = 0x0000000a;
        public static int SwitchButton_sb_shadow_offset = 0x0000000b;
        public static int SwitchButton_sb_shadow_radius = 0x0000000c;
        public static int SwitchButton_sb_show_indicator = 0x0000000d;
        public static int SwitchButton_sb_uncheck_color = 0x0000000e;
        public static int SwitchButton_sb_uncheckcircle_color = 0x0000000f;
        public static int SwitchButton_sb_uncheckcircle_radius = 0x00000010;
        public static int SwitchButton_sb_uncheckcircle_width = 0x00000011;

        private styleable() {
        }
    }

    private R() {
    }
}
