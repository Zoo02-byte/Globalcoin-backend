package com.taobao.weex;

import android.util.Log;
import android.view.Choreographer;
import com.taobao.weex.common.WXErrorCode;
import java.lang.ref.WeakReference;
/* loaded from: Coinglobal1.jar:com/taobao/weex/WeexFrameRateControl.class */
public class WeexFrameRateControl {
    private static final long VSYNC_FRAME = 16;
    private WeakReference<VSyncListener> mListener;
    private final Choreographer mChoreographer = Choreographer.getInstance();
    private final Choreographer.FrameCallback mVSyncFrameCallback = new Choreographer.FrameCallback(this) { // from class: com.taobao.weex.WeexFrameRateControl.1
        final WeexFrameRateControl this$0;

        {
            this.this$0 = r4;
        }

        @Override // android.view.Choreographer.FrameCallback
        public void doFrame(long j2) {
            VSyncListener vSyncListener;
            if (this.this$0.mListener != null && (vSyncListener = (VSyncListener) this.this$0.mListener.get()) != null) {
                try {
                    vSyncListener.OnVSync();
                    this.this$0.mChoreographer.postFrameCallback(this.this$0.mVSyncFrameCallback);
                } catch (UnsatisfiedLinkError e2) {
                    if (vSyncListener instanceof WXSDKInstance) {
                        ((WXSDKInstance) vSyncListener).onRenderError(WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorCode(), Log.getStackTraceString(e2));
                    }
                }
            }
        }
    };
    private final Runnable runnable = null;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/WeexFrameRateControl$VSyncListener.class */
    public interface VSyncListener {
        void OnVSync();
    }

    public WeexFrameRateControl(VSyncListener vSyncListener) {
        this.mListener = new WeakReference<>(vSyncListener);
    }

    public void start() {
        Choreographer choreographer = this.mChoreographer;
        if (choreographer != null) {
            choreographer.postFrameCallback(this.mVSyncFrameCallback);
        } else if (this.runnable != null) {
            WXSDKManager.getInstance().getWXRenderManager().postOnUiThread(this.runnable, 16);
        }
    }

    public void stop() {
        Choreographer choreographer = this.mChoreographer;
        if (choreographer != null) {
            choreographer.removeFrameCallback(this.mVSyncFrameCallback);
        } else if (this.runnable != null) {
            WXSDKManager.getInstance().getWXRenderManager().removeTask(this.runnable);
        }
    }
}
