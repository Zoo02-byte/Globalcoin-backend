package com.taobao.weex;

import android.view.View;
/* loaded from: Coinglobal1.jar:com/taobao/weex/IWXRenderListener.class */
public interface IWXRenderListener {
    void onException(WXSDKInstance wXSDKInstance, String str, String str2);

    void onRefreshSuccess(WXSDKInstance wXSDKInstance, int i2, int i3);

    void onRenderSuccess(WXSDKInstance wXSDKInstance, int i2, int i3);

    void onViewCreated(WXSDKInstance wXSDKInstance, View view);
}
