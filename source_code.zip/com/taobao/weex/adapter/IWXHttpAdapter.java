package com.taobao.weex.adapter;

import com.taobao.weex.common.WXRequest;
import com.taobao.weex.common.WXResponse;
import java.util.List;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXHttpAdapter.class */
public interface IWXHttpAdapter {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXHttpAdapter$OnHttpListener.class */
    public interface OnHttpListener {
        void onHeadersReceived(int i2, Map<String, List<String>> map);

        void onHttpFinish(WXResponse wXResponse);

        void onHttpResponseProgress(int i2);

        void onHttpStart();

        void onHttpUploadProgress(int i2);
    }

    void sendRequest(WXRequest wXRequest, OnHttpListener onHttpListener);
}
