package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXConfigAdapter.class */
public interface IWXConfigAdapter {
    boolean checkMode(String str);

    String getConfig(String str, String str2, String str3);

    String getConfigWhenInit(String str, String str2, String str3);
}
