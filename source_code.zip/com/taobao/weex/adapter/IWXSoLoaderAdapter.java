package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXSoLoaderAdapter.class */
public interface IWXSoLoaderAdapter {
    void doLoad(String str);

    void doLoadLibrary(String str);
}
