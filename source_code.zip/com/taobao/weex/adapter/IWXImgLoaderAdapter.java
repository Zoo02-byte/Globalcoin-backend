package com.taobao.weex.adapter;

import android.widget.ImageView;
import com.taobao.weex.common.WXImageStrategy;
import com.taobao.weex.dom.WXImageQuality;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXImgLoaderAdapter.class */
public interface IWXImgLoaderAdapter {
    void setImage(String str, ImageView imageView, WXImageQuality wXImageQuality, WXImageStrategy wXImageStrategy);
}
