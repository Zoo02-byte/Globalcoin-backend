package com.taobao.weex.adapter;

import android.graphics.drawable.Drawable;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IDrawableLoader.class */
public interface IDrawableLoader {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IDrawableLoader$AnimatedTarget.class */
    public interface AnimatedTarget extends DrawableTarget {
        void setAnimatedDrawable(Drawable drawable);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IDrawableLoader$DrawableTarget.class */
    public interface DrawableTarget {
        void setDrawable(Drawable drawable, boolean z2);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IDrawableLoader$StaticTarget.class */
    public interface StaticTarget extends DrawableTarget {
        @Override // com.taobao.weex.adapter.IDrawableLoader.DrawableTarget
        void setDrawable(Drawable drawable, boolean z2);
    }

    void setDrawable(String str, DrawableTarget drawableTarget, DrawableStrategy drawableStrategy);
}
