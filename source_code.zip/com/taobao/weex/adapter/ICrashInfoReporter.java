package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/ICrashInfoReporter.class */
public interface ICrashInfoReporter {
    void addCrashInfo(String str, String str2);
}
