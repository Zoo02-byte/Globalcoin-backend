package com.taobao.weex.adapter;

import io.dcloud.feature.uniapp.adapter.AbsURIAdapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/URIAdapter.class */
public interface URIAdapter extends AbsURIAdapter {
}
