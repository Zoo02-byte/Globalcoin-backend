package com.taobao.weex.adapter;

import com.taobao.weex.common.WXJSExceptionInfo;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXJSExceptionAdapter.class */
public interface IWXJSExceptionAdapter {
    void onJSException(WXJSExceptionInfo wXJSExceptionInfo);
}
