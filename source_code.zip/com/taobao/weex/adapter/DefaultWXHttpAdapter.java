package com.taobao.weex.adapter;

import android.text.TextUtils;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXHttpAdapter;
import com.taobao.weex.common.WXRequest;
import com.taobao.weex.common.WXResponse;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/DefaultWXHttpAdapter.class */
public class DefaultWXHttpAdapter implements IWXHttpAdapter {
    private static final IEventReporterDelegate DEFAULT_DELEGATE = new NOPEventReportDelegate();
    private ExecutorService mExecutorService;

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/DefaultWXHttpAdapter$IEventReporterDelegate.class */
    public interface IEventReporterDelegate {
        void httpExchangeFailed(IOException iOException);

        InputStream interpretResponseStream(InputStream inputStream);

        void postConnect();

        void preConnect(HttpURLConnection httpURLConnection, String str);
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/DefaultWXHttpAdapter$NOPEventReportDelegate.class */
    private static class NOPEventReportDelegate implements IEventReporterDelegate {
        private NOPEventReportDelegate() {
        }

        @Override // com.taobao.weex.adapter.DefaultWXHttpAdapter.IEventReporterDelegate
        public void httpExchangeFailed(IOException iOException) {
        }

        @Override // com.taobao.weex.adapter.DefaultWXHttpAdapter.IEventReporterDelegate
        public InputStream interpretResponseStream(InputStream inputStream) {
            return inputStream;
        }

        @Override // com.taobao.weex.adapter.DefaultWXHttpAdapter.IEventReporterDelegate
        public void postConnect() {
        }

        @Override // com.taobao.weex.adapter.DefaultWXHttpAdapter.IEventReporterDelegate
        public void preConnect(HttpURLConnection httpURLConnection, String str) {
        }
    }

    private void execute(Runnable runnable) {
        if (this.mExecutorService == null) {
            this.mExecutorService = Executors.newFixedThreadPool(3);
        }
        this.mExecutorService.execute(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public HttpURLConnection openConnection(WXRequest wXRequest, IWXHttpAdapter.OnHttpListener onHttpListener) throws IOException {
        HttpURLConnection createConnection = createConnection(new URL(wXRequest.url));
        createConnection.setConnectTimeout(wXRequest.timeoutMs);
        createConnection.setReadTimeout(wXRequest.timeoutMs);
        createConnection.setUseCaches(false);
        createConnection.setDoInput(true);
        if (wXRequest.paramMap != null) {
            for (String str : wXRequest.paramMap.keySet()) {
                createConnection.addRequestProperty(str, wXRequest.paramMap.get(str));
            }
        }
        if ("POST".equals(wXRequest.method) || "PUT".equals(wXRequest.method) || "PATCH".equals(wXRequest.method)) {
            createConnection.setRequestMethod(wXRequest.method);
            if (wXRequest.body != null) {
                if (onHttpListener != null) {
                    onHttpListener.onHttpUploadProgress(0);
                }
                createConnection.setDoOutput(true);
                DataOutputStream dataOutputStream = new DataOutputStream(createConnection.getOutputStream());
                dataOutputStream.write(wXRequest.body.getBytes());
                dataOutputStream.close();
                if (onHttpListener != null) {
                    onHttpListener.onHttpUploadProgress(100);
                }
            }
        } else if (!TextUtils.isEmpty(wXRequest.method)) {
            createConnection.setRequestMethod(wXRequest.method);
        } else {
            createConnection.setRequestMethod("GET");
        }
        return createConnection;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String readInputStream(InputStream inputStream, IWXHttpAdapter.OnHttpListener onHttpListener) throws IOException {
        if (inputStream == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        char[] cArr = new char[2048];
        while (true) {
            int read = bufferedReader.read(cArr);
            if (read != -1) {
                sb.append(cArr, 0, read);
                if (onHttpListener != null) {
                    onHttpListener.onHttpResponseProgress(sb.length());
                }
            } else {
                bufferedReader.close();
                return sb.toString();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public byte[] readInputStreamAsBytes(InputStream inputStream, IWXHttpAdapter.OnHttpListener onHttpListener) throws IOException {
        if (inputStream == null) {
            return null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[2048];
        int i2 = 0;
        while (true) {
            int read = inputStream.read(bArr, 0, 2048);
            if (read != -1) {
                byteArrayOutputStream.write(bArr, 0, read);
                int i3 = i2 + read;
                i2 = i3;
                if (onHttpListener != null) {
                    onHttpListener.onHttpResponseProgress(i3);
                    i2 = i3;
                }
            } else {
                byteArrayOutputStream.flush();
                return byteArrayOutputStream.toByteArray();
            }
        }
    }

    protected HttpURLConnection createConnection(URL url) throws IOException {
        return (HttpURLConnection) url.openConnection();
    }

    public IEventReporterDelegate getEventReporterDelegate() {
        return DEFAULT_DELEGATE;
    }

    @Override // com.taobao.weex.adapter.IWXHttpAdapter
    public void sendRequest(WXRequest wXRequest, IWXHttpAdapter.OnHttpListener onHttpListener) {
        if (onHttpListener != null) {
            onHttpListener.onHttpStart();
        }
        execute(new Runnable(this, wXRequest, onHttpListener) { // from class: com.taobao.weex.adapter.DefaultWXHttpAdapter.1
            final DefaultWXHttpAdapter this$0;
            final IWXHttpAdapter.OnHttpListener val$listener;
            final WXRequest val$request;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$request = r5;
                this.val$listener = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                boolean z2;
                WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(this.val$request.instanceId);
                if (wXSDKInstance != null && !wXSDKInstance.isDestroy()) {
                    wXSDKInstance.getApmForInstance().actionNetRequest();
                }
                WXResponse wXResponse = new WXResponse();
                IEventReporterDelegate eventReporterDelegate = this.this$0.getEventReporterDelegate();
                try {
                    HttpURLConnection openConnection = this.this$0.openConnection(this.val$request, this.val$listener);
                    eventReporterDelegate.preConnect(openConnection, this.val$request.body);
                    Map<String, List<String>> headerFields = openConnection.getHeaderFields();
                    int responseCode = openConnection.getResponseCode();
                    IWXHttpAdapter.OnHttpListener onHttpListener2 = this.val$listener;
                    if (onHttpListener2 != null) {
                        onHttpListener2.onHeadersReceived(responseCode, headerFields);
                    }
                    eventReporterDelegate.postConnect();
                    wXResponse.statusCode = String.valueOf(responseCode);
                    if (responseCode < 200 || responseCode > 299) {
                        wXResponse.errorMsg = this.this$0.readInputStream(openConnection.getErrorStream(), this.val$listener);
                        z2 = false;
                    } else {
                        wXResponse.originalData = this.this$0.readInputStreamAsBytes(eventReporterDelegate.interpretResponseStream(openConnection.getInputStream()), this.val$listener);
                        z2 = true;
                    }
                    IWXHttpAdapter.OnHttpListener onHttpListener3 = this.val$listener;
                    if (onHttpListener3 != null) {
                        onHttpListener3.onHttpFinish(wXResponse);
                    }
                } catch (IOException | IllegalArgumentException e2) {
                    e2.printStackTrace();
                    wXResponse.statusCode = "-1";
                    wXResponse.errorCode = "-1";
                    wXResponse.errorMsg = e2.getMessage();
                    IWXHttpAdapter.OnHttpListener onHttpListener4 = this.val$listener;
                    if (onHttpListener4 != null) {
                        onHttpListener4.onHttpFinish(wXResponse);
                    }
                    z2 = false;
                    if (e2 instanceof IOException) {
                        try {
                            eventReporterDelegate.httpExchangeFailed((IOException) e2);
                            z2 = false;
                        } catch (Throwable th) {
                            th.printStackTrace();
                            z2 = false;
                        }
                    }
                }
                if (wXSDKInstance != null && !wXSDKInstance.isDestroy()) {
                    wXSDKInstance.getApmForInstance().actionNetResult(z2, null);
                }
            }
        });
    }
}
