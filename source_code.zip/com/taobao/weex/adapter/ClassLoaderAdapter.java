package com.taobao.weex.adapter;

import android.content.Context;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.common.WXModule;
import com.taobao.weex.ui.component.WXComponent;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/ClassLoaderAdapter.class */
public class ClassLoaderAdapter {
    public Class<? extends WXComponent> getComponentClass(String str, String str2, WXSDKInstance wXSDKInstance) {
        try {
            return wXSDKInstance.getContext().getClassLoader().loadClass(str2);
        } catch (ClassNotFoundException e2) {
            throw new RuntimeException(e2);
        }
    }

    public Class<? extends WXModule> getModuleClass(String str, String str2, Context context) {
        try {
            return context.getClassLoader().loadClass(str2);
        } catch (ClassNotFoundException e2) {
            throw new RuntimeException(e2);
        }
    }
}
