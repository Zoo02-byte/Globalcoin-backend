package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/DrawableStrategy.class */
public class DrawableStrategy {
    public int height;
    public int width;
}
