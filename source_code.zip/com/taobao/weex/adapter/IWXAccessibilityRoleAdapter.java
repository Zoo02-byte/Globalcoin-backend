package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXAccessibilityRoleAdapter.class */
public interface IWXAccessibilityRoleAdapter {
    String getRole(String str);
}
