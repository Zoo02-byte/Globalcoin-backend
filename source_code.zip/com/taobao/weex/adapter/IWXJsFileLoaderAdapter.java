package com.taobao.weex.adapter;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXJsFileLoaderAdapter.class */
public interface IWXJsFileLoaderAdapter {
    String loadJsFramework();

    String loadJsFrameworkForSandBox();

    String loadRaxApi();
}
