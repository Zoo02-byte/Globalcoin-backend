package com.taobao.weex.adapter;

import com.taobao.weex.tracing.WXTracing;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/ITracingAdapter.class */
public interface ITracingAdapter {
    void disable();

    void enable();

    void submitTracingEvent(WXTracing.TraceEvent traceEvent);
}
