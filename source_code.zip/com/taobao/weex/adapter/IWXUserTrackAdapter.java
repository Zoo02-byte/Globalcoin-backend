package com.taobao.weex.adapter;

import android.content.Context;
import com.taobao.weex.common.WXPerformance;
import java.io.Serializable;
import java.util.Map;
/* loaded from: Coinglobal1.jar:com/taobao/weex/adapter/IWXUserTrackAdapter.class */
public interface IWXUserTrackAdapter {
    public static final String COUNTER;
    public static final String DOM_MODULE;
    public static final String INIT_FRAMEWORK;
    public static final String INVOKE_MODULE;
    public static final String JS_BRIDGE;
    public static final String JS_DOWNLOAD;
    public static final String JS_FRAMEWORK;
    public static final String LOAD;
    public static final String MODULE_NAME;
    public static final String MONITOR_ARG;
    public static final String MONITOR_ERROR_CODE;
    public static final String MONITOR_ERROR_MSG;
    public static final String STREAM_MODULE;

    void commit(Context context, String str, String str2, WXPerformance wXPerformance, Map<String, Serializable> map);
}
