package com.taobao.weex;

import android.content.Context;
import android.util.AttributeSet;
import com.taobao.weex.WeexFrameRateControl;
import com.taobao.weex.render.WXAbstractRenderContainer;
/* loaded from: Coinglobal1.jar:com/taobao/weex/RenderContainer.class */
public class RenderContainer extends WXAbstractRenderContainer implements WeexFrameRateControl.VSyncListener {
    private WeexFrameRateControl mFrameRateControl = new WeexFrameRateControl(this);

    public RenderContainer(Context context) {
        super(context);
    }

    public RenderContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public RenderContainer(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
    }

    public RenderContainer(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
    }

    @Override // com.taobao.weex.WeexFrameRateControl.VSyncListener
    public void OnVSync() {
        if (this.mSDKInstance != null && this.mSDKInstance.get() != null) {
            ((WXSDKInstance) this.mSDKInstance.get()).OnVSync();
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    public void dispatchWindowVisibilityChanged(int i2) {
        WeexFrameRateControl weexFrameRateControl;
        dispatchWindowVisibilityChanged(i2);
        if (i2 == 8) {
            WeexFrameRateControl weexFrameRateControl2 = this.mFrameRateControl;
            if (weexFrameRateControl2 != null) {
                weexFrameRateControl2.stop();
            }
        } else if (i2 == 0 && (weexFrameRateControl = this.mFrameRateControl) != null) {
            weexFrameRateControl.start();
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    public void onAttachedToWindow() {
        onAttachedToWindow();
        WeexFrameRateControl weexFrameRateControl = this.mFrameRateControl;
        if (weexFrameRateControl != null) {
            weexFrameRateControl.start();
        }
    }

    @Override // android.view.View, android.view.ViewGroup
    protected void onDetachedFromWindow() {
        onDetachedFromWindow();
        WeexFrameRateControl weexFrameRateControl = this.mFrameRateControl;
        if (weexFrameRateControl != null) {
            weexFrameRateControl.stop();
        }
    }
}
