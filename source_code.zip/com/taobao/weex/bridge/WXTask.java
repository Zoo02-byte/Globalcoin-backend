package com.taobao.weex.bridge;

import com.taobao.weex.common.IWXObject;
import java.util.ArrayList;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXTask.class */
public class WXTask implements IWXObject {
    public ArrayList<String> args;
    public String method;
    public String module;
}
