package com.taobao.weex.bridge;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/JavascriptInvokable.class */
public interface JavascriptInvokable {
    Invoker getMethodInvoker(String str);

    String[] getMethods();
}
