package com.taobao.weex.bridge;

import android.net.Uri;
import android.text.TextUtils;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXHttpListener;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXHttpAdapter;
import com.taobao.weex.bridge.WXBridgeManager;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.common.WXRequest;
import com.taobao.weex.common.WXResponse;
import com.taobao.weex.http.WXHttpUtil;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXLogUtils;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.feature.uniapp.adapter.AbsURIAdapter;
import java.util.HashMap;
import java.util.Locale;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/RequestHandler.class */
public class RequestHandler {

    /* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/RequestHandler$OnHttpListenerInner.class */
    class OnHttpListenerInner extends WXHttpListener {
        private long sNativeCallback;
        final RequestHandler this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        OnHttpListenerInner(RequestHandler requestHandler, WXSDKInstance wXSDKInstance, long j2, String str) {
            super(wXSDKInstance, str);
            this.this$0 = requestHandler;
            this.sNativeCallback = j2;
        }

        @Override // com.taobao.weex.WXHttpListener
        public void onFail(WXResponse wXResponse) {
            this.this$0.nativeInvokeOnFailed(this.sNativeCallback);
        }

        @Override // com.taobao.weex.WXHttpListener
        public void onSuccess(WXResponse wXResponse) {
            String str = new String(wXResponse.originalData);
            WXBridgeManager.BundType bundleType = WXBridgeManager.getInstance().getBundleType("", str);
            String bundType = bundleType == null ? "Others" : bundleType.toString();
            if ("Others".equalsIgnoreCase(bundType) && getInstance() != null) {
                WXExceptionUtils.commitCriticalExceptionRT(getInstance().getInstanceId(), WXErrorCode.WX_KEY_EXCEPTION_NO_BUNDLE_TYPE, "RequestHandler.onSuccess", "eagle ->" + WXErrorCode.WX_KEY_EXCEPTION_NO_BUNDLE_TYPE.getErrorMsg(), null);
            }
            WXBridgeManager.getInstance().post(new Runnable(this, str, bundType) { // from class: com.taobao.weex.bridge.RequestHandler.OnHttpListenerInner.1
                final OnHttpListenerInner this$1;
                final String val$bundleTypeStr;
                final String val$script;

                /* JADX WARN: Incorrect args count in method signature: ()V */
                {
                    this.this$1 = r4;
                    this.val$script = r5;
                    this.val$bundleTypeStr = r6;
                }

                @Override // java.lang.Runnable
                public void run() {
                    if (WXBridgeManager.getInstance().isJSFrameworkInit()) {
                        this.this$1.this$0.nativeInvokeOnSuccess(this.this$1.sNativeCallback, this.val$script, this.val$bundleTypeStr);
                    } else {
                        this.this$1.this$0.nativeInvokeOnFailed(this.this$1.sNativeCallback);
                    }
                }
            });
        }
    }

    public static RequestHandler create() {
        return new RequestHandler();
    }

    public void getBundleType(String str, String str2, long j2) {
        WXBridgeManager.BundType bundleType = WXBridgeManager.getInstance().getBundleType("", str2);
        String bundType = bundleType == null ? "Others" : bundleType.toString();
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        if ("Others".equalsIgnoreCase(bundType) && sDKInstance != null) {
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_NO_BUNDLE_TYPE, "RequestHandler.onSuccess", "eagle ->" + WXErrorCode.WX_KEY_EXCEPTION_NO_BUNDLE_TYPE.getErrorMsg(), null);
        }
        WXBridgeManager.getInstance().post(new Runnable(this, j2, str2, bundType) { // from class: com.taobao.weex.bridge.RequestHandler.1
            final RequestHandler this$0;
            final String val$bundleTypeStr;
            final String val$content;
            final long val$nativeCallback;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r5;
                this.val$nativeCallback = r6;
                this.val$content = r8;
                this.val$bundleTypeStr = r9;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (WXBridgeManager.getInstance().isJSFrameworkInit()) {
                    this.this$0.nativeInvokeOnSuccess(this.val$nativeCallback, this.val$content, this.val$bundleTypeStr);
                } else {
                    this.this$0.nativeInvokeOnFailed(this.val$nativeCallback);
                }
            }
        });
    }

    native void nativeInvokeOnFailed(long j2);

    native void nativeInvokeOnSuccess(long j2, String str, String str2);

    public void send(String str, String str2, long j2) {
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2) && j2 != 0 && WXSDKManager.getInstance().getAllInstanceMap().containsKey(str)) {
            WXSDKManager instance = WXSDKManager.getInstance();
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                IWXHttpAdapter iWXHttpAdapter = WXSDKManager.getInstance().getIWXHttpAdapter();
                WXRequest wXRequest = new WXRequest();
                wXRequest.url = instance.getURIAdapter().rewrite(sDKInstance, AbsURIAdapter.BUNDLE, Uri.parse(str2)).toString();
                if (wXRequest.paramMap == null) {
                    wXRequest.paramMap = new HashMap();
                }
                wXRequest.paramMap.put(WXHttpUtil.KEY_USER_AGENT, WXHttpUtil.assembleUserAgent(sDKInstance.getContext(), WXEnvironment.getConfig()));
                wXRequest.paramMap.put("isBundleRequest", AbsoluteConst.TRUE);
                WXLogUtils.i("Eagle", String.format(Locale.ENGLISH, "Weex eagle is going to download script from %s", str2));
                iWXHttpAdapter.sendRequest(wXRequest, new OnHttpListenerInner(this, sDKInstance, j2, str2));
            }
        }
    }
}
