package com.taobao.weex.bridge;

import com.alibaba.fastjson.JSON;
import com.taobao.weex.utils.WXWsonJSONSwitch;
import com.taobao.weex.wson.WsonUtils;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXDebugJsBridge.class */
public class WXDebugJsBridge {
    public void jsHandleCallAddElement(String str, String str2, String str3, String str4) {
        jsHandleCallAddElement(str, str2, WsonUtils.toWson(JSON.parse(str3)), str4, true);
    }

    public native void jsHandleCallAddElement(String str, String str2, byte[] bArr, String str3, boolean z2);

    public native void jsHandleCallAddEvent(String str, String str2, String str3);

    public void jsHandleCallCreateBody(String str, String str2) {
        jsHandleCallCreateBody(str, WsonUtils.toWson(JSON.parse(str2)), true);
    }

    public native void jsHandleCallCreateBody(String str, byte[] bArr, boolean z2);

    public native void jsHandleCallCreateFinish(String str);

    public native void jsHandleCallGCanvasLinkNative(String str, int i2, String str2);

    public native void jsHandleCallMoveElement(String str, String str2, String str3, String str4);

    public native void jsHandleCallNative(String str, byte[] bArr, String str2);

    public void jsHandleCallNativeComponent(String str, String str2, String str3, byte[] bArr, byte[] bArr2) {
        jsHandleCallNativeComponent(str, str2, str3, WXWsonJSONSwitch.convertJSONToWsonIfUseWson(bArr), WXWsonJSONSwitch.convertJSONToWsonIfUseWson(bArr2), true);
    }

    public native void jsHandleCallNativeComponent(String str, String str2, String str3, byte[] bArr, byte[] bArr2, boolean z2);

    public native void jsHandleCallNativeLog(byte[] bArr);

    public void jsHandleCallNativeModule(String str, String str2, String str3, byte[] bArr, byte[] bArr2) {
        jsHandleCallNativeModule(str, str2, str3, WXWsonJSONSwitch.convertJSONToWsonIfUseWson(bArr), WXWsonJSONSwitch.convertJSONToWsonIfUseWson(bArr2), true);
    }

    public native void jsHandleCallNativeModule(String str, String str2, String str3, byte[] bArr, byte[] bArr2, boolean z2);

    public native void jsHandleCallRefreshFinish(String str, byte[] bArr, String str2);

    public native void jsHandleCallRemoveElement(String str, String str2);

    public native void jsHandleCallRemoveEvent(String str, String str2, String str3);

    public void jsHandleCallUpdateAttrs(String str, String str2, String str3) {
        jsHandleCallUpdateAttrs(str, str2, WsonUtils.toWson(JSON.parseObject(str3)), true);
    }

    public native void jsHandleCallUpdateAttrs(String str, String str2, byte[] bArr, boolean z2);

    public native void jsHandleCallUpdateFinish(String str, byte[] bArr, String str2);

    public void jsHandleCallUpdateStyle(String str, String str2, String str3) {
        jsHandleCallUpdateStyleNative(str, str2, WsonUtils.toWson(JSON.parseObject(str3)), true);
    }

    public native void jsHandleCallUpdateStyleNative(String str, String str2, byte[] bArr, boolean z2);

    public native void jsHandleClearInterval(String str, String str2);

    public native void jsHandleReportException(String str, String str2, String str3);

    public native void jsHandleSetInterval(String str, String str2, String str3);

    public native void jsHandleSetJSVersion(String str);

    public native void jsHandleSetTimeout(String str, String str2);

    public native void resetWXBridge(Object obj, String str);
}
