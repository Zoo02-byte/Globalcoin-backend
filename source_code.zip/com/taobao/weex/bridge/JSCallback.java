package com.taobao.weex.bridge;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/JSCallback.class */
public interface JSCallback {
    void invoke(Object obj);

    void invokeAndKeepAlive(Object obj);
}
