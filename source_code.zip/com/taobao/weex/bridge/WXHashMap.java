package com.taobao.weex.bridge;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Stack;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXHashMap.class */
public class WXHashMap<K, V> extends HashMap<K, V> {
    private static final long serialVersionUID = 4294272345728974369L;
    private Stack<String> instancesStack = new Stack<>();
    private String mTag;

    public Stack<String> getInstanceStack() {
        return this.instancesStack;
    }

    public String getStackTopInstanceId() {
        return this.instancesStack.isEmpty() ? "" : this.instancesStack.pop();
    }

    public String getTag() {
        return this.mTag;
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public V put(K k2, V v2) {
        if (!(k2 == null || k2.toString() == null)) {
            if (this.instancesStack.contains(k2)) {
                this.instancesStack.remove(k2);
            }
            this.instancesStack.push(k2.toString());
        }
        return put(k2, v2);
    }

    @Override // java.util.HashMap, java.util.AbstractMap, java.util.Map
    public V remove(Object obj) {
        return remove(obj);
    }

    public V removeFromMapAndStack(Object obj) {
        this.instancesStack.remove(obj);
        return remove(obj);
    }

    public void setStackTopInstance(String str) {
        if (!TextUtils.isEmpty(str)) {
            this.instancesStack.remove(str);
            this.instancesStack.push(str);
        }
    }

    public void setTag(String str) {
        this.mTag = str;
    }
}
