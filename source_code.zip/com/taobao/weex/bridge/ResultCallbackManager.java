package com.taobao.weex.bridge;

import android.util.SparseArray;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/ResultCallbackManager.class */
class ResultCallbackManager {
    private static SparseArray<ResultCallback> mResultCallbacks = new SparseArray<>();
    private static long sCallbackId;

    ResultCallbackManager() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static long generateCallbackId(ResultCallback resultCallback) {
        if (sCallbackId >= 2147483647L) {
            sCallbackId = 0;
        }
        long j2 = sCallbackId;
        sCallbackId = 1 + j2;
        int i2 = (int) j2;
        mResultCallbacks.put(i2, resultCallback);
        return (long) i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ResultCallback removeCallbackById(long j2) {
        int i2 = (int) j2;
        ResultCallback resultCallback = mResultCallbacks.get(i2);
        mResultCallbacks.remove(i2);
        return resultCallback;
    }
}
