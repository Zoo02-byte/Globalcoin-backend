package com.taobao.weex.bridge;

import com.taobao.weex.WXSDKInstance;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/IDCVueBridgeAdapter.class */
public interface IDCVueBridgeAdapter {
    void exec(WXSDKInstance wXSDKInstance, String str, String str2);

    String execSync(WXSDKInstance wXSDKInstance, String str, String str2);
}
