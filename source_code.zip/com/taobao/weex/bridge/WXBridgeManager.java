package com.taobao.weex.bridge;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import androidx.collection.ArrayMap;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.Script;
import com.taobao.weex.WXEnvironment;
import com.taobao.weex.WXSDKEngine;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.adapter.IWXConfigAdapter;
import com.taobao.weex.adapter.IWXJSExceptionAdapter;
import com.taobao.weex.adapter.IWXJsFileLoaderAdapter;
import com.taobao.weex.adapter.IWXJscProcessManager;
import com.taobao.weex.adapter.IWXUserTrackAdapter;
import com.taobao.weex.bridge.WXValidateProcessor;
import com.taobao.weex.common.Constants;
import com.taobao.weex.common.IWXBridge;
import com.taobao.weex.common.WXConfig;
import com.taobao.weex.common.WXErrorCode;
import com.taobao.weex.common.WXException;
import com.taobao.weex.common.WXJSExceptionInfo;
import com.taobao.weex.common.WXRefreshData;
import com.taobao.weex.common.WXRenderStrategy;
import com.taobao.weex.common.WXRuntimeException;
import com.taobao.weex.common.WXThread;
import com.taobao.weex.dom.CSSShorthand;
import com.taobao.weex.el.parse.Operators;
import com.taobao.weex.layout.ContentBoxMeasurement;
import com.taobao.weex.performance.WXInstanceApm;
import com.taobao.weex.performance.WXStateRecord;
import com.taobao.weex.ui.WXComponentRegistry;
import com.taobao.weex.ui.WXRenderManager;
import com.taobao.weex.ui.action.ActionReloadPage;
import com.taobao.weex.ui.action.GraphicActionAddChildToRichtext;
import com.taobao.weex.ui.action.GraphicActionAddElement;
import com.taobao.weex.ui.action.GraphicActionAddEvent;
import com.taobao.weex.ui.action.GraphicActionAppendTreeCreateFinish;
import com.taobao.weex.ui.action.GraphicActionBatchBegin;
import com.taobao.weex.ui.action.GraphicActionBatchEnd;
import com.taobao.weex.ui.action.GraphicActionCreateBody;
import com.taobao.weex.ui.action.GraphicActionCreateFinish;
import com.taobao.weex.ui.action.GraphicActionLayout;
import com.taobao.weex.ui.action.GraphicActionMoveElement;
import com.taobao.weex.ui.action.GraphicActionRefreshFinish;
import com.taobao.weex.ui.action.GraphicActionRemoveChildFromRichtext;
import com.taobao.weex.ui.action.GraphicActionRemoveElement;
import com.taobao.weex.ui.action.GraphicActionRemoveEvent;
import com.taobao.weex.ui.action.GraphicActionRenderSuccess;
import com.taobao.weex.ui.action.GraphicActionUpdateAttr;
import com.taobao.weex.ui.action.GraphicActionUpdateRichtextAttr;
import com.taobao.weex.ui.action.GraphicActionUpdateRichtextStyle;
import com.taobao.weex.ui.action.GraphicActionUpdateStyle;
import com.taobao.weex.ui.action.GraphicPosition;
import com.taobao.weex.ui.action.GraphicSize;
import com.taobao.weex.ui.component.WXComponent;
import com.taobao.weex.ui.module.WXDomModule;
import com.taobao.weex.utils.WXExceptionUtils;
import com.taobao.weex.utils.WXFileUtils;
import com.taobao.weex.utils.WXJsonUtils;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXUtils;
import com.taobao.weex.utils.WXViewUtils;
import com.taobao.weex.utils.WXWsonJSONSwitch;
import com.taobao.weex.utils.batch.BactchExecutor;
import com.taobao.weex.utils.batch.Interceptor;
import com.taobao.weex.utils.tools.LogDetail;
import io.dcloud.common.adapter.ui.webview.WebLoadEvent;
import io.dcloud.common.adapter.util.UEH;
import io.dcloud.common.constant.AbsoluteConst;
import io.dcloud.common.util.AppRuntime;
import io.dcloud.common.util.BaseInfo;
import io.dcloud.common.util.ExifInterface;
import io.dcloud.common.util.JSONUtil;
import io.dcloud.common.util.PdrUtil;
import io.dcloud.common.util.RuningAcitvityUtil;
import io.dcloud.common.util.StringUtil;
import io.dcloud.weex.WXDotDataUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXBridgeManager.class */
public class WXBridgeManager implements Handler.Callback, BactchExecutor {
    public static final String ARGS;
    private static final boolean BRIDGE_LOG_SWITCH;
    private static final String BUNDLE_TYPE;
    public static final String COMPONENT;
    private static final int CRASHREINIT;
    private static String GLOBAL_CONFIG_KEY;
    public static final String INITLOGFILE;
    private static final int INIT_FRAMEWORK_OK;
    public static final String KEY_ARGS;
    public static final String KEY_METHOD;
    public static final String KEY_PARAMS;
    private static long LOW_MEM_VALUE;
    public static final String METHD_COMPONENT_HOOK_SYNC;
    public static final String METHD_FIRE_EVENT_SYNC;
    public static final String METHOD;
    public static final String METHOD_CALLBACK;
    public static final String METHOD_CALL_JS;
    public static final String METHOD_CHECK_APPKEY;
    public static final String METHOD_CREATE_INSTANCE;
    public static final String METHOD_CREATE_INSTANCE_CONTEXT;
    public static final String METHOD_CREATE_PAGE_WITH_CONTENT;
    public static final String METHOD_DESTROY_INSTANCE;
    public static final String METHOD_FIRE_EVENT;
    public static final String METHOD_FIRE_EVENT_ON_DATA_RENDER_NODE;
    private static final String METHOD_JSFM_NOT_INIT_IN_EAGLE_MODE;
    public static final String METHOD_NOTIFY_SERIALIZE_CODE_CACHE;
    public static final String METHOD_NOTIFY_TRIM_MEMORY;
    private static final String METHOD_POST_TASK_TO_MSG_LOOP;
    public static final String METHOD_REFRESH_INSTANCE;
    public static final String METHOD_REGISTER_COMPONENTS;
    public static final String METHOD_REGISTER_MODULES;
    public static final String METHOD_SET_TIMEOUT;
    public static final String METHOD_UPDATE_COMPONENT_WITH_DATA;
    public static final String MODULE;
    private static final String NON_CALLBACK;
    public static final String OPTIONS;
    public static final String REF;
    private static final String RENDER_STRATEGY;
    private static final String UNDEFINED;
    private static Class clazz_debugProxy;
    private static String crashUrl;
    private static String globalConfig;
    private static volatile boolean isJsEngineMultiThreadEnable;
    private static volatile boolean isSandBoxContext;
    private static boolean isUseSingleProcess;
    private static long lastCrashTime;
    static volatile WXBridgeManager mBridgeManager;
    private static volatile boolean mInit;
    private static String mRaxApi;
    public static volatile int reInitCount;
    public static long sInitFrameWorkTimeOrigin;
    private WXParams mInitParams;
    private Interceptor mInterceptor;
    Handler mJSHandler;
    private WXThread mJSThread;
    private IWXBridge mWXBridge;
    private Object mWxDebugProxy;
    private static Map<String, String> mWeexCoreEnvOptions = new HashMap();
    public static StringBuilder sInitFrameWorkMsg = new StringBuilder();
    private WXHashMap<String, ArrayList<WXHashMap<String, Object>>> mNextTickTasks = new WXHashMap<>();
    private boolean mMock = false;
    private List<Map<String, Object>> mRegisterComponentFailList = new ArrayList(8);
    private List<Map<String, Object>> mRegisterModuleFailList = new ArrayList(8);
    private List<String> mRegisterServiceFailList = new ArrayList(8);
    private HashSet<String> mDestroyedInstanceId = new HashSet<>();
    private StringBuilder mLodBuilder = new StringBuilder(50);

    /* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXBridgeManager$BundType.class */
    public enum BundType {
        Vue,
        Rax,
        Others
    }

    /* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/WXBridgeManager$TimerInfo.class */
    public static class TimerInfo {
        public String callbackId;
        public String instanceId;
        public long time;
    }

    private WXBridgeManager() {
        initWXBridge(WXEnvironment.sRemoteDebugMode);
        WXThread wXThread = new WXThread("WeexJSBridgeThread", this);
        this.mJSThread = wXThread;
        this.mJSHandler = wXThread.getHandler();
    }

    private void addJSEventTask(String str, String str2, List<Object> list, Object... objArr) {
        post(new Runnable(this, objArr, list, str, str2) { // from class: com.taobao.weex.bridge.WXBridgeManager.13
            final WXBridgeManager this$0;
            final Object[] val$args;
            final String val$instanceId;
            final String val$method;
            final List val$params;

            {
                this.this$0 = r4;
                this.val$args = r5;
                this.val$params = r6;
                this.val$method = r7;
                this.val$instanceId = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                Object[] objArr2 = this.val$args;
                if (!(objArr2 == null || objArr2.length == 0)) {
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : this.val$args) {
                        arrayList.add(obj);
                    }
                    if (this.val$params != null) {
                        ArrayMap arrayMap = new ArrayMap(4);
                        arrayMap.put("params", this.val$params);
                        arrayList.add(arrayMap);
                    }
                    WXHashMap wXHashMap = new WXHashMap();
                    wXHashMap.put("method", this.val$method);
                    wXHashMap.put("args", arrayList);
                    if (this.this$0.mNextTickTasks.get(this.val$instanceId) == 0) {
                        ArrayList arrayList2 = new ArrayList();
                        arrayList2.add(wXHashMap);
                        this.this$0.mNextTickTasks.put(this.val$instanceId, arrayList2);
                        return;
                    }
                    ((ArrayList) this.this$0.mNextTickTasks.get(this.val$instanceId)).add(wXHashMap);
                }
            }
        });
    }

    private void addJSTask(String str, String str2, Object... objArr) {
        addJSEventTask(str, str2, null, objArr);
    }

    public static String argsToJSON(WXJSObject[] wXJSObjectArr) {
        StringBuilder sb = new StringBuilder(Operators.ARRAY_START_STR);
        for (WXJSObject wXJSObject : wXJSObjectArr) {
            sb.append(WXWsonJSONSwitch.fromObjectToJSONString(wXJSObject));
            sb.append(",");
        }
        sb.append(Operators.ARRAY_END_STR);
        return sb.toString();
    }

    private WXParams assembleDefaultOptions() {
        checkJsEngineMultiThread();
        Map<String, String> config = WXEnvironment.getConfig();
        WXParams wXParams = new WXParams();
        wXParams.setPlatform(config.get(WXConfig.os));
        wXParams.setCacheDir(config.get(WXConfig.cacheDir));
        wXParams.setOsVersion(config.get(WXConfig.sysVersion));
        wXParams.setAppVersion(config.get(WXConfig.appVersion));
        wXParams.setWeexVersion(config.get(WXConfig.weexVersion));
        wXParams.setDeviceModel(config.get(WXConfig.sysModel));
        wXParams.setShouldInfoCollect(config.get("infoCollect"));
        wXParams.setLogLevel(config.get(WXConfig.logLevel));
        wXParams.setLayoutDirection(config.get(WXConfig.layoutDirection));
        wXParams.setUseSingleProcess(isUseSingleProcess ? AbsoluteConst.TRUE : AbsoluteConst.FALSE);
        wXParams.setCrashFilePath(WXEnvironment.getCrashFilePath(WXEnvironment.getApplication().getApplicationContext()));
        wXParams.setLibJsbPath(WXEnvironment.CORE_JSB_SO_PATH);
        wXParams.setLibJssPath(WXEnvironment.getLibJssRealPath());
        wXParams.setLibIcuPath(WXEnvironment.getLibJssIcuPath());
        wXParams.setLibLdPath(WXEnvironment.getLibLdPath());
        String libJScRealPath = WXEnvironment.getLibJScRealPath();
        wXParams.setLibJscPath(TextUtils.isEmpty(libJScRealPath) ? "" : new File(libJScRealPath).getParent());
        String str = config.get(WXConfig.appName);
        if (!TextUtils.isEmpty(str)) {
            wXParams.setAppName(str);
        }
        wXParams.setDeviceWidth(TextUtils.isEmpty(config.get(WXConfig.deviceWidth)) ? String.valueOf(WXViewUtils.getScreenWidth(WXEnvironment.sApplication)) : config.get(WXConfig.deviceWidth));
        wXParams.setDeviceHeight(TextUtils.isEmpty(config.get(WXConfig.deviceHeight)) ? String.valueOf(WXViewUtils.getScreenHeight(WXEnvironment.sApplication)) : config.get(WXConfig.deviceHeight));
        Map<String, String> customOptions = WXEnvironment.getCustomOptions();
        customOptions.put("enableBackupThread", String.valueOf(jsEngineMultiThreadEnable()));
        IWXJscProcessManager wXJscProcessManager = WXSDKManager.getInstance().getWXJscProcessManager();
        if (wXJscProcessManager != null) {
            customOptions.put("enableBackupThreadCache", String.valueOf(wXJscProcessManager.enableBackUpThreadCache()));
        }
        if (!WXEnvironment.sUseRunTimeApi) {
            customOptions.put("__enable_native_promise__", AbsoluteConst.TRUE);
        }
        wXParams.setOptions(customOptions);
        wXParams.setNeedInitV8(WXSDKManager.getInstance().needInitV8());
        this.mInitParams = wXParams;
        return wXParams;
    }

    private void asyncCallJSEventWithResult(EventResult eventResult, String str, String str2, List<Object> list, Object... objArr) {
        post(new Runnable(this, objArr, list, str, str2, eventResult) { // from class: com.taobao.weex.bridge.WXBridgeManager.12
            final WXBridgeManager this$0;
            final Object[] val$args;
            final EventResult val$eventCallback;
            final String val$instanceId;
            final String val$method;
            final List val$params;

            {
                this.this$0 = r4;
                this.val$args = r5;
                this.val$params = r6;
                this.val$method = r7;
                this.val$instanceId = r8;
                this.val$eventCallback = r9;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    Object[] objArr2 = this.val$args;
                    if (!(objArr2 == null || objArr2.length == 0)) {
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : this.val$args) {
                            arrayList.add(obj);
                        }
                        if (this.val$params != null) {
                            ArrayMap arrayMap = new ArrayMap(4);
                            arrayMap.put("params", this.val$params);
                            arrayList.add(arrayMap);
                        }
                        WXHashMap wXHashMap = new WXHashMap();
                        wXHashMap.put("method", this.val$method);
                        wXHashMap.put("args", arrayList);
                        WXJSObject[] wXJSObjectArr = new WXJSObject[2];
                        wXJSObjectArr[0] = new WXJSObject(2, this.val$instanceId);
                        wXJSObjectArr[1] = WXWsonJSONSwitch.toWsonOrJsonWXJSObject(new Object[]{wXHashMap});
                        this.this$0.invokeExecJSWithCallback(String.valueOf(this.val$instanceId), null, WXBridgeManager.METHOD_CALL_JS, wXJSObjectArr, this.val$eventCallback != null ? new ResultCallback<byte[]>(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.12.1
                            final AnonymousClass12 this$1;

                            {
                                this.this$1 = r4;
                            }

                            public void onReceiveResult(byte[] bArr) {
                                JSONArray jSONArray = (JSONArray) WXWsonJSONSwitch.parseWsonOrJSON(bArr);
                                if (jSONArray != null && jSONArray.size() > 0) {
                                    this.this$1.val$eventCallback.onCallback(jSONArray.get(0));
                                }
                            }
                        } : null, true);
                        wXJSObjectArr[0] = null;
                    }
                } catch (Exception e2) {
                    WXLogUtils.e("asyncCallJSEventWithResult", e2);
                }
            }
        });
    }

    private boolean checkMainThread() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    private void doReportJSException(String str, String str2, WXErrorCode wXErrorCode, String str3) {
        String str4;
        Throwable th;
        Throwable th2;
        File file;
        Exception e2;
        WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(str);
        if (WXSDKManager.getInstance().getIWXJSExceptionAdapter() != null) {
            String str5 = str;
            if (TextUtils.isEmpty(str)) {
                str5 = "instanceIdisNull";
            }
            String str6 = str3;
            if (wXSDKInstance == null) {
                str6 = str3;
                if (IWXUserTrackAdapter.INIT_FRAMEWORK.equals(str2)) {
                    try {
                    } catch (Throwable th3) {
                        th = th3;
                        str4 = null;
                    }
                    if (WXEnvironment.getApplication() != null) {
                        try {
                            file = new File(WXEnvironment.getApplication().getApplicationContext().getCacheDir().getPath() + INITLOGFILE);
                        } catch (Throwable th4) {
                            th2 = th4;
                            str4 = null;
                        }
                        if (file.exists()) {
                            if (file.length() > 0) {
                                StringBuilder sb = new StringBuilder();
                                try {
                                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
                                    while (true) {
                                        String readLine = bufferedReader.readLine();
                                        if (readLine == null) {
                                            break;
                                        }
                                        sb.append(readLine + "\n");
                                    }
                                    str4 = sb.toString();
                                    str4 = str4;
                                    try {
                                        try {
                                            bufferedReader.close();
                                        } catch (Exception e3) {
                                            e2 = e3;
                                            try {
                                                WXLogUtils.e(WXLogUtils.getStackTrace(e2));
                                                str4 = str4;
                                                file.delete();
                                            } catch (Throwable th5) {
                                                th2 = th5;
                                                try {
                                                    WXLogUtils.e(WXLogUtils.getStackTrace(th2));
                                                } catch (Throwable th6) {
                                                    th = th6;
                                                    WXLogUtils.e(WXLogUtils.getStackTrace(th));
                                                    str6 = str3 + "\n" + str4;
                                                    WXLogUtils.e("reportJSException:" + str6);
                                                    WXExceptionUtils.commitCriticalExceptionRT(str5, wXErrorCode, str2, wXErrorCode.getErrorMsg() + str6, null);
                                                }
                                                str6 = str3 + "\n" + str4;
                                                WXLogUtils.e("reportJSException:" + str6);
                                                WXExceptionUtils.commitCriticalExceptionRT(str5, wXErrorCode, str2, wXErrorCode.getErrorMsg() + str6, null);
                                            }
                                            str6 = str3 + "\n" + str4;
                                            WXLogUtils.e("reportJSException:" + str6);
                                            WXExceptionUtils.commitCriticalExceptionRT(str5, wXErrorCode, str2, wXErrorCode.getErrorMsg() + str6, null);
                                        }
                                    } catch (Throwable th7) {
                                        th2 = th7;
                                        WXLogUtils.e(WXLogUtils.getStackTrace(th2));
                                        str6 = str3 + "\n" + str4;
                                        WXLogUtils.e("reportJSException:" + str6);
                                        WXExceptionUtils.commitCriticalExceptionRT(str5, wXErrorCode, str2, wXErrorCode.getErrorMsg() + str6, null);
                                    }
                                } catch (Exception e4) {
                                    e2 = e4;
                                    str4 = null;
                                }
                            } else {
                                str4 = null;
                            }
                            str4 = str4;
                            file.delete();
                            str6 = str3 + "\n" + str4;
                            WXLogUtils.e("reportJSException:" + str6);
                        }
                    }
                    str4 = null;
                    str6 = str3 + "\n" + str4;
                    WXLogUtils.e("reportJSException:" + str6);
                }
            }
            WXExceptionUtils.commitCriticalExceptionRT(str5, wXErrorCode, str2, wXErrorCode.getErrorMsg() + str6, null);
        }
    }

    private void execJSOnInstance(EventResult eventResult, String str, String str2, int i2) {
        post(new Runnable(this, str, str2, i2, eventResult) { // from class: com.taobao.weex.bridge.WXBridgeManager.21
            final WXBridgeManager this$0;
            final EventResult val$eventCallback;
            final String val$instanceId;
            final String val$js;
            final int val$type;

            {
                this.this$0 = r4;
                this.val$instanceId = r5;
                this.val$js = r6;
                this.val$type = r7;
                this.val$eventCallback = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.val$eventCallback.onCallback(this.this$0.invokeExecJSOnInstance(this.val$instanceId, this.val$js, this.val$type));
            }
        });
    }

    private void execRegisterFailTask() {
        if (this.mRegisterModuleFailList.size() > 0) {
            ArrayList arrayList = new ArrayList();
            int size = this.mRegisterModuleFailList.size();
            for (int i2 = 0; i2 < size; i2++) {
                invokeRegisterModules(this.mRegisterModuleFailList.get(i2), arrayList);
            }
            this.mRegisterModuleFailList.clear();
            if (arrayList.size() > 0) {
                this.mRegisterModuleFailList.addAll(arrayList);
            }
        }
        if (this.mRegisterComponentFailList.size() > 0) {
            ArrayList arrayList2 = new ArrayList();
            invokeRegisterComponents(this.mRegisterComponentFailList, arrayList2);
            this.mRegisterComponentFailList.clear();
            if (arrayList2.size() > 0) {
                this.mRegisterComponentFailList.addAll(arrayList2);
            }
        }
        if (this.mRegisterServiceFailList.size() > 0) {
            ArrayList arrayList3 = new ArrayList();
            for (String str : this.mRegisterServiceFailList) {
                invokeExecJSService(str, arrayList3);
            }
            this.mRegisterServiceFailList.clear();
            if (arrayList3.size() > 0) {
                this.mRegisterServiceFailList.addAll(arrayList3);
            }
        }
    }

    private Pair<Pair<String, Object>, Boolean> extractCallbackArgs(String str) {
        try {
            JSONObject jSONObject = JSON.parseArray(str).getJSONObject(0);
            JSONArray jSONArray = jSONObject.getJSONArray("args");
            if (jSONArray.size() == 3 && METHOD_CALLBACK.equals(jSONObject.getString("method"))) {
                return new Pair<>(new Pair(jSONArray.getString(0), jSONArray.getJSONObject(1)), Boolean.valueOf(jSONArray.getBooleanValue(2)));
            }
            return null;
        } catch (Exception e2) {
            return null;
        }
    }

    private void fireEventOnDataRenderNode(String str, String str2, String str3, Map<String, Object> map, Map<String, Object> map2) {
        this.mJSHandler.postDelayed(WXThread.secure(new Runnable(this, str, map, str2, str3, map2) { // from class: com.taobao.weex.bridge.WXBridgeManager.14
            final WXBridgeManager this$0;
            final Map val$data;
            final Map val$domChanges;
            final String val$instanceId;
            final String val$ref;
            final String val$type;

            {
                this.this$0 = r4;
                this.val$instanceId = r5;
                this.val$data = r6;
                this.val$ref = r7;
                this.val$type = r8;
                this.val$domChanges = r9;
            }

            /* JADX WARN: Removed duplicated region for block: B:19:0x009a A[Catch: all -> 0x00cf, TRY_ENTER, TryCatch #0 {all -> 0x00cf, blocks: (B:2:0x0000, B:4:0x0015, B:6:0x003a, B:8:0x0046, B:11:0x0071, B:14:0x007d, B:16:0x008b, B:19:0x009a, B:23:0x00ab, B:25:0x00b6, B:27:0x00c4), top: B:31:0x0000 }] */
            @Override // java.lang.Runnable
            /* Code decompiled incorrectly, please refer to instructions dump */
            public void run() {
                /*
                // Method dump skipped, instructions count: 247
                */
                throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.bridge.WXBridgeManager.AnonymousClass14.run():void");
            }
        }), 0);
    }

    public static WXBridgeManager getInstance() {
        if (mBridgeManager == null) {
            synchronized (WXBridgeManager.class) {
                try {
                    if (mBridgeManager == null) {
                        mBridgeManager = new WXBridgeManager();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return mBridgeManager;
    }

    private void getNextTick(String str) {
        addJSTask(METHOD_CALLBACK, str, "", "{}");
        sendMessage(str, 6);
    }

    private void getNextTick(String str, String str2) {
        addJSTask(METHOD_CALLBACK, str, str2, "{}");
        sendMessage(str, 6);
    }

    public void initFramework(String str) {
        LogDetail logDetail = new LogDetail();
        logDetail.name(IWXUserTrackAdapter.INIT_FRAMEWORK);
        logDetail.taskStart();
        if (WXSDKEngine.isSoInitialized() && !isJSFrameworkInit()) {
            sInitFrameWorkTimeOrigin = System.currentTimeMillis();
            String str2 = str;
            if (TextUtils.isEmpty(str)) {
                WXLogUtils.d("weex JS framework from assets");
                LogDetail logDetail2 = new LogDetail();
                logDetail2.name("loadJSFramework");
                logDetail2.taskStart();
                IWXJsFileLoaderAdapter iWXJsFileLoaderAdapter = WXSDKEngine.getIWXJsFileLoaderAdapter();
                if (!isSandBoxContext) {
                    String str3 = str;
                    if (iWXJsFileLoaderAdapter != null) {
                        str3 = iWXJsFileLoaderAdapter.loadJsFramework();
                    }
                    str2 = str3;
                    if (TextUtils.isEmpty(str3)) {
                        str2 = WXFileUtils.loadAsset("main.js", WXEnvironment.getApplication());
                    }
                } else {
                    String str4 = str;
                    if (iWXJsFileLoaderAdapter != null) {
                        str4 = iWXJsFileLoaderAdapter.loadJsFrameworkForSandBox();
                    }
                    str2 = str4;
                    if (TextUtils.isEmpty(str4)) {
                        str2 = WXFileUtils.loadAsset("weex-main-jsfm.js", WXEnvironment.getApplication());
                    }
                }
                sInitFrameWorkMsg.append("| weex JS framework from assets, isSandBoxContext: ").append(isSandBoxContext);
                logDetail2.taskEnd();
                WXDotDataUtil.setValue(logDetail2.info.taskName, Long.valueOf(logDetail2.time.execTime));
            }
            WXDotDataUtil.setValue("jsEngine", Constants.CodeCache.SAVE_PATH);
            if (TextUtils.isEmpty(str2)) {
                setJSFrameworkInit(false);
                sInitFrameWorkMsg.append("| framework isEmpty ");
                WXExceptionUtils.commitCriticalExceptionRT(null, WXErrorCode.WX_ERR_JS_FRAMEWORK, IWXUserTrackAdapter.INIT_FRAMEWORK, "framework is empty!! ", null);
                return;
            }
            try {
                if (WXSDKManager.getInstance().getWXStatisticsListener() != null) {
                    long currentTimeMillis = System.currentTimeMillis();
                    WXSDKManager.getInstance().getWXStatisticsListener().onJsFrameworkStart();
                    WXEnvironment.sJSFMStartListenerTime = System.currentTimeMillis() - currentTimeMillis;
                    try {
                        IWXUserTrackAdapter iWXUserTrackAdapter = WXSDKManager.getInstance().getIWXUserTrackAdapter();
                        if (iWXUserTrackAdapter != null) {
                            HashMap hashMap = new HashMap(1);
                            hashMap.put(Constants.Value.TIME, String.valueOf(WXEnvironment.sJSFMStartListenerTime));
                            iWXUserTrackAdapter.commit(WXEnvironment.getApplication(), "sJSFMStartListener", IWXUserTrackAdapter.COUNTER, null, hashMap);
                        }
                    } catch (Exception e2) {
                        WXLogUtils.e(WXLogUtils.getStackTrace(e2));
                    }
                }
                long currentTimeMillis2 = System.currentTimeMillis();
                String str5 = "";
                try {
                    str5 = WXEnvironment.getApplication().getApplicationContext().getCacheDir().getPath();
                } catch (Exception e3) {
                    WXLogUtils.e(WXLogUtils.getStackTrace(e3));
                }
                sInitFrameWorkMsg.append(" | pieSupport:").append(true);
                WXLogUtils.d("[WXBridgeManager] initFrameworkEnv crashFile:" + str5 + " pieSupport:true");
                LogDetail logDetail3 = new LogDetail();
                logDetail3.name("native initFrameworkEnv");
                logDetail3.taskStart();
                if (this.mWXBridge.initFrameworkEnv(str2, assembleDefaultOptions(), str5, true) == 1) {
                    logDetail3.taskEnd();
                    WXDotDataUtil.setValue(logDetail3.info.taskName, Long.valueOf(logDetail3.time.execTime));
                    WXEnvironment.sJSLibInitTime = System.currentTimeMillis() - currentTimeMillis2;
                    WXEnvironment.sSDKInitTime = System.currentTimeMillis() - WXEnvironment.sSDKInitStart;
                    setJSFrameworkInit(true);
                    logDetail.taskEnd();
                    WXDotDataUtil.setValue(logDetail.info.taskName, Long.valueOf(logDetail.time.execTime));
                    if (WXSDKManager.getInstance().getWXStatisticsListener() != null) {
                        WXSDKManager.getInstance().getWXStatisticsListener().onJsFrameworkReady();
                    }
                    execRegisterFailTask();
                    WXEnvironment.JsFrameworkInit = true;
                    registerDomModule();
                    trackComponentAndModulesTime();
                    return;
                }
                sInitFrameWorkMsg.append(" | ExecuteJavaScript fail, reInitCount").append(reInitCount);
                if (reInitCount > 1) {
                    WXLogUtils.e("[WXBridgeManager] invokeReInitFramework  ExecuteJavaScript fail");
                } else {
                    WXLogUtils.e("[WXBridgeManager] invokeInitFramework  ExecuteJavaScript fail");
                }
            } catch (Throwable th) {
                sInitFrameWorkMsg.append(" | invokeInitFramework exception ").append(th.toString());
                if (reInitCount > 1) {
                    WXLogUtils.e("[WXBridgeManager] invokeInitFramework ", th);
                } else {
                    WXLogUtils.e("[WXBridgeManager] invokeInitFramework ", th);
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x0065, code lost:
        if ((r0 != null ? ((java.lang.Boolean) r0.invoke(r6.mWxDebugProxy, new java.lang.Object[0])).booleanValue() : false) != false) goto L_0x00d2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump */
    private void initWXBridge(boolean r7) {
        /*
        // Method dump skipped, instructions count: 317
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.bridge.WXBridgeManager.initWXBridge(boolean):void");
    }

    private void invokeCallJSBatch(Message message) {
        if (!this.mNextTickTasks.isEmpty() && isJSFrameworkInit()) {
            try {
                Object obj = message.obj;
                Stack<String> instanceStack = this.mNextTickTasks.getInstanceStack();
                ArrayList<WXHashMap<String, Object>> arrayList = null;
                for (int size = instanceStack.size() - 1; size >= 0; size--) {
                    obj = instanceStack.get(size);
                    arrayList = this.mNextTickTasks.remove(obj);
                    if (!(arrayList == null || arrayList.isEmpty())) {
                        break;
                    }
                }
                if (arrayList != null) {
                    invokeExecJS(String.valueOf(obj), null, METHOD_CALL_JS, new WXJSObject[]{new WXJSObject(2, obj), WXWsonJSONSwitch.toWsonOrJsonWXJSObject(arrayList.toArray())});
                }
            } catch (Throwable th) {
                WXLogUtils.e("WXBridgeManager", th);
                WXExceptionUtils.commitCriticalExceptionRT(null, WXErrorCode.WX_ERR_JS_FRAMEWORK, "invokeCallJSBatch", "invokeCallJSBatch#" + WXLogUtils.getStackTrace(th), null);
            }
            if (!this.mNextTickTasks.isEmpty()) {
                this.mJSHandler.sendEmptyMessage(6);
            }
        } else if (!isJSFrameworkInit()) {
            WXLogUtils.e("[WXBridgeManager] invokeCallJSBatch: framework.js uninitialized!!  message:" + message.toString());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x0288 A[Catch: all -> 0x046c, TRY_LEAVE, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:112:0x02c6 A[Catch: all -> 0x046c, TRY_LEAVE, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:113:0x02d8 A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:125:0x0366 A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:127:0x039e A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:74:0x01d0 A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0206  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x020d A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:86:0x0223  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x022a A[Catch: all -> 0x046c, TRY_ENTER, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:91:0x024e  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x0265 A[Catch: all -> 0x046c, TryCatch #2 {all -> 0x046c, blocks: (B:15:0x004a, B:69:0x0195, B:71:0x01a0, B:74:0x01d0, B:76:0x01dd, B:78:0x01f8, B:82:0x020d, B:84:0x0214, B:87:0x022a, B:89:0x0232, B:92:0x0255, B:94:0x0265, B:97:0x0272, B:98:0x0282, B:100:0x0288, B:102:0x0290, B:103:0x0299, B:104:0x029c, B:106:0x02a2, B:107:0x02ae, B:108:0x02b1, B:110:0x02bd, B:112:0x02c6, B:113:0x02d8, B:115:0x02e2, B:117:0x0300, B:119:0x030a, B:121:0x031b, B:123:0x034a, B:125:0x0366, B:127:0x039e, B:129:0x03a6, B:131:0x03ae, B:133:0x03b8, B:135:0x03c2, B:138:0x03cf, B:140:0x03e8, B:142:0x040a, B:17:0x0053, B:19:0x005c, B:21:0x0072, B:25:0x007c, B:27:0x0085, B:29:0x008e, B:31:0x009a), top: B:149:0x004a }] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public void invokeCreateInstance(com.taobao.weex.WXSDKInstance r8, com.taobao.weex.Script r9, java.util.Map<java.lang.String, java.lang.Object> r10, java.lang.String r11) {
        /*
        // Method dump skipped, instructions count: 1199
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.bridge.WXBridgeManager.invokeCreateInstance(com.taobao.weex.WXSDKInstance, com.taobao.weex.Script, java.util.Map, java.lang.String):void");
    }

    public void invokeDestroyInstance(String str) {
        try {
            WXEnvironment.isApkDebugable();
            WXJSObject wXJSObject = new WXJSObject(2, str);
            if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
                invokeDestoryInstance(str, null, METHOD_DESTROY_INSTANCE, new WXJSObject[]{wXJSObject}, true);
            }
        } catch (Throwable th) {
            String str2 = "[WXBridgeManager] invokeDestroyInstance " + th.getCause();
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "invokeDestroyInstance", str2, null);
            WXLogUtils.e(str2);
        }
    }

    public void invokeExecJS(String str, String str2, String str3, WXJSObject[] wXJSObjectArr) {
        invokeExecJS(str, str2, str3, wXJSObjectArr, true);
    }

    public String invokeExecJSOnInstance(String str, String str2, int i2) {
        this.mLodBuilder.append("execJSOnInstance >>>> instanceId:").append(str);
        WXLogUtils.d(this.mLodBuilder.substring(0));
        this.mLodBuilder.setLength(0);
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            return this.mWXBridge.execJSOnInstance(str, str2, i2);
        }
        return null;
    }

    public void invokeExecJSService(String str, List<String> list) {
        try {
            if (!isJSFrameworkInit()) {
                WXLogUtils.e("[WXBridgeManager] invoke execJSService: framework.js uninitialized.");
                list.add(str);
                return;
            }
            this.mWXBridge.execJSService(str);
        } catch (Throwable th) {
            WXLogUtils.e("[WXBridgeManager] invokeRegisterService:", th);
            HashMap hashMap = new HashMap();
            hashMap.put("inputParams", str + Operators.OR + list.toString());
            WXExceptionUtils.commitCriticalExceptionRT("invokeExecJSService", WXErrorCode.WX_KEY_EXCEPTION_INVOKE_JSSERVICE_EXECUTE, "invokeExecJSService", WXErrorCode.WX_KEY_EXCEPTION_INVOKE_JSSERVICE_EXECUTE.getErrorMsg() + "[WXBridgeManager] invokeRegisterService:" + WXLogUtils.getStackTrace(th), hashMap);
        }
    }

    public void invokeExecJSWithCallback(String str, String str2, String str3, WXJSObject[] wXJSObjectArr, ResultCallback resultCallback, boolean z2) {
        WXEnvironment.isOpenDebugLog();
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.execJSWithCallback(str, str2, str3, wXJSObjectArr, resultCallback);
        }
    }

    private void invokeInitFramework(Message message) {
        String str = message.obj != null ? (String) message.obj : "";
        if (WXUtils.getAvailMemory(WXEnvironment.getApplication()) > LOW_MEM_VALUE) {
            initFramework(str);
        }
    }

    public void invokeRefreshInstance(String str, WXRefreshData wXRefreshData) {
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
                System.currentTimeMillis();
                if (WXEnvironment.isApkDebugable()) {
                    WXLogUtils.d("refreshInstance >>>> instanceId:" + str + ", data:" + wXRefreshData.data + ", isDirty:" + wXRefreshData.isDirty);
                }
                if (!wXRefreshData.isDirty) {
                    this.mWXBridge.refreshInstance(str, null, METHOD_REFRESH_INSTANCE, new WXJSObject[]{new WXJSObject(2, str), new WXJSObject(3, wXRefreshData.data == null ? "{}" : wXRefreshData.data)});
                    return;
                }
                return;
            }
            if (sDKInstance != null) {
                sDKInstance.onRenderError(WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorCode(), WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorMsg() + "invokeRefreshInstance FAILED for JSFrameworkInit FAILED, intance will invoke instance.onRenderError");
            }
            WXLogUtils.e("[WXBridgeManager] invokeRefreshInstance: framework.js uninitialized.");
        } catch (Throwable th) {
            String str2 = "[WXBridgeManager] invokeRefreshInstance " + WXLogUtils.getStackTrace(th);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "invokeRefreshInstance", str2, null);
            WXLogUtils.e(str2);
        }
    }

    public void invokeRegisterComponents(List<Map<String, Object>> list, List<Map<String, Object>> list2) {
        String str;
        if (list == list2) {
            throw new RuntimeException("Fail receiver should not use source.");
        } else if (!isJSFrameworkInit()) {
            for (Map<String, Object> map : list) {
                list2.add(map);
            }
        } else if (list != null) {
            try {
                IWXBridge iWXBridge = this.mWXBridge;
                if (iWXBridge instanceof WXBridge) {
                    ((WXBridge) iWXBridge).registerComponentOnDataRenderNode(WXJsonUtils.fromObjectToJSONString(list));
                }
            } catch (Throwable th) {
                WXLogUtils.e("Weex [data_render register err]", th);
            }
            WXJSObject[] wXJSObjectArr = {WXWsonJSONSwitch.toWsonOrJsonWXJSObject(list)};
            try {
                str = this.mWXBridge.execJS("", null, METHOD_REGISTER_COMPONENTS, wXJSObjectArr) == 0 ? "execJS error" : null;
            } catch (Throwable th2) {
                str = WXErrorCode.WX_KEY_EXCEPTION_INVOKE_REGISTER_COMPONENT + wXJSObjectArr.toString() + WXLogUtils.getStackTrace(th2);
            }
            if (!TextUtils.isEmpty(str)) {
                WXLogUtils.e("[WXBridgeManager] invokeRegisterComponents ", str);
                WXExceptionUtils.commitCriticalExceptionRT(null, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_REGISTER_COMPONENT, METHOD_REGISTER_COMPONENTS, str, null);
            }
        }
    }

    public void invokeRegisterModules(Map<String, Object> map, List<Map<String, Object>> list) {
        String str;
        if (map == null || !isJSFrameworkInit()) {
            if (!isJSFrameworkInit()) {
                WXLogUtils.d("[WXinvokeRegisterModulesBridgeManager] invokeRegisterModules: framework.js uninitialized.");
            }
            list.add(map);
            return;
        }
        WXJSObject wsonOrJsonWXJSObject = WXWsonJSONSwitch.toWsonOrJsonWXJSObject(map);
        try {
            IWXBridge iWXBridge = this.mWXBridge;
            if (iWXBridge instanceof WXBridge) {
                ((WXBridge) iWXBridge).registerModuleOnDataRenderNode(WXJsonUtils.fromObjectToJSONString(map));
            }
        } catch (Throwable th) {
            WXLogUtils.e("Weex [data_render register err]", th);
        }
        try {
            str = this.mWXBridge.execJS("", null, METHOD_REGISTER_MODULES, new WXJSObject[]{wsonOrJsonWXJSObject}) == 0 ? "execJS error" : null;
            for (String str2 : map.keySet()) {
                if (str2 != null) {
                    WXModuleManager.resetModuleState(str2, true);
                }
            }
        } catch (Throwable th2) {
            str = WXErrorCode.WX_KEY_EXCEPTION_INVOKE_REGISTER_MODULES.getErrorMsg() + " \n " + th2.getMessage() + map.entrySet().toString();
        }
        if (!TextUtils.isEmpty(str)) {
            WXLogUtils.e("[WXBridgeManager] invokeRegisterModules:", str);
            WXExceptionUtils.commitCriticalExceptionRT(null, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_REGISTER_MODULES, "invokeRegisterModules", str, null);
        }
    }

    private boolean isSkipFrameworkInit(WXSDKInstance wXSDKInstance) {
        if (wXSDKInstance == null) {
            return false;
        }
        return wXSDKInstance.skipFrameworkInit();
    }

    private boolean isSkipFrameworkInit(String str) {
        return isSkipFrameworkInit(WXSDKManager.getInstance().getSDKInstance(str));
    }

    private void mock(String str) {
    }

    private void onJsFrameWorkInitSuccees() {
        for (Map.Entry<String, String> entry : mWeexCoreEnvOptions.entrySet()) {
            this.mWXBridge.registerCoreEnv(entry.getKey(), entry.getValue());
        }
        mWeexCoreEnvOptions.clear();
    }

    private void registerDomModule() throws WXException {
        HashMap hashMap = new HashMap();
        hashMap.put(WXDomModule.WXDOM, WXDomModule.METHODS);
        registerModules(hashMap);
    }

    public void removeTaskByInstance(String str) {
        this.mNextTickTasks.removeFromMapAndStack(str);
    }

    private void sendMessage(String str, int i2) {
        Message obtain = Message.obtain(this.mJSHandler);
        obtain.obj = str;
        obtain.what = i2;
        obtain.sendToTarget();
    }

    private void setExceedGPULimitComponentsInfo(String str, String str2, GraphicSize graphicSize) {
        float openGLRenderLimitValue = (float) WXRenderManager.getOpenGLRenderLimitValue();
        if (openGLRenderLimitValue <= 0.0f) {
            return;
        }
        if (graphicSize.getHeight() > openGLRenderLimitValue || graphicSize.getWidth() > openGLRenderLimitValue) {
            JSONObject jSONObject = new JSONObject();
            WXComponent wXComponent = WXSDKManager.getInstance().getWXRenderManager().getWXComponent(str, str2);
            jSONObject.put("GPU limit", (Object) String.valueOf(openGLRenderLimitValue));
            jSONObject.put("component.width", (Object) String.valueOf(graphicSize.getWidth()));
            jSONObject.put("component.height", (Object) String.valueOf(graphicSize.getHeight()));
            if (wXComponent.getComponentType() != null && !wXComponent.getComponentType().isEmpty()) {
                jSONObject.put("component.type", (Object) wXComponent.getComponentType());
            }
            if (wXComponent.getStyles() != null && !wXComponent.getStyles().isEmpty()) {
                jSONObject.put("component.style", (Object) wXComponent.getStyles().toString());
            }
            if (wXComponent.getAttrs() != null && !wXComponent.getAttrs().isEmpty()) {
                jSONObject.put("component.attr", (Object) wXComponent.getAttrs().toString());
            }
            if (wXComponent.getEvents() != null && !wXComponent.getEvents().isEmpty()) {
                jSONObject.put("component.event", (Object) wXComponent.getEvents().toString());
            }
            if (wXComponent.getMargin() != null) {
                jSONObject.put("component.margin", (Object) wXComponent.getMargin().toString());
            }
            if (wXComponent.getPadding() != null) {
                jSONObject.put("component.padding", (Object) wXComponent.getPadding().toString());
            }
            if (wXComponent.getBorder() != null) {
                jSONObject.put("component.border", (Object) wXComponent.getBorder().toString());
            }
            WXSDKManager.getInstance().getSDKInstance(str).setComponentsInfoExceedGPULimit(jSONObject);
        }
    }

    public void setJSFrameworkInit(boolean z2) {
        mInit = z2;
        if (z2) {
            onJsFrameWorkInitSuccees();
        }
    }

    private void trackComponentAndModulesTime() {
        post(new Runnable(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.22
            final WXBridgeManager this$0;

            {
                this.this$0 = r4;
            }

            @Override // java.lang.Runnable
            public void run() {
                WXEnvironment.sComponentsAndModulesReadyTime = System.currentTimeMillis() - WXEnvironment.sSDKInitStart;
            }
        });
    }

    public static void updateGlobalConfig(String str) {
        String str2 = str;
        if (TextUtils.isEmpty(str)) {
            str2 = "none";
        }
        if (!TextUtils.equals(str2, globalConfig)) {
            globalConfig = str2;
            WXEnvironment.addCustomOptions(GLOBAL_CONFIG_KEY, str2);
            AnonymousClass26 r02 = new Runnable() { // from class: com.taobao.weex.bridge.WXBridgeManager.26
                @Override // java.lang.Runnable
                public void run() {
                    if (WXBridgeManager.mBridgeManager != null && WXBridgeManager.mBridgeManager.isJSFrameworkInit() && (WXBridgeManager.mBridgeManager.mWXBridge instanceof WXBridge)) {
                        ((WXBridge) WXBridgeManager.mBridgeManager.mWXBridge).nativeUpdateGlobalConfig(WXBridgeManager.globalConfig);
                    }
                    if (WXBridgeManager.globalConfig.contains(WXWsonJSONSwitch.WSON_OFF)) {
                        WXWsonJSONSwitch.USE_WSON = false;
                    } else {
                        WXWsonJSONSwitch.USE_WSON = true;
                    }
                }
            };
            if (mBridgeManager == null || !mBridgeManager.isJSFrameworkInit()) {
                r02.run();
            } else {
                mBridgeManager.post(r02);
            }
        }
    }

    public void asyncCallJSEventVoidResult(String str, String str2, List<Object> list, Object... objArr) {
        post(new Runnable(this, objArr, list, str, str2) { // from class: com.taobao.weex.bridge.WXBridgeManager.11
            final WXBridgeManager this$0;
            final Object[] val$args;
            final String val$instanceId;
            final String val$method;
            final List val$params;

            {
                this.this$0 = r4;
                this.val$args = r5;
                this.val$params = r6;
                this.val$method = r7;
                this.val$instanceId = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    Object[] objArr2 = this.val$args;
                    if (!(objArr2 == null || objArr2.length == 0)) {
                        ArrayList arrayList = new ArrayList();
                        for (Object obj : this.val$args) {
                            arrayList.add(obj);
                        }
                        if (this.val$params != null) {
                            ArrayMap arrayMap = new ArrayMap(4);
                            arrayMap.put("params", this.val$params);
                            arrayList.add(arrayMap);
                        }
                        WXHashMap wXHashMap = new WXHashMap();
                        wXHashMap.put("method", this.val$method);
                        wXHashMap.put("args", arrayList);
                        WXJSObject[] wXJSObjectArr = new WXJSObject[2];
                        wXJSObjectArr[0] = new WXJSObject(2, this.val$instanceId);
                        wXJSObjectArr[1] = WXWsonJSONSwitch.toWsonOrJsonWXJSObject(new Object[]{wXHashMap});
                        this.this$0.invokeExecJS(String.valueOf(this.val$instanceId), null, WXBridgeManager.METHOD_CALL_JS, wXJSObjectArr, true);
                        wXJSObjectArr[0] = null;
                    }
                } catch (Exception e2) {
                    WXLogUtils.e("asyncCallJSEventVoidResult", e2);
                }
            }
        });
    }

    public void bindMeasurementToRenderObject(long j2) {
        if (isJSFrameworkInit()) {
            this.mWXBridge.bindMeasurementToRenderObject(j2);
        }
    }

    public int callAddChildToRichtext(String str, String str2, String str3, String str4, String str5, HashMap<String, String> hashMap, HashMap<String, String> hashMap2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str3)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callAddChildToRichtext arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callAddChildToRichtext", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionAddChildToRichtext graphicActionAddChildToRichtext = new GraphicActionAddChildToRichtext(sDKInstance, str2, str3, str4, str5, hashMap, hashMap2);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionAddChildToRichtext.getPageId(), graphicActionAddChildToRichtext);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callAddChildToRichtext exception: ", WXLogUtils.getStackTrace(e2));
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callAddChildToRichtext", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callAddElement(String str, String str2, String str3, int i2, String str4, HashMap<String, String> hashMap, HashMap<String, String> hashMap2, HashSet<String> hashSet, float[] fArr, float[] fArr2, float[] fArr3, boolean z2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callAddElement arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callAddElement", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet2 = this.mDestroyedInstanceId;
        if (hashSet2 != null && hashSet2.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionAddElement graphicActionAddElement = new GraphicActionAddElement(sDKInstance, str3, str2, str4, i2, hashMap, hashMap2, hashSet, fArr, fArr2, fArr3);
            if (z2) {
                sDKInstance.addInActiveAddElementAction(str3, graphicActionAddElement);
                return 1;
            }
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, graphicActionAddElement);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callAddElement exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callAddElement", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callAddEvent(String str, String str2, String str3) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callAddEvent arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callAddEvent", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                new GraphicActionAddEvent(sDKInstance, str2, str3).executeActionOnRender();
            }
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callAddEvent exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callAddEvent", WXLogUtils.getStackTrace(e2), null);
        }
        getNextTick(str);
        return 1;
    }

    public int callAppendTreeCreateFinish(String str, String str2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            WXLogUtils.d("[WXBridgeManager] call callAppendTreeCreateFinish arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callAppendTreeCreateFinish", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, new GraphicActionAppendTreeCreateFinish(WXSDKManager.getInstance().getSDKInstance(str), str2));
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callAppendTreeCreateFinish exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callAppendTreeCreateFinish", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public void callBacthEnd(String str) {
        if (TextUtils.isEmpty(str)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callRemoveChildFromRichtext arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRemoveChildFromRichtext", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                GraphicActionBatchEnd graphicActionBatchEnd = new GraphicActionBatchEnd(sDKInstance, "");
                WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionBatchEnd.getPageId(), graphicActionBatchEnd);
            }
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRemoveChildFromRichtext exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRemoveChildFromRichtext", WXLogUtils.getStackTrace(e2), null);
        }
    }

    public void callBacthStart(String str) {
        if (TextUtils.isEmpty(str)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callRemoveChildFromRichtext arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRemoveChildFromRichtext", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                GraphicActionBatchBegin graphicActionBatchBegin = new GraphicActionBatchBegin(sDKInstance, "");
                WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionBatchBegin.getPageId(), graphicActionBatchBegin);
            }
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRemoveChildFromRichtext exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRemoveChildFromRichtext", WXLogUtils.getStackTrace(e2), null);
        }
    }

    public int callCreateBody(String str, String str2, String str3, HashMap<String, String> hashMap, HashMap<String, String> hashMap2, HashSet<String> hashSet, float[] fArr, float[] fArr2, float[] fArr3) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            WXLogUtils.d("[WXBridgeManager] call callCreateBody arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callCreateBody", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet2 = this.mDestroyedInstanceId;
        if (hashSet2 != null && hashSet2.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionCreateBody graphicActionCreateBody = new GraphicActionCreateBody(sDKInstance, str3, str2, hashMap, hashMap2, hashSet, fArr, fArr2, fArr3);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionCreateBody.getPageId(), graphicActionCreateBody);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callCreateBody exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callCreateBody", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callCreateFinish(String str) {
        if (TextUtils.isEmpty(str)) {
            WXLogUtils.d("[WXBridgeManager] call callCreateFinish arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callCreateFinish", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            long currentTimeMillis = System.currentTimeMillis();
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            sDKInstance.firstScreenCreateInstanceTime(currentTimeMillis);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, new GraphicActionCreateFinish(sDKInstance));
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callCreateFinish exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callCreateFinish", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callHasTransitionPros(String str, String str2, HashMap<String, String> hashMap) {
        WXComponent wXComponent = WXSDKManager.getInstance().getWXRenderManager().getWXComponent(str, str2);
        if (wXComponent == null || wXComponent.getTransition() == null || wXComponent.getTransition().getProperties() == null) {
            return -1;
        }
        for (String str3 : wXComponent.getTransition().getProperties()) {
            if (hashMap.containsKey(str3)) {
                return 1;
            }
        }
        return 0;
    }

    public int callLayout(String str, String str2, int i2, int i3, int i4, int i5, int i6, int i7, boolean z2, int i8) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callLayout arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callLayout", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicSize graphicSize = new GraphicSize((float) i7, (float) i6);
            GraphicPosition graphicPosition = new GraphicPosition((float) i4, (float) i2, (float) i5, (float) i3);
            setExceedGPULimitComponentsInfo(str, str2, graphicSize);
            GraphicActionAddElement inActiveAddElementAction = sDKInstance.getInActiveAddElementAction(str2);
            if (inActiveAddElementAction != null) {
                inActiveAddElementAction.setRTL(z2);
                inActiveAddElementAction.setSize(graphicSize);
                inActiveAddElementAction.setPosition(graphicPosition);
                if (!TextUtils.equals(str2, WXComponent.ROOT)) {
                    inActiveAddElementAction.setIndex(i8);
                }
                WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, inActiveAddElementAction);
                sDKInstance.removeInActiveAddElmentAction(str2);
                return 1;
            }
            GraphicActionLayout graphicActionLayout = new GraphicActionLayout(sDKInstance, str2, graphicPosition, graphicSize, z2);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionLayout.getPageId(), graphicActionLayout);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callLayout exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callLayout", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public Object callModuleMethod(String str, String str2, String str3, JSONArray jSONArray) {
        return callModuleMethod(str, str2, str3, jSONArray, null);
    }

    public Object callModuleMethod(String str, String str2, String str3, JSONArray jSONArray, JSONObject jSONObject) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        if (sDKInstance == null) {
            return null;
        }
        if (!sDKInstance.isNeedValidate() || WXSDKManager.getInstance().getValidateProcessor() == null) {
            try {
                return WXModuleManager.callModuleMethod(str, str2, str3, jSONArray);
            } catch (NumberFormatException e2) {
                ArrayMap arrayMap = new ArrayMap();
                arrayMap.put("moduleName", str2);
                arrayMap.put("methodName", str3);
                arrayMap.put("args", jSONArray.toJSONString());
                WXLogUtils.e("[WXBridgeManager] callNative : numberFormatException when parsing string to numbers in args", arrayMap.toString());
                return null;
            }
        } else {
            WXValidateProcessor.WXModuleValidateResult onModuleValidate = WXSDKManager.getInstance().getValidateProcessor().onModuleValidate(sDKInstance, str2, str3, jSONArray, jSONObject);
            if (onModuleValidate == null) {
                return null;
            }
            if (onModuleValidate.isSuccess) {
                return WXModuleManager.callModuleMethod(str, str2, str3, jSONArray);
            }
            JSONObject jSONObject2 = onModuleValidate.validateInfo;
            if (jSONObject2 != null) {
                WXLogUtils.e("[WXBridgeManager] module validate fail. >>> " + jSONObject2.toJSONString());
            }
            return jSONObject2;
        }
    }

    public int callMoveElement(String str, String str2, String str3, int i2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callMoveElement arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callMoveElement", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionMoveElement graphicActionMoveElement = new GraphicActionMoveElement(sDKInstance, str2, str3, i2);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionMoveElement.getPageId(), graphicActionMoveElement);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callMoveElement exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callMoveElement", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callNative(String str, JSONArray jSONArray, String str2) {
        if (TextUtils.isEmpty(str) || jSONArray == null) {
            WXLogUtils.d("[WXBridgeManager] call callNative arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callNative", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        long nanoTime = System.nanoTime();
        long nanoTime2 = System.nanoTime();
        if (jSONArray != null && jSONArray.size() > 0) {
            int size = jSONArray.size();
            for (int i2 = 0; i2 < size; i2++) {
                try {
                    JSONObject jSONObject = (JSONObject) jSONArray.get(i2);
                    if (!(jSONObject == null || WXSDKManager.getInstance().getSDKInstance(str) == null)) {
                        Object obj = jSONObject.get("module");
                        if (obj != null) {
                            if (WXDomModule.WXDOM.equals(obj)) {
                                WXModuleManager.getDomModule(str).callDomMethod(jSONObject, nanoTime2 - nanoTime);
                            } else {
                                callModuleMethod(str, (String) obj, (String) jSONObject.get("method"), (JSONArray) jSONObject.get("args"), jSONObject.getJSONObject("options"));
                            }
                        } else if (jSONObject.get(COMPONENT) != null) {
                            WXModuleManager.getDomModule(str).invokeMethod((String) jSONObject.get("ref"), (String) jSONObject.get("method"), (JSONArray) jSONObject.get("args"));
                        } else {
                            throw new IllegalArgumentException("unknown callNative");
                        }
                    }
                } catch (Exception e2) {
                    WXLogUtils.e("[WXBridgeManager] callNative exception: ", e2);
                    WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callNative", WXLogUtils.getStackTrace(e2), null);
                }
            }
        }
        if ("undefined".equals(str2) || NON_CALLBACK.equals(str2)) {
            return 0;
        }
        getNextTick(str, str2);
        return 1;
    }

    public Object callNativeComponent(String str, String str2, String str3, JSONArray jSONArray, Object obj) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            WXLogUtils.d("[WXBridgeManager] call callNativeComponent arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callNativeComponent", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        try {
            WXDomModule domModule = WXModuleManager.getDomModule(str);
            if (domModule != null) {
                domModule.invokeMethod(str2, str3, jSONArray);
                return null;
            }
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null && sDKInstance.isDestroy()) {
                return null;
            }
            WXLogUtils.e("WXBridgeManager", "callNativeComponent exception :null == dom ,method:" + str3);
            return null;
        } catch (Exception e2) {
            while (true) {
                WXLogUtils.e("[WXBridgeManager] callNativeComponent exception: ", e2);
                WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callNativeComponent", WXLogUtils.getStackTrace(e2), null);
                return null;
            }
        }
    }

    public Object callNativeModule(String str, String str2, String str3, JSONArray jSONArray, JSONObject jSONObject) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            WXLogUtils.d("[WXBridgeManager] call callNativeModule arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callNativeModule", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXStateRecord.getInstance().recordAction(str, "callNativeModule:" + str2 + Operators.DOT_STR + str3);
        WXEnvironment.isApkDebugable();
        try {
            if (!WXDomModule.WXDOM.equals(str2)) {
                return callModuleMethod(str, str2, str3, jSONArray, jSONObject);
            }
            WXDomModule domModule = WXModuleManager.getDomModule(str);
            if (domModule != null) {
                return domModule.callDomMethod(str3, jSONArray, new long[0]);
            }
            WXModuleManager.createDomModule(WXSDKManager.getInstance().getSDKInstance(str));
            return null;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callNativeModule exception: " + WXLogUtils.getStackTrace(e2));
            return null;
        }
    }

    public Object callNativeModule(String str, String str2, String str3, JSONArray jSONArray, Object obj) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            WXLogUtils.d("[WXBridgeManager] call callNativeModule arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callNativeModule", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        try {
            return WXDomModule.WXDOM.equals(str2) ? WXModuleManager.getDomModule(str).callDomMethod(str3, jSONArray, new long[0]) : callModuleMethod(str, str2, str3, jSONArray);
        } catch (Exception e2) {
            String str4 = "[WXBridgeManager] callNative exception: " + WXLogUtils.getStackTrace(e2);
            WXLogUtils.e(str4);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callNativeModule", str4, null);
            return null;
        }
    }

    public int callRefreshFinish(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            WXLogUtils.d("[WXBridgeManager] call callRefreshFinish arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRefreshFinish", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, new GraphicActionRefreshFinish(sDKInstance));
            }
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRefreshFinish exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRefreshFinish", WXLogUtils.getStackTrace(e2), null);
        }
        if ("undefined".equals(str2) || NON_CALLBACK.equals(str2)) {
            return 0;
        }
        getNextTick(str, str2);
        return 1;
    }

    public int callRemoveChildFromRichtext(String str, String str2, String str3, String str4) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callRemoveChildFromRichtext arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRemoveChildFromRichtext", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionRemoveChildFromRichtext graphicActionRemoveChildFromRichtext = new GraphicActionRemoveChildFromRichtext(sDKInstance, str2, str3, str4);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionRemoveChildFromRichtext.getPageId(), graphicActionRemoveChildFromRichtext);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRemoveChildFromRichtext exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRemoveChildFromRichtext", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callRemoveElement(String str, String str2) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callRemoveElement arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRemoveElement", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionRemoveElement graphicActionRemoveElement = new GraphicActionRemoveElement(sDKInstance, str2);
            if (sDKInstance.getInActiveAddElementAction(str2) != null) {
                sDKInstance.removeInActiveAddElmentAction(str2);
                return 1;
            }
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionRemoveElement.getPageId(), graphicActionRemoveElement);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRemoveElement exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRemoveElement", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callRemoveEvent(String str, String str2, String str3) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callRemoveEvent arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRemoveEvent", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance != null) {
                new GraphicActionRemoveEvent(sDKInstance, str2, str3).executeActionOnRender();
            }
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRemoveEvent exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRemoveEvent", WXLogUtils.getStackTrace(e2), null);
        }
        getNextTick(str);
        return 1;
    }

    public int callRenderSuccess(String str) {
        if (TextUtils.isEmpty(str)) {
            WXLogUtils.d("[WXBridgeManager] call callRenderSuccess arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callRenderSuccess", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(str, new GraphicActionRenderSuccess(sDKInstance));
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callRenderSuccess exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callRenderSuccess", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public void callReportCrash(String str, String str2, String str3, Map<String, String> map) {
        String str4 = str + Operators.DOT_STR + new SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(new Date());
        File file = new File(str);
        File file2 = new File(str4);
        if (file.exists()) {
            file.renameTo(file2);
        }
        new Thread(new Runnable(this, str4, str2, str3, map) { // from class: com.taobao.weex.bridge.WXBridgeManager.7
            final WXBridgeManager this$0;
            final Map val$extInfo;
            final String val$instanceId;
            final String val$origin_filename;
            final String val$url;

            {
                this.this$0 = r4;
                this.val$origin_filename = r5;
                this.val$instanceId = r6;
                this.val$url = r7;
                this.val$extInfo = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    File file3 = new File(this.val$origin_filename);
                    if (file3.exists()) {
                        if (file3.length() > 0) {
                            StringBuilder sb = new StringBuilder();
                            try {
                                BufferedReader bufferedReader = new BufferedReader(new FileReader(this.val$origin_filename));
                                while (true) {
                                    String readLine = bufferedReader.readLine();
                                    if (readLine == null) {
                                        break;
                                    } else if (!"".equals(readLine)) {
                                        sb.append(readLine + "\n");
                                    }
                                }
                                this.this$0.commitJscCrashAlarmMonitor(IWXUserTrackAdapter.JS_BRIDGE, WXErrorCode.WX_ERR_JSC_CRASH, sb.toString(), this.val$instanceId, this.val$url, this.val$extInfo);
                                bufferedReader.close();
                            } catch (Exception e2) {
                                WXLogUtils.e(WXLogUtils.getStackTrace(e2));
                            }
                        } else {
                            WXLogUtils.e("[WXBridgeManager] callReportCrash crash file is empty");
                        }
                        if (!WXEnvironment.isApkDebugable()) {
                            file3.delete();
                        }
                    }
                } catch (Throwable th) {
                    WXLogUtils.e("[WXBridgeManager] callReportCrash exception: ", th);
                }
            }
        }).start();
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x00d3  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0123 A[Catch: Exception -> 0x0179, TRY_LEAVE, TryCatch #3 {Exception -> 0x0179, blocks: (B:3:0x0005, B:5:0x0013, B:7:0x0026, B:21:0x00bc, B:24:0x00c7, B:29:0x00db, B:30:0x00ef, B:35:0x0103, B:36:0x011b, B:36:0x011b, B:39:0x0123, B:41:0x014d, B:43:0x016d), top: B:60:0x0005 }] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x014d A[Catch: Exception -> 0x0179, TRY_ENTER, TRY_LEAVE, TryCatch #3 {Exception -> 0x0179, blocks: (B:3:0x0005, B:5:0x0013, B:7:0x0026, B:21:0x00bc, B:24:0x00c7, B:29:0x00db, B:30:0x00ef, B:35:0x0103, B:36:0x011b, B:36:0x011b, B:39:0x0123, B:41:0x014d, B:43:0x016d), top: B:60:0x0005 }] */
    /* Code decompiled incorrectly, please refer to instructions dump */
    public int callReportCrashReloadPage(java.lang.String r9, java.lang.String r10) {
        /*
        // Method dump skipped, instructions count: 452
        */
        throw new UnsupportedOperationException("Method not decompiled: com.taobao.weex.bridge.WXBridgeManager.callReportCrashReloadPage(java.lang.String, java.lang.String):int");
    }

    public int callUpdateAttrs(String str, String str2, HashMap<String, String> hashMap) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callUpdateAttrs arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callUpdateAttrs", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionUpdateAttr graphicActionUpdateAttr = new GraphicActionUpdateAttr(sDKInstance, str2, hashMap);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionUpdateAttr.getPageId(), graphicActionUpdateAttr);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callUpdateAttrs exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callUpdateAttrs", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callUpdateFinish(String str, String str2) {
        if (TextUtils.isEmpty(str)) {
            WXLogUtils.d("[WXBridgeManager] call callUpdateFinish arguments is null");
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callUpdateFinish", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKManager.getInstance().getSDKInstance(str);
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callUpdateFinish exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callUpdateFinish", WXLogUtils.getStackTrace(e2), null);
        }
        if (str2 == null || str2.isEmpty() || "undefined".equals(str2) || NON_CALLBACK.equals(str2)) {
            return 0;
        }
        getNextTick(str, str2);
        return 1;
    }

    public int callUpdateRichtextChildAttr(String str, String str2, HashMap<String, String> hashMap, String str3, String str4) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callUpdateRichtextChildAttr arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callUpdateRichtextChildAttr", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionUpdateRichtextAttr graphicActionUpdateRichtextAttr = new GraphicActionUpdateRichtextAttr(sDKInstance, str2, hashMap, str3, str4);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionUpdateRichtextAttr.getPageId(), graphicActionUpdateRichtextAttr);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callUpdateRichtextChildAttr exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callUpdateRichtextChildAttr", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callUpdateRichtextStyle(String str, String str2, HashMap<String, String> hashMap, String str3, String str4) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callUpdateRichtextStyle arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callUpdateRichtextStyle", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionUpdateRichtextStyle graphicActionUpdateRichtextStyle = new GraphicActionUpdateRichtextStyle(sDKInstance, str2, hashMap, str3, str4);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionUpdateRichtextStyle.getPageId(), graphicActionUpdateRichtextStyle);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callUpdateRichtextStyle exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callUpdateRichtextStyle", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    public int callUpdateStyle(String str, String str2, HashMap<String, Object> hashMap, HashMap<String, String> hashMap2, HashMap<String, String> hashMap3, HashMap<String, String> hashMap4) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            if (WXEnvironment.isApkDebugable()) {
                WXLogUtils.d("[WXBridgeManager] call callUpdateStyle arguments is null");
            }
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_BRIDGE_ARG_NULL, "callUpdateStyle", "arguments is empty, INSTANCE_RENDERING_ERROR will be set", null);
            return 0;
        }
        WXEnvironment.isApkDebugable();
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null && hashSet.contains(str)) {
            return -1;
        }
        try {
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null) {
                return 1;
            }
            GraphicActionUpdateStyle graphicActionUpdateStyle = new GraphicActionUpdateStyle(sDKInstance, str2, hashMap, hashMap2, hashMap3, hashMap4);
            WXSDKManager.getInstance().getWXRenderManager().postGraphicAction(graphicActionUpdateStyle.getPageId(), graphicActionUpdateStyle);
            return 1;
        } catch (Exception e2) {
            WXLogUtils.e("[WXBridgeManager] callUpdateStyle exception: ", e2);
            WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callUpdateStyle", WXLogUtils.getStackTrace(e2), null);
            return 1;
        }
    }

    @Deprecated
    public void callback(String str, String str2, Object obj, boolean z2) {
        callbackJavascript(str, str2, obj, z2);
    }

    @Deprecated
    public void callback(String str, String str2, String str3) {
        callback(str, str2, str3, false);
    }

    @Deprecated
    public void callback(String str, String str2, Map<String, Object> map) {
        callback(str, str2, map, false);
    }

    public void callbackJavascript(String str, String str2, Object obj, boolean z2) {
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2) && this.mJSHandler != null && RuningAcitvityUtil.isRuningActivity) {
            WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(str);
            if (wXSDKInstance == null || wXSDKInstance.getRenderStrategy() != WXRenderStrategy.DATA_RENDER_BINARY) {
                addJSTask(METHOD_CALLBACK, str, str2, obj, Boolean.valueOf(z2));
                sendMessage(str, 6);
                return;
            }
            callbackJavascriptOnDataRender(str, str2, obj, z2);
        }
    }

    void callbackJavascriptOnDataRender(String str, String str2, Object obj, boolean z2) {
        this.mJSHandler.postDelayed(WXThread.secure(new Runnable(this, obj, str, str2, z2) { // from class: com.taobao.weex.bridge.WXBridgeManager.15
            final WXBridgeManager this$0;
            final String val$callback;
            final Object val$data;
            final String val$instanceId;
            final boolean val$keepAlive;

            {
                this.this$0 = r4;
                this.val$data = r5;
                this.val$instanceId = r6;
                this.val$callback = r7;
                this.val$keepAlive = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    long currentTimeMillis = System.currentTimeMillis();
                    String jSONString = JSON.toJSONString(this.val$data);
                    if (WXEnvironment.isApkDebugable()) {
                        WXLogUtils.d("callbackJavascriptOnDataRender >>>> instanceId:" + this.val$instanceId + ", data:" + jSONString);
                    }
                    if (this.this$0.mWXBridge instanceof WXBridge) {
                        ((WXBridge) this.this$0.mWXBridge).invokeCallbackOnDataRender(this.val$instanceId, this.val$callback, jSONString, this.val$keepAlive);
                    }
                    WXLogUtils.renderPerformanceLog("callbackJavascriptOnDataRender", System.currentTimeMillis() - currentTimeMillis);
                } catch (Throwable th) {
                    String str3 = "[WXBridgeManager] callbackJavascriptOnDataRender " + WXLogUtils.getStackTrace(th);
                    WXExceptionUtils.commitCriticalExceptionRT(this.val$instanceId, WXErrorCode.WX_KEY_EXCEPTION_INVOKE_BRIDGE, "callbackJavascriptOnDataRender", str3, null);
                    WXLogUtils.e(str3);
                }
            }
        }), 0);
    }

    public void checkJsEngineMultiThread() {
        IWXJscProcessManager wXJscProcessManager = WXSDKManager.getInstance().getWXJscProcessManager();
        boolean enableBackupThread = wXJscProcessManager != null ? wXJscProcessManager.enableBackupThread() : false;
        if (enableBackupThread != isJsEngineMultiThreadEnable) {
            isJsEngineMultiThreadEnable = enableBackupThread;
            if (!isJSFrameworkInit()) {
                return;
            }
            if (isJSThread()) {
                WXSDKEngine.reload();
            } else {
                post(new Runnable(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.2
                    final WXBridgeManager this$0;

                    {
                        this.this$0 = r4;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        WXSDKEngine.reload();
                    }
                });
            }
        }
    }

    public void commitJscCrashAlarmMonitor(String str, WXErrorCode wXErrorCode, String str2, String str3, String str4, Map<String, String> map) {
        if (!TextUtils.isEmpty(str) && wXErrorCode != null) {
            Log.d("ReportCrash", " commitJscCrashAlarmMonitor errMsg " + str2);
            HashMap hashMap = new HashMap();
            hashMap.put("jscCrashStack", str2);
            if (map != null) {
                hashMap.putAll(map);
            }
            IWXJSExceptionAdapter iWXJSExceptionAdapter = WXSDKManager.getInstance().getIWXJSExceptionAdapter();
            if (iWXJSExceptionAdapter != null) {
                WXJSExceptionInfo wXJSExceptionInfo = new WXJSExceptionInfo(str3, str4, wXErrorCode, "callReportCrash", "weex core process crash and restart exception", hashMap);
                iWXJSExceptionAdapter.onJSException(wXJSExceptionInfo);
                WXLogUtils.e(wXJSExceptionInfo.toString());
            }
        }
    }

    public void createInstance(String str, Script script, Map<String, Object> map, String str2) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        if (sDKInstance == null) {
            WXLogUtils.e("WXBridgeManager", "createInstance failed, SDKInstance does not exist");
        } else if (TextUtils.isEmpty(str) || script == null || script.isEmpty() || this.mJSHandler == null) {
            sDKInstance.onRenderError(WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorCode(), WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorMsg() + " instanceId==" + str + " template ==" + script + " mJSHandler== " + this.mJSHandler.toString());
        } else if (isSkipFrameworkInit(str) || isJSFrameworkInit() || reInitCount != 1 || WXEnvironment.sDebugServerConnectable) {
            WXModuleManager.createDomModule(sDKInstance);
            sDKInstance.getApmForInstance().onStage(WXInstanceApm.KEY_PAGE_STAGES_LOAD_BUNDLE_START);
            post(new Runnable(this, str, sDKInstance, script, map, str2) { // from class: com.taobao.weex.bridge.WXBridgeManager.18
                final WXBridgeManager this$0;
                final String val$data;
                final WXSDKInstance val$instance;
                final String val$instanceId;
                final Map val$options;
                final Script val$template;

                {
                    this.this$0 = r4;
                    this.val$instanceId = r5;
                    this.val$instance = r6;
                    this.val$template = r7;
                    this.val$options = r8;
                    this.val$data = r9;
                }

                @Override // java.lang.Runnable
                public void run() {
                    long currentTimeMillis = System.currentTimeMillis();
                    this.this$0.mWXBridge.setPageArgument(this.val$instanceId, "renderTimeOrigin", String.valueOf(this.val$instance.getWXPerformance().renderTimeOrigin));
                    this.this$0.mWXBridge.setInstanceRenderType(this.val$instance.getInstanceId(), this.val$instance.getRenderType());
                    this.this$0.invokeCreateInstance(this.val$instance, this.val$template, this.val$options, this.val$data);
                    this.val$instance.getWXPerformance().callCreateInstanceTime = System.currentTimeMillis() - currentTimeMillis;
                    this.val$instance.getWXPerformance().communicateTime = this.val$instance.getWXPerformance().callCreateInstanceTime;
                }
            }, str, sDKInstance, METHOD_CREATE_INSTANCE);
        } else {
            sDKInstance.onRenderError(WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorCode(), WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorMsg() + " isJSFrameworkInit==" + isJSFrameworkInit() + " reInitCount == 1");
            post(new Runnable(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.17
                final WXBridgeManager this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.initFramework("");
                }
            }, str, sDKInstance, "initFrameworkInCreateInstance");
        }
    }

    public void createInstance(String str, String str2, Map<String, Object> map, String str3) {
        createInstance(str, new Script(str2), map, str3);
    }

    public String decrypt(String str, String str2, String str3, String str4) {
        IWXBridge iWXBridge = this.mWXBridge;
        return iWXBridge instanceof WXBridge ? ((WXBridge) iWXBridge).decrypt(str, str2, str3, str4) : "";
    }

    public void destroy() {
        WXThread wXThread = this.mJSThread;
        if (wXThread != null) {
            wXThread.quit();
        }
        mBridgeManager = null;
        HashSet<String> hashSet = this.mDestroyedInstanceId;
        if (hashSet != null) {
            hashSet.clear();
        }
    }

    public void destroyInstance(String str) {
        if (this.mJSHandler != null && !TextUtils.isEmpty(str)) {
            HashSet<String> hashSet = this.mDestroyedInstanceId;
            if (hashSet != null) {
                hashSet.add(str);
            }
            this.mJSHandler.removeCallbacksAndMessages(str);
            post(new Runnable(this, str) { // from class: com.taobao.weex.bridge.WXBridgeManager.19
                final WXBridgeManager this$0;
                final String val$instanceId;

                {
                    this.this$0 = r4;
                    this.val$instanceId = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.removeTaskByInstance(this.val$instanceId);
                    this.this$0.invokeDestroyInstance(this.val$instanceId);
                }
            }, str, null, METHOD_DESTROY_INSTANCE);
        }
    }

    public String dumpIpcPageInfo() {
        IWXBridge iWXBridge = this.mWXBridge;
        return iWXBridge instanceof WXBridge ? ((WXBridge) iWXBridge).nativeDumpIpcPageQueueInfo() : "";
    }

    public String encrypt(String str, String str2, String str3, String str4) {
        IWXBridge iWXBridge = this.mWXBridge;
        return iWXBridge instanceof WXBridge ? ((WXBridge) iWXBridge).encrypt(str, str2, str3, str4) : "";
    }

    public String encryptGetClientKeyPayload(String str, String str2, String str3) {
        IWXBridge iWXBridge = this.mWXBridge;
        return iWXBridge instanceof WXBridge ? ((WXBridge) iWXBridge).encryptGetClientKeyPayload(str, str2, str3) : "";
    }

    public void execJSService(String str) {
        postWithName(new Runnable(this, str) { // from class: com.taobao.weex.bridge.WXBridgeManager.25
            final WXBridgeManager this$0;
            final String val$service;

            {
                this.this$0 = r4;
                this.val$service = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                WXBridgeManager wXBridgeManager = this.this$0;
                wXBridgeManager.invokeExecJSService(this.val$service, wXBridgeManager.mRegisterServiceFailList);
            }
        }, null, "execJSService");
    }

    @Deprecated
    public void fireEvent(String str, String str2, String str3, Map<String, Object> map) {
        fireEvent(str, str2, str3, map, null);
    }

    @Deprecated
    public void fireEvent(String str, String str2, String str3, Map<String, Object> map, Map<String, Object> map2) {
        fireEventOnNode(str, str2, str3, map, map2);
    }

    public void fireEventOnNode(String str, String str2, String str3, Map<String, Object> map, Map<String, Object> map2) {
        fireEventOnNode(str, str2, str3, map, map2, null, null);
    }

    public void fireEventOnNode(String str, String str2, String str3, Map<String, Object> map, Map<String, Object> map2, List<Object> list) {
        fireEventOnNode(str, str2, str3, map, map2, list, null);
    }

    public void fireEventOnNode(String str, String str2, String str3, Map<String, Object> map, Map<String, Object> map2, List<Object> list, EventResult eventResult) {
        if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str2) && !TextUtils.isEmpty(str3) && this.mJSHandler != null) {
            if (checkMainThread()) {
                WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(str);
                if (wXSDKInstance != null && (wXSDKInstance.getRenderStrategy() == WXRenderStrategy.DATA_RENDER || wXSDKInstance.getRenderStrategy() == WXRenderStrategy.DATA_RENDER_BINARY)) {
                    fireEventOnDataRenderNode(str, str2, str3, map, map2);
                } else if (eventResult == null) {
                    addJSEventTask(METHOD_FIRE_EVENT, str, list, str2, str3, map, map2);
                    sendMessage(str, 6);
                } else {
                    asyncCallJSEventWithResult(eventResult, METHD_FIRE_EVENT_SYNC, str, list, str2, str3, map, map2);
                }
            } else {
                throw new WXRuntimeException("fireEvent must be called by main thread");
            }
        }
    }

    public void forceLayout(String str) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.forceLayout(str);
        }
    }

    public BundType getBundleType(String str, String str2) {
        if (str != null) {
            try {
                String queryParameter = Uri.parse(str).getQueryParameter(BUNDLE_TYPE);
                if (!"Vue".equals(queryParameter) && !"vue".equals(queryParameter)) {
                    if ("Rax".equals(queryParameter) || "rax".equals(queryParameter)) {
                        return BundType.Rax;
                    }
                }
                return BundType.Vue;
            } catch (Throwable th) {
                WXLogUtils.e(WXLogUtils.getStackTrace(th));
                return BundType.Others;
            }
        }
        return str2 != null ? BundType.Vue : BundType.Others;
    }

    public long[] getFirstScreenRenderTime(String str) {
        return isJSFrameworkInit() ? this.mWXBridge.getFirstScreenRenderTime(str) : new long[]{0, 0, 0};
    }

    public WXParams getInitParams() {
        return this.mInitParams;
    }

    public Looper getJSLooper() {
        WXThread wXThread = this.mJSThread;
        return wXThread != null ? wXThread.getLooper() : null;
    }

    public ContentBoxMeasurement getMeasurementFunc(String str, long j2) {
        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
        return sDKInstance != null ? sDKInstance.getContentBoxMeasurement(j2) : null;
    }

    public long[] getRenderFinishTime(String str) {
        return isJSFrameworkInit() ? this.mWXBridge.getRenderFinishTime(str) : new long[]{0, 0, 0};
    }

    public String getWeexCoreThreadStackTrace() {
        if (this.mJSThread == null) {
            return "null == mJSThread";
        }
        StringBuilder sb = new StringBuilder();
        try {
            sb.append(StringUtil.format("Thread Name: '%s'\n", this.mJSThread.getName()));
            sb.append(String.format(Locale.ENGLISH, "\"%s\" prio=%d tid=%d %s\n", this.mJSThread.getName(), Integer.valueOf(this.mJSThread.getPriority()), Long.valueOf(this.mJSThread.getId()), this.mJSThread.getState()));
            StackTraceElement[] stackTrace = this.mJSThread.getStackTrace();
            int length = stackTrace.length;
            for (int i2 = 0; i2 < length; i2++) {
                sb.append(StringUtil.format("\tat %s\n", stackTrace[i2].toString()));
            }
        } catch (Exception e2) {
            Log.e("weex", "getJSThreadStackTrace error:", e2);
        }
        return sb.toString();
    }

    @Override // android.os.Handler.Callback
    public boolean handleMessage(Message message) {
        if (message == null) {
            return false;
        }
        int i2 = message.what;
        if (i2 == 1) {
            TimerInfo timerInfo = (TimerInfo) message.obj;
            if (timerInfo == null) {
                return false;
            }
            invokeExecJS("", null, METHOD_SET_TIMEOUT, new WXJSObject[]{new WXJSObject(2, timerInfo.callbackId)});
            return false;
        } else if (i2 != 13) {
            if (i2 == 6) {
                invokeCallJSBatch(message);
                return false;
            } else if (i2 != 7) {
                return false;
            } else {
                invokeInitFramework(message);
                return false;
            }
        } else if (message.obj == null) {
            return false;
        } else {
            this.mWXBridge.takeHeapSnapshot((String) message.obj);
            return false;
        }
    }

    public void initScriptsFramework(String str) {
        synchronized (this) {
            Message obtainMessage = this.mJSHandler.obtainMessage();
            obtainMessage.obj = str;
            obtainMessage.what = 7;
            obtainMessage.setTarget(this.mJSHandler);
            obtainMessage.sendToTarget();
        }
    }

    public int invokeCreateInstanceContext(String str, String str2, String str3, WXJSObject[] wXJSObjectArr, boolean z2) {
        WXLogUtils.d("invokeCreateInstanceContext instanceId:" + str + " function:" + str3 + StringUtil.format(" isJSFrameworkInit：%b", Boolean.valueOf(isJSFrameworkInit())));
        this.mLodBuilder.append("createInstanceContext >>>> instanceId:").append(str).append("function:").append(str3);
        if (z2) {
            this.mLodBuilder.append(" tasks:").append(WXJsonUtils.fromObjectToJSONString(wXJSObjectArr));
        }
        WXLogUtils.d(this.mLodBuilder.substring(0));
        this.mLodBuilder.setLength(0);
        return this.mWXBridge.createInstanceContext(str, str2, str3, wXJSObjectArr);
    }

    public void invokeDestoryInstance(String str, String str2, String str3, WXJSObject[] wXJSObjectArr, boolean z2) {
        this.mLodBuilder.append("callJS >>>> instanceId:").append(str).append("function:").append(str3);
        if (z2) {
            this.mLodBuilder.append(" tasks:").append(WXJsonUtils.fromObjectToJSONString(wXJSObjectArr));
        }
        WXLogUtils.d(this.mLodBuilder.substring(0));
        this.mLodBuilder.setLength(0);
        this.mWXBridge.removeInstanceRenderType(str);
        this.mWXBridge.destoryInstance(str, str2, str3, wXJSObjectArr);
    }

    public void invokeExecJS(String str, String str2, String str3, WXJSObject[] wXJSObjectArr, boolean z2) {
        Pair<Pair<String, Object>, Boolean> extractCallbackArgs;
        WXEnvironment.isOpenDebugLog();
        if (RuningAcitvityUtil.isRuningActivity) {
            long currentTimeMillis = System.currentTimeMillis();
            WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
            if (sDKInstance == null || sDKInstance.getRenderStrategy() != WXRenderStrategy.DATA_RENDER_BINARY) {
                WXThread.secure(new Runnable(this, str, str2, str3, wXJSObjectArr) { // from class: com.taobao.weex.bridge.WXBridgeManager.20
                    final WXBridgeManager this$0;
                    final WXJSObject[] val$args;
                    final String val$function;
                    final String val$instanceId;
                    final String val$namespace;

                    {
                        this.this$0 = r4;
                        this.val$instanceId = r5;
                        this.val$namespace = r6;
                        this.val$function = r7;
                        this.val$args = r8;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        this.this$0.mWXBridge.execJS(this.val$instanceId, this.val$namespace, this.val$function, this.val$args);
                    }
                }, sDKInstance, "ExecJs").run();
            } else if (wXJSObjectArr.length != 2 || !(wXJSObjectArr[0].data instanceof String) || !(wXJSObjectArr[1].data instanceof String) || (extractCallbackArgs = extractCallbackArgs((String) wXJSObjectArr[1].data)) == null) {
                WXLogUtils.w("invokeExecJS on data render that is not a callback call");
                return;
            } else {
                callbackJavascriptOnDataRender(str, (String) ((Pair) extractCallbackArgs.first).first, ((Pair) extractCallbackArgs.first).second, ((Boolean) extractCallbackArgs.second).booleanValue());
            }
            if (sDKInstance != null) {
                long currentTimeMillis2 = System.currentTimeMillis() - currentTimeMillis;
                sDKInstance.getApmForInstance().updateFSDiffStats(WXInstanceApm.KEY_PAGE_STATS_FS_CALL_JS_NUM, 1.0d);
                sDKInstance.getApmForInstance().updateFSDiffStats(WXInstanceApm.KEY_PAGE_STATS_FS_CALL_JS_TIME, (double) currentTimeMillis2);
                sDKInstance.callJsTime(currentTimeMillis2);
            }
        }
    }

    public boolean isJSFrameworkInit() {
        return mInit;
    }

    public boolean isJSThread() {
        WXThread wXThread = this.mJSThread;
        return wXThread != null && wXThread.getId() == Thread.currentThread().getId();
    }

    public boolean jsEngineMultiThreadEnable() {
        return isJsEngineMultiThreadEnable;
    }

    public void loadJsBundleInPreInitMode(String str, String str2) {
        post(new Runnable(this, str, str2) { // from class: com.taobao.weex.bridge.WXBridgeManager.9
            final WXBridgeManager this$0;
            final String val$instanceId;
            final String val$js;

            {
                this.this$0 = r4;
                this.val$instanceId = r5;
                this.val$js = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.this$0.invokeExecJSOnInstance(this.val$instanceId, this.val$js, -1);
                WXSDKInstance wXSDKInstance = WXSDKManager.getInstance().getAllInstanceMap().get(this.val$instanceId);
                if (wXSDKInstance != null && wXSDKInstance.isPreInitMode()) {
                    wXSDKInstance.getApmForInstance().onStage(WXInstanceApm.KEY_PAGE_STAGES_LOAD_BUNDLE_END);
                    wXSDKInstance.getApmForInstance().onStageWithTime(WXInstanceApm.KEY_PAGE_STAGES_END_EXCUTE_BUNDLE, WXUtils.getFixUnixTime() + 600);
                }
            }
        });
    }

    public void markDirty(String str, String str2, boolean z2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.markDirty(str, str2, z2);
        }
    }

    public boolean notifyLayout(String str) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            return this.mWXBridge.notifyLayout(str);
        }
        return false;
    }

    public void notifySerializeCodeCache() {
        post(new Runnable(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.27
            final WXBridgeManager this$0;

            {
                this.this$0 = r4;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.isJSFrameworkInit()) {
                    this.this$0.invokeExecJS("", null, WXBridgeManager.METHOD_NOTIFY_SERIALIZE_CODE_CACHE, new WXJSObject[0]);
                }
            }
        });
    }

    @Deprecated
    public void notifyTrimMemory() {
    }

    public void onInstanceClose(String str) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.onInstanceClose(str);
        }
    }

    public void onInteractionTimeUpdate(String str) {
        post(new Runnable(this, str) { // from class: com.taobao.weex.bridge.WXBridgeManager.1
            final WXBridgeManager this$0;
            final String val$instanceId;

            {
                this.this$0 = r4;
                this.val$instanceId = r5;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.mWXBridge instanceof WXBridge) {
                    ((WXBridge) this.this$0.mWXBridge).nativeOnInteractionTimeUpdate(this.val$instanceId);
                }
            }
        });
    }

    public WXJSObject optionObjConvert(boolean z2, BundType bundType, WXJSObject wXJSObject) {
        JSONObject jSONObject;
        if (!z2) {
            return wXJSObject;
        }
        try {
            JSONObject parseObject = JSON.parseObject(wXJSObject.data.toString());
            JSONObject jSONObject2 = parseObject.getJSONObject("env");
            if (!(jSONObject2 == null || (jSONObject = jSONObject2.getJSONObject("options")) == null)) {
                for (String str : jSONObject.keySet()) {
                    jSONObject2.put(str, (Object) jSONObject.getString(str));
                }
            }
            return new WXJSObject(3, parseObject.toString());
        } catch (Throwable th) {
            WXLogUtils.e(WXLogUtils.getStackTrace(th));
            return wXJSObject;
        }
    }

    @Override // com.taobao.weex.utils.batch.BactchExecutor
    public void post(Runnable runnable) {
        postWithName(runnable, null, null);
    }

    public void post(Runnable runnable, Object obj) {
        post(runnable, obj, null, null);
    }

    public void post(Runnable runnable, Object obj, WXSDKInstance wXSDKInstance, String str) {
        Handler handler = this.mJSHandler;
        if (handler != null) {
            Message obtain = Message.obtain(handler, WXThread.secure(runnable, wXSDKInstance, str));
            obtain.obj = obj;
            obtain.sendToTarget();
        }
    }

    public void postDelay(Runnable runnable, long j2) {
        Handler handler = this.mJSHandler;
        if (handler != null) {
            handler.postDelayed(WXThread.secure(runnable), j2);
        }
    }

    public void postWithName(Runnable runnable, WXSDKInstance wXSDKInstance, String str) {
        Handler handler;
        Runnable secure = WXThread.secure(runnable, wXSDKInstance, str);
        Interceptor interceptor = this.mInterceptor;
        if ((interceptor == null || !interceptor.take(secure)) && (handler = this.mJSHandler) != null) {
            handler.post(secure);
        }
    }

    public void refreshInstance(String str, WXRefreshData wXRefreshData) {
        if (!TextUtils.isEmpty(str) && wXRefreshData != null) {
            this.mJSHandler.postDelayed(WXThread.secure(new Runnable(this, str, wXRefreshData) { // from class: com.taobao.weex.bridge.WXBridgeManager.16
                final WXBridgeManager this$0;
                final String val$instanceId;
                final WXRefreshData val$jsonData;

                {
                    this.this$0 = r4;
                    this.val$instanceId = r5;
                    this.val$jsonData = r6;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.invokeRefreshInstance(this.val$instanceId, this.val$jsonData);
                }
            }), 0);
        }
    }

    public void registerComponents(List<Map<String, Object>> list) {
        if (this.mJSHandler != null && list != null && list.size() != 0) {
            AnonymousClass24 r02 = new Runnable(this, list) { // from class: com.taobao.weex.bridge.WXBridgeManager.24
                final WXBridgeManager this$0;
                final List val$components;

                {
                    this.this$0 = r4;
                    this.val$components = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    WXBridgeManager wXBridgeManager = this.this$0;
                    wXBridgeManager.invokeRegisterComponents(this.val$components, wXBridgeManager.mRegisterComponentFailList);
                }
            };
            if (!isJSThread() || !isJSFrameworkInit()) {
                post(r02);
            } else {
                r02.run();
            }
        }
    }

    public void registerCoreEnv(String str, String str2) {
        if (isJSFrameworkInit()) {
            this.mWXBridge.registerCoreEnv(str, str2);
        } else {
            mWeexCoreEnvOptions.put(str, str2);
        }
    }

    public void registerModules(Map<String, Object> map) {
        if (map != null && map.size() != 0) {
            if (isJSThread()) {
                invokeRegisterModules(map, this.mRegisterModuleFailList);
            } else {
                post(new Runnable(this, map) { // from class: com.taobao.weex.bridge.WXBridgeManager.23
                    final WXBridgeManager this$0;
                    final Map val$modules;

                    {
                        this.this$0 = r4;
                        this.val$modules = r5;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        WXBridgeManager wXBridgeManager = this.this$0;
                        wXBridgeManager.invokeRegisterModules(this.val$modules, wXBridgeManager.mRegisterModuleFailList);
                    }
                }, null);
            }
        }
    }

    public void reloadPageLayout(String str) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.reloadPageLayout(str);
        }
    }

    public void removeMessage(int i2, Object obj) {
        WXThread wXThread;
        if (this.mJSHandler != null && (wXThread = this.mJSThread) != null && wXThread.isWXThreadAlive() && this.mJSThread.getLooper() != null) {
            this.mJSHandler.removeMessages(i2, obj);
        }
    }

    public void reportJSException(String str, String str2, String str3) {
        String str4 = str2;
        if (str2.startsWith("jsscope::")) {
            Context applicationContext = WXEnvironment.getApplication().getApplicationContext();
            if (applicationContext != null && !BaseInfo.isBase(applicationContext)) {
                str.hashCode();
                int i2 = 4;
                String str5 = "uni-jsframework.js";
                char c2 = 65535;
                switch (str.hashCode()) {
                    case -2076326187:
                        if (str.equals("jsframework")) {
                            c2 = 0;
                            break;
                        }
                        break;
                    case -518688385:
                        if (str.equals("uni-jsframework.js")) {
                            c2 = 1;
                            break;
                        }
                        break;
                    case 3271632:
                        if (str.equals("jsfm")) {
                            c2 = 2;
                            break;
                        }
                        break;
                    case 293174862:
                        if (str.equals("app-service.js")) {
                            c2 = 3;
                            break;
                        }
                        break;
                    case 1984153269:
                        if (str.equals("service")) {
                            c2 = 4;
                            break;
                        }
                        break;
                }
                switch (c2) {
                    case 0:
                    case 1:
                    case 2:
                    case 4:
                        break;
                    case 3:
                        str5 = str;
                        i2 = 5;
                        break;
                    default:
                        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(str);
                        if (sDKInstance == null) {
                            i2 = 6;
                            str5 = str;
                            break;
                        } else {
                            str5 = sDKInstance.getUniPagePath();
                            if (str5 != "app-service.js") {
                                i2 = 6;
                                break;
                            }
                            i2 = 5;
                            break;
                        }
                }
                org.json.JSONObject createJSONObject = JSONUtil.createJSONObject(AppRuntime.getUniStatistics());
                if (createJSONObject != null) {
                    String string = JSONUtil.getString(createJSONObject, "version");
                    boolean z2 = JSONUtil.getBoolean(createJSONObject, WebLoadEvent.ENABLE);
                    if (PdrUtil.isEquals(ExifInterface.GPS_MEASUREMENT_2D, string) && z2) {
                        UEH.commitUncatchException(applicationContext, str5, str3, i2);
                    }
                }
            }
            str4 = str2.substring(9);
        }
        WXLogUtils.e("reportJSException >>>> instanceId:" + str + ", exception function:" + str4 + ", exception:" + str3);
        WXErrorCode wXErrorCode = WXErrorCode.WX_ERR_JS_EXECUTE;
        WXErrorCode wXErrorCode2 = wXErrorCode;
        if (str != null) {
            WXSDKInstance sDKInstance2 = WXSDKManager.getInstance().getSDKInstance(str);
            wXErrorCode2 = wXErrorCode;
            if (sDKInstance2 != null) {
                sDKInstance2.setHasException(true);
                if (METHOD_CREATE_INSTANCE.equals(str4) || !sDKInstance2.isContentMd5Match()) {
                    try {
                        if (isSkipFrameworkInit(str) || !isJSFrameworkInit() || reInitCount <= 1 || reInitCount >= 10 || sDKInstance2.isNeedReLoad()) {
                            sDKInstance2.onRenderError(WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorCode(), WXErrorCode.WX_DEGRAD_ERR_INSTANCE_CREATE_FAILED.getErrorMsg() + ", reportJSException >>>> instanceId:" + str + ", exception function:" + str4 + ", exception:" + str3 + ", extInitTime:" + (System.currentTimeMillis() - sInitFrameWorkTimeOrigin) + "ms, extInitErrorMsg:" + sInitFrameWorkMsg.toString());
                            if (!WXEnvironment.sInAliWeex) {
                                WXExceptionUtils.commitCriticalExceptionRT(str, WXErrorCode.WX_RENDER_ERR_JS_CREATE_INSTANCE, str4, str3, null);
                                return;
                            }
                            return;
                        }
                        new ActionReloadPage(str, true).executeAction();
                        sDKInstance2.setNeedLoad(true);
                        return;
                    } catch (Exception e2) {
                        WXLogUtils.e(WXLogUtils.getStackTrace(e2));
                    }
                }
                if (METHOD_CREATE_INSTANCE.equals(str4) && !sDKInstance2.getApmForInstance().hasAddView) {
                    wXErrorCode = WXErrorCode.WX_RENDER_ERR_JS_CREATE_INSTANCE;
                } else if (METHOD_CREATE_INSTANCE_CONTEXT.equals(str4) && !sDKInstance2.getApmForInstance().hasAddView) {
                    wXErrorCode = WXErrorCode.WX_RENDER_ERR_JS_CREATE_INSTANCE_CONTEXT;
                } else if ((METHOD_UPDATE_COMPONENT_WITH_DATA.equals(str4) || METHOD_CREATE_PAGE_WITH_CONTENT.equals(str4) || METHOD_POST_TASK_TO_MSG_LOOP.equals(str4) || METHOD_JSFM_NOT_INIT_IN_EAGLE_MODE.equals(str4)) && !sDKInstance2.getApmForInstance().hasAddView) {
                    wXErrorCode = WXErrorCode.WX_DEGRAD_EAGLE_RENDER_ERROR;
                } else if (METHOD_CHECK_APPKEY.equals(str4)) {
                    wXErrorCode = WXErrorCode.WX_KEY_EXCEPTION_VALIDAPPKEY;
                }
                sDKInstance2.onJSException(wXErrorCode.getErrorCode(), str4, str3);
                wXErrorCode2 = wXErrorCode;
            }
        }
        doReportJSException(str, str4, wXErrorCode2, str3);
    }

    public void restart() {
        setJSFrameworkInit(false);
        WXModuleManager.resetAllModuleState();
        initWXBridge(WXEnvironment.sRemoteDebugMode);
        this.mWXBridge.resetWXBridge(WXEnvironment.sRemoteDebugMode);
    }

    public void sendMessageDelayed(Message message, long j2) {
        WXThread wXThread;
        if (message != null && this.mJSHandler != null && (wXThread = this.mJSThread) != null && wXThread.isWXThreadAlive() && this.mJSThread.getLooper() != null) {
            this.mJSHandler.sendMessageDelayed(message, j2);
        }
    }

    public void setDefaultRootSize(String str, float f2, float f3, boolean z2, boolean z3) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setDefaultHeightAndWidthIntoRootDom(str, f2, f3, z2, z3);
        }
    }

    public void setDeviceDisplay(String str, float f2, float f3, float f4) {
        post(new Runnable(this, str, f2, f3, f4) { // from class: com.taobao.weex.bridge.WXBridgeManager.28
            final WXBridgeManager this$0;
            final float val$deviceHeight;
            final float val$deviceWidth;
            final String val$instanceId;
            final float val$scale;

            {
                this.this$0 = r4;
                this.val$instanceId = r5;
                this.val$deviceWidth = r6;
                this.val$deviceHeight = r7;
                this.val$scale = r8;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.this$0.mWXBridge.setDeviceDisplay(this.val$instanceId, this.val$deviceWidth, this.val$deviceHeight, this.val$scale);
            }
        });
    }

    public void setDeviceDisplayOfPage(String str, float f2, float f3) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setDeviceDisplayOfPage(str, f2, f3);
        }
    }

    public void setFlexDirectionDef(String str) {
        if (isJSFrameworkInit()) {
            this.mWXBridge.setFlexDirectionDef(str);
        }
    }

    @Override // com.taobao.weex.utils.batch.BactchExecutor
    public void setInterceptor(Interceptor interceptor) {
        this.mInterceptor = interceptor;
    }

    public void setLogLevel(int i2, boolean z2) {
        post(new Runnable(this, i2, z2) { // from class: com.taobao.weex.bridge.WXBridgeManager.6
            final WXBridgeManager this$0;
            final boolean val$isPerf;
            final int val$level;

            {
                this.this$0 = r4;
                this.val$level = r5;
                this.val$isPerf = r6;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.mWXBridge != null) {
                    this.this$0.mWXBridge.setLogType((float) this.val$level, this.val$isPerf);
                }
            }
        });
    }

    public void setMargin(String str, String str2, CSSShorthand.EDGE edge, float f2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setMargin(str, str2, edge, f2);
        }
    }

    public void setPadding(String str, String str2, CSSShorthand.EDGE edge, float f2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setPadding(str, str2, edge, f2);
        }
    }

    public void setPageArgument(String str, String str2, String str3) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setPageArgument(str, str2, str3);
        }
    }

    public void setPosition(String str, String str2, CSSShorthand.EDGE edge, float f2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setPosition(str, str2, edge, f2);
        }
    }

    public void setRenderContentWrapContentToCore(boolean z2, String str) {
        if (isJSFrameworkInit()) {
            this.mWXBridge.setRenderContainerWrapContent(z2, str);
        }
    }

    public void setSandBoxContext(boolean z2) {
        if (z2 != isSandBoxContext) {
            isSandBoxContext = z2;
            if (isJSThread()) {
                setJSFrameworkInit(false);
                WXModuleManager.resetAllModuleState();
                initFramework(!isSandBoxContext ? WXFileUtils.loadAsset("main.js", WXEnvironment.getApplication()) : WXFileUtils.loadAsset("weex-main-jsfm.js", WXEnvironment.getApplication()));
                WXServiceManager.reload();
                WXModuleManager.reload();
                WXComponentRegistry.reload();
                return;
            }
            post(new Runnable(this) { // from class: com.taobao.weex.bridge.WXBridgeManager.3
                final WXBridgeManager this$0;

                {
                    this.this$0 = r4;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.setJSFrameworkInit(false);
                    WXModuleManager.resetAllModuleState();
                    this.this$0.initFramework(!WXBridgeManager.isSandBoxContext ? WXFileUtils.loadAsset("main.js", WXEnvironment.getApplication()) : WXFileUtils.loadAsset("weex-main-jsfm.js", WXEnvironment.getApplication()));
                    WXServiceManager.reload();
                    WXModuleManager.reload();
                    WXComponentRegistry.reload();
                }
            });
        }
    }

    public void setStackTopInstance(String str) {
        synchronized (this) {
            post(new Runnable(this, str) { // from class: com.taobao.weex.bridge.WXBridgeManager.5
                final WXBridgeManager this$0;
                final String val$instanceId;

                {
                    this.this$0 = r4;
                    this.val$instanceId = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mNextTickTasks.setStackTopInstance(this.val$instanceId);
                }
            }, str, null, null);
        }
    }

    public void setStyleHeight(String str, String str2, float f2) {
        setStyleHeight(str, str2, f2, false);
    }

    public void setStyleHeight(String str, String str2, float f2, boolean z2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setStyleHeight(str, str2, f2, z2);
        }
    }

    public void setStyleWidth(String str, String str2, float f2) {
        setStyleWidth(str, str2, f2, false);
    }

    public void setStyleWidth(String str, String str2, float f2, boolean z2) {
        if (isSkipFrameworkInit(str) || isJSFrameworkInit()) {
            this.mWXBridge.setStyleWidth(str, str2, f2, z2);
        }
    }

    public void setTimeout(String str, String str2) {
        Message obtain = Message.obtain();
        obtain.what = 1;
        TimerInfo timerInfo = new TimerInfo();
        timerInfo.callbackId = str;
        timerInfo.time = (long) Float.parseFloat(str2);
        obtain.obj = timerInfo;
        this.mJSHandler.sendMessageDelayed(obtain, timerInfo.time);
    }

    public void setUseSingleProcess(boolean z2) {
        if (z2 != isUseSingleProcess) {
            isUseSingleProcess = z2;
        }
    }

    public void setViewPortWidth(String str, float f2) {
        if (isJSFrameworkInit()) {
            this.mWXBridge.setViewPortWidth(str, f2);
        }
    }

    public boolean shouldReloadCurrentInstance(String str) {
        long currentTimeMillis = System.currentTimeMillis();
        IWXConfigAdapter wxConfigAdapter = WXSDKManager.getInstance().getWxConfigAdapter();
        String str2 = str;
        if (wxConfigAdapter != null) {
            boolean parseBoolean = Boolean.parseBoolean(wxConfigAdapter.getConfig("android_weex_ext_config", "check_biz_url", AbsoluteConst.TRUE));
            WXLogUtils.e("check_biz_url : " + parseBoolean);
            str2 = str;
            if (parseBoolean) {
                str2 = str;
                if (!TextUtils.isEmpty(str)) {
                    Uri parse = Uri.parse(str);
                    str2 = str;
                    if (parse != null) {
                        str2 = parse.buildUpon().clearQuery().build().toString();
                    }
                }
            }
        }
        String str3 = crashUrl;
        if (str3 == null || ((str3 != null && !str3.equals(str2)) || currentTimeMillis - lastCrashTime > 15000)) {
            crashUrl = str2;
            lastCrashTime = currentTimeMillis;
            return true;
        }
        lastCrashTime = currentTimeMillis;
        return false;
    }

    public void stopRemoteDebug() {
        Method method;
        if (this.mWxDebugProxy != null) {
            try {
                if (clazz_debugProxy == null) {
                    clazz_debugProxy = Class.forName("com.taobao.weex.devtools.debug.DebugServerProxy");
                }
                Class cls = clazz_debugProxy;
                if (cls != null && (method = cls.getMethod(Constants.Value.STOP, Boolean.TYPE)) != null) {
                    method.invoke(this.mWxDebugProxy, false);
                    this.mWxDebugProxy = null;
                }
            } catch (Throwable th) {
            }
        }
    }

    public EventResult syncCallJSEventWithResult(String str, String str2, List<Object> list, Object... objArr) {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        AnonymousClass10 r02 = new EventResult(this, countDownLatch) { // from class: com.taobao.weex.bridge.WXBridgeManager.10
            final WXBridgeManager this$0;
            final CountDownLatch val$waitLatch;

            {
                this.this$0 = r4;
                this.val$waitLatch = r5;
            }

            @Override // com.taobao.weex.bridge.EventResult
            public void onCallback(Object obj) {
                onCallback(obj);
                this.val$waitLatch.countDown();
            }
        };
        try {
            asyncCallJSEventWithResult(r02, str, str2, list, objArr);
            countDownLatch.await(100, TimeUnit.MILLISECONDS);
            return r02;
        } catch (Exception e2) {
            WXLogUtils.e("syncCallJSEventWithResult", e2);
            return r02;
        }
    }

    public String syncExecJsOnInstanceWithResult(String str, String str2, int i2) {
        CountDownLatch countDownLatch = new CountDownLatch(1);
        AnonymousClass8 r02 = new EventResult(this, countDownLatch) { // from class: com.taobao.weex.bridge.WXBridgeManager.8
            final WXBridgeManager this$0;
            final CountDownLatch val$waitLatch;

            {
                this.this$0 = r4;
                this.val$waitLatch = r5;
            }

            @Override // com.taobao.weex.bridge.EventResult
            public void onCallback(Object obj) {
                onCallback(obj);
                this.val$waitLatch.countDown();
            }
        };
        try {
            execJSOnInstance(r02, str, str2, i2);
            countDownLatch.await(100, TimeUnit.MILLISECONDS);
            return r02.getResult() != null ? r02.getResult().toString() : "";
        } catch (Throwable th) {
            WXLogUtils.e("syncCallExecJsOnInstance", th);
            return "";
        }
    }

    public void takeJSHeapSnapshot(String str) {
        Message obtainMessage = this.mJSHandler.obtainMessage();
        obtainMessage.obj = str;
        obtainMessage.what = 13;
        obtainMessage.setTarget(this.mJSHandler);
        obtainMessage.sendToTarget();
    }

    public void updateInitDeviceParams(String str, String str2, String str3, String str4) {
        if (isJSFrameworkInit()) {
            post(new Runnable(this, str) { // from class: com.taobao.weex.bridge.WXBridgeManager.29
                final WXBridgeManager this$0;
                final String val$width;

                {
                    this.this$0 = r4;
                    this.val$width = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mWXBridge.updateInitFrameworkParams(WXConfig.deviceWidth, this.val$width, WXConfig.deviceWidth);
                }
            });
            post(new Runnable(this, str2) { // from class: com.taobao.weex.bridge.WXBridgeManager.30
                final WXBridgeManager this$0;
                final String val$height;

                {
                    this.this$0 = r4;
                    this.val$height = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mWXBridge.updateInitFrameworkParams(WXConfig.deviceHeight, this.val$height, WXConfig.deviceHeight);
                }
            });
            post(new Runnable(this, str3) { // from class: com.taobao.weex.bridge.WXBridgeManager.31
                final WXBridgeManager this$0;
                final String val$density;

                {
                    this.this$0 = r4;
                    this.val$density = r5;
                }

                @Override // java.lang.Runnable
                public void run() {
                    this.this$0.mWXBridge.updateInitFrameworkParams("scale", this.val$density, "scale");
                }
            });
            if (str4 != null) {
                post(new Runnable(this, str4) { // from class: com.taobao.weex.bridge.WXBridgeManager.32
                    final WXBridgeManager this$0;
                    final String val$statusHeight;

                    {
                        this.this$0 = r4;
                        this.val$statusHeight = r5;
                    }

                    @Override // java.lang.Runnable
                    public void run() {
                        this.this$0.mWXBridge.updateInitFrameworkParams(WXConfig.androidStatusBarHeight, this.val$statusHeight, WXConfig.androidStatusBarHeight);
                    }
                });
            }
        }
    }

    public boolean verifyClientKeyPayload(String str, String str2, String str3) {
        IWXBridge iWXBridge = this.mWXBridge;
        if (iWXBridge instanceof WXBridge) {
            return ((WXBridge) iWXBridge).verifyClientKeyPayload(str, str2, str3);
        }
        return false;
    }
}
