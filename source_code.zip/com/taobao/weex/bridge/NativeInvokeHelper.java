package com.taobao.weex.bridge;

import android.util.Log;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.taobao.weex.WXSDKInstance;
import com.taobao.weex.WXSDKManager;
import com.taobao.weex.bridge.SimpleJSCallback;
import com.taobao.weex.performance.WXAnalyzerDataTransfer;
import com.taobao.weex.utils.WXLogUtils;
import com.taobao.weex.utils.WXReflectionUtils;
import io.dcloud.feature.uniapp.bridge.UniJSCallback;
import java.lang.reflect.Type;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/NativeInvokeHelper.class */
public class NativeInvokeHelper {
    private String mInstanceId;

    public NativeInvokeHelper(String str) {
        this.mInstanceId = str;
    }

    public Object invoke(Object obj, Invoker invoker, JSONArray jSONArray) throws Exception {
        Object[] prepareArguments = prepareArguments(invoker.getParameterTypes(), jSONArray);
        if (WXAnalyzerDataTransfer.isInteractionLogOpen() && (invoker instanceof MethodInvoker)) {
            int i2 = 0;
            while (true) {
                if (i2 >= prepareArguments.length) {
                    break;
                }
                Object obj2 = prepareArguments[i2];
                if (obj2 instanceof SimpleJSCallback) {
                    String callbackId = ((SimpleJSCallback) obj2).getCallbackId();
                    MethodInvoker methodInvoker = (MethodInvoker) invoker;
                    Log.d(WXAnalyzerDataTransfer.INTERACTION_TAG, "[client][callNativeModuleStart]," + this.mInstanceId + "," + methodInvoker.mMethod.getDeclaringClass() + "," + methodInvoker.mMethod.getName() + "," + callbackId);
                    ((SimpleJSCallback) prepareArguments[i2]).setInvokerCallback(new SimpleJSCallback.InvokerCallback(this, invoker, callbackId) { // from class: com.taobao.weex.bridge.NativeInvokeHelper.1
                        final NativeInvokeHelper this$0;
                        final String val$callBackId;
                        final Invoker val$invoker;

                        /* JADX WARN: Incorrect args count in method signature: ()V */
                        {
                            this.this$0 = r4;
                            this.val$invoker = r5;
                            this.val$callBackId = r6;
                        }

                        @Override // com.taobao.weex.bridge.SimpleJSCallback.InvokerCallback
                        public void onInvokeSuccess() {
                            Log.d(WXAnalyzerDataTransfer.INTERACTION_TAG, "[client][callNativeModuleEnd]," + this.this$0.mInstanceId + "," + ((MethodInvoker) this.val$invoker).mMethod.getDeclaringClass() + "," + ((MethodInvoker) this.val$invoker).mMethod.getName() + "," + this.val$callBackId);
                        }
                    });
                    break;
                }
                i2++;
            }
        }
        if (!invoker.isRunOnUIThread()) {
            return invoker.invoke(obj, prepareArguments);
        }
        WXSDKManager.getInstance().postOnUiThread(new Runnable(this, invoker, obj, prepareArguments) { // from class: com.taobao.weex.bridge.NativeInvokeHelper.2
            final NativeInvokeHelper this$0;
            final Invoker val$invoker;
            final Object[] val$params;
            final Object val$target;

            /* JADX WARN: Incorrect args count in method signature: ()V */
            {
                this.this$0 = r4;
                this.val$invoker = r5;
                this.val$target = r6;
                this.val$params = r7;
            }

            @Override // java.lang.Runnable
            public void run() {
                if (this.val$invoker != null) {
                    try {
                        WXSDKInstance sDKInstance = WXSDKManager.getInstance().getSDKInstance(this.this$0.mInstanceId);
                        if (sDKInstance != null && !sDKInstance.isDestroy()) {
                            this.val$invoker.invoke(this.val$target, this.val$params);
                        }
                    } catch (Exception e2) {
                        WXLogUtils.e("NativeInvokeHelper", this.val$target + " Invoker " + this.val$invoker.toString() + " exception:" + e2);
                    }
                }
            }
        }, 0);
        return null;
    }

    protected Object[] prepareArguments(Type[] typeArr, JSONArray jSONArray) throws Exception {
        Object[] objArr = new Object[typeArr.length];
        for (int i2 = 0; i2 < typeArr.length; i2++) {
            Type type = typeArr[i2];
            if (i2 < jSONArray.size()) {
                Object obj = jSONArray.get(i2);
                if (type == JSONObject.class) {
                    if ((obj instanceof JSONObject) || obj == null) {
                        objArr[i2] = obj;
                    } else if (obj instanceof String) {
                        objArr[i2] = JSON.parseObject(obj.toString());
                    }
                } else if (JSCallback.class != type && UniJSCallback.class != type) {
                    objArr[i2] = WXReflectionUtils.parseArgument(type, obj);
                } else if (obj instanceof String) {
                    objArr[i2] = new SimpleJSCallback(this.mInstanceId, (String) obj);
                } else {
                    throw new Exception("Parameter type not match.");
                }
            } else if (!type.getClass().isPrimitive()) {
                objArr[i2] = null;
            } else {
                throw new Exception("[prepareArguments] method argument list not match.");
            }
        }
        return objArr;
    }
}
