package com.taobao.weex.bridge;

import com.taobao.weex.common.WXModule;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/ModuleFactory.class */
public interface ModuleFactory<T extends WXModule> extends JavascriptInvokable {
    T buildInstance() throws IllegalAccessException, InstantiationException;
}
