package com.taobao.weex.bridge;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/ModuleFactoryImpl.class */
public class ModuleFactoryImpl {
    public boolean hasRigster;
    public ModuleFactory mFactory;

    public ModuleFactoryImpl(ModuleFactory moduleFactory) {
        this.hasRigster = false;
        this.mFactory = moduleFactory;
    }

    public ModuleFactoryImpl(ModuleFactory moduleFactory, boolean z2) {
        this.mFactory = moduleFactory;
        this.hasRigster = z2;
    }
}
