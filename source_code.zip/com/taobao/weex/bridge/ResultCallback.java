package com.taobao.weex.bridge;
/* loaded from: Coinglobal1.jar:com/taobao/weex/bridge/ResultCallback.class */
public interface ResultCallback<T> {
    void onReceiveResult(T t2);
}
