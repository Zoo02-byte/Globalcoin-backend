package com.taobao.weex;
@Deprecated
/* loaded from: Coinglobal1.jar:com/taobao/weex/IWXActivityStateListener.class */
public interface IWXActivityStateListener {
    boolean onActivityBack();

    void onActivityCreate();

    void onActivityDestroy();

    void onActivityPause();

    void onActivityResume();

    void onActivityStart();

    void onActivityStop();
}
