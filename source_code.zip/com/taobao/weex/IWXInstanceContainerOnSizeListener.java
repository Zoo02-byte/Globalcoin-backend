package com.taobao.weex;
/* loaded from: Coinglobal1.jar:com/taobao/weex/IWXInstanceContainerOnSizeListener.class */
public interface IWXInstanceContainerOnSizeListener {
    void onSizeChanged(String str, float f2, float f3, boolean z2, boolean z3);
}
